package com.cognizant.pace.datalayer;

import org.hibernate.Session;
import com.cognizant.pace.model.OPBusinessScenario;
import com.cognizant.pace.serviceobject.NFRAddServiceObject;

import java.util.List;

public class BusinessScenarioManager {

	public BusinessScenarioManager() {
		
	}

	    public void createAndStoreEvent(NFRAddServiceObject poServiceObject) throws Exception{
	        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
	        session.beginTransaction();
	 
	        OPBusinessScenario busScenario = new OPBusinessScenario();
	        busScenario.setName(poServiceObject.getName());
	        busScenario.setBusareaid(poServiceObject.getForKey());
	        busScenario.setScenariotime(poServiceObject.getResptime());
	        busScenario.setThroughput(poServiceObject.getThroughput());
	 
	        session.save(busScenario);
	 
	        session.getTransaction().commit();
	    }
	 
	    public List listBusScenarios(Integer poBusAreaId) {
	        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
	        session.beginTransaction();
	        List result = session.createQuery("from OPBusinessScenario where busareaid="+poBusAreaId.intValue()).list();
	        session.getTransaction().commit();
	        return result;
	    }
}
	
