package com.cognizant.pace.servicelayer;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cognizant.pace.datalayer.*;
import com.cognizant.pace.serviceobject.*;
import com.fasterxml.jackson.databind.ObjectMapper;
@SpringBootApplication
@RestController
@EnableAutoConfiguration
public class NfrServicesApplication {
	

	@CrossOrigin(origins = "*") 
	@RequestMapping(value = "/add", method = RequestMethod.POST, consumes="application/json")
	 void add(@RequestBody NFRAddServiceObject poNFRAddService) {
		 try {
			 System.out.println(poNFRAddService.getName());
			 System.out.println(poNFRAddService.getType());
			 ObjectMapper loMapper = new ObjectMapper();
			 //loMapper.readValues(poNFRAddService, NFRAddServiceObject.class);
			 if (poNFRAddService.getType().equals("domain"))
	{
	 DomainManager loDomManager = new DomainManager();
	 loDomManager.createAndStoreEvent(poNFRAddService.getName());
		 
	 }
	else if(poNFRAddService.getType().equalsIgnoreCase("businessarea"))
	{
		 BusinessAreaManager loBusAreaManager = new BusinessAreaManager();
		 loBusAreaManager.createAndStoreEvent(poNFRAddService.getName(), poNFRAddService.getForKey());
		 //return "I have added busarea";
	}
	else if(poNFRAddService.getType().equals("businessscenario"))
	{
		BusinessScenarioManager loBusScenarioManager = new BusinessScenarioManager();
		loBusScenarioManager.createAndStoreEvent(poNFRAddService);
		
	}
	else if(poNFRAddService.getType().equals("businesstransaction"))
	{
		BusinessTransactionManager loBusTransMgr = new BusinessTransactionManager();
		loBusTransMgr.createAndStoreEvent(poNFRAddService);
	}
	
		 }catch(Exception ex)
		 {ex.printStackTrace();
		 //return "failure";
		 }
	 }

	 
	
	/**
	@CrossOrigin(origins = "*") 
	@RequestMapping("/add")
	 void add(@RequestParam(value="name", defaultValue="World") String name,@RequestParam(value="type", defaultValue="domain") String type,
			 @RequestParam(value="domainid", required=false) Integer busDomId) {
		 try {
		 if (type.equals("domain"))
	{
	 DomainManager loDomManager = new DomainManager();
	 loDomManager.createAndStoreEvent(name);
		 
	 }
	else if(type.equalsIgnoreCase("businessarea"))
	{
		 BusinessAreaManager loBusAreaManager = new BusinessAreaManager();
		 loBusAreaManager.createAndStoreEvent(name, busDomId);
		 //return "I have added busarea";
	}
	else 
	{
		return "failure";
	}
		 }catch(Exception ex)
		 {ex.printStackTrace();
		 //return "failure";
		 }
	 }

	
	**/
	
	 
	@CrossOrigin(origins = "*")
	 @RequestMapping("/list")
	 List list(@RequestParam(value="type") String name,
			 @RequestParam(value="forKey", required=false) Integer forKeyId)  {
	 if (name.equals("domain")) {
		 System.out.println("inside domain List");
	 DomainManager loDomManager = new DomainManager();
	 return loDomManager.listDomains();
	 } else if (name.equals("businessarea")){
		 System.out.println("Here I am businessarea "+name);
		 BusinessAreaManager loBusAreaManager = new BusinessAreaManager();
		 return loBusAreaManager.listBusAreas(forKeyId);
	 } else if (name.equals("businessscenario")) {
	  System.out.println("Here I am businessscenario "+name);
		 BusinessScenarioManager loBusScenarioManager = new BusinessScenarioManager();
		 return loBusScenarioManager.listBusScenarios(forKeyId);
	 } else //if(name.equals("businesstransaction")) {
		  {System.out.println("Here I am businesstransaction "+name);
		  BusinessTransactionManager loBusTransMgr = new BusinessTransactionManager();
		  return loBusTransMgr.listBusTransactions(forKeyId);
	 }
	 }

	 
	 
	 
	public static void main(String[] args) {
		SpringApplication.run(NfrServicesApplication.class, args);
	}
}
