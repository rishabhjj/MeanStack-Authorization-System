package com.cognizant.pace.model;

public class OPDomain implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	private Integer id;
	private String domainName;
	
	public OPDomain() {
		
	}
	public OPDomain(String poDomainName) {
		this.domainName = poDomainName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}


}
