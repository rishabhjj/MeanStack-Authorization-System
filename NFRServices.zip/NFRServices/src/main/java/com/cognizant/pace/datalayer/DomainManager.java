package com.cognizant.pace.datalayer;
import org.hibernate.Session;
import com.cognizant.pace.model.OPDomain;
import java.util.List;

public class DomainManager {

	 /*public static void main(String[] args) throws Exception{
	        DomainManager mgr = new DomainManager();
	 
	        mgr.createAndStoreEvent("Bank");
	 

	        List domains = mgr.listDomains();
	        for (int i = 0; i < domains.size(); i++) {
	        	OPDomain domain = (OPDomain) domains.get(i);
	            System.out.println(
	                    "Event: " + domain.getDomainName());
	        }
	 
	        HibernateUtil.getSessionFactory().close();
	    }
	 */
	    public void createAndStoreEvent(String poDomainName) {
	        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
	        session.beginTransaction();
	 
	        OPDomain domain = new OPDomain(poDomainName);
	 
	        session.save(domain);
	 
	        session.getTransaction().commit();
	    }
	 
	    public List listDomains() {
	        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
	        session.beginTransaction();
	        List result = session.createQuery("from OPDomain").list();
	        session.getTransaction().commit();
	        return result;
	    }
}
