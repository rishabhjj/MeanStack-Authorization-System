import { Component, OnInit ,ElementRef} from '@angular/core';
import {Router} from '@angular/router';
import {GetPostService} from '../../services/get-post.service';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {
 comp:string;
  state:any;
  param1:any;
  param2:any;
  query_param:any;
  value:any;
  img :File;
t: File;
  constructor(private router:Router, private _getpost:GetPostService, private ele: ElementRef ) { }

  ngOnInit() {
console.log("testing");
    var keys = Object.keys(localStorage),
    j = keys.length;
    console.log(j + "gjkhbjk");
    console.log(keys);
if(j==1)
  {
    this.state = 0;
  }

    for(var i = j-2;i>=0;i--) {


      
      if(keys[i]=='bt-home'){
        console.log("entery");
        this.comp = 'bt';
        this.value = localStorage.getItem(keys[i]);
        var a2 = this.value.split('/');
        console.log(a2);
        this.param1 = a2[5];
        a3=a2[6].split('?');
        this.param2 = a3[0];
        a4 = a3[1].split('=');
        this.query_param = a4[1];
        // http://localhost:4200/nfr/bt/24/101?bsname=op
        this.state=3; 
        break;
      }

      else if(keys[i]=='bs-home'){
        this.comp = 'bs-home';
        this.value = localStorage.getItem(keys[i]);
        var a2 = this.value.split('/');
        var a3 = a2[5].split('?');
        var a4 = a3[1].split('=');
        var an = a4[1].replace("%20", " ");
        this.param1=a3[0];
        this.query_param = a4[1];
        this.state = 2;
        break;
      }
      else if(keys[i]=='ba-home'){
        this.comp = 'ba-home';
        this.value = localStorage.getItem(keys[i]);
        var a2 = this.value.split('/');
        var a3 = a2[5].split('?');
        var a4 = a3[1].split('=');
        var an = a4[1].replace("%20", " ");
        this.param1=a3[0];
        this.query_param = a4[1];
        this.state = 1;
        break;

      }
     
  }

}
cancel(){
  if(this.state==0)
    {
      this.router.navigate(['/']);
    }
    else if(this.state==1)
      {
        this.router.navigate(['/ba-home',this.param1],{queryParams:{dname:this.query_param}});
      }
      else if(this.state==2)
        {
          this.router.navigate(['/bs-home',this.param1],{queryParams:{baname:this.query_param}});
        }
        else if(this.state==3)
          {
            this.router.navigate(['/bt',this.param1,this.param2],{queryParams:{bsname:this.query_param}});
          }
}

onRegisterSubmit1(){
  console.log("form submitted");

  let files =this.ele.nativeElement.querySelector('#img').files;
  let file = files[0];
  this._getpost.upload(file).subscribe(
    
    );
 if(this.state==0)
    {
      setTimeout(() => 
      {
        this.router.navigate(['/']);
      },
      4000);
      //this.router.navigate(['/']);
    }
    else if(this.state==1)
      {
        setTimeout(() => 
        {
          this.router.navigate(['/ba-home',this.param1],{queryParams:{dname:this.query_param}});
        },
        4000);

       // this.router.navigate(['/ba-home',this.param1],{queryParams:{dname:this.query_param}});
      }
      else if(this.state==2)
        {
          setTimeout(() => 
          {
            this.router.navigate(['/bs-home',this.param1],{queryParams:{baname:this.query_param}});
          },
          4000);
          
        }
        else if(this.state==3)
          {
            setTimeout(() => 
            {
              this.router.navigate(['/bt',this.param1,this.param2],{queryParams:{bsname:this.query_param}});
            },
            4000);
            
          }


    console.log("working niow");
}

}
