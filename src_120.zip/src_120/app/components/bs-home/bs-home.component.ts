import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {GetPostService} from '../../services/get-post.service';
import * as _ from "lodash";
@Component({
  selector: 'app-bs-home',
  templateUrl: './bs-home.component.html',
  styleUrls: ['./bs-home.component.css']
})
export class BsHomeComponent implements OnInit {
  address = [];
  value:any;
  st1 = true;
  st = [];
  dd:any;
  forKey: number;
  private sub: any;
  domain: any;
  color =[];
  myArray = ['#5cc0c0', '#376999', '#d9b859','#83b640','#57c7f7'];
  state:boolean=false;
  constructor(private route: ActivatedRoute,private _getpost:GetPostService,private router:Router) { 
    _getpost.showMenuEvent.subscribe(
      (showMenu) => {
        this.state = !this.state;
      }
   );
 
  }
  ngOnInit() {  
    localStorage.removeItem('bt-home');
    localStorage.setItem("bs-home",window.location.href);
    this.sub = this.route.params.subscribe(params => {
      this.forKey = +params['id']; // (+) converts string 'id' to a number
      
       });
       this.sub = this.route.queryParams.subscribe(params => {
        this.domain = params['baname']; // (+) converts string 'id' to a numbe
         });

         localStorage.setItem("2",this.domain);
         localStorage.removeItem('3');
       console.log(this.forKey);

    //  console.log(this.forKey);
     
            this._getpost.getBs("businessscenario",this.forKey).subscribe(data => {
             console.log(data);
             this.dd = data;
             this.address = _.chunk(this.dd,3);
             console.log(this.address);
             for(var i = 0;i<this.dd.length;i++)
              { 
                if(i<=4)
                  this.color.push(this.myArray[i]);
                    else{
                      i=0;
                      this.dd.length = this.dd.length - 5;
                      this.color.push(this.myArray[i]);
                    }
              }
              for(var i = 0;i<this.dd.length;i++) {
                this.st.push('true');
              }
              console.log(this.color);
              console.log(this.color);
            },
             error => {
               console.log(error);
             })
  }

  onchk(id){
    console.log("Debuydd");
    console.log(id);
  this._getpost.delBs("businessscenario",id).subscribe(data => {
    this.dd = data;},
    error => {
      console.log(error);
    });
    this.value = localStorage.getItem('bs-home');
    var a2 = this.value.split('/');
    console.log(a2);
    var a3 = a2[5].split('?');
    var a4 = a3[1].split('=');
    console.log(a3);
    var roui = a2[4];
    var id = a3[0];
    var quer=a4[1];
   // this.router.navigate(['/ba-home']);
   //window.location.reload();
   console.log(id + "teshn;lk" + quer);
   setTimeout(() => 
   {
    this.router.navigate(['bs-home' , id],{queryParams:{baname:quer}});
   },
   2000);
   
   console.log("done");
  }
  getRandomColor() {
    var letters = '0123456789ABCDEF';
  
    var myArray = ['006400', 'FFD700', '800000','000080','00008B'];
    var color = '#';
      color += myArray[Math.floor(Math.random() * myArray.length)];
    
    return color;
  }
  chk(x:any)
  {
    this.st[x] = !this.st[x];
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }
}
