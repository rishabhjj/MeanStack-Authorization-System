import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {GetPostService} from '../../services/get-post.service';
import * as _ from "lodash";
@Component({
  selector: 'app-bussiness-area-home',
  templateUrl: './bussiness-area-home.component.html',
  styleUrls: ['./bussiness-area-home.component.css']
})
export class BussinessAreaHomeComponent implements OnInit {
  forKey: number;
  st = [];
  value:any;
  st1= true;
  private sub: any;
  myArray = ['#5cc0c0', '#376999', '#d9b859','#83b640','#57c7f7'];
  state:boolean=false;
  constructor(private route: ActivatedRoute,private _getpost: GetPostService,private router:Router) { 
    _getpost.showMenuEvent.subscribe(
      (showMenu) => {
        this.state = !this.state;
      }
   );
 
  }
  address = [];
  dd:any;
  color =[];
  domain: any;
  ngOnInit() {

    localStorage.removeItem('bt-home');
    localStorage.removeItem('bs-home');
    localStorage.setItem("ba-home",window.location.href);
    this.sub = this.route.params.subscribe(params => {
      this.forKey = +params['id']; // (+) converts string 'id' to a number
      
       });
       console.log(this.forKey);
       this.sub = this.route.queryParams.subscribe(params => {
        this.domain = params['dname']; // (+) converts string 'id' to a number
         });
         localStorage.setItem("1",this.domain);
         localStorage.removeItem('2');
         localStorage.removeItem('3');

       this._getpost.getBa("businessarea",this.forKey).subscribe(data => {
        console.log(data);
        this.dd = data;
        this.address = _.chunk(this.dd,3);
        console.log(this.address);
        for(var i = 0;i<this.dd.length;i++)
          { 
            if(i<=4)
              this.color.push(this.myArray[i]);
                else{
                  i=0;
                  this.dd.length = this.dd.length - 5;
                  this.color.push(this.myArray[i]);
                }
          }
          for(var i = 0;i<this.dd.length;i++) {
            this.st.push('true');
          }
          console.log(this.color);
       },
        error => {
          console.log(error);
        })
      
  }
  onchk(id){
    console.log(id);
  this._getpost.delBa("businessarea",id).subscribe(data => {
    this.dd = data;},
    error => {
      console.log(error);
    });
  
    this.value = localStorage.getItem('ba-home');
    var a2 = this.value.split('/');
    console.log(a2);
    var a3 = a2[5].split('?');
    var a4 = a3[1].split('=');
    console.log(a3);
    var roui = a2[4];
    var id = a3[0];
    var quer=a4[1];
   // this.router.navigate(['/ba-home']);
   setTimeout(() => 
   {
    this.router.navigate(['ba-home' ,id],{queryParams:{dname:quer}});
   },
   2000);
   console.log(roui + id + "teshn;lk" + quer);
  //window.location.reload();
    
    console.log("done");
  }
  getRandomColor() {
    var letters = '0123456789ABCDEF';
  
    var myArray = ['006400', 'FFD700', '800000','000080','00008B'];
    var color = '#';
      color += myArray[Math.floor(Math.random() * myArray.length)];
    
    return color;
  }
  chk(x: any)
  {
    this.st[x] = !this.st[x];
  }
  ngOnDestroy() {
     this.sub.unsubscribe();
   }
}
