import { Injectable } from '@angular/core';
import {Http, Headers,Response} from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/map';

@Injectable()
export class GetPostService {
  user:any;

  constructor(private http:Http) { }

  addDomain(user)
  {let headers = new Headers();
    headers.append('Content-type','application/json');
    return this.http.post('http://localhost:5555/posts', user,{headers: headers})
    .map(res => res.json());

  }

  // getDomain()
  // {

  //   return this.http.get('../assets/c.json')
  //   .map((response : Response) => {response.json()});


  // }
  
  getDomain(){
    return this.http.get('http://localhost:5555/posts').map(res => res.json());
   // .map((response : Response) => response.json());

  }
  getBa(){
    return this.http.get('http://localhost:5555/profile').map(res => res.json());
   // .map((response : Response) => response.json());

  }
}
