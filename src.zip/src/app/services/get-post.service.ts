import { Injectable } from '@angular/core';
import {Http, Headers,Response} from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/map';
import { URLSearchParams } from '@angular/http';

@Injectable()
export class GetPostService {
  user:any;

  constructor(private http:Http) { }

//   addDomain(type:any,name:any){
// // {  var headers = new Headers();
// //   headers.append('Content-Type', 'multipart/form-data');
//     let formData: FormData = new FormData(); 
//     formData.append('type', type); 
//     formData.append('name', name);
//     // return this.http.post('http://LT074407:8080/add', JSON.stringify({"type":"type",
//     //   "name": "name"}))
//     // .map(res => res.json());

//     return this.http.post('http://LT074407:8080/add',formData).map((response: Response)=>{
//     return response;});

//   }


addDomain(type:any,name:any){
  var headers = new Headers();
    headers.append('Content-Type', 'application/json');
  return this.http.post('http://LT074407:8080/add', JSON.stringify({"type":type,
      "name": name}),{headers:headers})
    .map((response: Response)=>{
         return response;});
}

  getDomain(test){
    
    let formData: FormData = new FormData(); 
    formData.append('type', test);
    return this.http.post('http://LT074407:8080/list',formData).map(res => res.json());

  }
  getBa(type:any,domainid:any){
    let formData: FormData = new FormData(); 
    formData.append('type', type); 
    formData.append('forKey', domainid);
    return this.http.post('http://LT074407:8080/list',formData).map(res => res.json());
  }

  addBa(type:any,name:any,id:any){
    var headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('http://LT074407:8080/add', JSON.stringify({"type":type,
    "name": name,"forKey": id}),{headers:headers})
  .map((response: Response)=>{
       return response;});
  }

}
