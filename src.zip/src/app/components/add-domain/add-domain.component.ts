import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {Router} from '@angular/router';
import {GetPostService} from '../../services/get-post.service';


@Component({
  selector: 'app-add-domain',
  templateUrl: './add-domain.component.html',
  styleUrls: ['./add-domain.component.css']
})
export class AddDomainComponent implements OnInit {
domain : String;
  constructor(private _getpost:GetPostService,
              private router:Router) { }

  ngOnInit() {
  }
  onRegisterSubmit(){
    console.log("Form Submitted");

    const user = {
      domain: this.domain
    }
    
    console.log(user);
    this._getpost.addDomain(user).subscribe(
      );
      this.router.navigate(['/']);
  }
}
