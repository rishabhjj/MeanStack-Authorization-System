import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {Router} from '@angular/router';
import {GetPostService} from '../../services/get-post.service';
import { FlashMessagesModule, FlashMessagesService } from 'angular2-flash-messages';

@Component({
  selector: 'app-add-domain',
  templateUrl: './add-domain.component.html',
  styleUrls: ['./add-domain.component.css']
})
export class AddDomainComponent implements OnInit {
name : any;
  constructor(private _getpost:GetPostService,
              private router:Router,
              private flashMessage:FlashMessagesService) { }

  ngOnInit() {
  }
  onRegisterSubmit1(){
    console.log("Form Submitted");
    const type="domain";
    
    const  name= this.name
    
      console.log(name);
    
    this._getpost.addDomain("domain",name).subscribe(
      
      );
      //this.flashMessage.show('You are now registerd and can login now', {cssClass: 'alert-success', timeout:3000});
      this.router.navigate(['/']);
  }
}
