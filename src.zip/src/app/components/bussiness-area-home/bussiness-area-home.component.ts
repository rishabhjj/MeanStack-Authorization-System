import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {GetPostService} from '../../services/get-post.service';
import * as _ from "lodash";
@Component({
  selector: 'app-bussiness-area-home',
  templateUrl: './bussiness-area-home.component.html',
  styleUrls: ['./bussiness-area-home.component.css']
})
export class BussinessAreaHomeComponent implements OnInit {
  id: number;
  private sub: any;
  constructor(private route: ActivatedRoute,private _getpost:GetPostService) { }
  address = [];
  dd:any;
  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.id = +params['id']; // (+) converts string 'id' to a number
      this._getpost.getBa().subscribe(data => {
        console.log(data);
        this.dd = data;
        this.address = _.chunk(this.dd[0].domain,3);
        // this.address = _.chunk(this.dd,3);
        console.log(this.address);
        
       },
        error => {
          console.log(error)
        })
      // In a real app: dispatch action to load the details here.
   });
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }
}
