import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {GetPostService} from '../../services/get-post.service';
import * as _ from "lodash";
@Component({
  selector: 'app-bussiness-area-home',
  templateUrl: './bussiness-area-home.component.html',
  styleUrls: ['./bussiness-area-home.component.css']
})
export class BussinessAreaHomeComponent implements OnInit {
  forKey: number;
  private sub: any;
  myArray = ['#209e91', '#2dacd1', '#90b900','#dfb81c','#e85656'];
  state:boolean=false;
  constructor(private route: ActivatedRoute,private _getpost: GetPostService) { 
    _getpost.showMenuEvent.subscribe(
      (showMenu) => {
        this.state = !this.state;
      }
   );
 
  }
  address = [];
  dd:any;
  color =[];
  domain: any;
  ngOnInit() {

    localStorage.removeItem('bt-home');
    localStorage.removeItem('bs-home');
    localStorage.setItem("ba-home",window.location.href);
    this.sub = this.route.params.subscribe(params => {
      this.forKey = +params['id']; // (+) converts string 'id' to a number
      
       });
       console.log(this.forKey);
       this.sub = this.route.queryParams.subscribe(params => {
        this.domain = params['dname']; // (+) converts string 'id' to a number
         });
         localStorage.setItem("1",this.domain);
         localStorage.removeItem('2');
         localStorage.removeItem('3');

       this._getpost.getBa("businessarea",this.forKey).subscribe(data => {
        console.log(data);
        this.dd = data;
        this.address = _.chunk(this.dd,3);
        console.log(this.address);
        for(var i = 0;i<this.dd.length;i++)
          { 
            if(i<=4)
              this.color.push(this.myArray[i]);
                else{
                  i=0;
                  this.dd.length = this.dd.length - 5;
                  this.color.push(this.myArray[i]);
                }
          }
          console.log(this.color);
       },
        error => {
          console.log(error);
        })
      
  }
  getRandomColor() {
    var letters = '0123456789ABCDEF';
  
    var myArray = ['006400', 'FFD700', '800000','000080','00008B'];
    var color = '#';
      color += myArray[Math.floor(Math.random() * myArray.length)];
    
    return color;
  }
  ngOnDestroy() {
     this.sub.unsubscribe();
   }
}
