import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-bussiness-area-home',
  templateUrl: './bussiness-area-home.component.html',
  styleUrls: ['./bussiness-area-home.component.css']
})
export class BussinessAreaHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
