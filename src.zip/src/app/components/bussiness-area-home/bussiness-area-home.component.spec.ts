import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BussinessAreaHomeComponent } from './bussiness-area-home.component';

describe('BussinessAreaHomeComponent', () => {
  let component: BussinessAreaHomeComponent;
  let fixture: ComponentFixture<BussinessAreaHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BussinessAreaHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BussinessAreaHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
