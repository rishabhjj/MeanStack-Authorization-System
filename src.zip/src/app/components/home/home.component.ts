import { Component, OnInit } from '@angular/core';
import * as _ from "lodash";
import {Router} from '@angular/router';
import {GetPostService} from '../../services/get-post.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  dd : any;
  data= [];
  address = [];
  constructor(private _getpost:GetPostService) { }
  
  ngOnInit() {
//    console.log("test");
//     this._getpost.getDomain().subscribe(dd => this.dd = dd);
//     this.data = _.chunk(this.dd,3);
//     console.log("test");
//   // }
// console.log("test" + this.dd);

this._getpost.getAddress()
.subscribe(resAdressData => this.address = resAdressData);
console.log(this.address);
console.log("Test");
}}
