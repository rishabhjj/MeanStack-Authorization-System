import { Component, OnInit } from '@angular/core';
import * as _ from "lodash";
import {Router} from '@angular/router';
import {GetPostService} from '../../services/get-post.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  data =[];
  dd =[];
  // data= _.chunk([
  //   {
  //     "id": "1",
  //     "domain":"LifeSciencee"
  //   },
  //   {
  //     "id": "2",
  //     "domain":"LifeSciencee1"

  //   },
  //   {"id": "3",
  //   "domain":"LifeSciencee12"},
  //   {"id": "4",
  //   "domain":"LifeSciencee13"},
  //   {"id": "5",
  //   "domain":"LifeSciencee187"}
  // ],3);
  address = [];
  constructor(private _getpost:GetPostService) { }
  color: any;
  color1: any;
  ngOnInit() {
//    console.log("test");
 this._getpost.getDomain().subscribe(data => {
  console.log(data);
  this.dd = data;
  this.address = _.chunk(this.dd,3);
  console.log(this.address);
  
 },
  error => {
    console.log(error);
  })


  this.color1 = this.getRandomColor();
  console.log(this.color1);
 
}    
 getRandomColor() {
  var letters = '0123456789ABCDEF';
  var color = '#';
  for (var i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}

}

