import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bt',
  templateUrl: './bt.component.html',
  styleUrls: ['./bt.component.css']
})
export class BtComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
