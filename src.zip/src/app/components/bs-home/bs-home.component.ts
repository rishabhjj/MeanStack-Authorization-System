import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {GetPostService} from '../../services/get-post.service';
import * as _ from "lodash";
@Component({
  selector: 'app-bs-home',
  templateUrl: './bs-home.component.html',
  styleUrls: ['./bs-home.component.css']
})
export class BsHomeComponent implements OnInit {
  address = [];
  dd:any;
  forKey: number;
  private sub: any;
  
  color =[];
  constructor(private route: ActivatedRoute,private _getpost:GetPostService) { }

  ngOnInit() {  
    this.sub = this.route.params.subscribe(params => {
      this.forKey = +params['id']; // (+) converts string 'id' to a number
      
       });
       console.log(this.forKey);

    //  console.log(this.forKey);
     
            this._getpost.getBs("businessscenario",this.forKey).subscribe(data => {
             console.log(data);
             this.dd = data;
             this.address = _.chunk(this.dd,3);
             console.log(this.address);
             for(var i = 0;i<this.dd.length;i++)
              { 
              this.color.push(this.getRandomColor());
              }
              console.log(this.color);
            },
             error => {
               console.log(error);
             })
  }
  getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }
}
