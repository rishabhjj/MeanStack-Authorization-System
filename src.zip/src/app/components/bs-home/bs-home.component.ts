import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bs-home',
  templateUrl: './bs-home.component.html',
  styleUrls: ['./bs-home.component.css']
})
export class BsHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
