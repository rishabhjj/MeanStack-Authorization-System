import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {GetPostService} from '../../services/get-post.service';

import * as _ from "lodash";
@Component({
  selector: 'app-bussiness-area-add',
  templateUrl: './bussiness-area-add.component.html',
  styleUrls: ['./bussiness-area-add.component.css']
})
export class BussinessAreaAddComponent implements OnInit {
domain : any;
forKey: number;
private sub: any;
name:any;
  state:boolean=false;
  constructor(private route: ActivatedRoute,private _getpost:GetPostService,private router:Router) { 
    _getpost.showMenuEvent.subscribe(
      (showMenu) => {
        this.state = !this.state;
      }
   );
 
  }
  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.forKey = +params['id']; // (+) converts string 'id' to a number
      
       });
       //console.log(this.forKey);
  }

  onRegisterSubmit1(){
    console.log("Form Submitted");
    const type="domain";
    
    const  name= this.name
    const id = this.forKey
      console.log(name);
      console.log(id);
    this._getpost.addBa("businessarea",name,id).subscribe(
      
      );
      //this.flashMessage.show('You are now registerd and can login now', {cssClass: 'alert-success', timeout:3000});
      this.router.navigate(['ba-home' , this.forKey]);
  }

}
