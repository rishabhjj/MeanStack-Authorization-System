import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-bussiness-area-add',
  templateUrl: './bussiness-area-add.component.html',
  styleUrls: ['./bussiness-area-add.component.css']
})
export class BussinessAreaAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
