import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {GetPostService} from '../../services/get-post.service';
import * as _ from "lodash";
@Component({
  selector: 'app-add-bt',
  templateUrl: './add-bt.component.html',
  styleUrls: ['./add-bt.component.css']
})
export class AddBtComponent implements OnInit {
  forKey: number;
  forKey2: number;
  private sub: any;
  step:any;
  vl:any;
  rt:any;
  app:any;
  constructor(private route: ActivatedRoute,private _getpost:GetPostService,private router:Router) { }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.forKey = +params['id1']; // (+) converts string 'id' to a number
      this.forKey2 = +params['id2'];
       });
       console.log(this.forKey + this.forKey2);
  }
  onRegisterSubmit(){
    console.log("Form Submitted");
    const th = this.vl
    const res = this.rt
    const  app= this.app
    const step = this.step
    const id = this.forKey
      console.log(name);
      console.log(id);
    this._getpost.addBt("businesstransaction",step,id,th,res,app,"chk").subscribe();
 this.router.navigate(['bt',this.forKey,this.forKey2]);
  console.log("tesi" + this.forKey + this.forKey2);
  }
}
