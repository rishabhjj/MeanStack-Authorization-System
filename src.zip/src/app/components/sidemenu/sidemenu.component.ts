import { Component, OnInit,ElementRef,ViewChild,AfterViewInit,Input  } from '@angular/core';
import {GetPostService} from '../../services/get-post.service';
@Component({
  selector: 'app-sidemenu',
  templateUrl: './sidemenu.component.html',
  styleUrls: ['./sidemenu.component.css']
})

export class SidemenuComponent implements OnInit {
  subModule : any;
  state=false;
  constructor(private _ref:ElementRef , private _getpost:GetPostService) { }

  ngOnInit() {
    
    //console.log(this.statex + "sidemenustate1566545656");
  }
  
  
  tog(state){
   // this.state=this._getpost.toggle1(state);
    console.log(state);
  }


}
