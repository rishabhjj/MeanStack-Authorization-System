import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bs-add',
  templateUrl: './bs-add.component.html',
  styleUrls: ['./bs-add.component.css']
})
export class BsAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
