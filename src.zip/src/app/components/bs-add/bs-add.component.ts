import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {GetPostService} from '../../services/get-post.service';
@Component({
  selector: 'app-bs-add',
  templateUrl: './bs-add.component.html',
  styleUrls: ['./bs-add.component.css']
})
export class BsAddComponent implements OnInit {
  domain : any;
  forKey: number;
  private sub: any;
  vl:any;
  rt:any;
  name:any;
  state:boolean=false;
  constructor(private route: ActivatedRoute,private _getpost:GetPostService,private router:Router) { 
    _getpost.showMenuEvent.subscribe(
      (showMenu) => {
        this.state = !this.state;
      }
   );
 
  }
  ngOnInit() {
   
    this.sub = this.route.params.subscribe(params => {
      this.forKey = +params['id']; // (+) converts string 'id' to a number
      
       });
       console.log(this.forKey);
       this.sub = this.route.queryParams.subscribe(params => {
        this.domain = params['baname']; // (+) converts string 'id' to a number
         });
  }
  onRegisterSubmit(){
    console.log("Form Submitted");
    const type="domain";
    const th = this.vl
    const res = this.rt
    const  name= this.name
    const id = this.forKey
      console.log(name);
      console.log(id);
    this._getpost.addBs("businessscenario",name,id,th,res).subscribe(
      
      );
      setTimeout(() => 
      {
          this.router.navigate(['bs-home' , this.forKey],{queryParams:{baname:this.domain}});
      },
      2000);
      //this.flashMessage.show('You are now registerd and can login now', {cssClass: 'alert-success', timeout:3000});
   //  this.router.navigate(['bs-home' , this.forKey]);
  }

}
