import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.css'],
  inputs: ['parentValue']
})
export class BreadcrumbComponent implements OnInit {
  @Input() public name: String;
  @Input() public baName: String;
  @Input() public bsname: String;
value :any;
bread: any;
values = [];
name1:any;
names = [];
type = [];
len:any;

  constructor() { }

  ngOnInit() {  
      console.log(this.name + "Business Domain");
      console.log(this.baName + "Business area nmae");
      console.log(this.bsname  + "Business area nmae")
      // this.names.push(this.name);
      // this.names.push(this.baName);
      // this.names.push(this.bsname);
      // console.log(this.names);
      //this.names.push("");
         this.type = ['Domain' , 'Business Area ' , 'Business Scenario', 'Business Transaction'];
         var     keys = Object.keys(localStorage),
              j = keys.length;
              this.bread = "";
              // this.bread = "One Pace";
              // this.bread = " NFR Blue Print " + ">>" + localStorage.getItem('url');;
            //  this.values.push("NFR Define");
              this.values.push(localStorage.getItem('url'));
          for(var i = 0;i<j;i++) {
              //values.push( localStorage.getItem(keys[i]) );
              if(keys[i]=='bt-home'){
                this.value = localStorage.getItem(keys[i]);
               // this.bread = this.bread  + this.value;
                //this.bread = this.bread + " >>" + this.value;
                // console.log(keys[i] + ":  " + this.value);
                // console.log(this.bread);
                this.values.push(this.value);
              }
              if(keys[i]=='bs-home'){
                this.value = localStorage.getItem(keys[i]);
                //this.bread = this.bread  + this.value;
                //this.bread = this.bread + " >>" + this.value;
                // console.log(keys[i] + ":  " + this.value);
                // console.log(this.bread);
                this.values.push(this.value);
              }
              if(keys[i]=='ba-home'){
                this.value = localStorage.getItem(keys[i]);
               // this.bread = this.bread  + this.value;
                // this.bread = this.bread + " >>" + this.value  ;
                // console.log(keys[i] + ":  " + this.value);
                // console.log(this.bread);
                this.values.push(this.value);
              }
              if(keys[i]=='1'){
                this.name1 = localStorage.getItem(keys[i]);
                this.names.push(this.name1);
              }
              if(keys[i]=='2'){
                this.name1 = localStorage.getItem(keys[i]);
                this.names.push(this.name1);
              }
              if(keys[i]=='3'){
                this.name1 = localStorage.getItem(keys[i]);
                this.names.push(this.name1);
              }
              
             
              // if(keys[i]=='url'){
              // this.value = localStorage.getItem(keys[i]);
              // this.bread = this.bread + " >>" + this.value;
              // console.log(keys[i] + ":  " + this.value);
              // console.log(this.bread);
              // }
              //console.log(this.values + "testings");
              

          }
      // console.log(this.values + "testings");
          // this.bread = "One Pace";
          // this.bread = this.bread  + " >> domain";
          // console.log(i);
          this.len = this.values.length;
          console.log(this.len);
          console.log(this.names);
          console.log(this.values);
        }
          



}
