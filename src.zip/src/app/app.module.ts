import { BrowserModule } from '@angular/platform-browser';
import {Component, NgModule} from '@angular/core';
import {  OnInit, AfterViewInit } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { RouterModule, Routes} from '@angular/router';
import { RouterLinkActive } from '@angular/router';
import { FormsModule } from '@angular/forms';
import {MdButtonModule, MdSidenavModule,MdCardModule, MdMenuModule, MdToolbarModule, MdIconModule } from '@angular/material';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import 'hammerjs';

import { ViewChild, ElementRef } from '@angular/core';
import { AddDomainComponent } from './components/add-domain/add-domain.component';
import { HomeComponent } from './components/home/home.component';
import { BussinessAreaHomeComponent } from './components/bussiness-area-home/bussiness-area-home.component';
import { BussinessAreaAddComponent } from './components/bussiness-area-add/bussiness-area-add.component';
import { GetPostService } from './services/get-post.service';
import {HttpClientModule} from '@angular/common/http';
import { BsHomeComponent } from './components/bs-home/bs-home.component';
import { BsAddComponent } from './components/bs-add/bs-add.component';
import { BtComponent } from './components/bt/bt.component';
const appRoutes: Routes = [
  {path:'add-domain', component: AddDomainComponent},
  {path:'', component: HomeComponent},
  {path:'ba-home/:id', component: BussinessAreaHomeComponent},
  {path:'ba-add/:id', component: BussinessAreaAddComponent},
  {path:'ba-add', component: BussinessAreaAddComponent},
  {path:'ba-home', component: BussinessAreaHomeComponent},
  {path:'bs-home/:ba', component: BsHomeComponent},
  {path:'bs-home', component: BsHomeComponent},
  {path:'bs-add/:ba', component: BsAddComponent},
  {path:'bs-add', component: BsAddComponent},
  {path:'bt', component: BtComponent}
  
]


@NgModule({
  declarations: [
    AppComponent,
    AddDomainComponent,
    HomeComponent,
    BussinessAreaHomeComponent,
    BussinessAreaAddComponent,
    BsHomeComponent,
    BsAddComponent,
    BtComponent
  ],
  imports: [
    BrowserModule,
    MdButtonModule,
    MdCardModule,
    MdMenuModule,
    MdToolbarModule,
    MdIconModule,
    BrowserAnimationsModule,
    MdSidenavModule,  
    RouterModule.forRoot(appRoutes),
    FormsModule,
    HttpModule,HttpClientModule

  ],
  providers: [GetPostService],
  bootstrap: [AppComponent]
})
export class AppModule   {
  

  }
