var faker = require('faker')

exports.Pace_Project = {
    headCount : faker.commerce.price(),
        projName : faker.name.firstName()
    
}