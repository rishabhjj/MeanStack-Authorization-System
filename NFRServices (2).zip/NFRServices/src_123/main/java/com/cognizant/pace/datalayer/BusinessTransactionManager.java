package com.cognizant.pace.datalayer;
import java.util.List;

import org.hibernate.Session;
import com.cognizant.pace.model.OPBusinessTransaction;
import com.cognizant.pace.serviceobject.NFRAddServiceObject;

public class BusinessTransactionManager {

	public BusinessTransactionManager() {
		
	}
	
    public void createAndStoreEvent(NFRAddServiceObject poServiceObject) throws Exception{
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
 
        OPBusinessTransaction busTrans = new OPBusinessTransaction();
        busTrans.setName(poServiceObject.getName());
        busTrans.setScenarioid(poServiceObject.getForKey());
        busTrans.setResponsetime(poServiceObject.getResptime());
        busTrans.setThroughput(poServiceObject.getThroughput());
        busTrans.setApplicationid(poServiceObject.getApplicationid());
        busTrans.setApplicationname(poServiceObject.getApplicationname());
        session.save(busTrans);
 
        session.getTransaction().commit();
    }
 
    public List listBusTransactions(Integer poScenarioId) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        List result = session.createQuery("from OPBusinessTransaction where scenarioid="+poScenarioId.intValue()).list();
        session.getTransaction().commit();
        return result;
    }

}
