package com.cognizant.pace.model;

public class OPBusinessScenario implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	private Integer id;
	private String name;
	private Integer busareaid;
	private Float scenariotime;
	private Integer throughput;
	
	
	public OPBusinessScenario() {
		
	}
	
	
		
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getBusareaid() {
		return busareaid;
	}
	public void setBusareaid(Integer busareaid) {
		this.busareaid = busareaid;
	}
	public float getScenariotime() {
		return scenariotime;
	}
	public void setScenariotime(float scenariotime) {
		this.scenariotime = scenariotime;
	}
	public Integer getThroughput() {
		return throughput;
	}
	public void setThroughput(Integer throughput) {
		this.throughput = throughput;
	}

	
	
}
