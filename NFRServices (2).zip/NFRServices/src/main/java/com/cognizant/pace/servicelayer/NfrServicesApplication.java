package com.cognizant.pace.servicelayer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cognizant.pace.datalayer.*;
import com.cognizant.pace.serviceobject.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

@SpringBootApplication
@RestController
@EnableAutoConfiguration
@RequestMapping("/nfr.svc") 
public class NfrServicesApplication {
	
	private static String UPLOAD_FOLDER = "C://test//";
	//private static String UPLOAD_FOLDER = "/apps/nfr-services/files/";
	@CrossOrigin(origins = "*") 
	@RequestMapping(value = "/add", method = RequestMethod.POST, consumes="application/json")
	 void add(@RequestBody NFRAddServiceObject poNFRAddService) {
		 try {
			 System.out.println(poNFRAddService.getName());
			 System.out.println(poNFRAddService.getType());
			 ObjectMapper loMapper = new ObjectMapper();
			 //loMapper.readValues(poNFRAddService, NFRAddServiceObject.class);
			 if (poNFRAddService.getType().equals("domain"))
	{
	 DomainManager loDomManager = new DomainManager();
	 loDomManager.createAndStoreEvent(poNFRAddService.getName());
		 
	 }
	else if(poNFRAddService.getType().equalsIgnoreCase("businessarea"))
	{
		 BusinessAreaManager loBusAreaManager = new BusinessAreaManager();
		 loBusAreaManager.createAndStoreEvent(poNFRAddService.getName(), poNFRAddService.getForKey());
		 //return "I have added busarea";
	}
	else if(poNFRAddService.getType().equals("businessscenario"))
	{
		BusinessScenarioManager loBusScenarioManager = new BusinessScenarioManager();
		loBusScenarioManager.createAndStoreEvent(poNFRAddService);
		
	}
	else if(poNFRAddService.getType().equals("businesstransaction"))
	{
		BusinessTransactionManager loBusTransMgr = new BusinessTransactionManager();
		loBusTransMgr.createAndStoreEvent(poNFRAddService);
	}
	
		 }catch(Exception ex)
		 {ex.printStackTrace();
		 //return "failure";
		 }
	 }

	@CrossOrigin(origins = "*")
	 @RequestMapping(value = "/upload", method = RequestMethod.POST)
	public void fileUpload(@RequestParam(value="file") MultipartFile file, RedirectAttributes redirectAttributes) throws FileNotFoundException {
	
		if (file.isEmpty()) {
		
			//return new ModelAndView("status", "message", "Please select a file and try again");
	}
	
	try {
		// read and write the file to the selected location-
		byte[] bytes = file.getBytes();
		Path path = Paths.get(UPLOAD_FOLDER + file.getOriginalFilename());
		Files.write(path, bytes);
		System.out.println(path);
		UploadFile uplo = new UploadFile();
		uplo.filesss(path.toString());

		} catch (IOException e) {
			e.printStackTrace();
			}
//
//		
//		//return new ModelAndView("status", "message", "File Uploaded sucessfully");
//		
//		FileInputStream fis = new FileInputStream
		String Filename=file.getOriginalFilename();
		System.out.println(Filename);
		
        
//		UploadFile uplo = new UploadFile();
//		uplo.filesss();
	}
		
		
		
	
	
	
	
	
	
	 
	@CrossOrigin(origins = "*")
	 @RequestMapping("/list")
	 List list(@RequestParam(value="type") String name,
			 @RequestParam(value="forKey", required=false) Integer forKeyId)  {
	 if (name.equals("domain"))  {
		 System.out.println("inside domain List");
	 DomainManager loDomManager = new DomainManager();
	 return loDomManager.listDomains();
	 } else if (name.equals("businessarea")){
		 System.out.println("Here I am businessarea "+name);
		 BusinessAreaManager loBusAreaManager = new BusinessAreaManager();
		 return loBusAreaManager.listBusAreas(forKeyId);
	 } else if (name.equals("businessscenario")) {
	  System.out.println("Here I am businessscenario "+name);
		 BusinessScenarioManager loBusScenarioManager = new BusinessScenarioManager();
		 return loBusScenarioManager.listBusScenarios(forKeyId);
	 } else //if(name.equals("businesstransaction")) {
		  {System.out.println("Here I am businesstransaction "+name);
		  BusinessTransactionManager loBusTransMgr = new BusinessTransactionManager();
		  return loBusTransMgr.listBusTransactions(forKeyId);
	 }
	 }

	
	
	
	
	@CrossOrigin(origins = "*")
	 @RequestMapping("/delete")
	 void delete(@RequestParam(value="type") String name,
			 @RequestParam(value="key") Integer keyId)  {
	 if (name.equals("domain"))  {
		 System.out.println("inside domain delete");
	 DomainManager loDomManager = new DomainManager();
	 loDomManager.deleteDomain(keyId);
	 } else if (name.equals("businessarea")){
		 System.out.println("Here I am businessarea "+name);
		 BusinessAreaManager loBusAreaManager = new BusinessAreaManager();
		 loBusAreaManager.deleteBusArea(keyId);
	 } else if (name.equals("businessscenario")) {
	  System.out.println("Here I am businessscenario "+name);
		 BusinessScenarioManager loBusScenarioManager = new BusinessScenarioManager();
		 loBusScenarioManager.deleteBusScenario(keyId);
	 } else //if(name.equals("businesstransaction")) {
		  {System.out.println("Here I am businesstransaction "+name);
		  BusinessTransactionManager loBusTransMgr = new BusinessTransactionManager();
		  loBusTransMgr.deleteBusTransaction(keyId);
		  
	 }
	 }
	 
	 
	 
	public static void main(String[] args) {
		SpringApplication.run(NfrServicesApplication.class, args);
	}
}
