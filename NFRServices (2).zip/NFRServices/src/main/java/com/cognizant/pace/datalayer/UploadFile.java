package com.cognizant.pace.datalayer;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Session;
import com.cognizant.pace.model.*;

import static org.mockito.Matchers.anyFloat;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
public class UploadFile {
	
	public void filesss(String path) {
		 try {
			// C://Users//477166//Desktop//sample.xlsx
			 
				            FileInputStream excelFile = new FileInputStream(path);
				            System.out.print("working till here");
				            Workbook workbook = new XSSFWorkbook(excelFile);
				            Sheet datatypeSheet = workbook.getSheetAt(0);
				            Iterator<Row> iterator = datatypeSheet.iterator();
				            XSSFRow row;
				    		XSSFCell cell;
				            while (iterator.hasNext()) {

				                Row currentRow = iterator.next();
				                if(currentRow.getRowNum()==0 ){
				                	   continue; //just skip the rows if row number is 0 or 1
				                	  }
				                Iterator<Cell> cellIterator = currentRow.iterator();
				                
				               ArrayList<String> names = new ArrayList<String>();
				               ArrayList<Float> values = new ArrayList<Float>();
				                while (cellIterator.hasNext()) {
				                	
				                    Cell currentCell = (XSSFCell) cellIterator.next();
				                    System.out.println(currentCell);
				                    if (currentCell.getCellType() == XSSFCell.CELL_TYPE_STRING) {
				    					System.out.print(currentCell.getStringCellValue() + "--String-- ");
				    					names.add(currentCell.toString());
				    					
				    				} else if (currentCell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC) {
				    					System.out.print(currentCell.getNumericCellValue() + "--Integer--");
				    					//currentCell.CELL_TYPE_NUMERIC();
				    					
				    					
				    					Float f=(float)currentCell.getNumericCellValue();
				    					values.add(f);
				    				} 

				                }
				                System.out.print(names);
				                System.out.print("--------");
				                System.out.print(values);
				                
			                Session session = HibernateUtil.getSessionFactory().getCurrentSession();
		        	        session.beginTransaction();
			        	        List result = session.createQuery("select domainName from OPDomain").list();
			        	       // System.out.println(places);
		        	        ListIterator<String> iterator1 = result.listIterator();
			        	        while (iterator1.hasNext())
		        	        {
		        	            iterator1.set(iterator1.next().toLowerCase());
		        	        }
		        	        if(!(result.contains(names.get(0).toLowerCase()))){
		        	        
		        	        OPDomain domain = new OPDomain(names.get(0));
		        	       int x = (int)session.save(domain);
		        	       System.out.println(x);
		        	       OPBusinessArea busArea = new OPBusinessArea(x,names.get(1));
		        	       
		        	        x =(int)session.save(busArea);
		        	        
		        	        OPBusinessScenario busScenario = new OPBusinessScenario();
			        	        busScenario.setName(names.get(2));
		        	        busScenario.setBusareaid(x);
		        	        busScenario.setScenariotime(values.get(1));
		        	        busScenario.setThroughput(Math.round(values.get(0)));
			        	 
			        	        x= (int)session.save(busScenario);
			        	        OPBusinessTransaction busTrans = new OPBusinessTransaction();
			        	        busTrans.setName(names.get(3));
			        	        busTrans.setScenarioid(x);
			        	        busTrans.setResponsetime(values.get(3));
			        	        busTrans.setThroughput(Math.round(values.get(2)));
			        	        busTrans.setApplicationid("123456");
			        	        busTrans.setApplicationname(names.get(4));
			        	        session.save(busTrans);

				            }
		        	        
		        	        else
		        	        {
		        	        	List resultBa = session.createQuery("select busAreaName from OPBusinessArea").list();
		        	        	ListIterator<String> iterator2 = resultBa.listIterator();
			        	        while (iterator2.hasNext())
		        	        {
		        	            iterator2.set(iterator2.next().toLowerCase());
		        	        }
		        	        	
			        	        if(!(resultBa.contains(names.get(1).toLowerCase()))) {
			        	        	
			        	        	System.out.println("checkingit is entering");
			        	        	
			        	        	System.out.println(names.get(0));
			        	        	String o = "\'" + names.get(0).toString() + "\'";
			        	        	List x = session.createQuery("select id from OPDomain where domainName ="+o ).list();
			        	        	System.out.println("checkingit is entering12314");
			        	        	System.out.println(x);
			        	        	int n = (int) x.get(0);
			        	        	System.out.println(n + "1245+32145664bhkjhblbj;");
			        	        	OPBusinessArea busArea = new OPBusinessArea(n,names.get(1));
					        	       
				        	        int p =(int)session.save(busArea);
				        	        
				        	        OPBusinessScenario busScenario = new OPBusinessScenario();
					        	        busScenario.setName(names.get(2));
				        	        busScenario.setBusareaid(p);
				        	        busScenario.setScenariotime(values.get(1));
				        	        busScenario.setThroughput(Math.round(values.get(0)));
					        	 
				        	         p = (int)session.save(busScenario);
					        	        OPBusinessTransaction busTrans = new OPBusinessTransaction();
					        	        busTrans.setName(names.get(3));
					        	        busTrans.setScenarioid(p);
					        	        busTrans.setResponsetime(values.get(3));
					        	        busTrans.setThroughput(Math.round(values.get(2)));
					        	        busTrans.setApplicationid("123456");
					        	        busTrans.setApplicationname(names.get(4));
					        	        session.save(busTrans);
			        	        }
			        	        
			        	        else {
			        	        	List resultBs = session.createQuery("select name from OPBusinessScenario").list();
			        	        	ListIterator<String> iterator3 = resultBs.listIterator();
				        	        while (iterator3.hasNext())
			        	        {
			        	            iterator3.set(iterator3.next().toLowerCase());
			        	        }
				        	        
				        	        if(!(resultBs.contains(names.get(2).toLowerCase()))) {
				        	        	String o = "\'" + names.get(1).toString() + "\'";
				        	        	List x = session.createQuery("select id from OPBusinessArea where busAreaName =" +o).list();
				        	   
				        	        	OPBusinessScenario busScenario = new OPBusinessScenario();
					        	        busScenario.setName(names.get(2));
				        	        busScenario.setBusareaid((int)x.get(0));
				        	        busScenario.setScenariotime(values.get(1));
				        	        busScenario.setThroughput(Math.round(values.get(0)));
					        	 
				        	        int p = (int)session.save(busScenario);
					        	        OPBusinessTransaction busTrans = new OPBusinessTransaction();
					        	        busTrans.setName(names.get(3));
					        	        busTrans.setScenarioid(p);
					        	        busTrans.setResponsetime(values.get(3));
					        	        busTrans.setThroughput(Math.round(values.get(2)));
					        	        busTrans.setApplicationid("123456");
					        	        busTrans.setApplicationname(names.get(4));
					        	        session.save(busTrans);
				        	        
				        	        }
				        	        
				        	        else
				        	        {
				        	        	List resultBt = session.createQuery("select name from OPBusinessTransaction").list();
				        	        	ListIterator<String> iterator4 = resultBt.listIterator();
					        	        while (iterator4.hasNext())
				        	        {
				        	            iterator4.set(iterator4.next().toLowerCase());
				        	        }
					        	        
					        	        if(!(resultBt.contains(names.get(3).toLowerCase()))) {
					        	        	String o = "\'" + names.get(2).toString() + "\'";
					        	        	List x = session.createQuery("select id from OPBusinessScenario where name = "+o).list();
								        	   
					        	        	 OPBusinessTransaction busTrans = new OPBusinessTransaction();
							        	        busTrans.setName(names.get(3));
							        	        busTrans.setScenarioid((int)x.get(0));
							        	        busTrans.setResponsetime(values.get(3));
							        	        busTrans.setThroughput(Math.round(values.get(2)));
							        	        busTrans.setApplicationid("123456");
							        	        busTrans.setApplicationname(names.get(4));
							        	        session.save(busTrans);
					        	        }
				        	        	
				        	        }
			        	        	
				        	        
			        	        }
		        	        	
		        	        	
		        	        }
		        	        
		        	        
		        	        
			        	        session.getTransaction().commit();
			            }
				        } catch (FileNotFoundException e) {
				            e.printStackTrace();
				        } catch (IOException e) {
				            e.printStackTrace();
				        }

	}

}
