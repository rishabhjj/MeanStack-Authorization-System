package com.cognizant.pace.serviceobject;

public class NFRAddServiceObject {

	private String name;
	private String type;
	private Integer forKey = 0;
	private Integer throughput = 0;
	private Float resptime = (float) 0.0;
	private String applicationid;
	private String applicationname;
	
	public String getApplicationid() {
		return applicationid;
	}

	public void setApplicationid(String applicationid) {
		this.applicationid = applicationid;
	}

	public String getApplicationname() {
		return applicationname;
	}

	public void setApplicationname(String applicationname) {
		this.applicationname = applicationname;
	}

	public Integer getThroughput() {
		return throughput;
	}

	public void setThroughput(Integer throughput) {
		this.throughput = throughput;
	}

	public Float getResptime() {
		return resptime;
	}

	public void setResptime(Float resptime) {
		this.resptime = resptime;
	}
	public NFRAddServiceObject() {
		
	}
	
	public NFRAddServiceObject(String poType,String poName,String poKey)
	{
		this.type = poType;
		this.name = poName;
		this.forKey = Integer.parseInt(poKey);
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Integer getForKey() {
		return forKey;
	}
	public void setForKey(Integer forKey) {
		this.forKey = forKey;
	}
	
}
