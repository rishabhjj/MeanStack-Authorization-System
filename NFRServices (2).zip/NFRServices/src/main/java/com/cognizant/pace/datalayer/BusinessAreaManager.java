package com.cognizant.pace.datalayer;

import org.hibernate.Session;
import com.cognizant.pace.model.OPBusinessArea;
import com.cognizant.pace.model.OPDomain;

import java.util.List;


public class BusinessAreaManager {
    public void createAndStoreEvent(String poBusAreaName,Integer poBusDomId) throws Exception{
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
 
        OPBusinessArea busArea = new OPBusinessArea(poBusDomId,poBusAreaName);
 
        session.save(busArea);
 
        session.getTransaction().commit();
    }
 
    public List listBusAreas(Integer poDomainId) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        List result = session.createQuery("from OPBusinessArea where busDomId="+poDomainId.intValue()).list();
        session.getTransaction().commit();
        return result;
    }
    
    public void deleteBusArea(Integer poID) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
 
        OPBusinessArea busArea = new OPBusinessArea();
        busArea.setId(poID);
 
        session.delete(busArea);
 
        session.getTransaction().commit();
    	
    }
    
}
