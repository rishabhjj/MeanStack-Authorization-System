package com.cognizant.pace.model;

public class OPBusinessArea implements java.io.Serializable {

 	
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String busAreaName;
	private Integer busDomId;
	
	public OPBusinessArea() {
		
	}
	
	public OPBusinessArea(Integer piBusDomId,String psBusAreaName) {
		busAreaName = psBusAreaName;
		busDomId = piBusDomId;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getBusAreaName() {
		return busAreaName;
	}
	public void setBusAreaName(String busAreaName) {
		this.busAreaName = busAreaName;
	}
	public Integer getBusDomId() {
		return busDomId;
	}
	public void setBusDomId(Integer busDomId) {
		this.busDomId = busDomId;
	}


	
}
