package com.cognizant.pace.model;
 
public class OPBusinessTransaction implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	private Integer id;
	private String name;
	private Integer scenarioid;
	private Float responsetime;
	private Integer throughput;
	private String applicationid;
	private String applicationname;

	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getScenarioid() {
		return scenarioid;
	}
	public void setScenarioid(Integer scenarioid) {
		this.scenarioid = scenarioid;
	}
	public Float getResponsetime() {
		return responsetime;
	}
	public void setResponsetime(Float responsetime) {
		this.responsetime = responsetime;
	}
	public Integer getThroughput() {
		return throughput;
	}
	public void setThroughput(Integer throughput) {
		this.throughput = throughput;
	}
	public String getApplicationid() {
		return applicationid;
	}
	public void setApplicationid(String applicationid) {
		this.applicationid = applicationid;
	}
	public String getApplicationname() {
		return applicationname;
	}
	public void setApplicationname(String applicationname) {
		this.applicationname = applicationname;
	}
		
	
}
