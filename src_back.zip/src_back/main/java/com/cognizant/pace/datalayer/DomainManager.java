package com.cognizant.pace.datalayer;
import org.hibernate.Session;
import com.cognizant.pace.model.OPDomain;
import java.util.List;

public class DomainManager {

	    public void createAndStoreEvent(String poDomainName) {
	        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
	        session.beginTransaction();
	 
	        OPDomain domain = new OPDomain(poDomainName);
	 
	        session.save(domain);
	 
	        session.getTransaction().commit();
	    }
	 
	    public List listDomains() {
	        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
	        session.beginTransaction();
	        List result = session.createQuery("from OPDomain").list();
	        session.getTransaction().commit();
	        return result;
	    }
	    
	    public void deleteDomain(Integer poID) {
	        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
	        session.beginTransaction();
	 
	        OPDomain domain = new OPDomain();
	        domain.setId(poID);
	 
	        session.delete(domain);
	 
	        session.getTransaction().commit();
	    	
	    }
}
