import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {GetPostService} from '../../services/get-post.service';
import * as _ from "lodash";
@Component({
  selector: 'app-bt',
  templateUrl: './bt.component.html',
  styleUrls: ['./bt.component.css']
})
export class BtComponent implements OnInit {
  forKey: number;
  forKey2: number;
  private sub: any;
  dd =[];
  dd1=[];
  step:any;
  vl:any;
  rt:any;
  app:any;
  address =[];
  domain:any;
  constructor(private route: ActivatedRoute,private _getpost:GetPostService,private router:Router) { }

  ngOnInit() {
    localStorage.setItem("bt-home",window.location.href);
    this.sub = this.route.params.subscribe(params => {
      this.forKey = +params['id1']; // (+) converts string 'id' to a number
      this.forKey2 = +params['id2'];
       });
       this.sub = this.route.queryParams.subscribe(params => {
        this.domain = params['bsname']; // (+) converts string 'id' to a number
        console.log(this.domain + "       Domain Name");
         });
       console.log(this.forKey);
       localStorage.setItem("3",this.domain);
       this._getpost.getBt("businesstransaction",this.forKey).subscribe(data => {
        console.log(data);
        this.dd1 = data;
        
       },
        error => {
          console.log(error);
        })

        this._getpost.getBs("businessscenario",this.forKey2).subscribe(data => {
          this.dd = data;
         console.log(this.dd);
         },
          error => {
            console.log(error);
          })
  }

  onRegisterSubmit(){
    console.log("Form Submitted");
    const type="domain";
    const th = this.vl
    const res = this.rt
    const  app= this.app
    const step = this.step
    const id = this.forKey
      console.log(name);
      console.log(id);
    this._getpost.addBt("businesstransaction",step,id,th,res,app,"chk").subscribe(
      
      );
      location.reload();
  //this.router.navigate(['bt' , forKey]);
  console.log("tesi");
  }

}
