import { Component, OnInit,ElementRef,ViewChild,AfterViewInit,Input  } from '@angular/core';

@Component({
  selector: 'app-sidemenu',
  templateUrl: './sidemenu.component.html',
  styleUrls: ['./sidemenu.component.css']
})

export class SidemenuComponent implements OnInit {
  @Input() public statex: boolean;
  constructor(private _ref:ElementRef) { }

  ngOnInit() {
   
    console.log(this.statex + "sidemenustate1566545656");
  }
  ngAfterViewInit(){
console.log(this._ref);
  }

toggle1(){
this.statex = !this.statex;
console.log(this.statex);
}

}
