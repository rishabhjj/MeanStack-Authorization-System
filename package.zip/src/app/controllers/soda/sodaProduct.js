import express from 'express'
import { isValid } from './../../../app/helpers/utilities/utility'
import { setQuery, getProducts, saveProduct, updateProduct, removeProduct } from '../../repo/soda/product/sodaProductRepo'

var routes = function (Product, Audit) {
  var router = express.Router()

  router.use(function (req, res, next) {
    isValid(req, res, next)
  })

  router.use(function (req, res, next) {
    setQuery(req, res, next)
  })

  router.route('/:id')
    .patch(function (req, res) {
      updateProduct(Product, Audit, req, res)
    })

  router.route('/')
    .post(function (req, res) {
      saveProduct(Product, req, res)
    })
    .get(function (req, res) {
      getProducts(Product, req, res)
    })
    .delete(function (req, res) {
      removeProduct(Product, req, res)
    })
  return router
}

module.exports = routes
