import express from 'express'
// import { consoleLogger } from './../../../app/helpers/logger/log'
import { isValid } from './../../../app/helpers/utilities/utility'

import { setQuery, getAddressLead, createAddressLead, removeAddressLead } from './../../../app/repo/soda/addressLead/sodaAddressLeadRepo'

let routes = function (SAddressLead) {
  let sAddressLeadRouter = express.Router()

  sAddressLeadRouter.use(function (req, res, next) {
    isValid(req, res, next, 'AddressLead')
  })

  sAddressLeadRouter.use(function (req, res, next) {
    setQuery(req, res, next)
  })

  sAddressLeadRouter.route('/')
    .post(function (req, res) {
      createAddressLead(SAddressLead, req, res)
    })
    .get(function (req, res) {
      getAddressLead(SAddressLead, req, res)
    })
    .delete(function (req, res) {
      removeAddressLead(SAddressLead, req, res)
    })
  return sAddressLeadRouter
}

module.exports = routes
