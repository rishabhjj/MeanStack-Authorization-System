import express from 'express'
import { isValid } from './../../../app/helpers/utilities/utility'
import { setQuery, updatetWorkMaterial, getWorkMaterialList, saveWorkMaterial, deleteWorkMaterial } from './../../../app/repo/soda/workMaterial/sodaWorkMaterialRepo'

var routes = function (WorkMaterial, Audit) {
  var workMaterialRouter = express.Router()

  workMaterialRouter.use(function (req, res, next) {
    isValid(req, res, next, 'WorkMaterial')
  })

  // Reads queryStrings & sets it to query field [middleware]
  workMaterialRouter.use(function (req, res, next) {
    setQuery(req, res, next)
  })

  workMaterialRouter.route('/:id')
    .patch(function (req, res) {
      updatetWorkMaterial(WorkMaterial, req, res)
    })

  workMaterialRouter.route('/')
    .post(function (req, res) {
      saveWorkMaterial(WorkMaterial, req, res)
    })
    .get(function (req, res) {
      getWorkMaterialList(WorkMaterial, req, res)
    })
    .delete(function (req, res) {
      deleteWorkMaterial(WorkMaterial, req, res)
    })
  return workMaterialRouter
}

module.exports = routes
