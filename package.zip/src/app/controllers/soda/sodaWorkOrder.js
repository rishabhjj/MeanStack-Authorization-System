import express from 'express'
import { isValid } from './../../../app/helpers/utilities/utility'
import { setQuery, updateWorkOrder, saveWorkOrder, getWorkOrders, deleteWorkOrder } from '../../repo/soda/workorder/sodaWorkOrderRepo'
import { updateWorkOrderROT, saveWorkOrderROT, getWorkOrdersROT, deleteWorkOrderROT } from '../../repo/soda/workorder/sodaWorkOrderROTRepo'
import { searchWorkOrder } from '../../repo/soda/workorder/sodaWorkOrderSearchRepo'
import { getWorkOrderNotes } from '../../repo/soda/workorder/sodaWorkOrderNotesRepo'
import { getWorkOrderSummary } from '../../repo/soda/workorder/sodaWorkOrderSummaryRepo'
import { getWorkOrderReports } from '../../repo/soda/workorder/sodaWorkOrderReportRepo'

let routes = function (Workorder, Audit, SODAAgeing, ROT, SAddressLead) {
  let workOrderRouter = express.Router()

  workOrderRouter.use(function (req, res, next) {
    isValid(req, res, next, 'Workorder')
  })

  workOrderRouter.use(function (req, res, next) {
    setQuery(req, res, next)
  })

  workOrderRouter.route('/:id')
    .patch(function (req, res) {
      updateWorkOrder(Workorder, Audit, SODAAgeing, ROT, req, res)
    })

  workOrderRouter.route('/')
    .post(function (req, res) {
      saveWorkOrder(Workorder, SODAAgeing, ROT, SAddressLead, req, res)
    })
    .get(function (req, res) {
      getWorkOrders(Workorder, req, res)
    })
    .delete(function (req, res) {
      deleteWorkOrder(Workorder, req, res)
    })

  workOrderRouter.route('/search')
    .get(function (req, res) {
      searchWorkOrder(Workorder, req, res)
    })

  workOrderRouter.route('/:id/rot')
    .post(function (req, res) {
      saveWorkOrderROT(ROT, req, res)
    })
    .get(function (req, res) {
      getWorkOrdersROT(ROT, req, res)
    })
    .patch(function (req, res) {
      updateWorkOrderROT(ROT, Audit, req, res)
    })
    .delete(function (req, res) {
      deleteWorkOrderROT(ROT, Audit, req, res)
    })

  workOrderRouter.route('/Notes/:id')
    .get(function (req, res) {
      getWorkOrderNotes(Workorder, req, res)
    })

  workOrderRouter.route('/summary')
    .get(function (req, res) {
      getWorkOrderSummary(Workorder, req, res)
    })

  workOrderRouter.route('/reporting')
    .get(function (req, res) {
      getWorkOrderReports(Workorder, req, res)
    })

  return workOrderRouter
}

module.exports = routes
