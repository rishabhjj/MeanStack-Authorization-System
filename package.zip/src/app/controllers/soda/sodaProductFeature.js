import express from 'express'
import { isValid } from './../../../app/helpers/utilities/utility'
import { setQuery, updateProductFeature, getProductFeatureList, saveProductFeature, deleteProductFeature } from './../../../app/repo/soda/product/sodaProductFeatureRepo'

var routes = function (ProductFeature, Audit) {
  var productFeatureRouter = express.Router()

  productFeatureRouter.use(function (req, res, next) {
    isValid(req, res, next)
  })

  // Reads queryStrings & sets it to query field [middleware]
  productFeatureRouter.use(function (req, res, next) {
    setQuery(req, res, next)
  })

  productFeatureRouter.route('/:id')
    .patch(function (req, res) {
      updateProductFeature(ProductFeature, req, res)
    })

  productFeatureRouter.route('/')
    .get(function (req, res) {
      getProductFeatureList(ProductFeature, req, res)
    })
    .post(function (req, res) {
      saveProductFeature(ProductFeature, req, res)
    })
    .delete(function (req, res) {
      deleteProductFeature(ProductFeature, req, res)
    })
  return productFeatureRouter
}

module.exports = routes
