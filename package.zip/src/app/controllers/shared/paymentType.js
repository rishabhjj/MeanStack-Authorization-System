import express from 'express'
import { consoleLogger } from './../../../app/helpers/logger/log'
import { isValid } from './../../../app/helpers/utilities/utility'
import { setQuery, getPaymentTypes, createPaymentType, updatePaymentType } from './../../../app/repo/shared/paymentTypeRepo'

let routes = function (paymentType, audit) {
  try {
    let router = express.Router()

    router.use(function (req, res, next) {
      isValid(req, res, next, 'PaymentType')
    })

    router.use(function (req, res, next) {
      setQuery(req, res, next)
    })

    router.route('/')
      .get(function (req, res) {
        getPaymentTypes(paymentType, req, res)
      })
      .post(function (req, res) {
        createPaymentType(paymentType, req, res)
      })

    router.route('/:id')
      .patch(function (req, res) {
        updatePaymentType(paymentType, req, res)
      })
    return router
  } catch (err) {
    consoleLogger(undefined, undefined, err, 'PAYMENT-TYPE')
  }
}
module.exports = routes
