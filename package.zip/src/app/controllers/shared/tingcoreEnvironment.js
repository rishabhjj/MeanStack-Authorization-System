export function tingcoreHomeCharge (req, res, next) {
  req.tingcore = 'https://homecharging-api-test.tingcore-infra.com'

  if (req.env === 'PROD') {
    req.tingcore = 'https://homecharging-api.tingcore-infra.com'
  } else if (req.env === 'QA') {
    req.tingcore = 'https://homecharging-api-stage.tingcore-infra.com'
  }
  next()
}
