let express = require('express')
let utility = require('./../../helpers/utilities/utility')

let routes = function (Workorder, Product, DeliverySite) {
  let router = express.Router()

  router.use(function (req, res, next) {
    req.isCustomer = true
    utility.isValid(req, res, next)
  })

  // Reads queryStrings & sets it to query field [middleware]
  router.use(function (req, res, next) {
    let query = {}

    if (req.query.customerid === undefined) {
      res.status(422).send({ 'error': 'Customer ID is missing' })
    } else {
      query.customerId = req.query.customerid
      query.country = req.country
      query.app = req.app
      req.queryForMongoose = query
      next()
    }
  })

  router.route('/')
    .get(function (req, res) {
      Workorder.find(req.queryForMongoose, {
        _id: 1,
        'country': 1,
        'app': 1,
        'contactInformation.name': 1,
        'workOrderNumber': 1,
        'customerId': 1,
        'status': 1,
        'benefitCalculations.customerSelectedProductPackageId': 1,
        'deliverySite.deliverySiteId': 1,
        'deliverySite.street': 1,
        'deliverySite.city': 1,
        'deliverySite.zip': 1,
        'installationHomeVisit': 1
      }, '-__v', function (err, data) {
        if (err) { res.status(417).send(err) } else {
          if (data.length > 0) {
            // var convertedJSON = JSON.parse(JSON.stringify(data))
            let response = []
            let y = 0

            for (var i = 0, len = data.length; i < len; i++) {
              let obj = new DeliverySite()
              if (data[i].installationHomeVisit !== undefined) {
                obj.yearOfInstallation = data[i].installationHomeVisit
              }

              obj.deliverySiteAddress = data[i].deliverySite
              obj.customerId = data[i].customerId

              // Get Products details
              let query = {}
              query.packageId = data[i].benefitCalculations.customerSelectedProductPackageId

              Product.find(query, {
                _id: 1, 'nameOfPackage': 1, 'noOfSolarPanels': 1, 'panelModel': 1, 'inverterModel': 1, 'peakPower': 1, 'peakPowerUnit': 1
              }, '-__v', function (err, product) {
                if (err) { res.status(417).send(err) } else {
                  obj.noOfPanels = product[0].noOfSolarPanels
                  obj.panelModel = product[0].panelModel
                  obj.inverterModel = product[0].inverterModel
                  obj.packageName = product[0].nameOfPackage
                  obj.peakPower = product[0].peakPower
                  obj.peakPowerUnit = product[0].peakPowerUnit
                  y++
                  response.push(obj)
                  if (y === len) {
                    partB(res, response)
                  }
                }
              })
            }
          } else {
            res.status(404).send()
          }
        }
      })
    }
    )

  function partB (res, response) {
    res.json(response)
  }

  return router
}

module.exports = routes
