import express from 'express'
import { consoleLogger } from './../../../app/helpers/logger/log'
import { isValid, validateHeader } from './../../../app/helpers/utilities/utility'
import { getCustomer, updateCustomer } from './../../repo/shared/customerRepo'

let routes = function (VODAWorkorder, HODAWorkorder, Audit) {
  try {
    let router = express.Router()

    router.use(function (req, res, next) {
      if (req.method === 'PATCH') {
        validateHeader(req, res, next, 'Customers')
      } else {
        isValid(req, res, next, 'Customers')
      }
    })

    router.route('/')
      .get(function (req, res) {
        getCustomer(req, res)
      })

    router.route('/:id')
      .patch(function (req, res) {
        let workorder = ''
        let requiredStatus = 'OrderReceived'
        if (req.app === 'VODA') {
          workorder = VODAWorkorder
        } else if (req.app === 'HODA') {
          workorder = HODAWorkorder
          requiredStatus = 'ValidOrder'
        }
        if (req.app === 'VODA' || req.app === 'HODA') {
          updateCustomer(workorder, requiredStatus, req, res)
        } else {
          res.status(403).send({ 'error': 'Invalid Application' })
        }
      })

    return router
  } catch (err) {
    consoleLogger(undefined, undefined, err, 'CUSTOMERS')
  }
}
module.exports = routes
