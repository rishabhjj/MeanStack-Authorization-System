import express from 'express'
import { consoleLogger } from './../../../app/helpers/logger/log'
import { isValid } from './../../../app/helpers/utilities/utility'
import { setQuery, getItems, createItem, syncItems } from './../../../app/repo/shared/itemServiceMasterRepo'

let routes = function (item, audit) {
  try {
    let router = express.Router()

    router.use(function (req, res, next) {
      isValid(req, res, next, 'Items')
    })

    router.use(function (req, res, next) {
      setQuery(req, res, next)
    })

    router.route('/')
      .get(function (req, res) {
        getItems(item, req, res)
      })
      .post(function (req, res) {
        createItem(item, req, res)
      })
      .put(function (req, res) {
        syncItems(item, req, res)
      })

    return router
  } catch (err) {
    consoleLogger(undefined, undefined, err, 'ITEMS')
  }
}
module.exports = routes
