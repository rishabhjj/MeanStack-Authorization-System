import express from 'express'
import { consoleLogger } from './../../../app/helpers/logger/log'
import { isValid } from './../../../app/helpers/utilities/utility'
import { getItemsOfCampaign } from './../../repo/shared/campaignItemsRepo'

let routes = function (item, hodaCampaign) {
  try {
    let router = express.Router()

    router.use(function (req, res, next) {
      isValid(req, res, next, 'Campaign-Items')
    })

    router.route('/:id')
      .get(function (req, res) {
        getItemsOfCampaign(item, hodaCampaign, req, res)
      })
    return router
  } catch (err) {
    consoleLogger(undefined, undefined, err, 'CAMPAIGN-ITEMS')
  }
}
module.exports = routes
