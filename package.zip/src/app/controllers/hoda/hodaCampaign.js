import express from 'express'
import { consoleLogger } from './../../../app/helpers/logger/log'
import { isValid } from './../../../app/helpers/utilities/utility'

import { setQuery, getCampaigns, createCampaign, updateCampaign } from './../../../app/repo/hoda/campaign/hodaCampaignRepo'

let routes = function (Campaign, Audit) {
  try {
    let router = express.Router()

    router.use(function (req, res, next) {
      isValid(req, res, next, 'Campaign')
    })

    router.use(function (req, res, next) {
      setQuery(req, res, next)
    })

    router.route('/')
      .get(function (req, res) {
        getCampaigns(Campaign, req, res)
      })
      .post(function (req, res) {
        createCampaign(Campaign, req, res)
      })

    router.route('/:id')
      .patch(function (req, res) {
        updateCampaign(Campaign, req, res)
      })

    return router
  } catch (err) {
    consoleLogger(undefined, undefined, err, 'HODA-CAMPAIGN')
  }
}
module.exports = routes
