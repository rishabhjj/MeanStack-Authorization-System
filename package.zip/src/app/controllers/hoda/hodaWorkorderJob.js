import express from 'express'
import { consoleLogger } from './../../../app/helpers/logger/log'
import { isValid } from './../../../app/helpers/utilities/utility'
import { processPendingWorkorders } from './../../../app/repo/hoda/workorder/hodaWorkorderRepo'

let routes = function (Workorder, Audit) {
  try {
    let router = express.Router()

    router.use(function (req, res, next) {
      isValid(req, res, next, 'Workorders-Jobs')
    })

    router.route('/')
      .post(function (req, res) {
        if (req.body !== undefined) {
          let sourceStatus = 'OrderReceived'
          let targetStatus = 'InCompleteOrder'

          if (req.body.targetStatus === 'InstallerYetToConfirm' && req.country === 'NO') {
            sourceStatus = 'SentToInstaller'
            targetStatus = 'InstallerYetToConfirm'
          }
          processPendingWorkorders(Workorder, sourceStatus, targetStatus, req, res)
        } else {
          res.status(400).send({ 'error': 'Invalid Body' })
        }
      })

    return router
  } catch (err) {
    consoleLogger(undefined, undefined, err, 'HODA-WORKORDER-JOB')
  }
}
module.exports = routes
