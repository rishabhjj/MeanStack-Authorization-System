import express from 'express'
import { consoleLogger } from './../../../app/helpers/logger/log'
import { isValid } from './../../../app/helpers/utilities/utility'
import { tingcoreHomeCharge } from './../shared/tingcoreEnvironment'
import { getCharger, deviceMapping, deleteMapping } from './../../../app/repo/hoda/device/hodaDeviceRepo'

let routes = function (Audit) {
  try {
    let router = express.Router()

    router.use(function (req, res, next) {
      isValid(req, res, next, 'Device')
    })

    router.use(function (req, res, next) {
      tingcoreHomeCharge(req, res, next)
    })

    router.route('/')
      .get(function (req, res) {
        getCharger(req, res)
      })

    router.route('/:cid/mapping')
      .post(function (req, res) {
        if (req.params.cid !== undefined) {
          deviceMapping(req.params.cid, req, res)
        } else {
          res.status(400).send('Charger ID missing')
        }
      })
      .delete(function (req, res) {
        if (req.params.cid !== undefined) {
          deleteMapping(req.params.cid, req, res)
        } else {
          res.status(400).send('Charger ID missing')
        }
      })

    return router
  } catch (err) {
    consoleLogger(undefined, undefined, err, 'HODA-DEVICE')
  }
}
module.exports = routes
