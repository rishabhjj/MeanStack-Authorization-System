import express from 'express'
import { consoleLogger } from './../../../app/helpers/logger/log'
import { isValid } from './../../../app/helpers/utilities/utility'

import { setQuery, getEVTypes, createEVType, updateEVType, deleteEVTypes } from './../../../app/repo/hoda/evType/hodaEVTypeRepo'

let routes = function (EVType) {
  try {
    let router = express.Router()

    router.use(function (req, res, next) {
      isValid(req, res, next, 'EVType')
    })

    router.use(function (req, res, next) {
      setQuery(req, res, next)
    })

    router.route('/')
      .get(function (req, res) {
        getEVTypes(EVType, req, res)
      })
      .post(function (req, res) {
        createEVType(EVType, req, res)
      })

    router.route('/:id')
      .delete(function (req, res) {
        deleteEVTypes(EVType, req, res)
      })
      .patch(function (req, res) {
        updateEVType(EVType, req, res)
      })

    return router
  } catch (err) {
    consoleLogger(undefined, undefined, err, 'HODA-EV-TYPE')
  }
}
module.exports = routes
