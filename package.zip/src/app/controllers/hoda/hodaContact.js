import express from 'express'
import { consoleLogger } from './../../../app/helpers/logger/log'
import { isValid } from './../../../app/helpers/utilities/utility'
import { setQuery, getContacts, createContact } from './../../../app/repo/hoda/contact/hodaContactRepo'

let routes = function (Contact) {
  try {
    let router = express.Router()

    router.use(function (req, res, next) {
      isValid(req, res, next, 'Contacts')
    })

    router.use(function (req, res, next) {
      setQuery(req, res, next)
    })

    router.route('/')
      .get(function (req, res) {
        getContacts(Contact, req, res)
      })
      .post(function (req, res) {
        createContact(Contact, req, res)
      })
    return router
  } catch (err) {
    consoleLogger(undefined, undefined, err, 'HODA-CONTACTS')
  }
}
module.exports = routes
