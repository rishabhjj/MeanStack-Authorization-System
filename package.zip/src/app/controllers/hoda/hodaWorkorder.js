import express from 'express'
import { consoleLogger } from './../../../app/helpers/logger/log'
import { isValid } from './../../../app/helpers/utilities/utility'
import { setQuery, getWorkorders, createWorkorder, updateSiteInfo, updatePaymentType, updateStatusToValidOrder, updateWorkorder, search, summary } from './../../../app/repo/hoda/workorder/hodaWorkorderRepo'

let routes = function (Workorder, Audit) {
  try {
    let router = express.Router()

    router.use(function (req, res, next) {
      isValid(req, res, next, 'Workorders')
    })

    router.use(function (req, res, next) {
      setQuery(req, res, next)
    })

    router.route('/')
      .get(function (req, res) {
        getWorkorders(Workorder, req, res)
      })
      .post(function (req, res) {
        createWorkorder(Workorder, req, res)
      })

    router.route('/:id')
      .patch(function (req, res) {
        updateWorkorder(Workorder, req, res)
      })

    router.route('/:id/SiteInfo')
      .put(function (req, res) {
        updateSiteInfo(Workorder, req, res)
      })

    router.route('/:id/PaymentType')
      .put(function (req, res) {
        updatePaymentType(Workorder, req, res)
      })

    router.route('/:id/Status')
      .put(function (req, res) {
        updateStatusToValidOrder(Workorder, req, res)
      })

    router.route('/summary')
      .get(function (req, res) {
        req.archival.request.resourceName = 'Workorder_Summary_' + req.method
        summary(Workorder, req, res)
      })

    router.route('/search')
      .get(function (req, res) {
        req.archival.request.resourceName = 'Workorder_Search_' + req.method
        search(Workorder, req, res)
      })

    /*
      .delete(function (req, res) {
        deleteWorkorder(Workorder, req, res)
      })

*/
    return router
  } catch (err) {
    consoleLogger(undefined, undefined, err, 'HODA-WORKORDER')
  }
}
module.exports = routes
