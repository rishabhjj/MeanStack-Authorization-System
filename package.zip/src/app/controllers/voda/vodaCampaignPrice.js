import express from 'express'
import { validateHeader, isValid } from './../../../app/helpers/utilities/utility'
import { consoleLogger } from './../../../app/helpers/logger/log'

import { setQuery, getCampaignPrice, createCampaignPrice, updateCampaignPrice } from './../../repo/voda/campaignPrice/vodaCampaignPriceRepo'

let routes = function (CampaignPrice, Audit) {
  try {
    let router = express.Router()

    router.use(function (req, res, next) {
      if (req.method === 'PATCH') {
        validateHeader(req, res, next, 'CampaignPrice')
      } else {
        isValid(req, res, next, 'CampaignPrice')
      }
    })

    router.use(function (req, res, next) {
      setQuery(req, res, next)
    })

    router.route('/')
      .get(function (req, res) {
        getCampaignPrice(CampaignPrice, req, res)
      })
      .post(function (req, res) {
        createCampaignPrice(CampaignPrice, req, res)
      })
      .patch(function (req, res) {
        updateCampaignPrice(CampaignPrice, Audit, req, res)
      })

    return router
  } catch (err) {
    consoleLogger(undefined, undefined, err, 'VODA-CampaignPrice')
  }
}
module.exports = routes
