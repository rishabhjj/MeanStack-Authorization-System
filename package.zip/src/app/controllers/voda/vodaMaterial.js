import express from 'express'
import { isValid } from './../../../app/helpers/utilities/utility'
import { error } from './../../../app/helpers/logger/log'
import { setQuery, getVodaMaterial, saveVodaMaterial, deleteVodaMaterial, updateVodaMaterial } from '../../repo/voda/material/vodaMaterialRepo'

let routes = function (Material, Audit) {
  try {
    let router = express.Router()

    router.use(function (req, res, next) {
      isValid(req, res, next, 'Material')
    })

    router.use(function (req, res, next) {
      setQuery(req, res, next)
    })

    router.route('/')
      .get(function (req, res) {
        getVodaMaterial(Material, req, res)
      })
      .post(function (req, res) {
        saveVodaMaterial(Material, req, res)
      })
      .delete(function (req, res) {
        deleteVodaMaterial(Material, req, res)
      })

    router.route('/:id')
      .patch(function (req, res) {
        let id = req.params.id
        updateVodaMaterial(Material, Audit, id, req, res)
      })
    return router
  } catch (err) {
    error(undefined, undefined, err, 'VODA-MATERIAL')
  }
}
module.exports = routes
