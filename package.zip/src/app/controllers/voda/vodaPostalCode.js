import express from 'express'
import { isValid } from './../../../app/helpers/utilities/utility'
import { error } from './../../../app/helpers/logger/log'
import { setQuery, getPostalCode, savePostalCode, getPostalCodeList, deletePostalCode, updatePostalCode } from '../../../app/repo/voda/postalCode/vodaPostalCodeRepo'

let routes = function (PostalCode) {
  try {
    let router = express.Router()

    router.use(function (req, res, next) {
      isValid(req, res, next, 'PostalCode')
    })

    router.use(function (req, res, next) {
      setQuery(req, res, next)
    })

    router.route('/')
      .get(function (req, res) {
        getPostalCode(PostalCode, req, res)
      })
      .post(function (req, res) {
        savePostalCode(PostalCode, req, res)
      })

    router.route('/list')
      .get(function (req, res) {
        getPostalCodeList(PostalCode, req, res)
      })

    router.route('/:id')
      .delete(function (req, res) {
        deletePostalCode(PostalCode, req, res)
      })
      .patch(function (req, res) {
        updatePostalCode(PostalCode, req, res)
      })

    return router
  } catch (err) {
    error(undefined, undefined, err, 'VODA-POSTAL-CODE')
  }
}
module.exports = routes
