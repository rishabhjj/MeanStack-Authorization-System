let Client = require('node-rest-client').Client
let MailsLogModel = require('./../../../app/models//shared/mailsLogModel')

function error (req, res, err, fileName = 'Not Specified') {
  try {
    console.log('ERROR in fileName: ' + fileName + '  ' + err)
    if (req !== undefined && res !== undefined) {
      res.status(417).send({ 'error': err.message })
    }
  } catch (err) {
    console.log('ERROR-LOGGER')
  }
}

function dashboard (environment, requestIdData, statusCodeData, resourceNameData, actionMethodData, queryStringData, requestingSystemData,
  targetSystemData, authorizationData, receivedTimeData, reponseReturnedTimeData, additionalDetailsData, ipData, processTimeData) {
  try {
    let client = new Client()
    let args = {
      data: {
        'requestId': requestIdData,
        'statusCode': statusCodeData.toString(),
        'resourceName': resourceNameData,
        'actionMethod': actionMethodData,
        'queryString': JSON.stringify(queryStringData),
        'requestingSystem': requestingSystemData,
        'targetSystem': targetSystemData,
        'authorization': authorizationData,
        'receivedTime': receivedTimeData.toString(),
        'reponseReturnedTime': reponseReturnedTimeData.toString(),
        'additionalDetails': additionalDetailsData,
        'ip': ipData,
        'processTime': processTimeData.toString()
      },
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
    }

    let loggerUri = 'https://fortum-testapi-logger.azurewebsites.net/api/logger'

    if (environment === 'PROD') {
      loggerUri = 'https://fortum-api-logger.azurewebsites.net/api/logger'
    }

    client.post(loggerUri, args, function (data, response) {
      /// To-do: Where to log incase of any issue???
    })
  } catch (err) {
    console.log('DASHBOARD-LOGGER')
  }
}

function mailLogger (app, country, email, template, statusCode, wo, woStatus, role, refId = {}) {
  try {
    var data = new MailsLogModel()
    data.app = app
    data.country = country
    data.email = email
    data.template = template
    data.statusCode = statusCode
    data.status = woStatus
    data.wo = wo
    data.role = role
    data.refId = refId['x-message-id'] !== undefined ? refId['x-message-id'] : refId

    var mailLog = new MailsLogModel(data)
    mailLog.save()
  } catch (err) {
    console.log('MAIL-LOGGER')
  }
}

module.exports = {
  error,
  dashboard,
  mailLogger,
  consoleLogger: error
}
