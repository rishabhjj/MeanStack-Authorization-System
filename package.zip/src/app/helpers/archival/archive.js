let Client = require('node-rest-client').Client
let apiLogger = require('./../../../app/helpers/logger/log')

function log (archive, responseBody, statusCode, environment, processName, receivedTime = null, requestId = '000') {
  try {
    // environment, requestIdData, statusCodeData, resourceNameData, actionMethodData, queryStringData, requestingSystemData,
    // targetSystemData, authorizationData, receivedTimeData, reponseReturnedTimeData, additionalDetailsData, ipData, processTimeData

    let now = new Date()
    receivedTime = receivedTime === null ? now : receivedTime
    apiLogger.dashboard(environment, requestId, statusCode, processName + '_' + archive.request.resourceName, archive.request.method,
      archive.request.queryString, processName, 'WOM', archive.request.headers.user + ' ' + archive.request.headers.role, receivedTime, now, '', '', Math.abs(receivedTime - new Date()))

    archive.response.statusCode = statusCode
    archive.response.content = responseBody
    let token = 'token deeb1bb79c6758c1d4z7b27547a6dd248y46081e'
    let url = 'https://fortumtestapi.azurewebsites.net/api/v1/Archive'

    if (environment === 'PROD') {
      url = 'https://fortumapi.azurewebsites.net/api/v1/Archive'
      token = 'token 8d919b21f82752c9f1ddce33ffcbb2170df618bd'
    }

    let client = new Client()
    let args = {
      data: archive,
      headers: {
        'X-Target-System': '-',
        'Authorization': token,
        'Content-Type': 'application/json',
        'X-Request-Id': '-',
        'X-Requesting-System': processName
      }
    }

    client.post(url, args, function (data, response) {
      try {
        if (response.statusCode === 200) {
        } else {
          console.log('ERROR Archival: StatusCode ' + response.statusCode + ' ' + response)
        }
      } catch (err) {
        console.log('ERROR Archival (Inside Post): ' + err)
      }
    })
  } catch (err) {
    console.log('ERROR Archival (Outer): ' + err)
  }
}

module.exports = {
  log: log,
  archive: log
}
