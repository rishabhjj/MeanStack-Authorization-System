let CryptoJS = require('crypto-js')
let logger = require('./../../../app/helpers/logger/log')

function encrypt (value) {
  try {
    var secretPhrase = 'aa31g-3f61f53-j135-4dbb-b2e8-e8bf88ffde3f'
    let encrpytedValue = CryptoJS.AES.encrypt(value, secretPhrase)
    return encrpytedValue
  } catch (err) {
    logger.error(undefined, undefined, err, '(EN)CRYPT')
  }
}

function decrypt (value) {
  try {
    let secretPhrase = 'aa31g-3f61f53-j135-4dbb-b2e8-e8bf88ffde3f'
    let decryptedData = CryptoJS.AES.decrypt(value, secretPhrase)
    let convertedValue = decryptedData.toString(CryptoJS.enc.Utf8)
    return convertedValue
  } catch (err) {
    logger.error(undefined, undefined, err, '(DE)CRYPT')
  }
}

module.exports = {
  encrypt: encrypt,
  decrypt: decrypt
}
