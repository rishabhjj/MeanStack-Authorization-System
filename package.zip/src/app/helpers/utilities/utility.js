import { archive } from './../../../app/helpers/archival/archive'
import { token } from './../../../app/helpers/auth/authorize'
import { consoleLogger } from './../../../app/helpers/logger/log'

function isValid (req, res, next, resourceName = 'NONE') {
  try {
    if (req.method !== 'OPTIONS') {
      if (req.header('country') !== undefined && req.header('app') !== undefined) {
        // Convert Query String fields into LowerCase
        for (var key in req.query) {
          req.query[key.toLowerCase()] = req.query[key]
        }

        // Assign Request Header fields value into request Object
        req.country = req.header('country').toUpperCase()
        req.app = req.header('app').toUpperCase()
        req.resourceName = resourceName + '_' + req.method
        req.processName = req.app + '_' + req.country
        req.receivedTime = new Date()
        req.requestId = req.header('X-Request-Id')

        // Authenticate & Authorize
        let bearerToken = (req.header('Authorization') !== undefined) ? req.header('Authorization') : undefined
        token(req.env, bearerToken, req, res, next)
      } else {
        res.status(400).send({ 'error': 'Country or App is missing' })
      }
    } else {
      next()
    }
  } catch (err) {
    consoleLogger(req, res, err, 'UTILITY')
  }
}

function queryStringToLowerCase (req, res, next) {
  for (var key in req.query) {
    req.query[key.toLowerCase()] = req.query[key]
  }
  next()
}

function validateHeader (req, res, next, resourceName = 'NONE') {
  if (req.method !== 'OPTIONS') {
    if (req.header('country') !== undefined && req.header('app') !== undefined) {
      req.country = req.header('country').toUpperCase()
      req.app = req.header('app').toUpperCase()
      req.resourceName = resourceName + '_' + req.method
      req.processName = req.app + '_' + req.country
      req.receivedTime = new Date()
      req.requestId = req.header('X-Request-Id')
      next()
    } else {
      res.status(400).send({ 'error': 'Country or App is missing' })
    }
  } else {
    next()
  }
}

function CompleteProcess (req, res, content, statusCode) {
  archive(req.archival, content, statusCode, req.env, req.processName, req.receivedTime, req.requestId)
  res.status(statusCode).send(content)
}

module.exports = {
  isValid: isValid,
  validateHeader: validateHeader,
  queryStringToLowerCase: queryStringToLowerCase,
  CompleteProcess
}
