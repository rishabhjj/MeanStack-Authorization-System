import { configs } from './../config/constants'
import { mailLogger } from './../../helpers/logger/log'
let Client = require('node-rest-client').Client

export function sendAvausMailer (app, country, from, fromName, to, cc, bcc, subject, substitutions, woe, templateId) {
  try {
    let client = new Client()
    let requestId = Math.floor((Math.random() * 1222222222200) + 1)
    let requestingSystem = 'JODA.' + country
    let environment = process.env.ENV || 'TEST'
    let baseURI = environment === 'PROD' ? configs.azureProdAPI : configs.azureTestAPI
    let url = baseURI + '/avaus/v1/Message'
    let azureKey = environment === 'PROD' ? '3693a9c99fd64dbcb65203dfa447d08d' : '3f7b92e86ed64d6193aec0f73704a545'

    let messageSource = 'Forum'
    let messageSender = fromName
    let language = 'FI'

    if (country === 'SE') {
      messageSender = 'Fortum'
    }

    var contentPlaceHolderList = []

    // Convert substitutions object to Avaus format & also remove a href tags as it is not allowed in AVAUS
    for (var key in substitutions) {
      if (substitutions.hasOwnProperty(key)) {
        let textContent = substitutions[key].toString()
        let isHTMLTag = textContent.includes('<a href')
        if (!isHTMLTag) {
          contentPlaceHolderList.push(
            {
              'PlaceHolderName': key,
              'PlaceHolderValue': substitutions[key]
            })
        }
      }
    }

    let logData = {
      'templateId': templateId,
      'to': to,
      'woe': woe,
      'country': country,
      'app': app
    }

    let args = {
      data: {
        'Message': {
          'MessagingMessageType': templateId,
          'MessageSource': messageSource,
          'Sender': messageSender,
          'DefaultLanguage': language
        },
        'AllowedChannels': [
          {
            'ChannelType': '1',
            'Priority': 1
          }
        ],
        'Recipients': [
          {
            'ContentPlaceHolderList': contentPlaceHolderList,
            'Email': to
          }
        ]
      },
      headers: {
        'RequestId': requestId,
        'RequestingSystem': requestingSystem,
        'Ocp-Apim-Subscription-Key': azureKey,
        'TargetSystem': 'NEOLANE',
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    }

    client.post(url, args, function (data, response, l = logData) {
      let id = (data !== undefined && data.text !== undefined) ? data.text : ''
      mailLogger(logData.app, logData.country, logData.to, logData.templateId, data.statusCode, data.hodaOrderNumber, data.status, data.role, id)
    })
  } catch (err) {
    console.log('AVAUS-MAIL - ERROR')
  }
}
