export const configs = {
  azureTestAPI: 'https://testapi.fortum.com',
  azureProdAPI: 'https://api.fortum.com'
}
