import { configs } from './../config/constants'
import { mailLogger } from './../../helpers/logger/log'
let Client = require('node-rest-client').Client

export function sendGridMailer (app, country, from, fromName, to, cc, bcc, subject, substitutions, templateId) {
  try {
    let client = new Client()
    let requestId = Math.floor((Math.random() * 1222222222200) + 1)
    let requestingSystem = 'JODA.' + country
    let environment = process.env.ENV || 'TEST'
    let baseURI = environment === 'PROD' ? configs.azureProdAPI : configs.azureTestAPI
    let url = baseURI + '/sendgrid/v1/mail'
    let azureKey = environment === 'PROD' ? '3693a9c99fd64dbcb65203dfa447d08d' : '3f7b92e86ed64d6193aec0f73704a545'

    let logData = {
      'templateId': templateId,
      'to': to,
      'woe': substitutions.woe,
      'country': country,
      'app': app
    }

    let args = {
      data: {
        'from': { 'email': from, 'name': fromName },
        'personalizations': [
          {
            'bcc': bcc,
            'cc': cc,
            'substitutions': substitutions,
            'to': to,
            'subject': subject
          }
        ],
        'template_id': templateId
      },
      headers: {
        'x-request-id': requestId,
        'x-requesting-system': requestingSystem,
        'Ocp-Apim-Subscription-Key': azureKey,
        'x-target-system': 'SendGrid',
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    }

    client.post(url, args, function (data, response, l = logData) {
      let id = (data !== undefined && data.messageId !== undefined) ? data.messageId : ''
      let to = logData.to.length > 0 ? logData.to[0] : ''
      mailLogger(logData.app, logData.country, to, logData.templateId, data.statusCode, data.hodaOrderNumber, data.status, data.role, id)
    })
  } catch (err) {
    console.log('SENDGRID-MAIL')
  }
}
