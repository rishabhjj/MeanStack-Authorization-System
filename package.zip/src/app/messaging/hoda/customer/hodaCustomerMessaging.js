import request from 'superagent'
import { mailLogger } from './../../../../app/helpers/logger/log'
import { configs } from './../../../../app/helpers/config/constants'

// Get all the data

export function sendMails (data, country, isProductChanged = false, cancelationReason = 'None') {
  let environment = process.env.HODA_FI_ENV_URL || 'http://localhost:9000'
  let template = ''
  let campaignName = ''
  let modelOfChargingStation = ''
  let subscription = ''
  let price = ''
  let customerId = data.customer.customerId !== undefined ? data.customer.customerId : ''
  let name = data.customer.lastName !== undefined ? data.customer.lastName : ''
  let firstName = data.customer.firstName !== undefined ? data.customer.firstName : ''
  let lastName = data.customer.lastName !== undefined ? data.customer.lastName : ''
  let streetName = ''
  let houseNumber = ''
  let stairway = ''
  let apartmentNumber = ''
  let postalCode = ''
  let city = ''
  let deliverySiteHouseNumber = ''
  let deliverySiteApartmentNumber = ''
  let deliverySiteStairway = ''
  let deliverySiteStreetName = ''
  let deliverySitePostalCode = ''
  let deliverySitePostOfficeName = ''
  let email = ''
  let sitedetailslink = environment + '/selfservice?workorder=' + data._id
  let avausEnv = process.env.ENV || 'TEST'
  let azureURL = avausEnv === 'PROD' ? configs.azureProdAPI : configs.azureTestAPI
  let azureAPI = azureURL + '/avaus/v1/Message'
  let azureKey = avausEnv === 'PROD' ? '3693a9c99fd64dbcb65203dfa447d08d' : '3f7b92e86ed64d6193aec0f73704a545'
  let messageSource = 'Forum'
  let messageSender = 'Fortum Asiakaspalvelu'
  let language = 'FI'
  let id = Math.floor((Math.random() * 1222222222200) + 1)

  if (data.customer.address !== undefined) {
    streetName = data.customer.address.street !== undefined ? data.customer.address.street : ''
    postalCode = data.customer.address.zip !== undefined ? data.customer.address.zip : ''
    city = data.customer.address.city !== undefined ? data.customer.address.city : ''
  }

  if (data.deliverySite.address !== undefined) {
    deliverySiteStreetName = data.deliverySite.address.street !== undefined ? data.deliverySite.address.street : ''
    deliverySitePostalCode = data.deliverySite.address.zip !== undefined ? data.deliverySite.address.zip : ''
    deliverySitePostOfficeName = data.deliverySite.address.city !== undefined ? data.deliverySite.address.city : ''
  }

  if (data.customer.contactInfo !== undefined) {
    email = data.customer.contactInfo.email !== undefined ? data.customer.contactInfo.email : ''
  }

  if (data.isProductChanged === true) {
    template = 226
  } else {
    if (data.status === 'OrderReceived' || data.status === undefined || data.status === null || data.status === '') { template = 221 }
    if (data.status === 'SentToInstaller') { template = 222 }
    if (data.status === 'Cancelled') { template = 223 }
    if (data.status === 'InCompleteOrder') { template = 224 }
    if (data.status === 'ValidOrder') { template = 225 }
    if (data.status === 'Installed') { template = 227 }
    if (data.status === 'TimeScheduled') { template = 228 }
  }

  if (template === 221 || template === 222 || template === 223 || template === 224 || template === 225 || template === 226 || template === 227 || template === 228) {
    request
      .post(azureAPI)
      .send(
        {
          'Message': {
            'MessagingMessageType': template,
            'MessageSource': messageSource,
            'Sender': messageSender,
            'DefaultLanguage': language
          },
          'AllowedChannels': [
            {
              'ChannelType': '1',
              'Priority': 1
            }
          ],
          'Recipients': [
            {
              'ContentPlaceHolderList': [
                {
                  'PlaceHolderName': 'customerId',
                  'PlaceHolderValue': customerId
                },
                {
                  'PlaceHolderName': 'firstName',
                  'PlaceHolderValue': firstName
                },
                {
                  'PlaceHolderName': 'lastName',
                  'PlaceHolderValue': lastName
                },
                {
                  'PlaceHolderName': 'name',
                  'PlaceHolderValue': name
                },
                {
                  'PlaceHolderName': 'customerName',
                  'PlaceHolderValue': name
                },
                {
                  'PlaceHolderName': 'campaignName',
                  'PlaceHolderValue': campaignName
                },
                {
                  'PlaceHolderName': 'modelOfChargingStation',
                  'PlaceHolderValue': modelOfChargingStation
                },
                {
                  'PlaceHolderName': 'subscription',
                  'PlaceHolderValue': subscription
                },
                {
                  'PlaceHolderName': 'material',
                  'PlaceHolderValue': price
                },
                {
                  'PlaceHolderName': 'streetName',
                  'PlaceHolderValue': streetName
                },
                {
                  'PlaceHolderName': 'houseNumber',
                  'PlaceHolderValue': houseNumber
                },
                {
                  'PlaceHolderName': 'stairway',
                  'PlaceHolderValue': stairway
                },
                {
                  'PlaceHolderName': 'apartmentNumber',
                  'PlaceHolderValue': apartmentNumber
                },
                {
                  'PlaceHolderName': 'postalCode',
                  'PlaceHolderValue': postalCode
                },
                {
                  'PlaceHolderName': 'postOfficeName',
                  'PlaceHolderValue': city
                },
                {
                  'PlaceHolderName': 'deliverySiteStreetName',
                  'PlaceHolderValue': deliverySiteStreetName
                },
                {
                  'PlaceHolderName': 'deliverySiteHouseNumber',
                  'PlaceHolderValue': deliverySiteHouseNumber
                },
                {
                  'PlaceHolderName': 'deliverySiteApartmentNumber',
                  'PlaceHolderValue': deliverySiteApartmentNumber
                },
                {
                  'PlaceHolderName': 'deliverySiteStairway',
                  'PlaceHolderValue': deliverySiteStairway
                },
                {
                  'PlaceHolderName': 'deliverySitepostalCode',
                  'PlaceHolderValue': deliverySitePostalCode
                },
                {
                  'PlaceHolderName': 'deliverySitePostOfficeName',
                  'PlaceHolderValue': deliverySitePostOfficeName
                },
                {
                  'PlaceHolderName': 'cancelationReason',
                  'PlaceHolderValue': cancelationReason
                },
                {
                  'PlaceHolderName': 'sitedetailslink',
                  'PlaceHolderValue': sitedetailslink
                }
              ],
              'Email': email
            }
          ]
        }
      )
      .set('RequestId', id)
      .set('Ocp-Apim-Subscription-Key', azureKey)
      .set('RequestingSystem', 'HODA')
      .set('TargetSystem', 'NEOLANE')
      .set('Content-Type', 'application/json')
      .set('Accept', 'application/json')
      .end(function (err, res) {
        var refId = err !== null ? err : res.text
        mailLogger('HODA', country, email, template, res.statusCode, data._id, data.status, 'CUSTOMER', refId)
      })
  }
}

/*
function post (data, country, Attachments, sendMail) {
  let query = {}
  query.workorderId = data._id
  let reason = ''
  Attachments.find(query, '-__v', function (err, doc) {
    if (err || doc.length === 0) {
      sendMails(data, country, reason)
    } else {
      if (data.status === 'Cancelled') {
        reason = doc[0].vpp.reasonCancellation
      }
      sendMails(data, country, reason)
    }
  })

  //   sendMail(data, country, reason)
*/
