import { sendGridMailer } from './../../helpers/sendGrid/mailer'
import { sendAvausMailer } from './../../helpers/avaus/messaging'
import { getCampaignById } from './../../repo/hoda/campaign/hodaCampaignFunc'

export function sendMail (workorder, country, app, role, isProductChanged = false) {
  let customerFI = process.env.HODA_FI_ENV_URL || 'http://localhost:9000'
  let customerNO = process.env.HODA_NO_ENV_URL || 'http://localhost:9000'
  let jodaFI = process.env.ENV_ADMIN_URL || 'http://localhost:9000'
  let jodaNO = process.env.ENV_ADMIN_NO_URL || 'http://localhost:9000'
  let btnText = 'Avaa tiedot'
  let sitedetailslink = customerFI + '/selfservice?workorder=' + workorder._id
  let sitedetailsButton = "<a href='" + sitedetailslink + "' style='text-decoration:none; color: #ffffff;'>" + btnText + '</a>'
  let urlText = jodaFI + '/hoda/workorder/' + workorder._id
  let url = "<a href='" + urlText + "'>her" + '</a>'
  let btn = "<a href='" + urlText + "' style='text-decoration:none; color: #ffffff;'>" + btnText + '</a>'

  if (country === 'NO') {
    btnText = 'Gå Til Skjema'
    jodaNO = process.env.ENV_ADMIN_NO_URL || 'http://localhost:9000'
    sitedetailslink = customerNO + '/selfservice?workorder=' + workorder._id
    sitedetailsButton = "<a href='" + sitedetailslink + "' style='text-decoration:none; color: #ffffff;'>" + btnText + '</a>'
    urlText = jodaNO + '/hoda/workorder/' + workorder._id
    url = "<a href='" + urlText + "'>her" + '</a>'
    btn = "<a href='" + urlText + "' style='text-decoration:none; color: #ffffff;'>" + btnText + '</a>'
  }

  // Initialize varaibles
  let data = {
    'from': 'Noreply.markets@fortum.com',
    'fromName': 'Fortum Asiakaspalvelu',
    'to': '',
    'cc': '',
    'bcc': '',
    'subject': '',
    'template': 'NONE',
    'woe': workorder.hodaOrderNumber,
    'email': '',
    'customerId': workorder.customer.customerId !== undefined ? workorder.customer.customerId : '',
    'campaignName': '',
    'modelOfChargingStation': '',
    'subscription': '',
    'firstName': workorder.customer.firstName !== undefined ? workorder.customer.firstName : '',
    'lastName': workorder.customer.lastName !== undefined ? workorder.customer.lastName : '',
    'deliverySiteStreetName': '',
    'deliverySitePostalCode': '',
    'deliverySitePostOfficeName': '',
    'sitedetailslink': sitedetailslink,
    'sitedetailsButton': sitedetailsButton,
    'installationStartDateTime': '',
    'installationEndDateTime': '',
    'totalPrice': '',
    'paymentType': workorder.pricing.paymentPlan,
    'currency': workorder.pricing.currency,
    'country': country,
    'btn': btn,
    'url': url,
    'urlText': urlText,
    'installationDate': '',
    'reason': '',
    'role': role,
    'status': workorder.status
  }

  data.firstName = capitalizeFirstLetter(data.firstName)
  data.lastName = capitalizeFirstLetter(data.lastName)

  if (country === 'NO') {
    data.from = 'salg@fortum.com'
    data.fromName = 'Fortum Kundeservice'
  }

  if (workorder.deliverySite.address !== undefined) {
    data.deliverySiteStreetName = workorder.deliverySite.address.street !== undefined ? workorder.deliverySite.address.street : ''
    data.deliverySitePostalCode = workorder.deliverySite.address.zip !== undefined ? workorder.deliverySite.address.zip : ''
    data.deliverySitePostOfficeName = workorder.deliverySite.address.city !== undefined ? workorder.deliverySite.address.city : ''
  }

  if (workorder.customer.contactInfo !== undefined) {
    data.email = workorder.customer.contactInfo.email !== undefined ? workorder.customer.contactInfo.email : ''
  }

  if (workorder.pricing.paymentPlan === 'Subscription') {
    if (workorder.pricing.subscription !== undefined && workorder.pricing.subscription.fee !== undefined) {
      data.subscription = workorder.pricing.subscription.fee
    }
  } else {
    if (workorder.pricing.buy !== undefined && workorder.pricing.buy.package !== undefined && workorder.pricing.buy.installation !== undefined) {
      data.totalPrice = workorder.pricing.buy.package + workorder.pricing.buy.installation
    }
  }

  data.totalPrice = data.currency + ' ' + data.totalPrice
  data.material = data.totalPrice

  // Daylight time adjustment

  if (workorder.installation !== undefined && workorder.installation.agreedVisitScheduleRange !== undefined) {
    let startTime = ''
    let endTime = ''

    if (workorder.installation.agreedVisitScheduleRange.startTime !== undefined) {
      let s = new Date(workorder.installation.agreedVisitScheduleRange.startTime)
      startTime = s.getHours() + ':' + s.getMinutes()
    }

    if (workorder.installation.agreedVisitScheduleRange.endTime !== undefined) {
      let e = new Date(workorder.installation.agreedVisitScheduleRange.endTime)
      endTime = e.getHours() + ':' + e.getMinutes()
    }
    if (workorder.installation.agreedVisitScheduleRange.date !== undefined) {
      let d = new Date(workorder.installation.agreedVisitScheduleRange.date)
      data.installationDate = d.getDate() + '.' + d.getMonth() + 1 + '.' + d.getFullYear()
      data.installationStartDateTime = data.installationDate + ' ' + startTime
      data.installationEndDateTime = data.installationDate + ' ' + endTime
    }
  }
  // Get Campaign Name & modelOfChargingStation
  getCampaignById(workorder.campaignId, country, app).then((result, d = data) => {
    if (result.length > 0) {
      data.campaignName = result[0].campaignName
      data.modelOfChargingStation = (result[0].chargingStation.modelOfChargingStation !== undefined && result[0].chargingStation.modelOfChargingStation.nb_NO) ? result[0].chargingStation.modelOfChargingStation.nb_NO : ''
    } else {
      console.log('Campaign is not avaialble or error while retriving...')
    }
  }).then((d = data) => {
    if (data.role === 'CUSTOMER' && data.country === 'NO') {
      data.to = data.email
      if (isProductChanged === true) {
        data.template = '3280315a-6c67-4706-aa98-1b283ebf1ea8'
        data.subject = 'Endring av din bestilling'
      } else {
        if (data.status === 'OrderReceived' || data.status === undefined || data.status === null || data.status === '') {
          data.template = '8d920316-3b95-4be5-b69e-484d503ae17c'
          data.subject = 'Takk for din bestilling'
        }
        if (data.status === 'InCompleteOrder') {
          data.template = '311655f9-0cae-444f-ad56-a955bf6aefba'
          data.subject = 'Hei' + data.firstname + ', vi mangler informasjon fra deg!'
        }
        if (data.status === 'ValidOrder') {
          data.template = '21c7a852-4e85-41db-8269-a9a96e86567f'
          data.subject = 'Takk!'
        }
        if (data.status === 'TimeScheduled') {
          data.template = 'a10f882d-27e8-4e8d-812b-11586fccd827'
          data.subject = 'Dette er din installasjonsdato'
        }
        if (data.status === 'Installed') {
          data.template = 'd7ea1864-1598-4a8b-84b0-00ebb168712a'
          data.subject = 'Samsvarserklæring for din hjemmelader'
        }
        if (data.status === 'Cancelled') {
          data.template = '9797f871-f72e-41e4-912b-1c8cbb014109'
          data.subject = 'Kansellering av bestilling'
        }
      }
    } else if (data.role === 'INSTALLER' && data.country === 'NO') {
      let toNOInstaller = process.env.HODA_INSTALLER_NO_EMAIL || 'Suresh.SapaniDevarajan@partners.fortum.com'
      data.to = toNOInstaller
      if (data.status === 'SentToInstaller') {
        data.template = 'c0b4c16e-3b73-48ef-a3b9-24361c249f46'
        data.subject = 'SentToInstaller'
      }
    } else if (data.role === 'INSTALLER' && data.country === 'FI') {
      let toFIInstaller = process.env.HODA_INSTALLER_FI_EMAIL || 'Suresh.SapaniDevarajan@partners.fortum.com'
      data.to = toFIInstaller
      if (data.status === 'SentToInstaller') {
        data.template = '6a1fbbb5-cb6b-45fe-986f-b30d3b640886'
        data.subject = 'Uusi Kotilatauslaitteen asennustilaus: WOE-' + data.woe
      } else {
        data.to = ''
      }
    } else if (data.role === 'CS' && data.country === 'FI') {
      let toFICS = process.env.HODA_CS2_FI_EMAIL || 'Suresh.SapaniDevarajan@partners.fortum.com'
      data.to = toFICS
      if (isProductChanged === true) {
        data.template = 'e461e39c-f083-4002-ba09-7e6d98eee3ea'
        data.subject = 'Product Changed'
      } else {
        if (data.status === 'ValidOrder') {
          data.template = 'dfd7e23b-061d-4423-ba62-5beefd28dd2b'
          data.subject = 'WOE-' + data.woe + ' Kotilatauslaitteen tilaus odottaa tarkastusta'
        } else if (data.status === 'OrderReceived') {
          data.template = '803aa245-cf9a-450c-88b5-aa52e2e0ae9e'
          data.subject = 'WOE-' + data.woe + ' Kotilatauslaitteen tilauksen lisätiedot myöhässä'
        } else if (data.status === 'InCompleteOrder') {
          data.template = '803aa245-cf9a-450c-88b5-aa52e2e0ae9e'
          data.subject = 'WOE-' + data.woe + ' Kotilatauslaitteen tilauksen lisätiedot myöhässä'
        } else if (data.status === 'Returned') {
          data.template = '42979da2-0aa6-40d4-9b0f-f3ca7ade05fc'
          data.subject = 'WOE-' + data.woe + ' Kotilatauslaitteen tilaus on palautettu'
        } else if (data.status === 'Completed') {
          data.template = '6fd8d787-f618-41c3-b5bf-2d77a4a3e12b'
          data.subject = 'WOE-' + data.woe + ' Kotilatauslaite on asennettu'
        } else if (data.status === 'Cancelled') {
          data.template = 'dd916e82-7cac-492a-b11c-00c6e08b9974'
          data.subject = 'WOE-' + data.woe + ' Kotilatauslaitteen tilaus on peruttu'
        }
      }
    } else if (data.role === 'CUSTOMER' && data.country === 'FI') {
      if (isProductChanged === true) {
        data.template = 226
        data.subject = 'Product Changed'
      } else {
        if (data.status === 'OrderReceived' || data.status === undefined || data.status === null || data.status === '') {
          data.template = 221
        } else if (data.status === 'SentToInstaller') {
          data.template = 222
        } else if (data.status === 'Cancelled') {
          data.template = 223
        } else if (data.status === 'InCompleteOrder') {
          data.template = 224
        } else if (data.status === 'ValidOrder') {
          data.template = 225
        } else if (data.status === 'Installed') {
          data.template = 227
        } else if (data.status === 'TimeScheduled') {
          data.template = 228
        }
      }
    }

    if (((data.country === 'NO' || (data.country === 'FI' && (data.role === 'INSTALLER' || data.role === 'CS'))) &&
      data.template !== 'NONE')) {
      let to = [{ 'email': data.to }]
      let bccNo = process.env.HODA_NO_BCC_EMAIL_ID || 'Suresh.SapaniDevarajan@partners.fortum.com'
      let bcc = [{ 'email': bccNo }]
      sendGridMailer(app, country, data.from, data.fromName, to, [], bcc, data.subject, data, data.template)
    } else if (data.country === 'FI' && data.role === 'CUSTOMER') {
      sendAvausMailer(app, country, data.from, data.fromName, data.email, '', '', '', data, data.woe, data.template)
    }
  }).catch(error => console.log('HODA Messaging... ' + error))
}

function capitalizeFirstLetter (name) {
  name = name.toLowerCase()
  return name.charAt(0).toUpperCase() + name.slice(1)
}
