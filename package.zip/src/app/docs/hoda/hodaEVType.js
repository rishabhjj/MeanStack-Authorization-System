/* eslint-disable */
/**
 * @api {get} /HODA/EVTypes GetAllHodaEVTypes
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName GetAllHodaEVTypes
 * @apiGroup HODA.EVTypes
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *
 * 
@apiSuccess {Object[]} Data Response Data
@apiSuccess {String} Data._id Mongodb id
@apiSuccess {String} Data.evId evId
@apiSuccess {String} Data.type type
@apiSuccess {Array} Data.years years
@apiSuccess {String} Data.app app
@apiSuccess {String} Data.country country
@apiSuccess {String} Data.createdOn createdOn
@apiSuccess {String} Data.modifiedOn modifiedOn
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
[
    {
        "_id": "59f324f3bcb7131f08fda719",
        "type": "Nissan Leaf",
        "evId": "nissanleaf",
        "modifiedOn": "2017-12-21T12:20:28.211Z",
        "createdOn": "2017-10-27T12:22:11.124Z",
        "app": "HODA",
        "country": "NO",
        "years": [
            "2015"
        ]
    }
]
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 Mongodb-error
 *     {
 *       "error": "Item not found"
 *     }
 * 
 */


 /**
 * @api {post} /HODA/EVTypes SaveHodaEVTypes
 * @apiVersion 1.0.0
 * @apiName SaveHodaEVTypes
 * @apiGroup HODA.EVTypes
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 
@apiParam {Object} Data Response Data
@apiParam {String} Data.evId evId
@apiParam {String} Data.type type
@apiParam {Array} Data.years years
 * 
 * @apiParamExample {json} Request-Example:
 * {
  "evId":"nissanleaf",
  "type":"Nissan Leaf",
  "years":[2015,2016]
}


 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 201 OK
 *  
{
        "_id": "59f324f3bcb7131f08fda719",
        "type": "Nissan Leaf",
        "evId": "nissanleaf",
        "modifiedOn": "2017-12-21T12:20:28.211Z",
        "createdOn": "2017-10-27T12:22:11.124Z",
        "app": "HODA",
        "country": "NO",
        "years": [
            "2015"
        ]
    }
 @apiSuccess {Object[]} Data Response Data
@apiSuccess {String} Data._id Mongodb id
@apiSuccess {String} Data.evId evId
@apiSuccess {String} Data.type type
@apiSuccess {Array} Data.years years
@apiSuccess {String} Data.app app
@apiSuccess {String} Data.country country
@apiSuccess {String} Data.createdOn createdOn
@apiSuccess {String} Data.modifiedOn modifiedOn
 *
 *
 *
 * @apiErrorExample Error-Response:
*     HTTP/1.1 400 Not Found
*     {
*       "error": "Evtypes not found"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 403 Invalid Role
*    { "info": "Invalid role" }
 */


 

 /**
 * @api {put} /HODA/EVTypes/:id UpdateHodaEVTypes
 * @apiVersion 1.0.0
 * @apiName UpdateHodaEVTypes
 * @apiGroup HODA.EVTypes
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} id Which Id we need to update the data
 * 
 * @apiParam {Object[]} Request Which package Id we need to get the data
 * @apiParam {String} Request.op Mention the operation to do.
 * @apiParam {String} Request.path Mention the data path to change
 * @apiParam {Object} Request.value Mention the data value to change ex: any Object
 * 
 * @apiParamExample {json} Request-Example:
 * [
  {
    "op": "add",
    "path": "/evId",
    "value": "444"
  }
]
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 202 Accepted
 *   
{
        "_id": "59f324f3bcb7131f08fda719",
        "type": "Nissan Leaf",
        "evId": "nissanleaf",
        "modifiedOn": "2017-12-21T12:20:28.211Z",
        "createdOn": "2017-10-27T12:22:11.124Z",
        "app": "HODA",
        "country": "NO",
        "years": [
            "2015"
        ]
    }
 @apiSuccess {Object[]} Data Response Data
@apiSuccess {String} Data._id Mongodb id
@apiSuccess {String} Data.evId evId
@apiSuccess {String} Data.type type
@apiSuccess {Array} Data.years years
@apiSuccess {String} Data.app app
@apiSuccess {String} Data.country country
@apiSuccess {String} Data.createdOn createdOn
@apiSuccess {String} Data.modifiedOn modifiedOn
 *
 *
 *
 * @apiErrorExample Error-Response:
*     HTTP/1.1 400 Not Found
*     {
*       "error": "Evtypes not found"
*     }
* @apiErrorExample Error-Response:
*     HTTP/1.1 404 Not Found
*     {
*       "error": "Evtypes not found"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 403 Invalid Role
*    { 'info': 'Invalid role' }
@  apiErrorExample Error-Response:
*     HTTP/1.1 403 Invalid Role
*    { 'info': 'Country or App Not matching' }
 */


 /**
 * @api {delete} /HODA/EVTypes/:id RemoveHodaEVTypes
 * @apiVersion 1.0.0
 * @apiName RemoveHodaEVTypes
 * @apiGroup HODA.EVTypes
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} token ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         token:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} _id Which  Id we need to delete the data
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 204 NO CONTENT
 * 
*  @apiErrorExample Error-Response:
*     HTTP/1.1 400 Not Found
*     {
*       "error": "Evtypes not found"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 403 Invalid Role
*    { 'info': 'Invalid role' }
*/