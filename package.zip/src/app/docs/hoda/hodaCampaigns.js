/* eslint-disable */
/**
 * @api {get} /HODA/Campaigns GetHodaCampaigns
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName GetHodaCampaigns
 * @apiGroup HODA.Campaign
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *
 * 
 * @apiSuccess {Object[]} Data Response Data
@apiSuccess {String} Data._id Mongodb id
@apiSuccess {String} Data.campaignId campaignId
@apiSuccess {String} Data.campaignName campaignName
@apiSuccess {Number} Data.kWhPerMonth kWhPerMonth
@apiSuccess {String} Data.power power
@apiSuccess {String} Data.type type 'Type1', 'Type2', 'NoType'
@apiSuccess {Number} Data.taxRebate taxRebate
@apiSuccess {Boolean} Data.plugTypeSelectionRequired plugTypeSelectionRequired
@apiSuccess {Boolean} Data.isActive isActive
@apiSuccess {Boolean} Data.isVisible isVisible

@apiSuccess {String} Data.startDate startDate
@apiSuccess {String} Data.endDate endDate
@apiSuccess {String} Data.country country 'NO', 'FI'
@apiSuccess {String} Data.sequence sequence 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35
@apiSuccess {String} Data.app app 'HODA'
@apiSuccess {String} Data.modifiedOn modifiedOn
@apiSuccess {String} Data.createdOn createdOn

@apiSuccess {Object} Data.installation installation
@apiSuccess {Object} Data.installation.basic installation basics
@apiSuccess {Object[]} Data.installation.basic.items installation basics
@apiSuccess {String} Data.installation.basic.items.itemId installation basics items itemId
@apiSuccess {Object[]} Data.installation.basic.services installation basics services
@apiSuccess {String} Data.installation.basic.services.serviceItemId installation basics items serviceItemId
@apiSuccess {Object} Data.installation.optional installation optional
@apiSuccess {Object[]} Data.installation.optional.items installation optional
@apiSuccess {String} Data.installation.optional.items.itemId installation optional items itemId
@apiSuccess {Object[]} Data.installation.optional.services installation optional services
@apiSuccess {String} Data.installation.optional.services.serviceItemId installation optional items serviceItemId @apiSuccess {Object[]}   Data.additionalFeatures additionalFeatures name
@apiSuccess {String}   Data.additionalFeatures.en_GB  Name of the additionalFeatures . in english.
@apiSuccess {String}   Data.additionalFeatures.fi_FI   Name of the additionalFeatures. in finnish.
@apiSuccess {String}   Data.additionalFeatures.sv_FI   Name of the additionalFeatures. in sweden.
@apiSuccess {String}   Data.additionalFeatures.sv_SE   Name of the additionalFeatures. in sweden.
@apiSuccess {String}   Data.additionalFeatures.nb_No   Name of the additionalFeatures. in Norway.
@apiSuccess {String}   Data.additionalFeatures.nn_No   Name of the additionalFeatures. in Norway.
@apiSuccess {String}   Data.additionalFeatures.pl_PL   Name of the additionalFeatures. in PL.
@apiSuccess {Object}   Data.description  Description of the Product feature.
@apiSuccess {String}   Data.description.en_GB  Description in english.
@apiSuccess {String}   Data.description.fi_FI  Description in finnish.
@apiSuccess {String}   Data.description.sv_FI  Description in sweden.
@apiSuccess {String}   Data.description.sv_SE  Description in sweden.
@apiSuccess {String}   Data.description.nb_No  Description in Norway.
@apiSuccess {String}   Data.description.nn_No  Description in Norway.
@apiSuccess {String}   Data.description.pl_PL  Description in PL.
@apiSuccess {Object}   Data.chargingStation chargingStation
@apiSuccess {Object}   Data.chargingStation.modelOfChargingStation chargingStation modelOfChargingStation
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.en_GB  Name of the additionalFeatures . in english.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.fi_FI   Name of the modelOfChargingStation in finnish.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.sv_FI   Name of the modelOfChargingStation in sweden.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.sv_SE   Name of the modelOfChargingStation in sweden.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.nb_No   Name of the modelOfChargingStation in Norway.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.nn_No   Name of the modelOfChargingStation in Norway.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.pl_PL   Name of the modelOfChargingStation in PL.
@apiSuccess {Object}   Data.chargingStation.description  Description
@apiSuccess {String}   Data.chargingStation.description.en_GB  Description in english.
@apiSuccess {String}   Data.chargingStation.description.fi_FI  Description in finnish.
@apiSuccess {String}   Data.chargingStation.description.sv_FI  Description in sweden.
@apiSuccess {String}   Data.chargingStation.description.sv_SE  Description in sweden.
@apiSuccess {String}   Data.chargingStation.description.nb_No  Description in Norway.
@apiSuccess {String}   Data.chargingStation.description.nn_No  Description in Norway.
@apiSuccess {String}   Data.chargingStation.description.pl_PL  Description in PL.

@apiSuccess {String}   Data.chargingStation.cableLength  cableLength
@apiSuccess {String}   Data.chargingStation.charing  charing
@apiSuccess {String}   Data.chargingStation.voltage  voltage
@apiSuccess {String}   Data.chargingStation.plug  plug
@apiSuccess {String}   Data.chargingStation.weight  weight
@apiSuccess {String}   Data.chargingStation.ipCode  ipCode
@apiSuccess {String}   Data.chargingStation.light  light
@apiSuccess {String}   Data.chargingStation.url  url

@apiSuccess {Object}   Data.pricing  pricing
@apiSuccess {Number}   Data.pricing.subscription  pricing subscription
@apiSuccess {String}   Data.pricing.currency  pricing currency
@apiSuccess {Object}   Data.pricing.buy  pricing buy
@apiSuccess {Number}   Data.pricing.buy.material  pricing buy material
@apiSuccess {Number}   Data.pricing.buy.installation  pricing buy installation


 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
[
    {
        "_id": "5a31396eeb59dc00254722e7",
        "kWhPerMonth": 12,
        "campaignId": "NO_HODA_PAKKE1_TYPE_1_20171117",
        "campaignName": "12",
        "power": "3,7kW",
        "type": "Type2",
        "description": {
            "en_GB": "For deg som ønsker trygg og effektiv lading.",
            "nb_NO": "For deg som ønsker trygg og effektiv lading."
        },
        "chargingStation": {
            "modelOfChargingStation": {
                "en_GB": "Charge Amps HALO Wallbox",
                "nb_NO": "Charge Amps HALO Wallbox"
            },
            "description": {
                "en_GB": "Opptil 16 A, opptil 3,7 kW, med Wifi og fastmontert ladekabel på 5,5m",
                "nb_NO": "Opptil 16 A, opptil 3,7 kW, med Wifi og fastmontert ladekabel på 5,5m"
            },
            "url": "https://www.fortum.no/hjemmelading/pakke1"
        },
        "pricing": {
            "buy": {
                "material": 17964,
                "installation": 12
            },
            "currency": "NOK",
            "subscription": 12
        },
        "installation": {
            "optional": {
                "services": [],
                "items": []
            },
            "basic": {
                "services": [
                    {
                        "serviceItemId": "03-03-02-001"
                    }
                ],
                "items": [
                    {
                        "itemId": "03-03-01-001"
                    }
                ]
            }
        },
        "country": "NO",
        "sequence": "11",
        "startDate": "2017-01-01T00:00:00.000Z",
        "endDate": "2018-12-31T00:00:00.000Z",
        "modifiedOn": "2017-12-22T09:03:14.128Z",
        "taxRebate": 200,
        "createdOn": "2017-12-13T14:30:06.028Z",
        "app": "HODA",
        "isVisible": true,
        "isActive": true,
        "plugTypeSelectionRequired": true,
        "additionalFeatures": []
    }
]
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 400 Not Found
 *     {
 *       "error": "_id not found"
 *     }
 * * @apiErrorExample Error-Response:
 * HTTP/1.1 403 Invalid Role
 *     {
 *       "error": "Invalid Role"
 *     }
 * 
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 Mongodb-error
 *     {
 *       "error": "Error occured"
 *     }
 * 
 */


 /**
 * @api {post} /HODA/Campaign SaveHodaCampaign
 * @apiVersion 1.0.0
 * @apiName SaveHodaCampaign
 * @apiGroup HODA.Campaign
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 
 * @apiParam {Object} Data Request Data
@apiParam {String} Data.campaignId campaignId
@apiParam {String} Data.campaignName campaignName
@apiParam {Number} Data.kWhPerMonth kWhPerMonth
@apiParam {String} Data.power power
@apiParam {String} Data.type type 'Type1', 'Type2', 'NoType'
@apiParam {Number} Data.taxRebate taxRebate
@apiParam {Boolean} Data.plugTypeSelectionRequired plugTypeSelectionRequired
@apiParam {Boolean} Data.isActive isActive
@apiParam {Boolean} Data.isVisible isVisible

@apiParam {String} Data.startDate startDate
@apiParam {String} Data.endDate endDate
@apiParam {String} Data.country country 'NO', 'FI'
@apiParam {String} Data.sequence sequence 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35
@apiParam {String} Data.app app 'HODA'
@apiParam {String} Data.modifiedOn modifiedOn
@apiParam {String} Data.createdOn createdOn

@apiParam {Object} Data.installation installation
@apiParam {Object} Data.installation.basic installation basics
@apiParam {Object[]} Data.installation.basic.items installation basics
@apiParam {String} Data.installation.basic.items.itemId installation basics items itemId
@apiParam {Object[]} Data.installation.basic.services installation basics services
@apiParam {String} Data.installation.basic.services.serviceItemId installation basics items serviceItemId
@apiParam {Object} Data.installation.optional installation optional
@apiParam {Object[]} Data.installation.optional.items installation optional
@apiParam {String} Data.installation.optional.items.itemId installation optional items itemId
@apiParam {Object[]} Data.installation.optional.services installation optional services
@apiParam {String} Data.installation.optional.services.serviceItemId installation optional items serviceItemId @apiParam {Object[]}   Data.additionalFeatures additionalFeatures name
@apiParam {String}   Data.additionalFeatures.en_GB  Name of the additionalFeatures . in english.
@apiParam {String}   Data.additionalFeatures.fi_FI   Name of the additionalFeatures. in finnish.
@apiParam {String}   Data.additionalFeatures.sv_FI   Name of the additionalFeatures. in sweden.
@apiParam {String}   Data.additionalFeatures.sv_SE   Name of the additionalFeatures. in sweden.
@apiParam {String}   Data.additionalFeatures.nb_No   Name of the additionalFeatures. in Norway.
@apiParam {String}   Data.additionalFeatures.nn_No   Name of the additionalFeatures. in Norway.
@apiParam {String}   Data.additionalFeatures.pl_PL   Name of the additionalFeatures. in PL.
@apiParam {Object}   Data.description  Description of the Product feature.
@apiParam {String}   Data.description.en_GB  Description in english.
@apiParam {String}   Data.description.fi_FI  Description in finnish.
@apiParam {String}   Data.description.sv_FI  Description in sweden.
@apiParam {String}   Data.description.sv_SE  Description in sweden.
@apiParam {String}   Data.description.nb_No  Description in Norway.
@apiParam {String}   Data.description.nn_No  Description in Norway.
@apiParam {String}   Data.description.pl_PL  Description in PL.
@apiParam {Object}   Data.chargingStation chargingStation
@apiParam {Object}   Data.chargingStation.modelOfChargingStation chargingStation modelOfChargingStation
@apiParam {String}   Data.chargingStation.modelOfChargingStation.en_GB  Name of the additionalFeatures . in english.
@apiParam {String}   Data.chargingStation.modelOfChargingStation.fi_FI   Name of the modelOfChargingStation in finnish.
@apiParam {String}   Data.chargingStation.modelOfChargingStation.sv_FI   Name of the modelOfChargingStation in sweden.
@apiParam {String}   Data.chargingStation.modelOfChargingStation.sv_SE   Name of the modelOfChargingStation in sweden.
@apiParam {String}   Data.chargingStation.modelOfChargingStation.nb_No   Name of the modelOfChargingStation in Norway.
@apiParam {String}   Data.chargingStation.modelOfChargingStation.nn_No   Name of the modelOfChargingStation in Norway.
@apiParam {String}   Data.chargingStation.modelOfChargingStation.pl_PL   Name of the modelOfChargingStation in PL.
@apiParam {Object}   Data.chargingStation.description  Description
@apiParam {String}   Data.chargingStation.description.en_GB  Description in english.
@apiParam {String}   Data.chargingStation.description.fi_FI  Description in finnish.
@apiParam {String}   Data.chargingStation.description.sv_FI  Description in sweden.
@apiParam {String}   Data.chargingStation.description.sv_SE  Description in sweden.
@apiParam {String}   Data.chargingStation.description.nb_No  Description in Norway.
@apiParam {String}   Data.chargingStation.description.nn_No  Description in Norway.
@apiParam {String}   Data.chargingStation.description.pl_PL  Description in PL.

@apiParam {String}   Data.chargingStation.cableLength  cableLength
@apiParam {String}   Data.chargingStation.charing  charing
@apiParam {String}   Data.chargingStation.voltage  voltage
@apiParam {String}   Data.chargingStation.plug  plug
@apiParam {String}   Data.chargingStation.weight  weight
@apiParam {String}   Data.chargingStation.ipCode  ipCode
@apiParam {String}   Data.chargingStation.light  light
@apiParam {String}   Data.chargingStation.url  url

@apiParam {Object}   Data.pricing  pricing
@apiParam {Number}   Data.pricing.subscription  pricing subscription
@apiParam {String}   Data.pricing.currency  pricing currency
@apiParam {Object}   Data.pricing.buy  pricing buy
@apiParam {Number}   Data.pricing.buy.material  pricing buy material
@apiParam {Number}   Data.pricing.buy.installation  pricing buy installation


 * 
 * @apiParamExample {json} Request-Example:
 * {
        "campaignId": "FI_HODA_100KM_VRK_T2_460KWH_KK_14112017",
        "campaignName": "007",
        "kWhPerMonth": 4600,
    "power": "110kW", 
    "type": "NoType",
        "description": {
            "en_GB": "Dummy.",
            "fi_FI": "Dummy"
        },
        "chargingStation": {
            "modelOfChargingStation": {
                "en_GB": "Charge Amps HALO Wallbox",
                "fi_FI": "Charge Amps HALO Wallbox"
            },
            "description": {
                "en_GB": "Compact and durable charging station",
                "fi_FI": "Kompakti ja kestävä latauslaite"
            },
             "cableLength": "7.5 m",
    "charing": "6-16 A",
    "voltage": "100-240 V",
    "plug": "Schuko",
    "weight": "4 KG",
    "ipCode": "IP66",
    "light": "Kyllä"
        },
        "pricing": {
            "subscription": 95,
            "buy": {
                "material": 1000,
                "installation": 600
            },
            "currency": "EUR"
        },
        "taxRebate": 200,
        "installation": {
            "basic": {
                "services": [
                    {
                        "serviceItemId": "03-01-02-001"
                    }
                ],
                "items": [
                    {
                        "itemId": "03-01-01-003"
                    }
                ]
            }
        },
        "country": "FI",
        "app": "HODA",
        "isActive": false,
        "isVisible": true,
          "sequence": 16,
  "plugTypeSelectionRequired": true,
        "startDate": "01-01-2017",
    "endDate": "12-31-2018",
        "additionalFeatures": [
            {
                "en_GB": "Charge&Drive public charging membership with 10% discount for charging",
                "fi_FI": "Tarjoamme kotilataajille 10% alennuksen julkisen Charge&Drive latausverkoston käytöstä"
            }
        ]
    }


 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
{
        "_id": "5a31396eeb59dc00254722e7",
        "kWhPerMonth": 12,
        "campaignId": "NO_HODA_PAKKE1_TYPE_1_20171117",
        "campaignName": "12",
        "power": "3,7kW",
        "type": "Type2",
        "description": {
            "en_GB": "For deg som ønsker trygg og effektiv lading.",
            "nb_NO": "For deg som ønsker trygg og effektiv lading."
        },
        "chargingStation": {
            "modelOfChargingStation": {
                "en_GB": "Charge Amps HALO Wallbox",
                "nb_NO": "Charge Amps HALO Wallbox"
            },
            "description": {
                "en_GB": "Opptil 16 A, opptil 3,7 kW, med Wifi og fastmontert ladekabel på 5,5m",
                "nb_NO": "Opptil 16 A, opptil 3,7 kW, med Wifi og fastmontert ladekabel på 5,5m"
            },
            "url": "https://www.fortum.no/hjemmelading/pakke1"
        },
        "pricing": {
            "buy": {
                "material": 17964,
                "installation": 12
            },
            "currency": "NOK",
            "subscription": 12
        },
        "installation": {
            "optional": {
                "services": [],
                "items": []
            },
            "basic": {
                "services": [
                    {
                        "serviceItemId": "03-03-02-001"
                    }
                ],
                "items": [
                    {
                        "itemId": "03-03-01-001"
                    }
                ]
            }
        },
        "country": "NO",
        "sequence": "11",
        "startDate": "2017-01-01T00:00:00.000Z",
        "endDate": "2018-12-31T00:00:00.000Z",
        "modifiedOn": "2017-12-22T09:03:14.128Z",
        "taxRebate": 200,
        "createdOn": "2017-12-13T14:30:06.028Z",
        "app": "HODA",
        "isVisible": true,
        "isActive": true,
        "plugTypeSelectionRequired": true,
        "additionalFeatures": []
    }
 * @apiSuccess {Object} Data Response Data
@apiSuccess {String} Data._id Mongodb id
@apiSuccess {String} Data.campaignId campaignId
@apiSuccess {String} Data.campaignName campaignName
@apiSuccess {Number} Data.kWhPerMonth kWhPerMonth
@apiSuccess {String} Data.power power
@apiSuccess {String} Data.type type 'Type1', 'Type2', 'NoType'
@apiSuccess {Number} Data.taxRebate taxRebate
@apiSuccess {Boolean} Data.plugTypeSelectionRequired plugTypeSelectionRequired
@apiSuccess {Boolean} Data.isActive isActive
@apiSuccess {Boolean} Data.isVisible isVisible

@apiSuccess {String} Data.startDate startDate
@apiSuccess {String} Data.endDate endDate
@apiSuccess {String} Data.country country 'NO', 'FI'
@apiSuccess {String} Data.sequence sequence 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35
@apiSuccess {String} Data.app app 'HODA'
@apiSuccess {String} Data.modifiedOn modifiedOn
@apiSuccess {String} Data.createdOn createdOn

@apiSuccess {Object} Data.installation installation
@apiSuccess {Object} Data.installation.basic installation basics
@apiSuccess {Object[]} Data.installation.basic.items installation basics
@apiSuccess {String} Data.installation.basic.items.itemId installation basics items itemId
@apiSuccess {Object[]} Data.installation.basic.services installation basics services
@apiSuccess {String} Data.installation.basic.services.serviceItemId installation basics items serviceItemId
@apiSuccess {Object} Data.installation.optional installation optional
@apiSuccess {Object[]} Data.installation.optional.items installation optional
@apiSuccess {String} Data.installation.optional.items.itemId installation optional items itemId
@apiSuccess {Object[]} Data.installation.optional.services installation optional services
@apiSuccess {String} Data.installation.optional.services.serviceItemId installation optional items serviceItemId @apiSuccess {Object[]}   Data.additionalFeatures additionalFeatures name
@apiSuccess {String}   Data.additionalFeatures.en_GB  Name of the additionalFeatures . in english.
@apiSuccess {String}   Data.additionalFeatures.fi_FI   Name of the additionalFeatures. in finnish.
@apiSuccess {String}   Data.additionalFeatures.sv_FI   Name of the additionalFeatures. in sweden.
@apiSuccess {String}   Data.additionalFeatures.sv_SE   Name of the additionalFeatures. in sweden.
@apiSuccess {String}   Data.additionalFeatures.nb_No   Name of the additionalFeatures. in Norway.
@apiSuccess {String}   Data.additionalFeatures.nn_No   Name of the additionalFeatures. in Norway.
@apiSuccess {String}   Data.additionalFeatures.pl_PL   Name of the additionalFeatures. in PL.
@apiSuccess {Object}   Data.description  Description of the Product feature.
@apiSuccess {String}   Data.description.en_GB  Description in english.
@apiSuccess {String}   Data.description.fi_FI  Description in finnish.
@apiSuccess {String}   Data.description.sv_FI  Description in sweden.
@apiSuccess {String}   Data.description.sv_SE  Description in sweden.
@apiSuccess {String}   Data.description.nb_No  Description in Norway.
@apiSuccess {String}   Data.description.nn_No  Description in Norway.
@apiSuccess {String}   Data.description.pl_PL  Description in PL.
@apiSuccess {Object}   Data.chargingStation chargingStation
@apiSuccess {Object}   Data.chargingStation.modelOfChargingStation chargingStation modelOfChargingStation
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.en_GB  Name of the additionalFeatures . in english.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.fi_FI   Name of the modelOfChargingStation in finnish.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.sv_FI   Name of the modelOfChargingStation in sweden.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.sv_SE   Name of the modelOfChargingStation in sweden.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.nb_No   Name of the modelOfChargingStation in Norway.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.nn_No   Name of the modelOfChargingStation in Norway.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.pl_PL   Name of the modelOfChargingStation in PL.
@apiSuccess {Object}   Data.chargingStation.description  Description
@apiSuccess {String}   Data.chargingStation.description.en_GB  Description in english.
@apiSuccess {String}   Data.chargingStation.description.fi_FI  Description in finnish.
@apiSuccess {String}   Data.chargingStation.description.sv_FI  Description in sweden.
@apiSuccess {String}   Data.chargingStation.description.sv_SE  Description in sweden.
@apiSuccess {String}   Data.chargingStation.description.nb_No  Description in Norway.
@apiSuccess {String}   Data.chargingStation.description.nn_No  Description in Norway.
@apiSuccess {String}   Data.chargingStation.description.pl_PL  Description in PL.

@apiSuccess {String}   Data.chargingStation.cableLength  cableLength
@apiSuccess {String}   Data.chargingStation.charing  charing
@apiSuccess {String}   Data.chargingStation.voltage  voltage
@apiSuccess {String}   Data.chargingStation.plug  plug
@apiSuccess {String}   Data.chargingStation.weight  weight
@apiSuccess {String}   Data.chargingStation.ipCode  ipCode
@apiSuccess {String}   Data.chargingStation.light  light
@apiSuccess {String}   Data.chargingStation.url  url

@apiSuccess {Object}   Data.pricing  pricing
@apiSuccess {Number}   Data.pricing.subscription  pricing subscription
@apiSuccess {String}   Data.pricing.currency  pricing currency
@apiSuccess {Object}   Data.pricing.buy  pricing buy
@apiSuccess {Number}   Data.pricing.buy.material  pricing buy material
@apiSuccess {Number}   Data.pricing.buy.installation  pricing buy installation


 *
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 */


 

 /**
 * @api {put} /HODA/Campaign/:id UpdateHodaCampaign
 * @apiVersion 1.0.0
 * @apiName UpdateHodaCampaign
 * @apiGroup HODA.Campaign
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} id Which Id we need to update the data
 * 
 * @apiParam {Object[]} Request Which package Id we need to get the data
 * @apiParam {String} Request.op Mention the operation to do.
 * @apiParam {String} Request.path Mention the data path to change
 * @apiParam {Object} Request.value Mention the data value to change ex: any Object
 * 
 * @apiParamExample {json} Request-Example:
 * [
  {
    "op": "add",
    "path": "/description/en_GB",
    "value": "Fortum Solar Package S 8 - CHANGED 222"
  }
]
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 202 Accepted
 *     
{
        "_id": "5a31396eeb59dc00254722e7",
        "kWhPerMonth": 12,
        "campaignId": "NO_HODA_PAKKE1_TYPE_1_20171117",
        "campaignName": "12",
        "power": "3,7kW",
        "type": "Type2",
        "description": {
            "en_GB": "For deg som ønsker trygg og effektiv lading.",
            "nb_NO": "For deg som ønsker trygg og effektiv lading."
        },
        "chargingStation": {
            "modelOfChargingStation": {
                "en_GB": "Charge Amps HALO Wallbox",
                "nb_NO": "Charge Amps HALO Wallbox"
            },
            "description": {
                "en_GB": "Opptil 16 A, opptil 3,7 kW, med Wifi og fastmontert ladekabel på 5,5m",
                "nb_NO": "Opptil 16 A, opptil 3,7 kW, med Wifi og fastmontert ladekabel på 5,5m"
            },
            "url": "https://www.fortum.no/hjemmelading/pakke1"
        },
        "pricing": {
            "buy": {
                "material": 17964,
                "installation": 12
            },
            "currency": "NOK",
            "subscription": 12
        },
        "installation": {
            "optional": {
                "services": [],
                "items": []
            },
            "basic": {
                "services": [
                    {
                        "serviceItemId": "03-03-02-001"
                    }
                ],
                "items": [
                    {
                        "itemId": "03-03-01-001"
                    }
                ]
            }
        },
        "country": "NO",
        "sequence": "11",
        "startDate": "2017-01-01T00:00:00.000Z",
        "endDate": "2018-12-31T00:00:00.000Z",
        "modifiedOn": "2017-12-22T09:03:14.128Z",
        "taxRebate": 200,
        "createdOn": "2017-12-13T14:30:06.028Z",
        "app": "HODA",
        "isVisible": true,
        "isActive": true,
        "plugTypeSelectionRequired": true,
        "additionalFeatures": []
    }
 * @apiSuccess {Object} Data Response Data
@apiSuccess {String} Data._id Mongodb id
@apiSuccess {String} Data.campaignId campaignId
@apiSuccess {String} Data.campaignName campaignName
@apiSuccess {Number} Data.kWhPerMonth kWhPerMonth
@apiSuccess {String} Data.power power
@apiSuccess {String} Data.type type 'Type1', 'Type2', 'NoType'
@apiSuccess {Number} Data.taxRebate taxRebate
@apiSuccess {Boolean} Data.plugTypeSelectionRequired plugTypeSelectionRequired
@apiSuccess {Boolean} Data.isActive isActive
@apiSuccess {Boolean} Data.isVisible isVisible

@apiSuccess {String} Data.startDate startDate
@apiSuccess {String} Data.endDate endDate
@apiSuccess {String} Data.country country 'NO', 'FI'
@apiSuccess {String} Data.sequence sequence 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35
@apiSuccess {String} Data.app app 'HODA'
@apiSuccess {String} Data.modifiedOn modifiedOn
@apiSuccess {String} Data.createdOn createdOn

@apiSuccess {Object} Data.installation installation
@apiSuccess {Object} Data.installation.basic installation basics
@apiSuccess {Object[]} Data.installation.basic.items installation basics
@apiSuccess {String} Data.installation.basic.items.itemId installation basics items itemId
@apiSuccess {Object[]} Data.installation.basic.services installation basics services
@apiSuccess {String} Data.installation.basic.services.serviceItemId installation basics items serviceItemId
@apiSuccess {Object} Data.installation.optional installation optional
@apiSuccess {Object[]} Data.installation.optional.items installation optional
@apiSuccess {String} Data.installation.optional.items.itemId installation optional items itemId
@apiSuccess {Object[]} Data.installation.optional.services installation optional services
@apiSuccess {String} Data.installation.optional.services.serviceItemId installation optional items serviceItemId @apiSuccess {Object[]}   Data.additionalFeatures additionalFeatures name
@apiSuccess {String}   Data.additionalFeatures.en_GB  Name of the additionalFeatures . in english.
@apiSuccess {String}   Data.additionalFeatures.fi_FI   Name of the additionalFeatures. in finnish.
@apiSuccess {String}   Data.additionalFeatures.sv_FI   Name of the additionalFeatures. in sweden.
@apiSuccess {String}   Data.additionalFeatures.sv_SE   Name of the additionalFeatures. in sweden.
@apiSuccess {String}   Data.additionalFeatures.nb_No   Name of the additionalFeatures. in Norway.
@apiSuccess {String}   Data.additionalFeatures.nn_No   Name of the additionalFeatures. in Norway.
@apiSuccess {String}   Data.additionalFeatures.pl_PL   Name of the additionalFeatures. in PL.
@apiSuccess {Object}   Data.description  Description of the Product feature.
@apiSuccess {String}   Data.description.en_GB  Description in english.
@apiSuccess {String}   Data.description.fi_FI  Description in finnish.
@apiSuccess {String}   Data.description.sv_FI  Description in sweden.
@apiSuccess {String}   Data.description.sv_SE  Description in sweden.
@apiSuccess {String}   Data.description.nb_No  Description in Norway.
@apiSuccess {String}   Data.description.nn_No  Description in Norway.
@apiSuccess {String}   Data.description.pl_PL  Description in PL.
@apiSuccess {Object}   Data.chargingStation chargingStation
@apiSuccess {Object}   Data.chargingStation.modelOfChargingStation chargingStation modelOfChargingStation
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.en_GB  Name of the additionalFeatures . in english.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.fi_FI   Name of the modelOfChargingStation in finnish.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.sv_FI   Name of the modelOfChargingStation in sweden.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.sv_SE   Name of the modelOfChargingStation in sweden.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.nb_No   Name of the modelOfChargingStation in Norway.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.nn_No   Name of the modelOfChargingStation in Norway.
@apiSuccess {String}   Data.chargingStation.modelOfChargingStation.pl_PL   Name of the modelOfChargingStation in PL.
@apiSuccess {Object}   Data.chargingStation.description  Description
@apiSuccess {String}   Data.chargingStation.description.en_GB  Description in english.
@apiSuccess {String}   Data.chargingStation.description.fi_FI  Description in finnish.
@apiSuccess {String}   Data.chargingStation.description.sv_FI  Description in sweden.
@apiSuccess {String}   Data.chargingStation.description.sv_SE  Description in sweden.
@apiSuccess {String}   Data.chargingStation.description.nb_No  Description in Norway.
@apiSuccess {String}   Data.chargingStation.description.nn_No  Description in Norway.
@apiSuccess {String}   Data.chargingStation.description.pl_PL  Description in PL.

@apiSuccess {String}   Data.chargingStation.cableLength  cableLength
@apiSuccess {String}   Data.chargingStation.charing  charing
@apiSuccess {String}   Data.chargingStation.voltage  voltage
@apiSuccess {String}   Data.chargingStation.plug  plug
@apiSuccess {String}   Data.chargingStation.weight  weight
@apiSuccess {String}   Data.chargingStation.ipCode  ipCode
@apiSuccess {String}   Data.chargingStation.light  light
@apiSuccess {String}   Data.chargingStation.url  url

@apiSuccess {Object}   Data.pricing  pricing
@apiSuccess {Number}   Data.pricing.subscription  pricing subscription
@apiSuccess {String}   Data.pricing.currency  pricing currency
@apiSuccess {Object}   Data.pricing.buy  pricing buy
@apiSuccess {Number}   Data.pricing.buy.material  pricing buy material
@apiSuccess {Number}   Data.pricing.buy.installation  pricing buy installation


 *
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 */


 /**
 * @api {delete} /VODA/Material?materialId="new one" RemoveVodaMaterial
 * @apiVersion 1.0.0
 * @apiName RemoveVodaMaterial
 * @apiGroup VODA.Material
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} token ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         token:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} _id Which package Id we need to delete the data
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 204 NO CONTENT
 * 
*  @apiErrorExample Error-Response:
*     HTTP/1.1 404 Not Found
*     {
*       "error": "product Fetaure NotFound"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 401 Not Allowed
*     {
*       "error": "productNotFound"
*     }
*/