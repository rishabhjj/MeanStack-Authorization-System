/* eslint-disable */
/**
 * @api {get} /HODA/WorkOrder GetHodaWorkOrders
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName GetHodaWorkOrders
 * @apiGroup HODA.WorkOrder
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         token: "7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *
 * 
 
@apiSuccess {Object[]} Data Response Data
@apiSuccess {String} Data._id Mongodb id
@apiSuccess {Object} Data.ev EV Data
@apiSuccess {String} Data.ev.type EV Data type
@apiSuccess {String} Data.ev.year EV Data year
@apiSuccess {String} Data.ev.description EV Data description
@apiSuccess {Object} Data.customer Customerdata'
@apiSuccess {String} Data.customer.customerId Customer _id
@apiSuccess {String} Data.customer.firstName firstName of the customer
@apiSuccess {String} Data.customer.lastName lastName of the customer
@apiSuccess {String} Data.customer.dateOfBirth dateOfBirth of the customer
@apiSuccess {String} Data.customer.ssn ssn of the customer
@apiSuccess {Object} Data.customer.address Customer address
@apiSuccess {String} Data.customer.address.zip zip
@apiSuccess {String} Data.customer.address.city city
@apiSuccess {String} Data.customer.address.street street
@apiSuccess {String} Data.customer.address.postalPlace postalPlace
@apiSuccess {Object} Data.customer.contactInfo Customer contactInfo
@apiSuccess {String} Data.customer.contactInfo.email email
@apiSuccess {String} Data.customer.contactInfo.phone phone
@apiSuccess {Object} Data.deliverySite Customer deliverySite
@apiSuccess {String} Data.deliverySite.deliverysiteId deliverysiteId
@apiSuccess {String} Data.deliverySite.isDeliverySiteAddressSameAsContactAddress isDeliverySiteAddressSameAsContactAddress ex : Yes, No
@apiSuccess {Object} Data.deliverySite.address Customer deliverySite address
@apiSuccess {String} Data.deliverySite.address.zip zip
@apiSuccess {String} Data.deliverySite.address.city city
@apiSuccess {String} Data.deliverySite.address.street street
@apiSuccess {String} Data.deliverySite.address.postalPlace postalPlace
@apiSuccess {String} Data.contractId contractId
@apiSuccess {String} Data.campaignId campaignId
@apiSuccess {Object[]}   Data.campaignChangeNotes  campaignChangeNotes
@apiSuccess {String}   Data.campaignChangeNotes.note  note
@apiSuccess {String}   Data.campaignChangeNotes.createdBy  createdBy
@apiSuccess {String}   Data.campaignChangeNotes.createdOn  createdOn
@apiSuccess {Object[]}   Data.customerServiceNotes  customerServiceNotes
@apiSuccess {String}   Data.customerServiceNotes.note  note
@apiSuccess {String}   Data.customerServiceNotes.createdBy  createdBy
@apiSuccess {String}   Data.customerServiceNotes.createdOn  createdOn
@apiSuccess {Object[]}   Data.installerNotes  installerNotes
@apiSuccess {String}   Data.installerNotes.note  note
@apiSuccess {String}   Data.installerNotes.createdBy  createdBy
@apiSuccess {String}   Data.installerNotes.createdOn  createdOn
@apiSuccess {Object} Data.installation installation
@apiSuccess {String} Data.installation.installerCompany installation installerCompany
@apiSuccess {String} Data.installation.installer installation installer
@apiSuccess {String} Data.installation.devicePickUpLocation installation devicePickUpLocation
@apiSuccess {String} Data.installation.actualInstallationDateTime installation actualInstallationDateTime
@apiSuccess {Object} Data.installation.agreedVisitScheduleRange installation agreedVisitScheduleRange
@apiSuccess {String} Data.installation.agreedVisitScheduleRange.startDate installation agreedVisitScheduleRange startDate
@apiSuccess {String} Data.installation.agreedVisitScheduleRange.endDate installation agreedVisitScheduleRange endDate
@apiSuccess {String} Data.installation.agreedVisitScheduleRange.endDate installation agreedVisitScheduleRange endDate
@apiSuccess {String} Data.installation.agreedVisitScheduleRange.endTime installation agreedVisitScheduleRange endTime
@apiSuccess {String} Data.installation.agreedVisitScheduleRange.startTime installation agreedVisitScheduleRange startTime
@apiSuccess {String} Data.plugType plugType 'Type1', 'Type2', 'NoType'
@apiSuccess {Object} Data.siteInfo siteInfo
@apiSuccess {Number} Data.siteInfo.totalCablingDistance siteInfo totalCablingDistance
@apiSuccess {Number} Data.siteInfo.outsideCablingDistance siteInfo outsideCablingDistance
@apiSuccess {Number} Data.siteInfo.numberOfInlets siteInfo numberOfInlets
@apiSuccess {String} Data.siteInfo.cabling siteInfo cabling 'InsideOrSurface', 'Outside', 'CustomerTakesCare'
@apiSuccess {String} Data.siteInfo.groundSurface siteInfo groundSurface 'OpenGround', 'Tiling', 'Tarmac'
@apiSuccess {String} Data.siteInfo.wallMaterial siteInfo wallMaterial
@apiSuccess {String} Data.siteInfo.description siteInfo description
@apiSuccess {String} Data.siteInfo.excavation siteInfo excavation  'fortum', 'customer'
@apiSuccess {Boolean} Data.siteInfo.isMountingLocationAwayFromHouse siteInfo isMountingLocationAwayFromHouse
@apiSuccess {Object} Data.assets assets
@apiSuccess {String} Data.assets.itemId assets itemId
@apiSuccess {String} Data.assets.itemDescription assets itemDescription
@apiSuccess {String} Data.assets.serialNumber assets serialNumber

@apiSuccess {Object} Data.partnerServices partnerServicessets
@apiSuccess {Number} Data.partnerServices.installationTime installationTime
@apiSuccess {Number} Data.partnerServices.connectionTime connectionTime
@apiSuccess {Number} Data.partnerServices.cablingTime cablingTime

@apiSuccess {Object} Data.pricing pricing
@apiSuccess {Number} Data.pricing.paymentPlan paymentPlan
@apiSuccess {Number} Data.pricing.currency currency 'EUR', 'Kr', 'NOK', 'PLN'
@apiSuccess {Object} Data.pricing.buy buy
@apiSuccess {String} Data.pricing.buy.buyType buyType
@apiSuccess {Number} Data.pricing.buy.package package
@apiSuccess {Number} Data.pricing.buy.package package
@apiSuccess {Number} Data.pricing.buy.numberOfMonthlyInstallments numberOfMonthlyInstallments
@apiSuccess {Object} Data.pricing.buy.installmentComponents installmentComponents
@apiSuccess {Boolean} Data.pricing.buy.installmentComponents.material installmentCmaterialomponents
@apiSuccess {Boolean} Data.pricing.buy.installmentComponents.installation installation
@apiSuccess {Boolean} Data.pricing.buy.installmentComponents.extraMaterial extraMaterial
@apiSuccess {Boolean} Data.pricing.buy.installmentComponents.extraWork extraWork

@apiSuccess {Object} Data.pricing.subscription subscription
@apiSuccess {Number} Data.pricing.subscription.fee fee
@apiSuccess {String} Data.pricing.subscription.paymentCycle paymentCycle

@apiSuccess {Object[]} Data.pricing.discounts discounts
@apiSuccess {Number} Data.pricing.discounts.amount amount
@apiSuccess {String} Data.pricing.discounts.code code
@apiSuccess {String} Data.pricing.discounts.addedBy addedBy

@apiSuccess {Object} Data.pricing.extraItemsAndServices extraItemsAndServices
@apiSuccess {Object} Data.pricing.extraItemsAndServices.items items
@apiSuccess {String} Data.pricing.extraItemsAndServices.items.itemId itemId
@apiSuccess {Number} Data.pricing.extraItemsAndServices.items.units units
@apiSuccess {Number} Data.pricing.extraItemsAndServices.items.costPerUnit costPerUnit
@apiSuccess {Number} Data.pricing.extraItemsAndServices.items.totalAmount totalAmount
@apiSuccess {Object} Data.pricing.extraItemsAndServices.services services
@apiSuccess {String} Data.pricing.extraItemsAndServices.services.serviceItemId serviceItemId
@apiSuccess {Number} Data.pricing.extraItemsAndServices.services.amount amount
@apiSuccess {String} Data.pricing.extraItemsAndServices.services.description description

@apiSuccess {String}   Data.status  status
@apiSuccess {String}   Data.statebeforecancelled  statebeforecancelled
@apiSuccess {String}   Data.status  status
@apiSuccess {String}   Data.statebeforecancelled  statebeforecancelled
@apiSuccess {String}   Data.statusChangeOn  statusChangeOn
@apiSuccess {String}   Data.sentToInstallerOn  sentToInstallerOn
@apiSuccess {String}   Data.ts_tc_gdpr  ts_tc_gdpr
@apiSuccess {String}   Data.isExcavationPrice  isExcavationPrice
@apiSuccess {String}   Data.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
@apiSuccess {String}   Data.app   App name 'VODA'
@apiSuccess {String}   Data.createdOn   Created date
@apiSuccess {String}   Data.modifiedOn   modifiedOn date
@apiSuccess {String}   Data.createdBy  createdBy
@apiSuccess {String}   Data.createdByUserRole  createdByUserRole

 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
[
    {
        "_id": "5a41fe091886480025c5d747",
        "hodaOrderNumber": 1753,
        "modifiedOn": "2017-12-26T07:46:13.971Z",
        "createdByUserRole": "CUSTOMER",
        "createdBy": "Anonymous",
        "country": "NO",
        "ev": {
            "type": "bmwi3",
            "year": "2017",
            "description": "BMW i3"
        },
        "deliverySite": {
            "isDeliverySiteAddressSameAsContactAddress": "Yes",
            "address": {
                "street": "TEST",
                "city": "123",
                "zip": "1234"
            },
            "buildingType": "VillaOrSemiDetached"
        },
        "customer": {
            "customerId": "",
            "firstName": "TEST",
            "lastName": "NAME",
            "ssn": "",
            "dateOfBirth": "2017-12-25T18:30:00.000Z",
            "address": {
                "street": "TEST",
                "city": "123",
                "zip": "1234"
            },
            "contactInfo": {
                "phone": "123",
                "email": "123@email.com"
            }
        },
        "campaignId": "NO_HODA_PAKKE1_NO_TYPE_20171117",
        "plugType": "NoType",
        "pricing": {
            "currency": "NOK",
            "paymentPlan": "Buy",
            "buy": {
                "buyType": "INSTALLMENT",
                "package": 17964,
                "installation": 12,
                "numberOfMonthlyInstallments": 24
            },
            "discounts": [
                {
                    "code": "NONE",
                    "amount": 0
                }
            ]
        },
        "ts_tc_gdpr": "AGREE",
        "statusChangeOn": "2017-12-26T07:46:13.971Z",
        "createdOn": "2017-12-26T07:45:13.246Z",
        "isExcavationPrice": false,
        "app": "HODA",
        "status": "ValidOrder",
        "partnerServices": {},
        "assets": [
            {}
        ],
        "siteInfo": {
            "description": "12",
            "groundSurface": "OpenGround",
            "isMountingLocationAwayFromHouse": true,
            "outsideCablingDistance": 12,
            "totalCablingDistance": 12
        },
        "installerNotes": [],
        "customerServiceNotes": [],
        "campaignChangeNotes": []
    }
]
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 400 Not Found
 *     {
 *       "error": "_id not found"
 *     }
 * * @apiErrorExample Error-Response:
 * HTTP/1.1 403 Invalid Role
 *     {
 *       "error": "Invalid Role"
 *     }
 * 
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 Mongodb-error
 *     {
 *       "error": "Error occured"
 *     }
 * 
 */


 /**
 * @api {post} /HODA/WorkOrders SaveHodaWorkOrder
 * @apiVersion 1.0.0
 * @apiName SaveHodaWorkOrder
 * @apiGroup HODA.WorkOrder
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 
 * 
@apiParam {Object[]} Data Response Data
@apiParam {String} Data._id Mongodb id
@apiParam {Object} Data.ev EV Data
@apiParam {String} Data.ev.type EV Data type
@apiParam {String} Data.ev.year EV Data year
@apiParam {String} Data.ev.description EV Data description
@apiParam {Object} Data.customer Customerdata'
@apiParam {String} Data.customer.customerId Customer _id
@apiParam {String} Data.customer.firstName firstName of the customer
@apiParam {String} Data.customer.lastName lastName of the customer
@apiParam {String} Data.customer.dateOfBirth dateOfBirth of the customer
@apiParam {String} Data.customer.ssn ssn of the customer
@apiParam {Object} Data.customer.address Customer address
@apiParam {String} Data.customer.address.zip zip
@apiParam {String} Data.customer.address.city city
@apiParam {String} Data.customer.address.street street
@apiParam {String} Data.customer.address.postalPlace postalPlace
@apiParam {Object} Data.customer.contactInfo Customer contactInfo
@apiParam {String} Data.customer.contactInfo.email email
@apiParam {String} Data.customer.contactInfo.phone phone
@apiParam {Object} Data.deliverySite Customer deliverySite
@apiParam {String} Data.deliverySite.deliverysiteId deliverysiteId
@apiParam {String} Data.deliverySite.isDeliverySiteAddressSameAsContactAddress isDeliverySiteAddressSameAsContactAddress ex : Yes, No
@apiParam {Object} Data.deliverySite.address Customer deliverySite address
@apiParam {String} Data.deliverySite.address.zip zip
@apiParam {String} Data.deliverySite.address.city city
@apiParam {String} Data.deliverySite.address.street street
@apiParam {String} Data.deliverySite.address.postalPlace postalPlace
@apiParam {String} Data.contractId contractId
@apiParam {String} Data.campaignId campaignId
@apiParam {Object[]}   Data.campaignChangeNotes  campaignChangeNotes
@apiParam {String}   Data.campaignChangeNotes.note  note
@apiParam {String}   Data.campaignChangeNotes.createdBy  createdBy
@apiParam {String}   Data.campaignChangeNotes.createdOn  createdOn
@apiParam {Object[]}   Data.customerServiceNotes  customerServiceNotes
@apiParam {String}   Data.customerServiceNotes.note  note
@apiParam {String}   Data.customerServiceNotes.createdBy  createdBy
@apiParam {String}   Data.customerServiceNotes.createdOn  createdOn
@apiParam {Object[]}   Data.installerNotes  installerNotes
@apiParam {String}   Data.installerNotes.note  note
@apiParam {String}   Data.installerNotes.createdBy  createdBy
@apiParam {String}   Data.installerNotes.createdOn  createdOn
@apiParam {Object} Data.installation installation
@apiParam {String} Data.installation.installerCompany installation installerCompany
@apiParam {String} Data.installation.installer installation installer
@apiParam {String} Data.installation.devicePickUpLocation installation devicePickUpLocation
@apiParam {String} Data.installation.actualInstallationDateTime installation actualInstallationDateTime
@apiParam {Object} Data.installation.agreedVisitScheduleRange installation agreedVisitScheduleRange
@apiParam {String} Data.installation.agreedVisitScheduleRange.startDate installation agreedVisitScheduleRange startDate
@apiParam {String} Data.installation.agreedVisitScheduleRange.endDate installation agreedVisitScheduleRange endDate
@apiParam {String} Data.installation.agreedVisitScheduleRange.endDate installation agreedVisitScheduleRange endDate
@apiParam {String} Data.installation.agreedVisitScheduleRange.endTime installation agreedVisitScheduleRange endTime
@apiParam {String} Data.installation.agreedVisitScheduleRange.startTime installation agreedVisitScheduleRange startTime
@apiParam {String} Data.plugType plugType 'Type1', 'Type2', 'NoType'
@apiParam {Object} Data.siteInfo siteInfo
@apiParam {Number} Data.siteInfo.totalCablingDistance siteInfo totalCablingDistance
@apiParam {Number} Data.siteInfo.outsideCablingDistance siteInfo outsideCablingDistance
@apiParam {Number} Data.siteInfo.numberOfInlets siteInfo numberOfInlets
@apiParam {String} Data.siteInfo.cabling siteInfo cabling 'InsideOrSurface', 'Outside', 'CustomerTakesCare'
@apiParam {String} Data.siteInfo.groundSurface siteInfo groundSurface 'OpenGround', 'Tiling', 'Tarmac'
@apiParam {String} Data.siteInfo.wallMaterial siteInfo wallMaterial
@apiParam {String} Data.siteInfo.description siteInfo description
@apiParam {String} Data.siteInfo.excavation siteInfo excavation  'fortum', 'customer'
@apiParam {Boolean} Data.siteInfo.isMountingLocationAwayFromHouse siteInfo isMountingLocationAwayFromHouse
@apiParam {Object} Data.assets assets
@apiParam {String} Data.assets.itemId assets itemId
@apiParam {String} Data.assets.itemDescription assets itemDescription
@apiParam {String} Data.assets.serialNumber assets serialNumber

@apiParam {Object} Data.partnerServices partnerServicessets
@apiParam {Number} Data.partnerServices.installationTime installationTime
@apiParam {Number} Data.partnerServices.connectionTime connectionTime
@apiParam {Number} Data.partnerServices.cablingTime cablingTime

@apiParam {Object} Data.pricing pricing
@apiParam {Number} Data.pricing.paymentPlan paymentPlan
@apiParam {Number} Data.pricing.currency currency 'EUR', 'Kr', 'NOK', 'PLN'
@apiParam {Object} Data.pricing.buy buy
@apiParam {String} Data.pricing.buy.buyType buyType
@apiParam {Number} Data.pricing.buy.package package
@apiParam {Number} Data.pricing.buy.package package
@apiParam {Number} Data.pricing.buy.numberOfMonthlyInstallments numberOfMonthlyInstallments
@apiParam {Object} Data.pricing.buy.installmentComponents installmentComponents
@apiParam {Boolean} Data.pricing.buy.installmentComponents.material installmentCmaterialomponents
@apiParam {Boolean} Data.pricing.buy.installmentComponents.installation installation
@apiParam {Boolean} Data.pricing.buy.installmentComponents.extraMaterial extraMaterial
@apiParam {Boolean} Data.pricing.buy.installmentComponents.extraWork extraWork

@apiParam {Object} Data.pricing.subscription subscription
@apiParam {Number} Data.pricing.subscription.fee fee
@apiParam {String} Data.pricing.subscription.paymentCycle paymentCycle

@apiParam {Object[]} Data.pricing.discounts discounts
@apiParam {Number} Data.pricing.discounts.amount amount
@apiParam {String} Data.pricing.discounts.code code
@apiParam {String} Data.pricing.discounts.addedBy addedBy

@apiParam {Object} Data.pricing.extraItemsAndServices extraItemsAndServices
@apiParam {Object} Data.pricing.extraItemsAndServices.items items
@apiParam {String} Data.pricing.extraItemsAndServices.items.itemId itemId
@apiParam {Number} Data.pricing.extraItemsAndServices.items.units units
@apiParam {Number} Data.pricing.extraItemsAndServices.items.costPerUnit costPerUnit
@apiParam {Number} Data.pricing.extraItemsAndServices.items.totalAmount totalAmount
@apiParam {Object} Data.pricing.extraItemsAndServices.services services
@apiParam {String} Data.pricing.extraItemsAndServices.services.serviceItemId serviceItemId
@apiParam {Number} Data.pricing.extraItemsAndServices.services.amount amount
@apiParam {String} Data.pricing.extraItemsAndServices.services.description description


@apiParam {String}   Data.status  status
@apiParam {String}   Data.statebeforecancelled  statebeforecancelled
@apiParam {String}   Data.statusChangeOn  statusChangeOn
@apiParam {String}   Data.sentToInstallerOn  sentToInstallerOn
@apiParam {String}   Data.ts_tc_gdpr  ts_tc_gdpr
@apiParam {String}   Data.isExcavationPrice  isExcavationPrice


 * 
 * @apiParamExample {json} Request-Example:
 * {
        "_id": "5a41fe091886480025c5d747",
        "hodaOrderNumber": 1753,
        "modifiedOn": "2017-12-26T07:46:13.971Z",
        "createdByUserRole": "CUSTOMER",
        "createdBy": "Anonymous",
        "country": "NO",
        "ev": {
            "type": "bmwi3",
            "year": "2017",
            "description": "BMW i3"
        },
        "deliverySite": {
            "isDeliverySiteAddressSameAsContactAddress": "Yes",
            "address": {
                "street": "TEST",
                "city": "123",
                "zip": "1234"
            },
            "buildingType": "VillaOrSemiDetached"
        },
        "customer": {
            "customerId": "",
            "firstName": "TEST",
            "lastName": "NAME",
            "ssn": "",
            "dateOfBirth": "2017-12-25T18:30:00.000Z",
            "address": {
                "street": "TEST",
                "city": "123",
                "zip": "1234"
            },
            "contactInfo": {
                "phone": "123",
                "email": "123@email.com"
            }
        },
        "campaignId": "NO_HODA_PAKKE1_NO_TYPE_20171117",
        "plugType": "NoType",
        "pricing": {
            "currency": "NOK",
            "paymentPlan": "Buy",
            "buy": {
                "buyType": "INSTALLMENT",
                "package": 17964,
                "installation": 12,
                "numberOfMonthlyInstallments": 24
            },
            "discounts": [
                {
                    "code": "NONE",
                    "amount": 0
                }
            ]
        },
        "ts_tc_gdpr": "AGREE",
        "statusChangeOn": "2017-12-26T07:46:13.971Z",
        "createdOn": "2017-12-26T07:45:13.246Z",
        "isExcavationPrice": false,
        "app": "HODA",
        "status": "ValidOrder",
        "partnerServices": {},
        "assets": [
            {}
        ],
        "siteInfo": {
            "description": "12",
            "groundSurface": "OpenGround",
            "isMountingLocationAwayFromHouse": true,
            "outsideCablingDistance": 12,
            "totalCablingDistance": 12
        },
        "installerNotes": [],
        "customerServiceNotes": [],
        "campaignChangeNotes": []
    }


 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
{
        "_id": "5a41fe091886480025c5d747",
        "hodaOrderNumber": 1753,
        "modifiedOn": "2017-12-26T07:46:13.971Z",
        "createdByUserRole": "CUSTOMER",
        "createdBy": "Anonymous",
        "country": "NO",
        "ev": {
            "type": "bmwi3",
            "year": "2017",
            "description": "BMW i3"
        },
        "deliverySite": {
            "isDeliverySiteAddressSameAsContactAddress": "Yes",
            "address": {
                "street": "TEST",
                "city": "123",
                "zip": "1234"
            },
            "buildingType": "VillaOrSemiDetached"
        },
        "customer": {
            "customerId": "",
            "firstName": "TEST",
            "lastName": "NAME",
            "ssn": "",
            "dateOfBirth": "2017-12-25T18:30:00.000Z",
            "address": {
                "street": "TEST",
                "city": "123",
                "zip": "1234"
            },
            "contactInfo": {
                "phone": "123",
                "email": "123@email.com"
            }
        },
        "campaignId": "NO_HODA_PAKKE1_NO_TYPE_20171117",
        "plugType": "NoType",
        "pricing": {
            "currency": "NOK",
            "paymentPlan": "Buy",
            "buy": {
                "buyType": "INSTALLMENT",
                "package": 17964,
                "installation": 12,
                "numberOfMonthlyInstallments": 24
            },
            "discounts": [
                {
                    "code": "NONE",
                    "amount": 0
                }
            ]
        },
        "ts_tc_gdpr": "AGREE",
        "statusChangeOn": "2017-12-26T07:46:13.971Z",
        "createdOn": "2017-12-26T07:45:13.246Z",
        "isExcavationPrice": false,
        "app": "HODA",
        "status": "ValidOrder",
        "partnerServices": {},
        "assets": [
            {}
        ],
        "siteInfo": {
            "description": "12",
            "groundSurface": "OpenGround",
            "isMountingLocationAwayFromHouse": true,
            "outsideCablingDistance": 12,
            "totalCablingDistance": 12
        },
        "installerNotes": [],
        "customerServiceNotes": [],
        "campaignChangeNotes": []
    }
 * 
@apiSuccess {Object} Data Response Data
@apiSuccess {String} Data._id Mongodb id
@apiSuccess {Object} Data.ev EV Data
@apiSuccess {String} Data.ev.type EV Data type
@apiSuccess {String} Data.ev.year EV Data year
@apiSuccess {String} Data.ev.description EV Data description
@apiSuccess {Object} Data.customer Customerdata'
@apiSuccess {String} Data.customer.customerId Customer _id
@apiSuccess {String} Data.customer.firstName firstName of the customer
@apiSuccess {String} Data.customer.lastName lastName of the customer
@apiSuccess {String} Data.customer.dateOfBirth dateOfBirth of the customer
@apiSuccess {String} Data.customer.ssn ssn of the customer
@apiSuccess {Object} Data.customer.address Customer address
@apiSuccess {String} Data.customer.address.zip zip
@apiSuccess {String} Data.customer.address.city city
@apiSuccess {String} Data.customer.address.street street
@apiSuccess {String} Data.customer.address.postalPlace postalPlace
@apiSuccess {Object} Data.customer.contactInfo Customer contactInfo
@apiSuccess {String} Data.customer.contactInfo.email email
@apiSuccess {String} Data.customer.contactInfo.phone phone
@apiSuccess {Object} Data.deliverySite Customer deliverySite
@apiSuccess {String} Data.deliverySite.deliverysiteId deliverysiteId
@apiSuccess {String} Data.deliverySite.isDeliverySiteAddressSameAsContactAddress isDeliverySiteAddressSameAsContactAddress ex : Yes, No
@apiSuccess {Object} Data.deliverySite.address Customer deliverySite address
@apiSuccess {String} Data.deliverySite.address.zip zip
@apiSuccess {String} Data.deliverySite.address.city city
@apiSuccess {String} Data.deliverySite.address.street street
@apiSuccess {String} Data.deliverySite.address.postalPlace postalPlace
@apiSuccess {String} Data.contractId contractId
@apiSuccess {String} Data.campaignId campaignId
@apiSuccess {Object[]}   Data.campaignChangeNotes  campaignChangeNotes
@apiSuccess {String}   Data.campaignChangeNotes.note  note
@apiSuccess {String}   Data.campaignChangeNotes.createdBy  createdBy
@apiSuccess {String}   Data.campaignChangeNotes.createdOn  createdOn
@apiSuccess {Object[]}   Data.customerServiceNotes  customerServiceNotes
@apiSuccess {String}   Data.customerServiceNotes.note  note
@apiSuccess {String}   Data.customerServiceNotes.createdBy  createdBy
@apiSuccess {String}   Data.customerServiceNotes.createdOn  createdOn
@apiSuccess {Object[]}   Data.installerNotes  installerNotes
@apiSuccess {String}   Data.installerNotes.note  note
@apiSuccess {String}   Data.installerNotes.createdBy  createdBy
@apiSuccess {String}   Data.installerNotes.createdOn  createdOn
@apiSuccess {Object} Data.installation installation
@apiSuccess {String} Data.installation.installerCompany installation installerCompany
@apiSuccess {String} Data.installation.installer installation installer
@apiSuccess {String} Data.installation.devicePickUpLocation installation devicePickUpLocation
@apiSuccess {String} Data.installation.actualInstallationDateTime installation actualInstallationDateTime
@apiSuccess {Object} Data.installation.agreedVisitScheduleRange installation agreedVisitScheduleRange
@apiSuccess {String} Data.installation.agreedVisitScheduleRange.startDate installation agreedVisitScheduleRange startDate
@apiSuccess {String} Data.installation.agreedVisitScheduleRange.endDate installation agreedVisitScheduleRange endDate
@apiSuccess {String} Data.installation.agreedVisitScheduleRange.endDate installation agreedVisitScheduleRange endDate
@apiSuccess {String} Data.installation.agreedVisitScheduleRange.endTime installation agreedVisitScheduleRange endTime
@apiSuccess {String} Data.installation.agreedVisitScheduleRange.startTime installation agreedVisitScheduleRange startTime
@apiSuccess {String} Data.plugType plugType 'Type1', 'Type2', 'NoType'
@apiSuccess {Object} Data.siteInfo siteInfo
@apiSuccess {Number} Data.siteInfo.totalCablingDistance siteInfo totalCablingDistance
@apiSuccess {Number} Data.siteInfo.outsideCablingDistance siteInfo outsideCablingDistance
@apiSuccess {Number} Data.siteInfo.numberOfInlets siteInfo numberOfInlets
@apiSuccess {String} Data.siteInfo.cabling siteInfo cabling 'InsideOrSurface', 'Outside', 'CustomerTakesCare'
@apiSuccess {String} Data.siteInfo.groundSurface siteInfo groundSurface 'OpenGround', 'Tiling', 'Tarmac'
@apiSuccess {String} Data.siteInfo.wallMaterial siteInfo wallMaterial
@apiSuccess {String} Data.siteInfo.description siteInfo description
@apiSuccess {String} Data.siteInfo.excavation siteInfo excavation  'fortum', 'customer'
@apiSuccess {Boolean} Data.siteInfo.isMountingLocationAwayFromHouse siteInfo isMountingLocationAwayFromHouse
@apiSuccess {Object} Data.assets assets
@apiSuccess {String} Data.assets.itemId assets itemId
@apiSuccess {String} Data.assets.itemDescription assets itemDescription
@apiSuccess {String} Data.assets.serialNumber assets serialNumber

@apiSuccess {Object} Data.partnerServices partnerServicessets
@apiSuccess {Number} Data.partnerServices.installationTime installationTime
@apiSuccess {Number} Data.partnerServices.connectionTime connectionTime
@apiSuccess {Number} Data.partnerServices.cablingTime cablingTime

@apiSuccess {Object} Data.pricing pricing
@apiSuccess {Number} Data.pricing.paymentPlan paymentPlan
@apiSuccess {Number} Data.pricing.currency currency 'EUR', 'Kr', 'NOK', 'PLN'
@apiSuccess {Object} Data.pricing.buy buy
@apiSuccess {String} Data.pricing.buy.buyType buyType
@apiSuccess {Number} Data.pricing.buy.package package
@apiSuccess {Number} Data.pricing.buy.package package
@apiSuccess {Number} Data.pricing.buy.numberOfMonthlyInstallments numberOfMonthlyInstallments
@apiSuccess {Object} Data.pricing.buy.installmentComponents installmentComponents
@apiSuccess {Boolean} Data.pricing.buy.installmentComponents.material installmentCmaterialomponents
@apiSuccess {Boolean} Data.pricing.buy.installmentComponents.installation installation
@apiSuccess {Boolean} Data.pricing.buy.installmentComponents.extraMaterial extraMaterial
@apiSuccess {Boolean} Data.pricing.buy.installmentComponents.extraWork extraWork

@apiSuccess {Object} Data.pricing.subscription subscription
@apiSuccess {Number} Data.pricing.subscription.fee fee
@apiSuccess {String} Data.pricing.subscription.paymentCycle paymentCycle

@apiSuccess {Object[]} Data.pricing.discounts discounts
@apiSuccess {Number} Data.pricing.discounts.amount amount
@apiSuccess {String} Data.pricing.discounts.code code
@apiSuccess {String} Data.pricing.discounts.addedBy addedBy

@apiSuccess {Object} Data.pricing.extraItemsAndServices extraItemsAndServices
@apiSuccess {Object} Data.pricing.extraItemsAndServices.items items
@apiSuccess {String} Data.pricing.extraItemsAndServices.items.itemId itemId
@apiSuccess {Number} Data.pricing.extraItemsAndServices.items.units units
@apiSuccess {Number} Data.pricing.extraItemsAndServices.items.costPerUnit costPerUnit
@apiSuccess {Number} Data.pricing.extraItemsAndServices.items.totalAmount totalAmount
@apiSuccess {Object} Data.pricing.extraItemsAndServices.services services
@apiSuccess {String} Data.pricing.extraItemsAndServices.services.serviceItemId serviceItemId
@apiSuccess {Number} Data.pricing.extraItemsAndServices.services.amount amount
@apiSuccess {String} Data.pricing.extraItemsAndServices.services.description description

@apiSuccess {String}   Data.status  status
@apiSuccess {String}   Data.statebeforecancelled  statebeforecancelled
@apiSuccess {String}   Data.status  status
@apiSuccess {String}   Data.statebeforecancelled  statebeforecancelled
@apiSuccess {String}   Data.statusChangeOn  statusChangeOn
@apiSuccess {String}   Data.sentToInstallerOn  sentToInstallerOn
@apiSuccess {String}   Data.ts_tc_gdpr  ts_tc_gdpr
@apiSuccess {String}   Data.isExcavationPrice  isExcavationPrice
@apiSuccess {String}   Data.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
@apiSuccess {String}   Data.app   App name 'VODA'
@apiSuccess {String}   Data.createdOn   Created date
@apiSuccess {String}   Data.modifiedOn   modifiedOn date
@apiSuccess {String}   Data.createdBy  createdBy
@apiSuccess {String}   Data.createdByUserRole  createdByUserRole


 *
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 */


 

 /**
 * @api {put} /HODA/:id UpdateHodaWorkOrders
 * @apiVersion 1.0.0
 * @apiName UpdateHodaWorkOrders
 * @apiGroup HODA.WorkOrder
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} id Which Id we need to update the data
 * 
 * @apiParam {Object[]} Request Which package Id we need to get the data
 * @apiParam {String} Request.op Mention the operation to do.
 * @apiParam {String} Request.path Mention the data path to change
 * @apiParam {Object} Request.value Mention the data value to change ex: any Object
 * 
 * @apiParamExample {json} Request-Example:
 * [
  {
    "op": "add",
    "path": "/ev/type",
    "value": "Fortum Solar Package S 8 - CHANGED 222"
  }
]
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 202 Accepted
 *  
{
        "_id": "5a41fe091886480025c5d747",
        "hodaOrderNumber": 1753,
        "modifiedOn": "2017-12-26T07:46:13.971Z",
        "createdByUserRole": "CUSTOMER",
        "createdBy": "Anonymous",
        "country": "NO",
        "ev": {
            "type": "bmwi3",
            "year": "2017",
            "description": "BMW i3"
        },
        "deliverySite": {
            "isDeliverySiteAddressSameAsContactAddress": "Yes",
            "address": {
                "street": "TEST",
                "city": "123",
                "zip": "1234"
            },
            "buildingType": "VillaOrSemiDetached"
        },
        "customer": {
            "customerId": "",
            "firstName": "TEST",
            "lastName": "NAME",
            "ssn": "",
            "dateOfBirth": "2017-12-25T18:30:00.000Z",
            "address": {
                "street": "TEST",
                "city": "123",
                "zip": "1234"
            },
            "contactInfo": {
                "phone": "123",
                "email": "123@email.com"
            }
        },
        "campaignId": "NO_HODA_PAKKE1_NO_TYPE_20171117",
        "plugType": "NoType",
        "pricing": {
            "currency": "NOK",
            "paymentPlan": "Buy",
            "buy": {
                "buyType": "INSTALLMENT",
                "package": 17964,
                "installation": 12,
                "numberOfMonthlyInstallments": 24
            },
            "discounts": [
                {
                    "code": "NONE",
                    "amount": 0
                }
            ]
        },
        "ts_tc_gdpr": "AGREE",
        "statusChangeOn": "2017-12-26T07:46:13.971Z",
        "createdOn": "2017-12-26T07:45:13.246Z",
        "isExcavationPrice": false,
        "app": "HODA",
        "status": "ValidOrder",
        "partnerServices": {},
        "assets": [
            {}
        ],
        "siteInfo": {
            "description": "12",
            "groundSurface": "OpenGround",
            "isMountingLocationAwayFromHouse": true,
            "outsideCablingDistance": 12,
            "totalCablingDistance": 12
        },
        "installerNotes": [],
        "customerServiceNotes": [],
        "campaignChangeNotes": []
    }
 * 
@apiSuccess {Object} Data Response Data
@apiSuccess {String} Data._id Mongodb id
@apiSuccess {Object} Data.ev EV Data
@apiSuccess {String} Data.ev.type EV Data type
@apiSuccess {String} Data.ev.year EV Data year
@apiSuccess {String} Data.ev.description EV Data description
@apiSuccess {Object} Data.customer Customerdata'
@apiSuccess {String} Data.customer.customerId Customer _id
@apiSuccess {String} Data.customer.firstName firstName of the customer
@apiSuccess {String} Data.customer.lastName lastName of the customer
@apiSuccess {String} Data.customer.dateOfBirth dateOfBirth of the customer
@apiSuccess {String} Data.customer.ssn ssn of the customer
@apiSuccess {Object} Data.customer.address Customer address
@apiSuccess {String} Data.customer.address.zip zip
@apiSuccess {String} Data.customer.address.city city
@apiSuccess {String} Data.customer.address.street street
@apiSuccess {String} Data.customer.address.postalPlace postalPlace
@apiSuccess {Object} Data.customer.contactInfo Customer contactInfo
@apiSuccess {String} Data.customer.contactInfo.email email
@apiSuccess {String} Data.customer.contactInfo.phone phone
@apiSuccess {Object} Data.deliverySite Customer deliverySite
@apiSuccess {String} Data.deliverySite.deliverysiteId deliverysiteId
@apiSuccess {String} Data.deliverySite.isDeliverySiteAddressSameAsContactAddress isDeliverySiteAddressSameAsContactAddress ex : Yes, No
@apiSuccess {Object} Data.deliverySite.address Customer deliverySite address
@apiSuccess {String} Data.deliverySite.address.zip zip
@apiSuccess {String} Data.deliverySite.address.city city
@apiSuccess {String} Data.deliverySite.address.street street
@apiSuccess {String} Data.deliverySite.address.postalPlace postalPlace
@apiSuccess {String} Data.contractId contractId
@apiSuccess {String} Data.campaignId campaignId
@apiSuccess {Object[]}   Data.campaignChangeNotes  campaignChangeNotes
@apiSuccess {String}   Data.campaignChangeNotes.note  note
@apiSuccess {String}   Data.campaignChangeNotes.createdBy  createdBy
@apiSuccess {String}   Data.campaignChangeNotes.createdOn  createdOn
@apiSuccess {Object[]}   Data.customerServiceNotes  customerServiceNotes
@apiSuccess {String}   Data.customerServiceNotes.note  note
@apiSuccess {String}   Data.customerServiceNotes.createdBy  createdBy
@apiSuccess {String}   Data.customerServiceNotes.createdOn  createdOn
@apiSuccess {Object[]}   Data.installerNotes  installerNotes
@apiSuccess {String}   Data.installerNotes.note  note
@apiSuccess {String}   Data.installerNotes.createdBy  createdBy
@apiSuccess {String}   Data.installerNotes.createdOn  createdOn
@apiSuccess {Object} Data.installation installation
@apiSuccess {String} Data.installation.installerCompany installation installerCompany
@apiSuccess {String} Data.installation.installer installation installer
@apiSuccess {String} Data.installation.devicePickUpLocation installation devicePickUpLocation
@apiSuccess {String} Data.installation.actualInstallationDateTime installation actualInstallationDateTime
@apiSuccess {Object} Data.installation.agreedVisitScheduleRange installation agreedVisitScheduleRange
@apiSuccess {String} Data.installation.agreedVisitScheduleRange.startDate installation agreedVisitScheduleRange startDate
@apiSuccess {String} Data.installation.agreedVisitScheduleRange.endDate installation agreedVisitScheduleRange endDate
@apiSuccess {String} Data.installation.agreedVisitScheduleRange.endDate installation agreedVisitScheduleRange endDate
@apiSuccess {String} Data.installation.agreedVisitScheduleRange.endTime installation agreedVisitScheduleRange endTime
@apiSuccess {String} Data.installation.agreedVisitScheduleRange.startTime installation agreedVisitScheduleRange startTime
@apiSuccess {String} Data.plugType plugType 'Type1', 'Type2', 'NoType'
@apiSuccess {Object} Data.siteInfo siteInfo
@apiSuccess {Number} Data.siteInfo.totalCablingDistance siteInfo totalCablingDistance
@apiSuccess {Number} Data.siteInfo.outsideCablingDistance siteInfo outsideCablingDistance
@apiSuccess {Number} Data.siteInfo.numberOfInlets siteInfo numberOfInlets
@apiSuccess {String} Data.siteInfo.cabling siteInfo cabling 'InsideOrSurface', 'Outside', 'CustomerTakesCare'
@apiSuccess {String} Data.siteInfo.groundSurface siteInfo groundSurface 'OpenGround', 'Tiling', 'Tarmac'
@apiSuccess {String} Data.siteInfo.wallMaterial siteInfo wallMaterial
@apiSuccess {String} Data.siteInfo.description siteInfo description
@apiSuccess {String} Data.siteInfo.excavation siteInfo excavation  'fortum', 'customer'
@apiSuccess {Boolean} Data.siteInfo.isMountingLocationAwayFromHouse siteInfo isMountingLocationAwayFromHouse
@apiSuccess {Object} Data.assets assets
@apiSuccess {String} Data.assets.itemId assets itemId
@apiSuccess {String} Data.assets.itemDescription assets itemDescription
@apiSuccess {String} Data.assets.serialNumber assets serialNumber

@apiSuccess {Object} Data.partnerServices partnerServicessets
@apiSuccess {Number} Data.partnerServices.installationTime installationTime
@apiSuccess {Number} Data.partnerServices.connectionTime connectionTime
@apiSuccess {Number} Data.partnerServices.cablingTime cablingTime

@apiSuccess {Object} Data.pricing pricing
@apiSuccess {Number} Data.pricing.paymentPlan paymentPlan
@apiSuccess {Number} Data.pricing.currency currency 'EUR', 'Kr', 'NOK', 'PLN'
@apiSuccess {Object} Data.pricing.buy buy
@apiSuccess {String} Data.pricing.buy.buyType buyType
@apiSuccess {Number} Data.pricing.buy.package package
@apiSuccess {Number} Data.pricing.buy.package package
@apiSuccess {Number} Data.pricing.buy.numberOfMonthlyInstallments numberOfMonthlyInstallments
@apiSuccess {Object} Data.pricing.buy.installmentComponents installmentComponents
@apiSuccess {Boolean} Data.pricing.buy.installmentComponents.material installmentCmaterialomponents
@apiSuccess {Boolean} Data.pricing.buy.installmentComponents.installation installation
@apiSuccess {Boolean} Data.pricing.buy.installmentComponents.extraMaterial extraMaterial
@apiSuccess {Boolean} Data.pricing.buy.installmentComponents.extraWork extraWork

@apiSuccess {Object} Data.pricing.subscription subscription
@apiSuccess {Number} Data.pricing.subscription.fee fee
@apiSuccess {String} Data.pricing.subscription.paymentCycle paymentCycle

@apiSuccess {Object[]} Data.pricing.discounts discounts
@apiSuccess {Number} Data.pricing.discounts.amount amount
@apiSuccess {String} Data.pricing.discounts.code code
@apiSuccess {String} Data.pricing.discounts.addedBy addedBy

@apiSuccess {Object} Data.pricing.extraItemsAndServices extraItemsAndServices
@apiSuccess {Object} Data.pricing.extraItemsAndServices.items items
@apiSuccess {String} Data.pricing.extraItemsAndServices.items.itemId itemId
@apiSuccess {Number} Data.pricing.extraItemsAndServices.items.units units
@apiSuccess {Number} Data.pricing.extraItemsAndServices.items.costPerUnit costPerUnit
@apiSuccess {Number} Data.pricing.extraItemsAndServices.items.totalAmount totalAmount
@apiSuccess {Object} Data.pricing.extraItemsAndServices.services services
@apiSuccess {String} Data.pricing.extraItemsAndServices.services.serviceItemId serviceItemId
@apiSuccess {Number} Data.pricing.extraItemsAndServices.services.amount amount
@apiSuccess {String} Data.pricing.extraItemsAndServices.services.description description

@apiSuccess {String}   Data.status  status
@apiSuccess {String}   Data.statebeforecancelled  statebeforecancelled
@apiSuccess {String}   Data.status  status
@apiSuccess {String}   Data.statebeforecancelled  statebeforecancelled
@apiSuccess {String}   Data.statusChangeOn  statusChangeOn
@apiSuccess {String}   Data.sentToInstallerOn  sentToInstallerOn
@apiSuccess {String}   Data.ts_tc_gdpr  ts_tc_gdpr
@apiSuccess {String}   Data.isExcavationPrice  isExcavationPrice
@apiSuccess {String}   Data.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
@apiSuccess {String}   Data.app   App name 'VODA'
@apiSuccess {String}   Data.createdOn   Created date
@apiSuccess {String}   Data.modifiedOn   modifiedOn date
@apiSuccess {String}   Data.createdBy  createdBy
@apiSuccess {String}   Data.createdByUserRole  createdByUserRole


 *
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 */

