/**
 * @api {post} /api/VODA/Device VodaDevice
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName VodaDevice
 * @apiGroup VODA.Device
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *  * 
 * @apiParamExample {json} Request-Example:
 * {
    "deviceId":"863586039678978",
    "contractId":"123456",
    }

    @apiParam {Object} Data Request is an object
    @apiParam {String} Data.deviceId Device Id
    @apiParam {String} Data.contractId Device contract Id
 * 
 * @apiSuccess {Object} Request	     Response is an array of objects.
 
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 201 OK
 *  
{}
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 422 Error
 *     {
 *       "error":  'Body content is not as per required'
 *     }
 * 
 */

 /**
 * @api {get} /api/VODA/Device/Connect?deviceId="863586039678978" VodaDeviceConnect
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName VodaDeviceConnect
 * @apiGroup VODA.Device
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *  * 
 * @apiParam {String} deviceId deviceId needs to check

 * 
 * @apiSuccess {Object} Request	     Response is an  object.
 * @apiSuccess {String} Request.isConnected	     Response is an array of objects.
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
    { 'isConnected': 1 }
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 422 Error
 *    { 'error': 'Not allowed role' }
 * 
 */


 /**
 * @api {put} /api/VODA/Device/FailSafe/:id VodaDeviceFailSafe
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName VodaDeviceFailSafe
 * @apiGroup VODA.Device
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *  * 
 * @apiParam {String} id deviceId needs to check
 * @apiParamExample {json} Request-Example:
 * {
    "value":"863586039678978"
    }
 * @apiParam {Object} Data Request data
 * @apiParam {String} Data.value Value needs to be changed

 * 
 * @apiSuccess {Object} Request	     Response is an  object.
 * @apiSuccess {String} Request.isConnected	     Response is an array of objects.
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
    { 'settingType': "seetingstype", 'value': "valuedata" }
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 422 Error
 *    { 'error': 'Not allowed role' }
 * 
 */


 /**
 * @api {post} /api/VODA/Device/Relay VodaDeviceRelay
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName VodaDeviceRelay
 * @apiGroup VODA.Device
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *  * 
 * @apiParamExample {json} Request-Example:
 * {
    "deviceId":"863586039678978",
    "value":"123456",
    }

    @apiParam {Object} Data Request is an object
    @apiParam {String} Data.deviceId Device Id
    @apiParam {String} Data.value Device contract Id
 * 
 * @apiSuccess {Object} Request	     Response is an array of objects.
 
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 201 OK
 *  
    {}
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 422 Error
 *     { 'error': 'Not allowed role' }
 * 
 */

 
 /**
 * @api {post} /api/VODA/Device/Settings VodaDeviceSettings
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName VodaDeviceSettings
 * @apiGroup VODA.Device
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *  * 
 * @apiParamExample {json} Request-Example:
 * {
    "deviceId":"863586039678978"
    }

    @apiParam {Object} Data Request is an object
    @apiParam {String} Data.deviceId Device Id

 * 
 * @apiSuccess {Object} Data	     Response is an array of objects.
 * @apiSuccess {String} Data.id	     Id as reponse
 
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 201 OK
 *  
    {"id":"12345"}
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 422 Error
 *     { 'error': 'Not allowed role' }
 * 
 */

 
 /**
 * @api {get} /api/VODA/Device/Signal?deviceid="id" VodaDeviceSignal
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName VodaDeviceSignal
 * @apiGroup VODA.Device
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *  * 
 * @apiParam {String} id deviceId needs to check

 * 
 * @apiSuccess {Object} Request	     Response is an  object.
 * @apiSuccess {String} Request.signal	     signal data
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
   { 'signal': "signaldata" }
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 422 Error
 *    { 'error': 'Not allowed role' }
 * 
 */


 

 /**
 * @api {post} /api/VODA/Device/SettingsType VodaDeviceSettingsType
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName VodaDeviceSettingsType
 * @apiGroup VODA.Device
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *  * 
 * @apiParamExample {json} Request-Example:
 * {
    "deviceId":"863586039678978",
    "value":"123456",
    "readingMethod":"read"
    }

    @apiParam {Object} Data Request is an object
    @apiParam {String} Data.deviceId Device Id
    @apiParam {String} Data.value Device contract Id
    @apiParam {String} Data.readingMethod Device contract Id
 * 
 * @apiSuccess {Object} Request	     Response is an array of objects.
 
 *
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 201 OK
 *  
    {}
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 422 Error
 *     { 'error': 'Not allowed role' }
 * 
 */