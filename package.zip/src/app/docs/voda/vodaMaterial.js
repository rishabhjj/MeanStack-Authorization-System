/* eslint-disable */
/**
 * @api {get} /VODA/Material GetAllVodaMaterials
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName GetAllVodaMaterials
 * @apiGroup VODA.Material
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *
 * 
 * @apiSuccess {Object[]} Request	     Response is an array of objects.
 * @apiSuccess {String}   Request._id   Corresponding Mongodb id.
 * @apiSuccess {Object}   Request.description  Description of the Product feature.
 * @apiSuccess {String}   Request.description.en_GB  Description of the Product feature. in english.
 * @apiSuccess {String}   Request.description.fi_FI  Description of the Product feature. in finnish.
 * @apiSuccess {String}   Request.description.sv_FI  Description of the Product feature. in sweden.
 * @apiSuccess {String}   Request.description.sv_SE  Description of the Product feature. in sweden.
 * @apiSuccess {String}   Request.description.nb_No  Description of the Product feature. in Norway.
 * @apiSuccess {String}   Request.description.nn_No  Description of the Product feature. in Norway.
 * @apiSuccess {String}   Request.description.pl_PL  Description of the Product feature. in PL.
 * @apiSuccess {String}   Request.materialId   Corresponding materialId.
 * @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.app   App name 'VODA'
 * @apiSuccess {String}   Request.modifiedOn   Modified date
 * @apiSuccess {String}   Request.createdOn   Created date
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
[
    {
        "_id": "58e1c9818f7f450011e52dde",
        "description": {
            "en_GB": "Voit seurata järjestelmän tuotantoa sekä kotisi nettokulutusta reaaliajassa Oma Fortum palvelun kautta.",
            "fi_FI": "Voit seurata järjestelmän tuotantoa sekä kotisi nettokulutusta reaaliajassa Oma Fortum palvelun kautta.",
            "sv_FI": "Voit seurata järjestelmän tuotantoa sekä kotisi nettokulutusta reaaliajassa Oma Fortum palvelun kautta."
        },
        "materialId": "Antenna",
        "country": "FI",
        "modifiedOn": "2017-10-02T12:35:36.353Z",
        "createdOn": "2017-06-10T04:50:23.604Z",
        "app": "VODA"
    }
]
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 Mongodb-error
 *     {
 *       "error": "Item not found"
 *     }
 * 
 */


 /**
 * @api {post} /VODA/Material SaveVodaMaterial
 * @apiVersion 1.0.0
 * @apiName SaveVodaMaterial
 * @apiGroup VODA.Material
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 
 * @apiParam {Object}   Request.description  Name of the package.
 * @apiParam {String}   Request.description.en_GB  Name of the package in english.
 * @apiParam {String}   Request.description.fi_FI  Name of the package in finnish.
 * @apiParam {String}   Request.description.sv_FI  Description of the Product feature. in sweden.
 * @apiParam {String}   Request.description.sv_SE  Description of the Product feature. in sweden.
 * @apiParam {String}   Request.description.nb_No  Description of the Product feature. in Norway.
 * @apiParam {String}   Request.description.nn_No  Description of the Product feature. in Norway.
 * @apiParam {String}   Request.description.pl_PL  Description of the Product feature. in PL.
 * @apiParam {String}   Request.materialId   Corresponding materialId.
 * 
 * @apiParamExample {json} Request-Example:
 * {
  "materialId": "new one",
  "description": {
        "en_GB": "dummy",
        "fi_FI": "dummy" 
    }
}


 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
[
    {
    "__v": 0,
    "_id": "5a3b41f6e0ab031cf4195214",
    "description": {
        "en_GB": "dummy",
        "fi_FI": "dummy"
    },
    "materialId": "new one",
    "country": "FI",
    "modifiedOn": "2017-12-21T05:09:10.400Z",
    "createdOn": "2017-12-21T05:09:10.400Z",
    "app": "VODA"
}
]
 * @apiSuccess {Object}   Request	     Response is an array of objects.
 * @apiSuccess {String}   Request._id   Corresponding Mongodb id.
 * @apiSuccess {Object}   Request.description  Description of the Product feature.
 * @apiSuccess {String}   Request.description.en_GB  Description of the Product feature. in english.
 * @apiSuccess {String}   Request.description.fi_FI  Description of the Product feature. in finnish.
 * @apiSuccess {String}   Request.description.sv_FI  Description of the Product feature. in sweden.
 * @apiSuccess {String}   Request.description.sv_SE  Description of the Product feature. in sweden.
 * @apiSuccess {String}   Request.description.nb_No  Description of the Product feature. in Norway.
 * @apiSuccess {String}   Request.description.nn_No  Description of the Product feature. in Norway.
 * @apiSuccess {String}   Request.description.pl_PL  Description of the Product feature. in PL.
 * @apiSuccess {String}   Request.materialId   Corresponding materialId.
 * @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.app   App name 'VODA'
 * @apiSuccess {String}   Request.modifiedOn   Modified date
 * @apiSuccess {String}   Request.createdOn   Created date
 *
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 */


 

 /**
 * @api {put} /VODA/Material/:id UpdateVodaMaterial
 * @apiVersion 1.0.0
 * @apiName UpdateVodaMaterial
 * @apiGroup VODA.Material
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} id Which Material Id we need to update the data
 * 
 * @apiParam {Object[]} Request Which package Id we need to get the data
 * @apiParam {String} Request.op Mention the operation to do.
 * @apiParam {String} Request.path Mention the data path to change
 * @apiParam {Object} Request.value Mention the data value to change ex: any Object
 * 
 * @apiParamExample {json} Request-Example:
 * [
  {
    "op": "add",
    "path": "/description/en_GB",
    "value": "Fortum Solar Package S 8 - CHANGED 222"
  }
]
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 202 Accepted
 *    {
    "__v": 0,
    "_id": "5a3b41f6e0ab031cf4195214",
    "description": {
        "en_GB": "dummy",
        "fi_FI": "dummy"
    },
    "materialId": "new one",
    "country": "FI",
    "modifiedOn": "2017-12-21T05:09:10.400Z",
    "createdOn": "2017-12-21T05:09:10.400Z",
    "app": "VODA"
}

 * @apiSuccess {Object}   Request	     Response is an array of objects.
 * @apiSuccess {String}   Request._id   Corresponding Mongodb id.
 * @apiSuccess {Object}   Request.description  Description of the Product feature.
 * @apiSuccess {String}   Request.description.en_GB  Description of the Product feature. in english.
 * @apiSuccess {String}   Request.description.fi_FI  Description of the Product feature. in finnish.
 * @apiSuccess {String}   Request.description.sv_FI  Description of the Product feature. in sweden.
 * @apiSuccess {String}   Request.description.sv_SE  Description of the Product feature. in sweden.
 * @apiSuccess {String}   Request.description.nb_No  Description of the Product feature. in Norway.
 * @apiSuccess {String}   Request.description.nn_No  Description of the Product feature. in Norway.
 * @apiSuccess {String}   Request.description.pl_PL  Description of the Product feature. in PL.
 * @apiSuccess {String}   Request.materialId   Corresponding materialId.
 * @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.app   App name 'VODA'
 * @apiSuccess {String}   Request.modifiedOn   Modified date
 * @apiSuccess {String}   Request.createdOn   Created date
 *
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 *
 */


 /**
 * @api {delete} /VODA/Material?materialId="new one" RemoveVodaMaterial
 * @apiVersion 1.0.0
 * @apiName RemoveVodaMaterial
 * @apiGroup VODA.Material
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} token ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         token:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} _id Which package Id we need to delete the data
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 204 NO CONTENT
 * 
*  @apiErrorExample Error-Response:
*     HTTP/1.1 404 Not Found
*     {
*       "error": "product Fetaure NotFound"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 401 Not Allowed
*     {
*       "error": "productNotFound"
*     }
*/