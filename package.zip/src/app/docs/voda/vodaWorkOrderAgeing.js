/* eslint-disable */
/**
 * @api {get} /VODA/WorkOrder/ageing?SearchQuery GetVodaWorkOrderAgeing
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName GetVodaWorkOrderAgeing
 * @apiGroup VODA.WorkOrderAgeing
 * 
 * @apiParam {String} searchQuery Custome search query
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *
 * 
 * @apiSuccess {Object[]} Request	     Response is an array of objects.
 * @apiSuccess {String}   Request._id   Corresponding Mongodb id.
 * @apiSuccess {String}   Request.name  name
 * @apiSuccess {String}   Request.workOrderServiceKey   workOrderServiceKey
 * @apiSuccess {String}   Request.workOrderNumber   workOrderNumber
 * @apiSuccess {String}   Request.orderReceived  orderReceived
 * @apiSuccess {String}   Request.currentStatus    currentStatus
 * @apiSuccess {String}   Request.modifiedOn   Modified date
 * @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.waitingForInstallation   waitingForInstallation
 * @apiSuccess {String}   Request.timeScheduled  timeScheduled
 * @apiSuccess {String}   Request.returned   returned
 * @apiSuccess {String}   Request.cancelled   cancelled
 * @apiSuccess {String}   Request.modifiedOn   Modified date
 * 
 * @apiSuccess {String}   Request.createdOn   createdOn
 * @apiSuccess {String}   Request.app   App name 'VODA'
 * @apiSuccess {String}   Request.createdBy   createdBy

 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
[
    {
        "_id": "59ba27c1c738300012b33467",
        "name": "TEST1",
        "workOrderServiceKey": "59ba27c1c738300012b33466",
        "workOrderNumber": "2503",
        "orderReceived": "2017-09-14T06:54:57.856Z",
        "currentStatus": "Cancelled",
        "country": "FI",
        "modifiedOn": "2017-09-14T11:38:08.145Z",
        "waitingForInstallation": "2017-09-14T10:51:16.319Z",
        "timeScheduled": "2017-09-14T10:52:33.733Z",
        "returned": "2017-09-14T11:37:21.914Z",
        "cancelled": "2017-09-14T11:38:08.145Z",
        "createdOn": "2017-09-14T06:54:57.874Z",
        "app": "VODA",
        "createdBy": "CulbertCustomerservice"
    }
]
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 Mongodb-error
 *     {
 *       "error": "Item not found"
 *     }
 * 
 */


 /**
 * @api {post} /VODA/WorkOrder/ageing SaveVodaWorkOrderAgeing
 * @apiVersion 1.0.0
 * @apiName SaveVodaWorkOrderAgeing
 * @apiGroup VODA.WorkOrderAgeing
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 
 * @apiParam  {Object} Request	     Response is an array of objects.
 * @apiParam  {String}   Request._id   Corresponding Mongodb id.
 * @apiParam  {String}   Request.name  name
 * @apiParam  {String}   Request.workOrderServiceKey   workOrderServiceKey
 * @apiParam  {String}   Request.workOrderNumber   workOrderNumber
 * @apiParam  {String}   Request.orderReceived  orderReceived
 * @apiParam  {String}   Request.currentStatus    currentStatus
 * @apiParam  {String}   Request.modifiedOn   Modified date
 * @apiParam {String}   Request.country   country
 * @apiParam {String}   Request.createdBy   createdBy
 * 
 * 
 * @apiParamExample {json} Request-Example:
 * {
        "name": "TEST1",
        "workOrderServiceKey": "59ba27c1c738300012b33466",
        "workOrderNumber": "2503",
        "orderReceived": "2017-09-14T06:54:57.856Z",
        "currentStatus": "Cancelled",
        "country": "FI",
        "modifiedOn": "2017-09-14T11:38:08.145Z",
    }
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
 {
        "_id": "59ba27c1c738300012b33467",
        "name": "TEST1",
        "workOrderServiceKey": "59ba27c1c738300012b33466",
        "workOrderNumber": "2503",
        "orderReceived": "2017-09-14T06:54:57.856Z",
        "currentStatus": "Cancelled",
        "country": "FI",
        "modifiedOn": "2017-09-14T11:38:08.145Z",
        "waitingForInstallation": "2017-09-14T10:51:16.319Z",
        "timeScheduled": "2017-09-14T10:52:33.733Z",
        "returned": "2017-09-14T11:37:21.914Z",
        "cancelled": "2017-09-14T11:38:08.145Z",
        "createdOn": "2017-09-14T06:54:57.874Z",
        "app": "VODA",
        "createdBy": "CulbertCustomerservice"
    }
 * @apiSuccess {Object} Request	     Response is an array of objects.
 * @apiSuccess {String}   Request._id   Corresponding Mongodb id.
 * @apiSuccess {String}   Request.name  name
 * @apiSuccess {String}   Request.workOrderServiceKey   workOrderServiceKey
 * @apiSuccess {String}   Request.workOrderNumber   workOrderNumber
 * @apiSuccess {String}   Request.orderReceived  orderReceived
 * @apiSuccess {String}   Request.currentStatus    currentStatus
 * @apiSuccess {String}   Request.modifiedOn   Modified date
 * @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.waitingForInstallation   waitingForInstallation
 * @apiSuccess {String}   Request.timeScheduled  timeScheduled
 * @apiSuccess {String}   Request.returned   returned
 * @apiSuccess {String}   Request.cancelled   cancelled
 * @apiSuccess {String}   Request.modifiedOn   Modified date
 * 
 * @apiSuccess {String}   Request.createdOn   createdOn
 * @apiSuccess {String}   Request.app   App name 'VODA'
 * @apiSuccess {String}   Request.createdBy   createdBy
 *
 *
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 */


 

 /**
 * @api {put} /VODA/WorkOrder/ageing/:id UpdateVodaCampaignPrice
 * @apiVersion 1.0.0
 * @apiName UpdateVodaWorkOrderAgeing
 * @apiGroup VODA.WorkOrderAgeing
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} id Which Ageing Id we need to update the data
 * 
 * @apiParam {Object[]} Request Which package Id we need to get the data
 * @apiParam {String} Request.op Mention the operation to do.
 * @apiParam {String} Request.path Mention the data path to change
 * @apiParam {Object} Request.value Mention the data value to change ex: any Object
 * 
 * @apiParamExample {json} Request-Example:
 * [
  {
    "op": "replace",
    "path": "/namen",
    "value": "Test1"
  }
]
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 202 Accepted
 *     {
        "_id": "59ba27c1c738300012b33467",
        "name": "Test1",
        "workOrderServiceKey": "59ba27c1c738300012b33466",
        "workOrderNumber": "2503",
        "orderReceived": "2017-09-14T06:54:57.856Z",
        "currentStatus": "Cancelled",
        "country": "FI",
        "modifiedOn": "2017-09-14T11:38:08.145Z",
        "waitingForInstallation": "2017-09-14T10:51:16.319Z",
        "timeScheduled": "2017-09-14T10:52:33.733Z",
        "returned": "2017-09-14T11:37:21.914Z",
        "cancelled": "2017-09-14T11:38:08.145Z",
        "createdOn": "2017-09-14T06:54:57.874Z",
        "app": "VODA",
        "createdBy": "CulbertCustomerservice"
        "app": "VODA"
    }

 * @apiSuccess {Object} Request	     Response is an array of objects.
 * @apiSuccess {String}   Request._id   Corresponding Mongodb id.
 * @apiSuccess {String}   Request.name  name
 * @apiSuccess {String}   Request.workOrderServiceKey   workOrderServiceKey
 * @apiSuccess {String}   Request.workOrderNumber   workOrderNumber
 * @apiSuccess {String}   Request.orderReceived  orderReceived
 * @apiSuccess {String}   Request.currentStatus    currentStatus
 * @apiSuccess {String}   Request.modifiedOn   Modified date
 * @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.waitingForInstallation   waitingForInstallation
 * @apiSuccess {String}   Request.timeScheduled  timeScheduled
 * @apiSuccess {String}   Request.returned   returned
 * @apiSuccess {String}   Request.cancelled   cancelled
 * @apiSuccess {String}   Request.modifiedOn   Modified date
 * 
 * @apiSuccess {String}   Request.createdOn   createdOn
 * @apiSuccess {String}   Request.app   App name 'VODA'
 * @apiSuccess {String}   Request.createdBy   createdBy
 *
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 *
 */
