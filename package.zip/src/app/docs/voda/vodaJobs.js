/**
 * @api {post} /voda/jobs/workorders/pushtoinstaller VodaJobsPushToInstaller
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName VodaJobsPushToInstaller
 * @apiGroup VODA.Jobs
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *
 * 
 * @apiSuccess {Object} Request	     Response is an object
 *  * @apiSuccess {String} Request.info	     Response numbers
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
{
    "info": "No of Workorders updated: 0"
}
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 Mongodb-error
 *     {
 *       "error": "Item not found"
 *     }
 * 
 */

 /**
 * @api {get} /voda/jobs/workorders/kpi/OrderReceived VodaJobsKpiNotification
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName VodaJobsKpiNotification
 * @apiGroup VODA.Jobs
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 
 * @apiSuccess {Object} Request	     Response is an array of objects.
 * @apiSuccess {String}   Request._id   Corresponding Mongodb id.
 * @apiSuccess {String}   Request.vodaOrderNumber  vodaOrderNumber
 * @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.createdOn   createdOn
 * @apiSuccess {String}   Request.app   App name 'VODA'
 * @apiSuccess {String}   Request.createdBy   createdBy
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
[
    {
        "_id": "5a28b1a4427f2d0025f25056",
        "vodaOrderNumber": 10000000168,
        "country": "FI",
        "app": "VODA",
        "createdBy": "Anonymous",
        "createdOn": "2017-12-07T03:12:36.493Z"
    }
]
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 Mongodb-error
 *     {
 *       "error": "Item not found"
 *     }
 * 
 */