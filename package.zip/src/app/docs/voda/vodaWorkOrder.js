/* eslint-disable */
/**
 * @api {get} /VODA/WorkOrder GetAllVodaWorkOrders
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName GetAllVodaPostalCode
 * @apiGroup VODA.WorkOrder
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         token:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA", //admin
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *
 * 
 *   @apiSuccess {Object[]} Data Response is Array of Objects
  @apiSuccess {Object[]} Data._id Mongodb Id
  @apiSuccess {String} Data.vodaOrderNumber vodaOrderNumber
  
  @apiSuccess {Object} Data.customer Customerdata'
  @apiSuccess {String} Data.customer.customerId Customer _id
  @apiSuccess {String} Data.customer.name Name of the customerr

  @apiSuccess {Object} Data.customer.address Customer address
  @apiSuccess {String} Data.customer.address.zip zip
  @apiSuccess {String} Data.customer.address.city city
  @apiSuccess {String} Data.customer.address.street street
  @apiSuccess {String} Data.customer.address.postalPlace postalPlace

  @apiSuccess {Object} Data.customer.contactInfo Customer contactInfo
  @apiSuccess {String} Data.customer.contactInfo.additionalContactNumber additionalContactNumber
  @apiSuccess {String} Data.customer.contactInfo.email email
  @apiSuccess {String} Data.customer.contactInfo.phone phone
  
  @apiSuccess {Object} Data.deliverySite Customer deliverySite
  @apiSuccess {String} Data.deliverySite.deliverysiteId deliverysiteId
  @apiSuccess {String} Data.deliverySite.isDeliverySiteAddressSameAsContactAddress isDeliverySiteAddressSameAsContactAddress ex : Yes, No
  @apiSuccess {Object} Data.deliverySite.address Customer deliverySite address
  @apiSuccess {String} Data.deliverySite.address.zip zip
  @apiSuccess {String} Data.deliverySite.address.city city
  @apiSuccess {String} Data.deliverySite.address.street street
  @apiSuccess {String} Data.deliverySite.address.postalPlace postalPlace

  @apiSuccess {String} Data.contractId contractId
  @apiSuccess {String} Data.ssn ssn
  @apiSuccess {String} Data.companyId companyId 'Fortum Finland', 'Fortum Sweden', 'Fortum Poland '

  @apiSuccess {Object} Data.installation installation
  @apiSuccess {String} Data.installation.installerCompany installation installerCompany
  @apiSuccess {String} Data.installation.installer installation installer
  @apiSuccess {String} Data.installation.actualInstallationDateTime installation actualInstallationDateTime
  @apiSuccess {Object} Data.installation.agreedVisitScheduleRange installation agreedVisitScheduleRange
  @apiSuccess {String} Data.installation.agreedVisitScheduleRange.startDate installation agreedVisitScheduleRange startDate
  @apiSuccess {String} Data.installation.agreedVisitScheduleRange.endDate installation agreedVisitScheduleRange endDate
  @apiSuccess {String} Data.installation.agreedVisitScheduleRange.endDate installation agreedVisitScheduleRange endDate
  @apiSuccess {String} Data.installation.agreedVisitScheduleRange.endTime installation agreedVisitScheduleRange endTime
  @apiSuccess {String} Data.installation.agreedVisitScheduleRange.startTime installation agreedVisitScheduleRange startTime

  @apiSuccess {Object} Data.additionalParts additionalParts
  @apiSuccess {String} Data.additionalParts.antenna additionalParts antenna : Yes, No
  @apiSuccess {String} Data.additionalParts.currectClamps additionalParts currectClamps

  @apiSuccess {String} Data.deviceId deviceId
  @apiSuccess {Number} Data.multiplier multiplier
  @apiSuccess {Number} Data.clampCT clampCT

  @apiSuccess {String} Data.led led
  @apiSuccess {String} Data.readingMethod readingMethod 'Current Clamp', 'Led'
  @apiSuccess {String} Data.installationMethod installationMethod 'DIN', 'Empty Slot'

  @apiSuccess {Object} Data.device device 
  @apiSuccess {String} Data.device.registerDevice registerDevice 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.settingType device settingType 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.createDeviceSetting device createDeviceSetting 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.connection device connection 'Passed', 'Failed', 'YetToBeConnected'
  @apiSuccess {String} Data.device.setFailSafeOff device setFailSafeOff 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.setRelayOn device setRelayOn 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.setRelayOff device setRelayOff 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.setFailSafeOn device setFailSafeOn 'NotCompleted', 'Completed'
  @apiSuccess {Number} Data.device.signalStrength device signalStrength


  @apiSuccess {Object} Data.selfService selfService 
  @apiSuccess {String} Data.selfService.package selfService package 'VAKAA', 'KESTO', 'TARKKA', 'TAKUU'
  @apiSuccess {String} Data.selfService.endCurrentContract selfService endCurrentContract 'Yes', 'No'
  @apiSuccess {String} Data.selfService.purposeOfRequest selfService purposeOfRequest 'PRODUCTCHANGE', 'MOVING', 'PROVIDERCHANGE', 'ANOTHERLOCATION'
  @apiSuccess {Object} Data.selfService.address Customer selfService address
  @apiSuccess {String} Data.selfService.address.zip zip
  @apiSuccess {String} Data.selfService.address.city city
  @apiSuccess {String} Data.selfService.address.street street
  @apiSuccess {String} Data.selfService.address.postalPlace postalPlace
  @apiSuccess {String} Data.selfService.oldContractEndDate selfService oldContractEndDate 
  @apiSuccess {String} Data.selfService.package newContractStartDate newContractStartDate 
  @apiSuccess {String} Data.selfService.measurementMethod selfService packameasurementMethodge 'Yleissähkö', 'Yösähkö', 'Kausisähkö'

 * @apiSuccess {Object}   Data.selfService.takuu   takuu data.
 * @apiSuccess {Number}   Data.selfService.takuu.lyleise   takuu data-lyleise.
 * @apiSuccess {Number}   Data.selfService.takuu.lyopv   takuu data-lyopv.
 * @apiSuccess {Number}   Data.selfService.takuu.lyoyo   takuu data-lyoyo.
 * @apiSuccess {Number}   Data.selfService.takuu.lkausitp   takuu data-lkausitp.
 * @apiSuccess {Number}   Data.selfService.takuu.lkausimu   takuu data-lkausimu.
 * 
 * @apiSuccess {Object}   Data.selfService.kesto   kesto data.
 * @apiSuccess {Number}   Data.selfService.kesto.myyen   kesto data-myyen.
 * @apiSuccess {Number}   Data.selfService.kesto.myspv   kesto data-myspv.
 * @apiSuccess {Number}   Data.selfService.kesto.mysyo   kesto data-mysyo.
 * @apiSuccess {Number}   Data.selfService.kesto.myktp   kesto data-myktp.
 * @apiSuccess {Number}   Data.selfService.kesto.mykyo   kesto data-mykyo.
 * 
 * @apiSuccess {Object}   Data.selfService.vakaa   vakaa data.
 * @apiSuccess {Number}   Data.selfService.vakaa.vakyleisen   vakaa data-vakyleisen.
 * @apiSuccess {Number}   Data.selfServiceest.vakaa.vakyopv   vakaa data-vakyopv.
 * @apiSuccess {Number}   Data.selfService.vakaa.vakyoyo   vakaa data-vakyoyo.
 * @apiSuccess {Number}   Data.selfService.vakaa.vakkausitp   vakaa data-vakkausitp.
 * @apiSuccess {Number}   Data.selfService.vakaa.vakkausimu   vakaa data-vakkausimu.
   @apiSuccess {String}   Data.saleAgentId  saleAgentId

   @apiSuccess {Object}   Data.faultDevices  faultDevices
 * @apiSuccess {Object[]}   Data.faultDevices.devices
   @apiSuccess {String}   Data.faultDevices.deviceId  deviceId
   @apiSuccess {String}   Data.faultDevices.faultCode  faultCode

   @apiSuccess {Object[]}   Data.notes  notes
   @apiSuccess {String}   Data.notes.note  note
   @apiSuccess {String}   Data.notes.createdBy  createdBy
   @apiSuccess {String}   Data.notes.createdOn  createdOn

   @apiSuccess {Object[]}   Data.installatorNotes  notes
   @apiSuccess {String}   Data.installatorNotes.note  note
   @apiSuccess {String}   Data.installatorNotes.createdBy  createdBy
   @apiSuccess {String}   Data.installatorNotes.createdOn  createdOn
   @apiSuccess {String}   Data.additionalInformation  additionalInformation
   @apiSuccess {String}   Data.extraInfoForInstallation  extraInfoForInstallation
   @apiSuccess {String}   Data.deviceSettingId  deviceSettingId

   @apiSuccess {String}   Data.status  status 'OrderReceived', 'InstallerYetToReceive', 'WaitingForInstallation', 'Completed', 'TimeScheduled', 'Returned', 'Cancelled'], default: 'OrderReceived'
   @apiSuccess {String}   Data.statebeforecancelled  statebeforecancelled 'OrderReceived', 'InstallerYetToReceive', 'WaitingForInstallation', 'Completed', 'TimeScheduled', 'Returned', 'Cancelled'
   @apiSuccess {String}   Data.statusChangeOn  statusChangeOn
   @apiSuccess {String}   Data.sentToInstallerOn  sentToInstallerOn
   @apiSuccess {String}   Data.AccessibilityForTechnician  AccessibilityForTechnician 'InsideTheBuilding', 'OutsideTheBuilding'
   @apiSuccess {String}   Data.termsAccepted  termsAccepted 'Yes', 'No
   
   @apiSuccess {Object}   Data.extraMaterial  extraMaterial
   @apiSuccess {String}   Data.extraMaterial.materialId  materialId
   @apiSuccess {Number}   Data.extraMaterial.quantity  quantity

   @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.app   App name 'VODA'
 * @apiSuccess {String}   Request.createdOn   Created date
   @apiSuccess {String}   Request.modifiedOn   modifiedOn date

   @apiSuccess {String}   Data.createdBy  createdBy
   @apiSuccess {String}   Data.createdByUserRole  createdByUserRole
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
[
    {
        "_id": "5a156a59245cf100252b8daa",
        "vodaOrderNumber": 10000000152,
        "deliverySite": {
            "isDeliverySiteAddressSameAsContactAddress": "Yes",
            "address": {
                "street": "12",
                "city": "123",
                "zip": "123"
            }
        },
        "customer": {
            "customerId": "612795",
            "address": {
                "street": "12",
                "city": "123",
                "zip": "123"
            },
            "contactInfo": {
                "phone": "123",
                "email": "123@meial.com"
            }
        },
        "companyId": "Fortum Finland",
        "country": "FI",
        "app": "VODA",
        "createdBy": "jim makela",
        "createdByUserRole": "EMP",
        "modifiedOn": "2017-11-24T05:43:51.214Z",
        "statusChangeOn": "2017-11-24T05:43:51.220Z",
        "createdOn": "2017-11-22T12:15:21.911Z",
        "extraMaterial": [],
        "status": "Cancelled",
        "installatorNotes": [],
        "notes": [],
        "faultDevices": [],
        "device": {
            "setFailSafeOn": "NotCompleted",
            "setRelayOff": "NotCompleted",
            "setRelayOn": "NotCompleted",
            "setFailSafeOff": "NotCompleted",
            "connection": "YetToBeConnected",
            "createDeviceSetting": "NotCompleted",
            "settingType": "NotCompleted",
            "registerDevice": "NotCompleted"
        }
    }
]
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 Mongodb-error
 *     {
 *       "error": "Item not found"
 *     }
 * 
 */


 /**
 * @api {post} /VODA/WorkOrder SaveVodaWorkOrder
 * @apiVersion 1.0.0
 * @apiName SaveVodaWorkOrder
 * @apiGroup VODA.WorkOrder
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 
  @apiParam  {Object[]} Data Response is Array of Objects
  @apiParam  {Object} Data.customer Customerdata'
  @apiParam  {String} Data.customer.customerId Customer _id
  @apiParam  {String} Data.customer.name Name of the customerr

  @apiParam  {Object} Data.customer.address Customer address
  @apiParam  {String} Data.customer.address.zip zip
  @apiParam  {String} Data.customer.address.city city
  @apiParam  {String} Data.customer.address.street street
  @apiParam  {String} Data.customer.address.postalPlace postalPlace

  @apiParam  {Object} Data.customer.contactInfo Customer contactInfo
  @apiParam  {String} Data.customer.contactInfo.additionalContactNumber additionalContactNumber
  @apiParam  {String} Data.customer.contactInfo.email email
  @apiParam  {String} Data.customer.contactInfo.phone phone
  @apiParam  {String} Data.customer.contactInfo.phone phone
  
  @apiParam  {Object} Data.deliverySite Customer deliverySite
  @apiParam  {String} Data.deliverySite.deliverysiteId deliverysiteId
  @apiParam  {String} Data.deliverySite.isDeliverySiteAddressSameAsContactAddress isDeliverySiteAddressSameAsContactAddress ex : Yes, No
  @apiParam  {Object} Data.deliverySite.address Customer deliverySite address
  @apiParam  {String} Data.customer.address.zip zip
  @apiParam  {String} Data.customer.address.city city
  @apiParam  {String} Data.customer.address.street street
  @apiParam  {String} Data.customer.address.postalPlace postalPlace

  @apiParam  {String} Data.contractId contractId
  @apiParam  {String} Data.ssn ssn
  @apiParam  {String} Data.companyId companyId 'Fortum Finland', 'Fortum Sweden', 'Fortum Poland '

  @apiParam  {Object} Data.installation installation
  @apiParam  {String} Data.installation.installerCompany installation installerCompany
  @apiParam  {String} Data.installation.installer installation installer
  @apiParam  {String} Data.installation.actualInstallationDateTime installation actualInstallationDateTime
  @apiParam  {Object} Data.installation.agreedVisitScheduleRange installation agreedVisitScheduleRange
  @apiParam  {String} Data.installation.agreedVisitScheduleRange.startDate installation agreedVisitScheduleRange startDate
  @apiParam  {String} Data.installation.agreedVisitScheduleRange.endDate installation agreedVisitScheduleRange endDate
  @apiParam  {String} Data.installation.agreedVisitScheduleRange.endDate installation agreedVisitScheduleRange endDate
  @apiParam  {String} Data.installation.agreedVisitScheduleRange.endTime installation agreedVisitScheduleRange endTime
  @apiParam  {String} Data.installation.agreedVisitScheduleRange.startTime installation agreedVisitScheduleRange startTime

  @apiParam  {Object} Data.additionalParts additionalParts
  @apiParam  {String} Data.additionalParts.antenna additionalParts antenna : Yes, No
  @apiParam  {String} Data.additionalParts.currectClamps additionalParts currectClamps

  @apiParam  {String} Data.deviceId deviceId
  @apiParam  {Number} Data.multiplier multiplier
  @apiParam  {Number} Data.clampCT clampCT

  @apiParam  {String} Data.led led
  @apiParam  {String} Data.readingMethod readingMethod 'Current Clamp', 'Led'
  @apiParam  {String} Data.installationMethod installationMethod 'DIN', 'Empty Slot'

  @apiParam  {Object} Data.device device 
  @apiParam  {String} Data.device.registerDevice registerDevice 'NotCompleted', 'Completed'
  @apiParam  {String} Data.device.settingType device settingType 'NotCompleted', 'Completed'
  @apiParam  {String} Data.device.createDeviceSetting device createDeviceSetting 'NotCompleted', 'Completed'
  @apiParam  {String} Data.device.connection device connection 'Passed', 'Failed', 'YetToBeConnected'
  @apiParam  {String} Data.device.setFailSafeOff device setFailSafeOff 'NotCompleted', 'Completed'
  @apiParam  {String} Data.device.setRelayOn device setRelayOn 'NotCompleted', 'Completed'
  @apiParam  {String} Data.device.setRelayOff device setRelayOff 'NotCompleted', 'Completed'
  @apiParam  {String} Data.device.setFailSafeOn device setFailSafeOn 'NotCompleted', 'Completed'
  @apiParam  {Number} Data.device.signalStrength device signalStrength


  @apiParam  {Object} Data.selfService selfService 
  @apiParam  {String} Data.selfService.package selfService package 'VAKAA', 'KESTO', 'TARKKA', 'TAKUU'
  @apiParam  {String} Data.selfService.endCurrentContract selfService endCurrentContract 'Yes', 'No'
  @apiParam  {String} Data.selfService.purposeOfRequest selfService purposeOfRequest 'PRODUCTCHANGE', 'MOVING', 'PROVIDERCHANGE', 'ANOTHERLOCATION'
  @apiParam  {Object} Data.selfService.address Customer selfService address
  @apiParam  {String} Data.selfService.address.zip zip
  @apiParam  {String} Data.selfService.address.city city
  @apiParam  {String} Data.selfService.address.street street
  @apiParam  {String} Data.selfService.address.postalPlace postalPlace
  @apiParam  {String} Data.selfService.oldContractEndDate selfService oldContractEndDate 
  @apiParam  {String} Data.selfService.package newContractStartDate newContractStartDate 
  @apiParam  {String} Data.selfService.measurementMethod selfService packameasurementMethodge 'Yleissähkö', 'Yösähkö', 'Kausisähkö'

 * @apiParam  {Object}   Data.selfService.takuu   takuu data.
 * @apiParam  {Number}   Data.selfService.takuu.lyleise   takuu data-lyleise.
 * @apiParam  {Number}   Data.selfService.takuu.lyopv   takuu data-lyopv.
 * @apiParam  {Number}   Data.selfService.takuu.lyoyo   takuu data-lyoyo.
 * @apiParam  {Number}   Data.selfService.takuu.lkausitp   takuu data-lkausitp.
 * @apiParam  {Number}   Data.selfService.takuu.lkausimu   takuu data-lkausimu.
 * 
 * @apiParam  {Object}   Data.selfService.kesto   kesto data.
 * @apiParam  {Number}   Data.selfService.kesto.myyen   kesto data-myyen.
 * @apiParam  {Number}   Data.selfService.kesto.myspv   kesto data-myspv.
 * @apiParam  {Number}   Data.selfService.kesto.mysyo   kesto data-mysyo.
 * @apiParam  {Number}   Data.selfService.kesto.myktp   kesto data-myktp.
 * @apiParam  {Number}   Data.selfService.kesto.mykyo   kesto data-mykyo.
 * 
 * @apiParam  {Object}   Data.selfService.vakaa   vakaa data.
 * @apiParam  {Number}   Data.selfService.vakaa.vakyleisen   vakaa data-vakyleisen.
 * @apiParam  {Number}   Data.selfServiceest.vakaa.vakyopv   vakaa data-vakyopv.
 * @apiParam  {Number}   Data.selfService.vakaa.vakyoyo   vakaa data-vakyoyo.
 * @apiParam  {Number}   Data.selfService.vakaa.vakkausitp   vakaa data-vakkausitp.
 * @apiParam  {Number}   Data.selfService.vakaa.vakkausimu   vakaa data-vakkausimu.
   @apiParam  {String}   Data.saleAgentId  saleAgentId

   @apiParam  {Object}   Data.faultDevices  faultDevices
 * @apiParam  {Object[]}   Data.faultDevices.devices
   @apiParam  {String}   Data.faultDevices.deviceId  deviceId
   @apiParam  {String}   Data.faultDevices.faultCode  faultCode

   @apiParam  {Object[]}   Data.notes  notes
   @apiParam  {String}   Data.notes.note  note
   @apiParam  {String}   Data.notes.createdBy  createdBy
   @apiParam  {String}   Data.notes.createdOn  createdOn

   @apiParam  {Object[]}   Data.installatorNotes  notes
   @apiParam  {String}   Data.installatorNotes.note  note
   @apiParam  {String}   Data.installatorNotes.createdBy  createdBy
   @apiParam  {String}   Data.installatorNotes.createdOn  createdOn
   @apiParam  {String}   Data.additionalInformation  additionalInformation
   @apiParam  {String}   Data.extraInfoForInstallation  extraInfoForInstallation
   @apiParam  {String}   Data.deviceSettingId  deviceSettingId

   @apiParam  {String}   Data.status  status 'OrderReceived', 'InstallerYetToReceive', 'WaitingForInstallation', 'Completed', 'TimeScheduled', 'Returned', 'Cancelled'], default: 'OrderReceived'
   @apiParam  {String}   Data.statebeforecancelled  statebeforecancelled 'OrderReceived', 'InstallerYetToReceive', 'WaitingForInstallation', 'Completed', 'TimeScheduled', 'Returned', 'Cancelled'
   @apiParam  {String}   Data.statusChangeOn  statusChangeOn
   @apiParam  {String}   Data.sentToInstallerOn  sentToInstallerOn
   @apiParam  {String}   Data.AccessibilityForTechnician  AccessibilityForTechnician 'InsideTheBuilding', 'OutsideTheBuilding'
   @apiParam  {String}   Data.termsAccepted  termsAccepted 'Yes', 'No
   
   @apiParam  {Object}   Data.extraMaterial  extraMaterial
   @apiParam  {String}   Data.extraMaterial.materialId  materialId
   @apiParam  {Number}   Data.extraMaterial.quantity  quantity






 * 
 * @apiParamExample {json} Request-Example:
 * {
  "customer": {
    "customerId": "2",
    "name": "2",
    "address": {
      "street": "2",
      "city": "2",
      "zip": "2"
    },
    "contactInfo": {
      "phone": "2",
      "email": "Suresh.SapaniDevarajan@partners.fortum.com"
    }
  },
  "ssn": "311280-999J",
  "deliverySite": {
    "isDeliverySiteAddressSameAsContactAddress": "Yes",
    "deiverySiteId": "2",
    "address": {
      "street": "2",
      "city": "2",
      "zip": "2"
    }
  },
  "companyId": "Fortum Finland",
  "AccessibilityForTechnician": "InsideTheBuilding",
  "additionalInformation": "2"
}


 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
{
    "__v": 0,
    "vodaOrderNumber": 10000000338,
    "customer": {
        "customerId": "2",
        "name": "2",
        "address": {
            "street": "2",
            "city": "2",
            "zip": "2"
        },
        "contactInfo": {
            "phone": "2",
            "email": "Suresh.SapaniDevarajan@partners.fortum.com"
        }
    },
    "ssn": "U2FsdGVkX19KxHO/tLxNvYw9fuhYJ3IP7jjdq745Qp8=",
    "deliverySite": {
        "isDeliverySiteAddressSameAsContactAddress": "Yes",
        "address": {
            "street": "2",
            "city": "2",
            "zip": "2"
        }
    },
    "companyId": "Fortum Finland",
    "AccessibilityForTechnician": "InsideTheBuilding",
    "additionalInformation": "2",
    "country": "FI",
    "app": "VODA",
    "createdBy": "Anonymous",
    "createdByUserRole": "CUSTOMER",
    "modifiedOn": "2017-12-21T09:58:20.387Z",
    "statusChangeOn": "2017-12-21T09:58:20.387Z",
    "_id": "5a3b85bca771691104bfbe9e",
    "createdOn": "2017-12-21T09:58:20.387Z",
    "extraMaterial": [],
    "status": "OrderReceived",
    "installatorNotes": [],
    "notes": [],
    "faultDevices": [],
    "device": {
        "setFailSafeOn": "NotCompleted",
        "setRelayOff": "NotCompleted",
        "setRelayOn": "NotCompleted",
        "setFailSafeOff": "NotCompleted",
        "connection": "YetToBeConnected",
        "createDeviceSetting": "NotCompleted",
        "settingType": "NotCompleted",
        "registerDevice": "NotCompleted"
    }
}
   @apiSuccess {Object} Data Response is Array of Objects
    @apiSuccess {String} Data.vodaOrderNumber vodaOrderNumber
  @apiSuccess {Object[]} Data._id Mongodb Id
  @apiSuccess {Object} Data.customer Customerdata'
  @apiSuccess {String} Data.customer.customerId Customer _id
  @apiSuccess {String} Data.customer.name Name of the customerr

  @apiSuccess {Object} Data.customer.address Customer address
  @apiSuccess {String} Data.customer.address.zip zip
  @apiSuccess {String} Data.customer.address.city city
  @apiSuccess {String} Data.customer.address.street street
  @apiSuccess {String} Data.customer.address.postalPlace postalPlace

  @apiSuccess {Object} Data.customer.contactInfo Customer contactInfo
  @apiSuccess {String} Data.customer.contactInfo.additionalContactNumber additionalContactNumber
  @apiSuccess {String} Data.customer.contactInfo.email email
  @apiSuccess {String} Data.customer.contactInfo.phone phone
  @apiSuccess {String} Data.customer.contactInfo.phone phone
  
  @apiSuccess {Object} Data.deliverySite Customer deliverySite
  @apiSuccess {String} Data.deliverySite.deliverysiteId deliverysiteId
  @apiSuccess {String} Data.deliverySite.isDeliverySiteAddressSameAsContactAddress isDeliverySiteAddressSameAsContactAddress ex : Yes, No
  @apiSuccess {Object} Data.deliverySite.address Customer deliverySite address
  @apiSuccess {String} Data.customer.address.zip zip
  @apiSuccess {String} Data.customer.address.city city
  @apiSuccess {String} Data.customer.address.street street
  @apiSuccess {String} Data.customer.address.postalPlace postalPlace

  @apiSuccess {String} Data.contractId contractId
  @apiSuccess {String} Data.ssn ssn
  @apiSuccess {String} Data.companyId companyId 'Fortum Finland', 'Fortum Sweden', 'Fortum Poland '

  @apiSuccess {Object} Data.installation installation
  @apiSuccess {String} Data.installation.installerCompany installation installerCompany
  @apiSuccess {String} Data.installation.installer installation installer
  @apiSuccess {String} Data.installation.actualInstallationDateTime installation actualInstallationDateTime
  @apiSuccess {Object} Data.installation.agreedVisitScheduleRange installation agreedVisitScheduleRange
  @apiSuccess {String} Data.installation.agreedVisitScheduleRange.startDate installation agreedVisitScheduleRange startDate
  @apiSuccess {String} Data.installation.agreedVisitScheduleRange.endDate installation agreedVisitScheduleRange endDate
  @apiSuccess {String} Data.installation.agreedVisitScheduleRange.endDate installation agreedVisitScheduleRange endDate
  @apiSuccess {String} Data.installation.agreedVisitScheduleRange.endTime installation agreedVisitScheduleRange endTime
  @apiSuccess {String} Data.installation.agreedVisitScheduleRange.startTime installation agreedVisitScheduleRange startTime

  @apiSuccess {Object} Data.additionalParts additionalParts
  @apiSuccess {String} Data.additionalParts.antenna additionalParts antenna : Yes, No
  @apiSuccess {String} Data.additionalParts.currectClamps additionalParts currectClamps

  @apiSuccess {String} Data.deviceId deviceId
  @apiSuccess {Number} Data.multiplier multiplier
  @apiSuccess {Number} Data.clampCT clampCT

  @apiSuccess {String} Data.led led
  @apiSuccess {String} Data.readingMethod readingMethod 'Current Clamp', 'Led'
  @apiSuccess {String} Data.installationMethod installationMethod 'DIN', 'Empty Slot'

  @apiSuccess {Object} Data.device device 
  @apiSuccess {String} Data.device.registerDevice registerDevice 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.settingType device settingType 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.createDeviceSetting device createDeviceSetting 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.connection device connection 'Passed', 'Failed', 'YetToBeConnected'
  @apiSuccess {String} Data.device.setFailSafeOff device setFailSafeOff 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.setRelayOn device setRelayOn 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.setRelayOff device setRelayOff 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.setFailSafeOn device setFailSafeOn 'NotCompleted', 'Completed'
  @apiSuccess {Number} Data.device.signalStrength device signalStrength


  @apiSuccess {Object} Data.selfService selfService 
  @apiSuccess {String} Data.selfService.package selfService package 'VAKAA', 'KESTO', 'TARKKA', 'TAKUU'
  @apiSuccess {String} Data.selfService.endCurrentContract selfService endCurrentContract 'Yes', 'No'
  @apiSuccess {String} Data.selfService.purposeOfRequest selfService purposeOfRequest 'PRODUCTCHANGE', 'MOVING', 'PROVIDERCHANGE', 'ANOTHERLOCATION'
  @apiSuccess {Object} Data.selfService.address Customer selfService address
  @apiSuccess {String} Data.selfService.address.zip zip
  @apiSuccess {String} Data.selfService.address.city city
  @apiSuccess {String} Data.selfService.address.street street
  @apiSuccess {String} Data.selfService.address.postalPlace postalPlace
  @apiSuccess {String} Data.selfService.oldContractEndDate selfService oldContractEndDate 
  @apiSuccess {String} Data.selfService.package newContractStartDate newContractStartDate 
  @apiSuccess {String} Data.selfService.measurementMethod selfService packameasurementMethodge 'Yleissähkö', 'Yösähkö', 'Kausisähkö'

 * @apiSuccess {Object}   Data.selfService.takuu   takuu data.
 * @apiSuccess {Number}   Data.selfService.takuu.lyleise   takuu data-lyleise.
 * @apiSuccess {Number}   Data.selfService.takuu.lyopv   takuu data-lyopv.
 * @apiSuccess {Number}   Data.selfService.takuu.lyoyo   takuu data-lyoyo.
 * @apiSuccess {Number}   Data.selfService.takuu.lkausitp   takuu data-lkausitp.
 * @apiSuccess {Number}   Data.selfService.takuu.lkausimu   takuu data-lkausimu.
 * 
 * @apiSuccess {Object}   Data.selfService.kesto   kesto data.
 * @apiSuccess {Number}   Data.selfService.kesto.myyen   kesto data-myyen.
 * @apiSuccess {Number}   Data.selfService.kesto.myspv   kesto data-myspv.
 * @apiSuccess {Number}   Data.selfService.kesto.mysyo   kesto data-mysyo.
 * @apiSuccess {Number}   Data.selfService.kesto.myktp   kesto data-myktp.
 * @apiSuccess {Number}   Data.selfService.kesto.mykyo   kesto data-mykyo.
 * 
 * @apiSuccess {Object}   Data.selfService.vakaa   vakaa data.
 * @apiSuccess {Number}   Data.selfService.vakaa.vakyleisen   vakaa data-vakyleisen.
 * @apiSuccess {Number}   Data.selfServiceest.vakaa.vakyopv   vakaa data-vakyopv.
 * @apiSuccess {Number}   Data.selfService.vakaa.vakyoyo   vakaa data-vakyoyo.
 * @apiSuccess {Number}   Data.selfService.vakaa.vakkausitp   vakaa data-vakkausitp.
 * @apiSuccess {Number}   Data.selfService.vakaa.vakkausimu   vakaa data-vakkausimu.
   @apiSuccess {String}   Data.saleAgentId  saleAgentId

   @apiSuccess {Object}   Data.faultDevices  faultDevices
 * @apiSuccess {Object[]}   Data.faultDevices.devices
   @apiSuccess {String}   Data.faultDevices.deviceId  deviceId
   @apiSuccess {String}   Data.faultDevices.faultCode  faultCode

   @apiSuccess {Object[]}   Data.notes  notes
   @apiSuccess {String}   Data.notes.note  note
   @apiSuccess {String}   Data.notes.createdBy  createdBy
   @apiSuccess {String}   Data.notes.createdOn  createdOn

   @apiSuccess {Object[]}   Data.installatorNotes  notes
   @apiSuccess {String}   Data.installatorNotes.note  note
   @apiSuccess {String}   Data.installatorNotes.createdBy  createdBy
   @apiSuccess {String}   Data.installatorNotes.createdOn  createdOn
   @apiSuccess {String}   Data.additionalInformation  additionalInformation
   @apiSuccess {String}   Data.extraInfoForInstallation  extraInfoForInstallation
   @apiSuccess {String}   Data.deviceSettingId  deviceSettingId

   @apiSuccess {String}   Data.status  status 'OrderReceived', 'InstallerYetToReceive', 'WaitingForInstallation', 'Completed', 'TimeScheduled', 'Returned', 'Cancelled'], default: 'OrderReceived'
   @apiSuccess {String}   Data.statebeforecancelled  statebeforecancelled 'OrderReceived', 'InstallerYetToReceive', 'WaitingForInstallation', 'Completed', 'TimeScheduled', 'Returned', 'Cancelled'
   @apiSuccess {String}   Data.statusChangeOn  statusChangeOn
   @apiSuccess {String}   Data.sentToInstallerOn  sentToInstallerOn
   @apiSuccess {String}   Data.AccessibilityForTechnician  AccessibilityForTechnician 'InsideTheBuilding', 'OutsideTheBuilding'
   @apiSuccess {String}   Data.termsAccepted  termsAccepted 'Yes', 'No
   
   @apiSuccess {Object}   Data.extraMaterial  extraMaterial
   @apiSuccess {String}   Data.extraMaterial.materialId  materialId
   @apiSuccess {Number}   Data.extraMaterial.quantity  quantity

   @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.app   App name 'VODA'
 * @apiSuccess {String}   Request.createdOn   Created date
   @apiSuccess {String}   Request.modifiedOn   modifiedOn date

   @apiSuccess {String}   Data.createdBy  createdBy
   @apiSuccess {String}   Data.createdByUserRole  createdByUserRole





 *
 *
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 */


 

 /**
 * @api {put} /VODA/WorkOrder/:id UpdateVodaWorkOrder
 * @apiVersion 1.0.0
 * @apiName UpdateVodaWorkOrder
 * @apiGroup VODA.WorkOrder
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} id Which order Id we need to update the data
 * 
 * @apiParam {Object[]} Request Which package Id we need to get the data
 * @apiParam {String} Request.op Mention the operation to do.
 * @apiParam {String} Request.path Mention the data path to change
 * @apiParam {Object} Request.value Mention the data value to change ex: any Object
 * 
 * @apiParamExample {json} Request-Example:
 * [
  {
    "op": "add",
    "path": "/status",
    "value": "Cancelled"
  }
]
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 202 Accepted
 *   
{
    "__v": 0,
    "vodaOrderNumber": 10000000338,
    "customer": {
        "customerId": "2",
        "name": "2",
        "address": {
            "street": "2",
            "city": "2",
            "zip": "2"
        },
        "contactInfo": {
            "phone": "2",
            "email": "Suresh.SapaniDevarajan@partners.fortum.com"
        }
    },
    "ssn": "U2FsdGVkX19KxHO/tLxNvYw9fuhYJ3IP7jjdq745Qp8=",
    "deliverySite": {
        "isDeliverySiteAddressSameAsContactAddress": "Yes",
        "address": {
            "street": "2",
            "city": "2",
            "zip": "2"
        }
    },
    "companyId": "Fortum Finland",
    "AccessibilityForTechnician": "InsideTheBuilding",
    "additionalInformation": "2",
    "country": "FI",
    "app": "VODA",
    "createdBy": "Anonymous",
    "createdByUserRole": "CUSTOMER",
    "modifiedOn": "2017-12-21T09:58:20.387Z",
    "statusChangeOn": "2017-12-21T09:58:20.387Z",
    "_id": "5a3b85bca771691104bfbe9e",
    "createdOn": "2017-12-21T09:58:20.387Z",
    "extraMaterial": [],
    "status": "OrderReceived",
    "installatorNotes": [],
    "notes": [],
    "faultDevices": [],
    "device": {
        "setFailSafeOn": "NotCompleted",
        "setRelayOff": "NotCompleted",
        "setRelayOn": "NotCompleted",
        "setFailSafeOff": "NotCompleted",
        "connection": "YetToBeConnected",
        "createDeviceSetting": "NotCompleted",
        "settingType": "NotCompleted",
        "registerDevice": "NotCompleted"
    }
}
   @apiSuccess {Object} Data Response is Array of Objects
    @apiSuccess {String} Data.vodaOrderNumber vodaOrderNumber
  @apiSuccess {Object[]} Data._id Mongodb Id
  @apiSuccess {Object} Data.customer Customerdata'
  @apiSuccess {String} Data.customer.customerId Customer _id
  @apiSuccess {String} Data.customer.name Name of the customerr

  @apiSuccess {Object} Data.customer.address Customer address
  @apiSuccess {String} Data.customer.address.zip zip
  @apiSuccess {String} Data.customer.address.city city
  @apiSuccess {String} Data.customer.address.street street
  @apiSuccess {String} Data.customer.address.postalPlace postalPlace

  @apiSuccess {Object} Data.customer.contactInfo Customer contactInfo
  @apiSuccess {String} Data.customer.contactInfo.additionalContactNumber additionalContactNumber
  @apiSuccess {String} Data.customer.contactInfo.email email
  @apiSuccess {String} Data.customer.contactInfo.phone phone
  @apiSuccess {String} Data.customer.contactInfo.phone phone
  
  @apiSuccess {Object} Data.deliverySite Customer deliverySite
  @apiSuccess {String} Data.deliverySite.deliverysiteId deliverysiteId
  @apiSuccess {String} Data.deliverySite.isDeliverySiteAddressSameAsContactAddress isDeliverySiteAddressSameAsContactAddress ex : Yes, No
  @apiSuccess {Object} Data.deliverySite.address Customer deliverySite address
  @apiSuccess {String} Data.customer.address.zip zip
  @apiSuccess {String} Data.customer.address.city city
  @apiSuccess {String} Data.customer.address.street street
  @apiSuccess {String} Data.customer.address.postalPlace postalPlace

  @apiSuccess {String} Data.contractId contractId
  @apiSuccess {String} Data.ssn ssn
  @apiSuccess {String} Data.companyId companyId 'Fortum Finland', 'Fortum Sweden', 'Fortum Poland '

  @apiSuccess {Object} Data.installation installation
  @apiSuccess {String} Data.installation.installerCompany installation installerCompany
  @apiSuccess {String} Data.installation.installer installation installer
  @apiSuccess {String} Data.installation.actualInstallationDateTime installation actualInstallationDateTime
  @apiSuccess {Object} Data.installation.agreedVisitScheduleRange installation agreedVisitScheduleRange
  @apiSuccess {String} Data.installation.agreedVisitScheduleRange.startDate installation agreedVisitScheduleRange startDate
  @apiSuccess {String} Data.installation.agreedVisitScheduleRange.endDate installation agreedVisitScheduleRange endDate
  @apiSuccess {String} Data.installation.agreedVisitScheduleRange.endDate installation agreedVisitScheduleRange endDate
  @apiSuccess {String} Data.installation.agreedVisitScheduleRange.endTime installation agreedVisitScheduleRange endTime
  @apiSuccess {String} Data.installation.agreedVisitScheduleRange.startTime installation agreedVisitScheduleRange startTime

  @apiSuccess {Object} Data.additionalParts additionalParts
  @apiSuccess {String} Data.additionalParts.antenna additionalParts antenna : Yes, No
  @apiSuccess {String} Data.additionalParts.currectClamps additionalParts currectClamps

  @apiSuccess {String} Data.deviceId deviceId
  @apiSuccess {Number} Data.multiplier multiplier
  @apiSuccess {Number} Data.clampCT clampCT

  @apiSuccess {String} Data.led led
  @apiSuccess {String} Data.readingMethod readingMethod 'Current Clamp', 'Led'
  @apiSuccess {String} Data.installationMethod installationMethod 'DIN', 'Empty Slot'

  @apiSuccess {Object} Data.device device 
  @apiSuccess {String} Data.device.registerDevice registerDevice 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.settingType device settingType 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.createDeviceSetting device createDeviceSetting 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.connection device connection 'Passed', 'Failed', 'YetToBeConnected'
  @apiSuccess {String} Data.device.setFailSafeOff device setFailSafeOff 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.setRelayOn device setRelayOn 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.setRelayOff device setRelayOff 'NotCompleted', 'Completed'
  @apiSuccess {String} Data.device.setFailSafeOn device setFailSafeOn 'NotCompleted', 'Completed'
  @apiSuccess {Number} Data.device.signalStrength device signalStrength


  @apiSuccess {Object} Data.selfService selfService 
  @apiSuccess {String} Data.selfService.package selfService package 'VAKAA', 'KESTO', 'TARKKA', 'TAKUU'
  @apiSuccess {String} Data.selfService.endCurrentContract selfService endCurrentContract 'Yes', 'No'
  @apiSuccess {String} Data.selfService.purposeOfRequest selfService purposeOfRequest 'PRODUCTCHANGE', 'MOVING', 'PROVIDERCHANGE', 'ANOTHERLOCATION'
  @apiSuccess {Object} Data.selfService.address Customer selfService address
  @apiSuccess {String} Data.selfService.address.zip zip
  @apiSuccess {String} Data.selfService.address.city city
  @apiSuccess {String} Data.selfService.address.street street
  @apiSuccess {String} Data.selfService.address.postalPlace postalPlace
  @apiSuccess {String} Data.selfService.oldContractEndDate selfService oldContractEndDate 
  @apiSuccess {String} Data.selfService.package newContractStartDate newContractStartDate 
  @apiSuccess {String} Data.selfService.measurementMethod selfService packameasurementMethodge 'Yleissähkö', 'Yösähkö', 'Kausisähkö'

 * @apiSuccess {Object}   Data.selfService.takuu   takuu data.
 * @apiSuccess {Number}   Data.selfService.takuu.lyleise   takuu data-lyleise.
 * @apiSuccess {Number}   Data.selfService.takuu.lyopv   takuu data-lyopv.
 * @apiSuccess {Number}   Data.selfService.takuu.lyoyo   takuu data-lyoyo.
 * @apiSuccess {Number}   Data.selfService.takuu.lkausitp   takuu data-lkausitp.
 * @apiSuccess {Number}   Data.selfService.takuu.lkausimu   takuu data-lkausimu.
 * 
 * @apiSuccess {Object}   Data.selfService.kesto   kesto data.
 * @apiSuccess {Number}   Data.selfService.kesto.myyen   kesto data-myyen.
 * @apiSuccess {Number}   Data.selfService.kesto.myspv   kesto data-myspv.
 * @apiSuccess {Number}   Data.selfService.kesto.mysyo   kesto data-mysyo.
 * @apiSuccess {Number}   Data.selfService.kesto.myktp   kesto data-myktp.
 * @apiSuccess {Number}   Data.selfService.kesto.mykyo   kesto data-mykyo.
 * 
 * @apiSuccess {Object}   Data.selfService.vakaa   vakaa data.
 * @apiSuccess {Number}   Data.selfService.vakaa.vakyleisen   vakaa data-vakyleisen.
 * @apiSuccess {Number}   Data.selfServiceest.vakaa.vakyopv   vakaa data-vakyopv.
 * @apiSuccess {Number}   Data.selfService.vakaa.vakyoyo   vakaa data-vakyoyo.
 * @apiSuccess {Number}   Data.selfService.vakaa.vakkausitp   vakaa data-vakkausitp.
 * @apiSuccess {Number}   Data.selfService.vakaa.vakkausimu   vakaa data-vakkausimu.
   @apiSuccess {String}   Data.saleAgentId  saleAgentId

   @apiSuccess {Object}   Data.faultDevices  faultDevices
 * @apiSuccess {Object[]}   Data.faultDevices.devices
   @apiSuccess {String}   Data.faultDevices.deviceId  deviceId
   @apiSuccess {String}   Data.faultDevices.faultCode  faultCode

   @apiSuccess {Object[]}   Data.notes  notes
   @apiSuccess {String}   Data.notes.note  note
   @apiSuccess {String}   Data.notes.createdBy  createdBy
   @apiSuccess {String}   Data.notes.createdOn  createdOn

   @apiSuccess {Object[]}   Data.installatorNotes  notes
   @apiSuccess {String}   Data.installatorNotes.note  note
   @apiSuccess {String}   Data.installatorNotes.createdBy  createdBy
   @apiSuccess {String}   Data.installatorNotes.createdOn  createdOn
   @apiSuccess {String}   Data.additionalInformation  additionalInformation
   @apiSuccess {String}   Data.extraInfoForInstallation  extraInfoForInstallation
   @apiSuccess {String}   Data.deviceSettingId  deviceSettingId

   @apiSuccess {String}   Data.status  status 'OrderReceived', 'InstallerYetToReceive', 'WaitingForInstallation', 'Completed', 'TimeScheduled', 'Returned', 'Cancelled'], default: 'OrderReceived'
   @apiSuccess {String}   Data.statebeforecancelled  statebeforecancelled 'OrderReceived', 'InstallerYetToReceive', 'WaitingForInstallation', 'Completed', 'TimeScheduled', 'Returned', 'Cancelled'
   @apiSuccess {String}   Data.statusChangeOn  statusChangeOn
   @apiSuccess {String}   Data.sentToInstallerOn  sentToInstallerOn
   @apiSuccess {String}   Data.AccessibilityForTechnician  AccessibilityForTechnician 'InsideTheBuilding', 'OutsideTheBuilding'
   @apiSuccess {String}   Data.termsAccepted  termsAccepted 'Yes', 'No
   
   @apiSuccess {Object}   Data.extraMaterial  extraMaterial
   @apiSuccess {String}   Data.extraMaterial.materialId  materialId
   @apiSuccess {Number}   Data.extraMaterial.quantity  quantity

   @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.app   App name 'VODA'
 * @apiSuccess {String}   Request.createdOn   Created date
   @apiSuccess {String}   Request.modifiedOn   modifiedOn date

   @apiSuccess {String}   Data.createdBy  createdBy
   @apiSuccess {String}   Data.createdByUserRole  createdByUserRole
 *
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 *
 */


 /**
 * @api {delete} /VODA/WorkOrder?_id="ordererid" RemoveVodaWorkOrder
 * @apiVersion 1.0.0
 * @apiName RemoveVodaWorkOrder
 * @apiGroup VODA.WorkOrder
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} token ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         token:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} _id Which package Id we need to delete the data
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 204 NO CONTENT
 * 
*  @apiErrorExample Error-Response:
*     HTTP/1.1 404 Not Found
*     {
*       "error": "product Fetaure NotFound"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 401 Not Allowed
*     {
*       "error": "productNotFound"
*     }
*/