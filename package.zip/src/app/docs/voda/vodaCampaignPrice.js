/* eslint-disable */
/**
 * @api {get} /VODA/CampaignPrice GetAllVodaCampaignPrice
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName GetAllVodaCampaignPrice
 * @apiGroup VODA.CampaignPrice
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *
 * 
 * @apiSuccess {Object[]} Request	     Response is an array of objects.
 * @apiSuccess {String}   Request._id   Corresponding Mongodb id.
 * @apiSuccess {Object}   Request.takuu   takuu data.
 * @apiSuccess {String}   Request.takuu.lyleise   takuu data-lyleise.
 * @apiSuccess {String}   Request.takuu.lyopv   takuu data-lyopv.
 * @apiSuccess {String}   Request.takuu.lyoyo   takuu data-lyoyo.
 * @apiSuccess {String}   Request.takuu.lkausitp   takuu data-lkausitp.
 * @apiSuccess {String}   Request.takuu.lkausimu   takuu data-lkausimu.
 * 
 * @apiSuccess {Object}   Request.kesto   kesto data.
 * @apiSuccess {String}   Request.kesto.myyen   kesto data-myyen.
 * @apiSuccess {String}   Request.kesto.myspv   kesto data-myspv.
 * @apiSuccess {String}   Request.kesto.mysyo   kesto data-mysyo.
 * @apiSuccess {String}   Request.kesto.myktp   kesto data-myktp.
 * @apiSuccess {String}   Request.kesto.mykyo   kesto data-mykyo.
 * 
 * @apiSuccess {Object}   Request.vakaa   vakaa data.
 * @apiSuccess {String}   Request.vakaa.vakyleisen   vakaa data-vakyleisen.
 * @apiSuccess {String}   Request.vakaa.vakyopv   vakaa data-vakyopv.
 * @apiSuccess {String}   Request.vakaa.vakyoyo   vakaa data-vakyoyo.
 * @apiSuccess {String}   Request.vakaa.vakkausitp   vakaa data-vakkausitp.
 * @apiSuccess {String}   Request.vakaa.vakkausimu   vakaa data-vakkausimu.
 * 
 * @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.app   App name 'VODA'
 * @apiSuccess {String}   Request.modifiedOn   Modified date

 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
[
    {
        "takuu": {
            "lyleise": 4.97,
            "lyopv": 5.53,
            "lyoyo": 4.51,
            "lkausitp": 5.94,
            "lkausimu": 4.61
        },
        "kesto": {
            "myyen": 6.13,
            "myspv": 6.54,
            "mysyo": 5.59,
            "myktp": 7,
            "mykyo": 5
        },
        "vakaa": {
            "vakyleisen": 5,
            "vakyopv": 5,
            "vakyoyo": 4.51,
            "vakkausitp": 5,
            "vakkausimu": 5
        },
        "country": "FI",
        "modifiedOn": "2017-11-17T11:57:31.584Z",
        "app": "VODA"
    }
]
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 Mongodb-error
 *     {
 *       "error": "Item not found"
 *     }
 * 
 */


 /**
 * @api {post} /VODA/CampaignPrice SaveVodaCampaignPrice
 * @apiVersion 1.0.0
 * @apiName SaveVodaCampaignPrice
 * @apiGroup VODA.CampaignPrice
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 
 * @apiParam {Object}   Request.description  Name of the package.
 * @apiParam {String}   Request._id   Corresponding Mongodb id.
 * @apiParam {Object}   Request.takuu   takuu data.
 * @apiParam {String}   Request.takuu.lyleise   takuu data-lyleise.
 * @apiParam {String}   Request.takuu.lyopv   takuu data-lyopv.
 * @apiParam {String}   Request.takuu.lyoyo   takuu data-lyoyo.
 * @apiParam {String}   Request.takuu.lkausitp   takuu data-lkausitp.
 * @apiParam {String}   Request.takuu.lkausimu   takuu data-lkausimu.
 * 
 * @apiParam {Object}   Request.kesto   kesto data.
 * @apiParam {String}   Request.kesto.myyen   kesto data-myyen.
 * @apiParam {String}   Request.kesto.myspv   kesto data-myspv.
 * @apiParam {String}   Request.kesto.mysyo   kesto data-mysyo.
 * @apiParam {String}   Request.kesto.myktp   kesto data-myktp.
 * @apiParam {String}   Request.kesto.mykyo   kesto data-mykyo.
 * 
 * @apiParam {Object}   Request.vakaa   vakaa data.
 * @apiParam {String}   Request.vakaa.vakyleisen   vakaa data-vakyleisen.
 * @apiParam {String}   Request.vakaa.vakyopv   vakaa data-vakyopv.
 * @apiParam {String}   Request.vakaa.vakyoyo   vakaa data-vakyoyo.
 * @apiParam {String}   Request.vakaa.vakkausitp   vakaa data-vakkausitp.
 * @apiParam {String}   Request.vakaa.vakkausimu   vakaa data-vakkausimu.
 * 
 * 
 * @apiParamExample {json} Request-Example:
 * {
        "takuu": {
            "lyleise": 4.97,
            "lyopv": 5.53,
            "lyoyo": 4.51,
            "lkausitp": 5.94,
            "lkausimu": 4.61
        },
        "kesto": {
            "myyen": 6.13,
            "myspv": 6.54,
            "mysyo": 5.59,
            "myktp": 7,
            "mykyo": 5
        },
        "vakaa": {
            "vakyleisen": 5,
            "vakyopv": 5,
            "vakyoyo": 4.51,
            "vakkausitp": 5,
            "vakkausimu": 5
        }
    }
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
{
        "takuu": {
            "lyleise": 4.97,
            "lyopv": 5.53,
            "lyoyo": 4.51,
            "lkausitp": 5.94,
            "lkausimu": 4.61
        },
        "kesto": {
            "myyen": 6.13,
            "myspv": 6.54,
            "mysyo": 5.59,
            "myktp": 7,
            "mykyo": 5
        },
        "vakaa": {
            "vakyleisen": 5,
            "vakyopv": 5,
            "vakyoyo": 4.51,
            "vakkausitp": 5,
            "vakkausimu": 5
        },
        "country": "FI",
        "modifiedOn": "2017-11-17T11:57:31.584Z",
        "app": "VODA"
    }
 * @apiSuccess {Object} Request	     Response is an array of objects.
 * @apiSuccess {String}   Request._id   Corresponding Mongodb id.
 * @apiSuccess {Object}   Request.takuu   takuu data.
 * @apiSuccess {String}   Request.takuu.lyleise   takuu data-lyleise.
 * @apiSuccess {String}   Request.takuu.lyopv   takuu data-lyopv.
 * @apiSuccess {String}   Request.takuu.lyoyo   takuu data-lyoyo.
 * @apiSuccess {String}   Request.takuu.lkausitp   takuu data-lkausitp.
 * @apiSuccess {String}   Request.takuu.lkausimu   takuu data-lkausimu.
 * 
 * @apiSuccess {Object}   Request.kesto   kesto data.
 * @apiSuccess {String}   Request.kesto.myyen   kesto data-myyen.
 * @apiSuccess {String}   Request.kesto.myspv   kesto data-myspv.
 * @apiSuccess {String}   Request.kesto.mysyo   kesto data-mysyo.
 * @apiSuccess {String}   Request.kesto.myktp   kesto data-myktp.
 * @apiSuccess {String}   Request.kesto.mykyo   kesto data-mykyo.
 * 
 * @apiSuccess {Object}   Request.vakaa   vakaa data.
 * @apiSuccess {String}   Request.vakaa.vakyleisen   vakaa data-vakyleisen.
 * @apiSuccess {String}   Request.vakaa.vakyopv   vakaa data-vakyopv.
 * @apiSuccess {String}   Request.vakaa.vakyoyo   vakaa data-vakyoyo.
 * @apiSuccess {String}   Request.vakaa.vakkausitp   vakaa data-vakkausitp.
 * @apiSuccess {String}   Request.vakaa.vakkausimu   vakaa data-vakkausimu.
 * 
 * @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.app   App name 'VODA'
 * @apiSuccess {String}   Request.modifiedOn   Modified date
 *
 *
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 */


 

 /**
 * @api {put} /VODA/CampaignPrice/:id UpdateVodaCampaignPrice
 * @apiVersion 1.0.0
 * @apiName UpdateVodaCampaignPrice
 * @apiGroup VODA.CampaignPrice
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} id Which Material Id we need to update the data
 * 
 * @apiParam {Object[]} Request Which package Id we need to get the data
 * @apiParam {String} Request.op Mention the operation to do.
 * @apiParam {String} Request.path Mention the data path to change
 * @apiParam {Object} Request.value Mention the data value to change ex: any Object
 * 
 * @apiParamExample {json} Request-Example:
 * [
  {
    "op": "replace",
    "path": "/vakaa/vakyleisen",
    "value": 4.97
  }
]
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 202 Accepted
 *    {
        "takuu": {
            "lyleise": 4.97,
            "lyopv": 5.53,
            "lyoyo": 4.51,
            "lkausitp": 5.94,
            "lkausimu": 4.61
        },
        "kesto": {
            "myyen": 6.13,
            "myspv": 6.54,
            "mysyo": 5.59,
            "myktp": 7,
            "mykyo": 5
        },
        "vakaa": {
            "vakyleisen": 5,
            "vakyopv": 5,
            "vakyoyo": 4.51,
            "vakkausitp": 5,
            "vakkausimu": 5
        },
        "country": "FI",
        "modifiedOn": "2017-11-17T11:57:31.584Z",
        "app": "VODA"
    }

 * @apiSuccess {Object} Request	     Response is an array of objects.
 * @apiSuccess {String}   Request._id   Corresponding Mongodb id.
 * @apiSuccess {Object}   Request.takuu   takuu data.
 * @apiSuccess {String}   Request.takuu.lyleise   takuu data-lyleise.
 * @apiSuccess {String}   Request.takuu.lyopv   takuu data-lyopv.
 * @apiSuccess {String}   Request.takuu.lyoyo   takuu data-lyoyo.
 * @apiSuccess {String}   Request.takuu.lkausitp   takuu data-lkausitp.
 * @apiSuccess {String}   Request.takuu.lkausimu   takuu data-lkausimu.
 * 
 * @apiSuccess {Object}   Request.kesto   kesto data.
 * @apiSuccess {String}   Request.kesto.myyen   kesto data-myyen.
 * @apiSuccess {String}   Request.kesto.myspv   kesto data-myspv.
 * @apiSuccess {String}   Request.kesto.mysyo   kesto data-mysyo.
 * @apiSuccess {String}   Request.kesto.myktp   kesto data-myktp.
 * @apiSuccess {String}   Request.kesto.mykyo   kesto data-mykyo.
 * 
 * @apiSuccess {Object}   Request.vakaa   vakaa data.
 * @apiSuccess {String}   Request.vakaa.vakyleisen   vakaa data-vakyleisen.
 * @apiSuccess {String}   Request.vakaa.vakyopv   vakaa data-vakyopv.
 * @apiSuccess {String}   Request.vakaa.vakyoyo   vakaa data-vakyoyo.
 * @apiSuccess {String}   Request.vakaa.vakkausitp   vakaa data-vakkausitp.
 * @apiSuccess {String}   Request.vakaa.vakkausimu   vakaa data-vakkausimu.
 * 
 * @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.app   App name 'VODA'
 * @apiSuccess {String}   Request.modifiedOn   Modified date
 *
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 *
 */
