/* eslint-disable */
/**
 * @api {get} /Feature GetAllSodaProductFeature
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName GetAllSodaProductFeature
 * @apiGroup SODA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *
 * @apiSuccess {Object[]} Request	     Response is an array of objects.
 * @apiSuccess {Object}   Request.description  Description of the Product feature.
 * @apiSuccess {String}   Request.description.en_GB  Description of the Product feature. in english.
 * @apiSuccess {String}   Request.description.fi_FI  Description of the Product feature. in finnish.
 * @apiSuccess {String}   Request.description.sv_FI  Description of the Product feature. in sweden.
 * @apiSuccess {String}   Request.description.sv_SE  Description of the Product feature. in sweden.
 * @apiSuccess {String}   Request.description.nb_No  Description of the Product feature. in Norway.
 * @apiSuccess {String}   Request.description.nn_No  Description of the Product feature. in Norway.
 * @apiSuccess {String}   Request.description.pl_PL  Description of the Product feature. in PL.
 * @apiSuccess {String}   Request._Id   Corresponding MongoDb ID.
 * @apiSuccess {String}   Request.category   Choosen category from 'Equipment', 'Service', 'AdditionalBenefit', 'StandardMaterial', 'StandardInstallationWork' 
 * @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.app   App name 'SODA'
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
[
    {
        "_id": "58e1c9818f7f450011e52dde",
        "description": {
            "en_GB": "Voit seurata järjestelmän tuotantoa sekä kotisi nettokulutusta reaaliajassa Oma Fortum palvelun kautta.",
            "fi_FI": "Voit seurata järjestelmän tuotantoa sekä kotisi nettokulutusta reaaliajassa Oma Fortum palvelun kautta.",
            "sv_FI": "Voit seurata järjestelmän tuotantoa sekä kotisi nettokulutusta reaaliajassa Oma Fortum palvelun kautta."
        },
        "category": "AdditionalBenefit",
        "country": "FI",
        "app": "SODA"
    }
]
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 Mongodb-error
 *     {
 *       "error": "Item not found"
 *     }
 * 
 */


 /**
 * @api {post} /Feature SaveSodaProductFeature
 * @apiVersion 1.0.0
 * @apiName SaveSodaProductFeature
 * @apiGroup SODA
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 
 * @apiParam {Object}   Request.nameOfPackage  Name of the package.
 * @apiParam {String}   Request.nameOfPackage.en_GB  Name of the package in english.
 * @apiParam {String}   Request.nameOfPackage.fi_FI  Name of the package in finnish.
 * @apiParam {String}   Request.description.sv_FI  Description of the Product feature. in sweden.
 * @apiParam {String}   Request.description.sv_SE  Description of the Product feature. in sweden.
 * @apiParam {String}   Request.description.nb_No  Description of the Product feature. in Norway.
 * @apiParam {String}   Request.description.nn_No  Description of the Product feature. in Norway.
 * @apiParam {String}   Request.description.pl_PL  Description of the Product feature. in PL.
 * @apiParam {String}   Request.cateogry Choosen category from 'Equipment', 'Service', 'AdditionalBenefit', 'StandardMaterial', 'StandardInstallationWork' 
 * 
 * @apiParamExample {json} Request-Example:
 * {
  "description": {
            "en_GB": "Dummy",
            "fi_FI": "Dummy",
            "sv_FI": "Dummy"
        },
  "category": "Equipment"
}

 * @apiParam {Object[]} Request	     Response is an array of objects.
 * @apiParam {Object}   Request.description  Description of the Product feature.
 * @apiParam {String}   Request.description.en_GB  Description of the Product feature. in english.
 * @apiParam {String}   Request.description.fi_FI  Description of the Product feature. in finnish.
 * @apiParam {String}   Request.description.sv_FI  Description of the Product feature. in sweden.
 * @apiParam {String}   Request.description.sv_SE  Description of the Product feature. in sweden.
 * @apiParam {String}   Request.description.nb_No  Description of the Product feature. in Norway.
 * @apiParam {String}   Request.description.nn_No  Description of the Product feature. in Norway.
 * @apiParam {String}   Request.description.pl_PL  Description of the Product feature. in PL.
 * @apiParam {String}   Request.category   Choosen category from 'Equipment', 'Service', 'AdditionalBenefit', 'StandardMaterial', 'StandardInstallationWork' 
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
[
    {
        "_id": "58e1c9818f7f450011e52dde",
        "description": {
            "en_GB": "Voit seurata järjestelmän tuotantoa sekä kotisi nettokulutusta reaaliajassa Oma Fortum palvelun kautta.",
            "fi_FI": "Voit seurata järjestelmän tuotantoa sekä kotisi nettokulutusta reaaliajassa Oma Fortum palvelun kautta.",
            "sv_FI": "Voit seurata järjestelmän tuotantoa sekä kotisi nettokulutusta reaaliajassa Oma Fortum palvelun kautta."
        },
        "category": "AdditionalBenefit",
        "country": "FI",
        "app": "SODA"
    }
]
 * @apiSuccess {Object}   Response	     Response is an array of objects.
 * @apiSuccess {Object}   Response.description  Description of the Product feature.
 * @apiSuccess {String}   Response.description.en_GB  Description of the Product feature. in english.
 * @apiSuccess {String}   Response.description.fi_FI  Description of the Product feature. in finnish.
 * @apiSuccess {String}   Response.description.sv_FI  Description of the Product feature. in sweden.
 * @apiSuccess {String}   Response.description.sv_SE  Description of the Product feature. in sweden.
 * @apiSuccess {String}   Response.description.nb_No  Description of the Product feature. in Norway.
 * @apiSuccess {String}   Response.description.nn_No  Description of the Product feature. in Norway.
 * @apiSuccess {String}   Response.description.pl_PL  Description of the Product feature. in PL.
 * @apiSuccess {String}   Response._Id   Corresponding MongoDb ID.
 * @apiSuccess {String}   Response.category   Choosen category from 'Equipment', 'Service', 'AdditionalBenefit', 'StandardMaterial', 'StandardInstallationWork' 
 * @apiSuccess {String}   Response.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Response.app   App name 'SODA'
 *
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 */


 

 /**
 * @api {put} /Feature/:producId UpdateSodaProductFeature
 * @apiVersion 1.0.0
 * @apiName UpdateSodaProductFeature
 * @apiGroup SODA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} packageId Which package Id we need to update the data
 * 
 * @apiParam {Object[]} Request Which package Id we need to get the data
 * @apiParam {String} Request.op Mention the operation to do.
 * @apiParam {String} Request.path Mention the data path to change
 * @apiParam {Object} Request.value Mention the data value to change ex: any Object
 * 
 * @apiParamExample {json} Request-Example:
 * [
  {
    "op": "add",
    "path": "/description/en_GB",
    "value": "Fortum Solar Package S 8 - CHANGED 222"
  }
]
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 202 Accepted
 *     {
    "_id": "58e1c9818f7f450011e52dde",
    "description": {
        "en_GB": "Fortum Solar Package S 8 - CHANGED 222",
        "fi_FI": "Voit seurata järjestelmän tuotantoa sekä kotisi nettokulutusta reaaliajassa Oma Fortum palvelun kautta.",
        "sv_FI": "Voit seurata järjestelmän tuotantoa sekä kotisi nettokulutusta reaaliajassa Oma Fortum palvelun kautta."
    },
    "category": "AdditionalBenefit",
    "country": "FI",
    "app": "SODA"
}

 * @apiSuccess {Object}   Response	     Response is an array of objects.
 * @apiSuccess {Object}   Response.description  Description of the Product feature.
 * @apiSuccess {String}   Response.description.en_GB  Description of the Product feature. in english.
 * @apiSuccess {String}   Response.description.fi_FI  Description of the Product feature. in finnish.
 * @apiSuccess {String}   Response.description.sv_FI  Description of the Product feature. in sweden.
 * @apiSuccess {String}   Response.description.sv_SE  Description of the Product feature. in sweden.
 * @apiSuccess {String}   Response.description.nb_No  Description of the Product feature. in Norway.
 * @apiSuccess {String}   Response.description.nn_No  Description of the Product feature. in Norway.
 * @apiSuccess {String}   Response.description.pl_PL  Description of the Product feature. in PL.
 * @apiSuccess {String}   Response._Id   Corresponding MongoDb ID.
 * @apiSuccess {String}   Response.category   Choosen category from 'Equipment', 'Service', 'AdditionalBenefit', 'StandardMaterial', 'StandardInstallationWork' 
 * @apiSuccess {String}   Response.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Response.app   App name 'SODA'
 *
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 *
 */


 /**
 * @api {delete} /Feature?_id=58e1c9818f7f450011e52dde RemoveSodaProductFeature
 * @apiVersion 1.0.0
 * @apiName RemoveSodaProductFeature
 * @apiGroup SODA
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} token ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         token:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} _id Which package Id we need to delete the data
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 204 NO CONTENT
 * 
*  @apiErrorExample Error-Response:
*     HTTP/1.1 404 Not Found
*     {
*       "error": "product Fetaure NotFound"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 401 Not Allowed
*     {
*       "error": "productNotFound"
*     }
*/