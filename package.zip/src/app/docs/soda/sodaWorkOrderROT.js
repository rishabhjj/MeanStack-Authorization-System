/* eslint-disable */

/**
 * @api {get} /WorkOrder/:_Id/rot GetAllWorkOrdersROT
 * @apiVersion 1.0.0
 * @apiName GetAllWorkOrdersROT
 * @apiGroup SODA.WorkOrderROT
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *
 * @apiSuccessExample Success-Response:
 *   HTTP/1.1 200 OK
 *  [
        {
            "rot": true,
            "allocation": [
                {
                "name": "s1",
                "ssn": "100",
                "amount": 2004
                },
                {
                "name": "s2",
                "ssn": "201",
                "amount": 104
                },
                {
                "name": "s3",
                "ssn": "300",
                "amount": 1345
                }
            ]
        }
    ]
  @apiSuccess {Object} Data This is array of Objects
  @apiSuccess {String} Data.workOrderServiceKey This is workOrderServiceKey
  @apiSuccess {String} Data.propertyDetail This is the propertyDetail
  @apiSuccess {Boolean} Data.rot rot
  @apiSuccess {String} Data.createdOn createdOn
  @apiSuccess {String} Data.modifiedOn modifiedOn
  @apiSuccess {Object} Data.allocation External marketing externalMarketingPartner
  @apiSuccess {String} Data.allocation.name name
  @apiSuccess {String} Data.ssn Enter the ssn
  @apiSuccess {Number} Data.amount Enter the amount
 * 
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Address leads not found"
 *     }
 *  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
 */

 /**
 * @api {post} /WorkOrder/:_Id/rot CreateWorkOrderROT
 * @apiVersion 1.0.0
 * @apiName CreateWorkOrderROT
 * @apiGroup SODA.WorkOrderROT
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
  @apiParam {Object} Data This is array of Objects
  @apiParam {String} Data.workOrderServiceKey This is workOrderServiceKey
  @apiParam {String} Data.propertyDetail This is the propertyDetail
  @apiParam {Boolean} Data.rot rot
  @apiParam {String} Data.createdOn createdOn
  @apiParam {String} Data.modifiedOn modifiedOn
  @apiParam {Object} Data.allocation External marketing externalMarketingPartner
  @apiParam {String} Data.allocation.name name
  @apiParam {String} Data.ssn Enter the ssn
  @apiParam {Number} Data.amount Enter the amount
 * 
 * @apiParamExample {json} Request-Example:
 *   {
  "rot": true,
  "allocation": [
    {
      "name": "s1",
      "ssn": "100",
      "amount": 2004
    },
    {
      "name": "s2",
      "ssn": "201",
      "amount": 104
    },
    {
      "name": "s3",
      "ssn": "300",
      "amount": 1345
    }
  ]
}
 * 
  * @apiSuccessExample Success-Response:
 *   HTTP/1.1 201 OK
 *  [
        {
            "rot": true,
            "allocation": [
                {
                "name": "s1",
                "ssn": "100",
                "amount": 2004
                },
                {
                "name": "s2",
                "ssn": "201",
                "amount": 104
                },
                {
                "name": "s3",
                "ssn": "300",
                "amount": 1345
                }
            ]
        }
    ]
  @apiSuccess {Object} Data This is array of Objects
  @apiSuccess {String} Data.workOrderServiceKey This is workOrderServiceKey
  @apiSuccess {String} Data.propertyDetail This is the propertyDetail
  @apiSuccess {Boolean} Data.rot rot
  @apiSuccess {String} Data.createdOn createdOn
  @apiSuccess {String} Data.modifiedOn modifiedOn
  @apiSuccess {Object} Data.allocation External marketing externalMarketingPartner
  @apiSuccess {String} Data.allocation.name name
  @apiSuccess {String} Data.ssn Enter the ssn
  @apiSuccess {Number} Data.amount Enter the amount
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Address leads not found"
 *     }
 *  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
 */


 /**
 * @api {put} /WorkOrder/:_id/rot UpdateSodaWorkorderROT
 * @apiVersion 1.0.0
 * @apiName UpdateSodaProduct
 * @apiGroup SODA.WorkOrderROT
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} _id Which package Id we need to get the data
 * 
 * @apiParam {Object[]} Request Which package Id we need to get the data
 * @apiParam {String} Request.op Mention the operation to do.
 * @apiParam {String} Request.path Mention the data path to change
 * @apiParam {Object} Request.value Mention the data value to change ex: any Object
 * 
 * @apiParamExample {json} Request-Example:
 * [
  {
    "op": "add",
    "path": "/ROT",
    "value": true
  }
]
 * @apiSuccessExample Success-Response:
 *   HTTP/1.1 200 OK
 *  [
        {
            "rot": true,
            "allocation": [
                {
                "name": "s1",
                "ssn": "100",
                "amount": 2004
                },
                {
                "name": "s2",
                "ssn": "201",
                "amount": 104
                },
                {
                "name": "s3",
                "ssn": "300",
                "amount": 1345
                }
            ]
        }
    ]
  @apiSuccess {Object} Data This is array of Objects
  @apiSuccess {String} Data.workOrderServiceKey This is workOrderServiceKey
  @apiSuccess {String} Data.propertyDetail This is the propertyDetail
  @apiSuccess {Boolean} Data.rot rot
  @apiSuccess {String} Data.createdOn createdOn
  @apiSuccess {String} Data.modifiedOn modifiedOn
  @apiSuccess {Object} Data.allocation External marketing externalMarketingPartner
  @apiSuccess {String} Data.allocation.name name
  @apiSuccess {String} Data.ssn Enter the ssn
  @apiSuccess {Number} Data.amount Enter the amount
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Address leads not found"
 *     }
 *  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
 */

 /**
 * @api {delete} /WorkOrder/:_id/rot RemoveSodaWorkOrderROT
 * @apiVersion 1.0.0
 * @apiName RemoveSodaWorkOrderROT
 * @apiGroup SODA.WorkOrderROT
 * 
* @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} token ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         token:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * @apiParam {String} _id Mongodb Id of the address lead
 * 
 * @apiSuccessExample Success-Response:
 *   HTTP/1.1 204 No Content
 *   {}
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Address leads not found"
 *     }
 */


 