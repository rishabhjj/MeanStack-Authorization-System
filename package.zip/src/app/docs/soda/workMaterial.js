/* eslint-disable */
/**
 * @api {get} /WorkMaterial GetAllWorkMaterial
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName GetAllWorkMaterial
 * @apiGroup SODA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *
 * @apiSuccess {Object[]} Request	     Response is an array of objects.
 * @apiSuccess {String}   Request.workMaterialId  workMaterialId.
 * @apiSuccess {Object}   Request.Name  Name of the workmaterial.
 * @apiSuccess {String}   Request.description.en_GB  Name of the workmaterial in english.
 * @apiSuccess {String}   Request.description.fi_FI  Name of the workmaterial in finnish.
 * @apiSuccess {String}   Request.description.sv_FI  Name of the workmaterial in sweden.
 * @apiSuccess {String}   Request.description.sv_SE  Name of the workmaterial in sweden.
 * @apiSuccess {String}   Request.description.nb_No  Name of the workmaterial in Norway.
 * @apiSuccess {String}   Request.description.nn_No  Name of the workmaterial in Norway.
 * @apiSuccess {String}   Request.description.pl_PL  Name of the workmaterial in PL
 * @apiSuccess {Object}   Request.description  Description of the Product feature.
 * @apiSuccess {String}   Request.description.en_GB  Description of the workmaterial in english.
 * @apiSuccess {String}   Request.description.fi_FI  Description of the workmaterial in finnish.
 * @apiSuccess {String}   Request.description.sv_FI  Description of the workmaterial in sweden.
 * @apiSuccess {String}   Request.description.sv_SE  Description of the workmaterial in sweden.
 * @apiSuccess {String}   Request.description.nb_No  Description of the workmaterial in Norway.
 * @apiSuccess {String}   Request.description.nn_No  Description of the workmaterial in Norway.
 * @apiSuccess {String}   Request.description.pl_PL  Description of the workmaterial in PL.
 * @apiSuccess {String}   Request._Id   Corresponding MongoDb ID.
 * @apiSuccess {String}   Request.type   Choosen category from 'Work', 'Material' 
 * @apiSuccess {String}   Request.measurementUnit   Choosen category from 'Quantity', 'Non Quantity', 'Meter', 'KM', 'Calculated'
 * @apiSuccess {Boolean}  Request.isCalculated  Whether it is calculated
 * @apiSuccess {Boolean}  Request.isRemovable   Whether is is removable.
 * @apiSuccess {Boolean}  Request.isPackageSpecific whether package is specific
 * @apiSuccess {Number}   Request.perUnitPrice what is per unit price
 * @apiSuccess {Number}   Request.formula What is the formula
 * @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.app   App name 'SODA', 'FODA', 'VODA', 'BODA'
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
[
   {
        "_id": "5902d078f0ed1600119fd11f",
        "workMaterialId": "crane",
        "title": {
            "fi_FI": "Crane",
            "en_GB": "Crane"
        },
        "description": {
            "fi_FI": "Crane",
            "en_GB": "Crane"
        },
        "type": "Material",
        "measurementUnit": "Calculated",
        "perUnitPrice": null,
        "formula": ".1xinstallation",
        "country": "FI",
        "app": "SODA",
        "isPackageSpecific": true,
        "isRemovable": false,
        "isCalculated": true
    }
]
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 Mongodb-error
 *     {
 *       "error": "Item not found"
 *     }
 * 
 */


 /**
 * @api {post} /WorkMaterial SaveSodaWorkMaterial
 * @apiVersion 1.0.0
 * @apiName SaveSodaProductFeature
 * @apiGroup SODA
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 

 *
 * 
 * @apiParamExample {json} Request-Example:
 *{
  "workMaterialId": "Dummy",
  "title": {
        "en": "Extra mileage",
        "fi": "Extra mittarilukema",
        "se": "Extra körsträcka"
    },
      "description": {
        "en": "If installation wanted outside offered area extra mileage to be added. ",
        "fi": "Jos asennus halusi ulkopuolella tarjotaan alueen ylimääräistä mittarilukema lisättävä.",
        "se": "Om installationen ville utanför erbjuds område extra körsträcka tillsättas ."
    },
  "type": "Work",
  "measurementUnit": "KM",
  "isCalculated": false,
  "perUnitPrice": 1.7,
  "formula":""
}

 * @apiParam {Object} Request Request is an object.
 * @apiParam {String}   Request.workMaterialId  workMaterialId.
 * @apiParam {Object}   Request.Name  Name of the workmaterial.
 * @apiParam {String}   Request.description.en_GB  Name of the workmaterial in english.
 * @apiParam {String}   Request.description.fi_FI  Name of the workmaterial in finnish.
 * @apiParam {String}   Request.description.sv_FI  Name of the workmaterial in sweden.
 * @apiParam {String}   Request.description.sv_SE  Name of the workmaterial in sweden.
 * @apiParam {String}   Request.description.nb_No  Name of the workmaterial in Norway.
 * @apiParam {String}   Request.description.nn_No  Name of the workmaterial in Norway.
 * @apiParam {String}   Request.description.pl_PL  Name of the workmaterial in PL
 * @apiParam {Object}   Request.description  Description of the Product feature.
 * @apiParam {String}   Request.description.en_GB  Description of the workmaterial in english.
 * @apiParam {String}   Request.description.fi_FI  Description of the workmaterial in finnish.
 * @apiParam {String}   Request.description.sv_FI  Description of the workmaterial in sweden.
 * @apiParam {String}   Request.description.sv_SE  Description of the workmaterial in sweden.
 * @apiParam {String}   Request.description.nb_No  Description of the workmaterial in Norway.
 * @apiParam {String}   Request.description.nn_No  Description of the workmaterial in Norway.
 * @apiParam {String}   Request.description.pl_PL  Description of the workmaterial in PL.
 * @apiParam {String}   Request._Id   Corresponding MongoDb ID.
 * @apiParam {String}   Request.type   Choosen category from 'Work', 'Material' 
 * @apiParam {String}   Request.measurementUnit   Choosen category from 'Quantity', 'Non Quantity', 'Meter', 'KM', 'Calculated'
 * @apiParam {Boolean}  Request.isCalculated  Whether it is calculated
 * @apiParam {Boolean}  Request.isRemovable   Whether is is removable.
 * @apiParam {Boolean}  Request.isPackageSpecific whether package is specific
 * @apiParam {Number}   Request.perUnitPrice what is per unit price
 * @apiParam {Number}   Request.formula What is the formula
 * @apiParam {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiParam {String}   Request.app   App name 'SODA', 'FODA', 'VODA', 'BODA'
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
{
        "_id": "5902d078f0ed1600119fd11f",
        "workMaterialId": "crane",
        "title": {
            "fi_FI": "Crane",
            "en_GB": "Crane"
        },
        "description": {
            "fi_FI": "Crane",
            "en_GB": "Crane"
        },
        "type": "Material",
        "measurementUnit": "Calculated",
        "perUnitPrice": null,
        "formula": ".1xinstallation",
        "country": "FI",
        "app": "SODA",
        "isPackageSpecific": true,
        "isRemovable": false,
        "isCalculated": true
    }
 * @apiSuccess {Object} Request Request is an object.
 * @apiSuccess {String}   Request.workMaterialId  workMaterialId.
 * @apiSuccess {Object}   Request.Name  Name of the workmaterial.
 * @apiSuccess {String}   Request.description.en_GB  Name of the workmaterial in english.
 * @apiSuccess {String}   Request.description.fi_FI  Name of the workmaterial in finnish.
 * @apiSuccess {String}   Request.description.sv_FI  Name of the workmaterial in sweden.
 * @apiSuccess {String}   Request.description.sv_SE  Name of the workmaterial in sweden.
 * @apiSuccess {String}   Request.description.nb_No  Name of the workmaterial in Norway.
 * @apiSuccess {String}   Request.description.nn_No  Name of the workmaterial in Norway.
 * @apiSuccess {String}   Request.description.pl_PL  Name of the workmaterial in PL
 * @apiSuccess {Object}   Request.description  Description of the Product feature.
 * @apiSuccess {String}   Request.description.en_GB  Description of the workmaterial in english.
 * @apiSuccess {String}   Request.description.fi_FI  Description of the workmaterial in finnish.
 * @apiSuccess {String}   Request.description.sv_FI  Description of the workmaterial in sweden.
 * @apiSuccess {String}   Request.description.sv_SE  Description of the workmaterial in sweden.
 * @apiSuccess {String}   Request.description.nb_No  Description of the workmaterial in Norway.
 * @apiSuccess {String}   Request.description.nn_No  Description of the workmaterial in Norway.
 * @apiSuccess {String}   Request.description.pl_PL  Description of the workmaterial in PL.
 * @apiSuccess {String}   Request._Id   Corresponding MongoDb ID.
 * @apiSuccess {String}   Request.type   Choosen category from 'Work', 'Material' 
 * @apiSuccess {String}   Request.measurementUnit   Choosen category from 'Quantity', 'Non Quantity', 'Meter', 'KM', 'Calculated'
 * @apiSuccess {Boolean}  Request.isCalculated  Whether it is calculated
 * @apiSuccess {Boolean}  Request.isRemovable   Whether is is removable.
 * @apiSuccess {Boolean}  Request.isPackageSpecific whether package is specific
 * @apiSuccess {Number}   Request.perUnitPrice what is per unit price
 * @apiSuccess {Number}   Request.formula What is the formula
 * @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.app   App name 'SODA', 'FODA', 'VODA', 'BODA'
 *
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 */


 

 /**
 * @api {put} /WorkMaterial/:Id UpdateWorkmaterial
 * @apiVersion 1.0.0
 * @apiName UpdateWorkmaterial
 * @apiGroup SODA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} Id Mongodb id of the work material
 * 
 * @apiParam {Object[]} Request Which package Id we need to get the data
 * @apiParam {String} Request.op Mention the operation to do.
 * @apiParam {String} Request.path Mention the data path to change
 * @apiParam {Object} Request.value Mention the data value to change ex: any Object
 * 
 * @apiParamExample {json} Request-Example:
 * [
  {
    "op": "add",
    "path": "/title/fi_FI",
    "value": "Fortum Solar Package S 8 - CHANGED 222"
  }
]
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 202 Accepted
 *     {
        "_id": "5902d078f0ed1600119fd11f",
        "workMaterialId": "crane",
        "title": {
            "fi_FI": ""Fortum Solar Package S 8 - CHANGED 222",
            "en_GB": "Crane"
        },
        "description": {
            "fi_FI": "Crane",
            "en_GB": "Crane"
        },
        "type": "Material",
        "measurementUnit": "Calculated",
        "perUnitPrice": null,
        "formula": ".1xinstallation",
        "country": "FI",
        "app": "SODA",
        "isPackageSpecific": true,
        "isRemovable": false,
        "isCalculated": true
    }

 * @apiSuccess {Object} Request Request is an object.
 * @apiSuccess {String}   Request.workMaterialId  workMaterialId.
 * @apiSuccess {Object}   Request.Name  Name of the workmaterial.
 * @apiSuccess {String}   Request.description.en_GB  Name of the workmaterial in english.
 * @apiSuccess {String}   Request.description.fi_FI  Name of the workmaterial in finnish.
 * @apiSuccess {String}   Request.description.sv_FI  Name of the workmaterial in sweden.
 * @apiSuccess {String}   Request.description.sv_SE  Name of the workmaterial in sweden.
 * @apiSuccess {String}   Request.description.nb_No  Name of the workmaterial in Norway.
 * @apiSuccess {String}   Request.description.nn_No  Name of the workmaterial in Norway.
 * @apiSuccess {String}   Request.description.pl_PL  Name of the workmaterial in PL
 * @apiSuccess {Object}   Request.description  Description of the Product feature.
 * @apiSuccess {String}   Request.description.en_GB  Description of the workmaterial in english.
 * @apiSuccess {String}   Request.description.fi_FI  Description of the workmaterial in finnish.
 * @apiSuccess {String}   Request.description.sv_FI  Description of the workmaterial in sweden.
 * @apiSuccess {String}   Request.description.sv_SE  Description of the workmaterial in sweden.
 * @apiSuccess {String}   Request.description.nb_No  Description of the workmaterial in Norway.
 * @apiSuccess {String}   Request.description.nn_No  Description of the workmaterial in Norway.
 * @apiSuccess {String}   Request.description.pl_PL  Description of the workmaterial in PL.
 * @apiSuccess {String}   Request._Id   Corresponding MongoDb ID.
 * @apiSuccess {String}   Request.type   Choosen category from 'Work', 'Material' 
 * @apiSuccess {String}   Request.measurementUnit   Choosen category from 'Quantity', 'Non Quantity', 'Meter', 'KM', 'Calculated'
 * @apiSuccess {Boolean}  Request.isCalculated  Whether it is calculated
 * @apiSuccess {Boolean}  Request.isRemovable   Whether is is removable.
 * @apiSuccess {Boolean}  Request.isPackageSpecific whether package is specific
 * @apiSuccess {Number}   Request.perUnitPrice what is per unit price
 * @apiSuccess {Number}   Request.formula What is the formula
 * @apiSuccess {String}   Request.country   Choosen country from 'FI', 'SE', 'PL', 'NO'
 * @apiSuccess {String}   Request.app   App name 'SODA', 'FODA', 'VODA', 'BODA'
 *
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 *
 */


 /**
 * @api {delete} /Feature?_id=58e1c9818f7f450011e52dde RemoveWorkMaterial
 * @apiVersion 1.0.0
 * @apiName RemoveWorkMaterial
 * @apiGroup SODA
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} token ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         token:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {Boolean} _id Which package Id we need to delete the data
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 204 NO CONTENT
 * 
*  @apiErrorExample Error-Response:
*     HTTP/1.1 404 Not Found
*     {
*       "error": "product Fetaure NotFound"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 401 Not Allowed
*     {
*       "error": "productNotFound"
*     }
*/