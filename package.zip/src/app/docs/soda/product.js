/* eslint-disable */
/**
 * @api {get} /Product?includeInvalidProducts=false GetAllSodaProducts
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName GetAllSodaProducts
 * @apiGroup SODA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {Boolean} includeInvalidProducts whether to include InvalidProducts.
 *
 * @apiSuccess {Object[]} Response	     Response is an array of objects.
 * @apiSuccess {Object}   Request.nameOfPackage  Name of the package.
 * @apiSuccess {String}   Request.nameOfPackage.en_GB  Name of the package in english.
 * @apiSuccess {String}   Request.nameOfPackage.fi_FI  Name of the package in finnish.
 * @apiSuccess {String}   Request.nameOfPackage.sv_FI  Name of the package in sweden.
 * @apiSuccess {String}   Request.nameOfPackage.sv_SE  Name of the package in sweden.
 * @apiSuccess {String}   Request.nameOfPackage.nb_No  Name of the package in Norway.
 * @apiSuccess {String}   Request.nameOfPackage.nn_No  Name of the package in Norway.
 * @apiSuccess {String}   Request.nameOfPackage.pl_PL  Name of the package in PL.
 * @apiSuccess {Object}   Request.description  Description of the package.
 * @apiSuccess {String}   Request.description.en_GB  Description of the package in english.
 * @apiSuccess {String}   Request.description.fi_FI  Description of the package in finnish.
 * @apiSuccess {String}   Request.description.sv_FI  Description of the package in sweden.
 * @apiSuccess {String}   Request.description.sv_SE  Description of the package in sweden.
 * @apiSuccess {String}   Request.description.nb_No  Description of the package in Norway.
 * @apiSuccess {String}   Request.description.nn_No  Description of the package in Norway.
 * @apiSuccess {String}   Request.description.pl_PL  Description of the package in PL.
 * @apiSuccess {String}   Request.packageId   PackageId.
 * @apiSuccess {String}   Request.nameOfProductGroup   Name of the product Group.
 * @apiSuccess {String}   Request.productGroupId   Name of the product Group Id.
 * @apiSuccess {String}   Request.inverterModel   Name of the inverter model.
 * @apiSuccess {String}   Request.optimizer   Name of the optimizer.
 * @apiSuccess {String}   Request.panelModel   Name of the panel model.
 * @apiSuccess {Number}   Request.noOfSolarPanels   Number of solar panels
 * @apiSuccess {Number}   Request.effectiveArea   Mention effective area
 * @apiSuccess {Number}   Request.effectiveAreaUnit   Mention effective area unit ex: Square, Metre
 * @apiSuccess {Object}   Request.panelOuterDimensions   Panel outdoor diemensions
 * @apiSuccess {Number}   Request.panelOuterDimensions.width   Panel outdoor width
 * @apiSuccess {Number}   Request.panelOuterDimensions.height   Panel outdoor height
 * @apiSuccess {Number}   Request.panelOuterDimensions.thickness   Panel outdoor thickness
 * @apiSuccess {Number}   Request.panelOuterDimensions.unit   Panel outdoor unit
 * @apiSuccess {Number}   Request.peakPower   Mention peak power
 * @apiSuccess {String}   Request.peakPower   Mention peak power unit ex : Square, Metre
 * @apiSuccess {String}   Request.currencyUnit   Product currency unit ex : EUR, Kr, NOK, PLN
 * @apiSuccess {Object}   Request.price   Product price
 * @apiSuccess {Number}   Request.price.productPackage   Product package price 
 * @apiSuccess {Number}   Request.price.installation   Product installation price 
 * @apiSuccess {Object}   Request.price.extraMaterialOrMachine   Product extraMaterial Or Machine price 
 * @apiSuccess {Number}   Request.price.extraMaterialOrMachine.flatRoof   Product  flatroof price 
 * @apiSuccess {Number}   Request.price.extraMaterialOrMachine.crane   Product crane usage price 
 * @apiSuccess {Object}   Request.price.extraWork   Product extraMaterial Or Machine price 
 * @apiSuccess {Number}   Request.price.extraWork.tileRoof   Tile roof charge 
 * @apiSuccess {Number}   Request.price.extraWork.steepRoof   Steep roof charge 
 * @apiSuccess {Object[]} Request.price.subsidies	    Subsidy product.
 * @apiSuccess {Object}   Request.price.subsidies.name	    Name of the subsidy product.
 * @apiSuccess {String}   Request.price.subsidies.name.en_GB  Name of the package in english.
 * @apiSuccess {String}   Request.price.subsidies.name.fi_FI  Name of the package in finnish.
 * @apiSuccess {String}   Request.price.subsidies.name.sv_FI  Name of the package in sweden.
 * @apiSuccess {String}   Request.price.subsidies.name.sv_SE  Name of the package in sweden.
 * @apiSuccess {String}   Request.price.subsidies.name.nb_No  Name of the package in Norway.
 * @apiSuccess {String}   Request.price.subsidies.name.nn_No  Name of the package in Norway.
 * @apiSuccess {String}   Request.price.subsidies.name.pl_PL  Name of the package in PL.
 * @apiSuccess {Number}   Request.price.subsidies.amount	     Subsidies for this product.
 * @apiSuccess {Object}   Request.price.standard	     Standrad for this product
 * @apiSuccess {Number}   Request.price.standard.packageAndInstallation	     Standard package installation.
 * @apiSuccess {Number}   Request.price.standard.noOfRails	     Standard package number of rails.
 * @apiSuccess {Number}   Request.price.standard.sections	     Standard package number of sections.
 * @apiSuccess {Object}   Request.price.standard.height	     Standard package number of sections height.
 * @apiSuccess {Number}   Request.price.standard.height.moreThan3dot5AndlessThan4dot5	     moreThan3dot5AndlessThan4dot5.
 * @apiSuccess {Number}   Request.price.standard.height.moreThan4dot5AndlessThan6	     moreThan4dot5AndlessThan6.
 * 
 * @apiSuccess {Object}   Request.price.tile	     Tile for this product
 * @apiSuccess {Number}   Request.price.tile.packageAndInstallation	     Tile package installation.
 * @apiSuccess {Number}   Request.price.tile.noOfRails	     Tile package number of rails.
 * @apiSuccess {Number}   Request.price.tile.sections	     Tile package number of sections.
 * @apiSuccess {Object}   Request.price.tile.height	     Tile package number of sections height.
 * @apiSuccess {Number}   Request.price.tile.height.moreThan3dot5AndlessThan4dot5	     moreThan3dot5AndlessThan4dot5.
 * @apiSuccess {Number}   Request.price.tile.height.moreThan4dot5AndlessThan6	     moreThan4dot5AndlessThan6.
 * 
 * @apiSuccess {Object}   Request.price.common	     Common price of the product
 * @apiSuccess {Object}   Request.price.common.cable	     Product cable details
 * @apiSuccess {Number}   Request.price.common.cable.moreThan10AndLessThan20	     Cable length.
 * @apiSuccess {Number}   Request.price.common.cable.moreThan20	     Cable length.
 * @apiSuccess {Object}   Request.price.common.angle	     Product angle details
 * @apiSuccess {Number}   Request.price.common.angle.moreThan10AndLessThan30	     Cable angle.
 * @apiSuccess {Number}   Request.price.common.angle.moreThan30	     Cable angle.
 * @apiSuccess {Object[]} Request.includedInfo	     Additional included info.
 * @apiSuccess {Object} Request.includedInfo.description	     Additional included info description.
 * @apiSuccess {String} Request.includedInfo.description.en_GB	     Additional included info description in english.
 * @apiSuccess {String} Request.includedInfo.description.fi_FI	     Additional included info description in finnish.
 * @apiSuccess {String} Request.includedInfo.description.sv_FI	     Additional included info description in sweden.
 * @apiSuccess {Object[]} Request.includedInfo.category	     Additional included infos category.
 * @apiSuccess {Object[]} Request.includedInfo._id	     Additional included infos mongodb id.
 
 * @apiSuccess {Number}   Request.noOfInstallmentMonths   Number of installment months
 * @apiSuccess {String}   Request.startDate   Start date as string format
 * @apiSuccess {String}   Request.endDate   End date as string format
 * @apiSuccess {String}   Request.country   Choosen country
 * @apiSuccess {String}   Request.createdOn   Product created date
 * @apiSuccess {String}   Request.modifiedon   Product modified date
 * @apiSuccess {Boolean}  Request.isActive   Wether the product is active or not
 * @apiSuccess {String}   Request.app   App name
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  [{
	"_id": "59f2dbdaf47bc300121b1cbf",
	"nameOfPackage": {
		"en_GB": "Fortum Solar Package S 8",
		"fi_FI": "Fortum Aurinkopaketti S 8",
		"sv_FI": "Fortum Solcellspaket S 8"
	},
	"description": {
		"en_GB": "Edullinen paketti kesämökeille ja pienemmille taloille ilman sähkölämmitystä",
		"fi_FI": "Edullinen paketti kesämökeille ja pienemmille taloille ilman sähkölämmitystä",
		"sv_FI": "Edullinen paketti kesämökeille ja pienemmille taloille ilman sähkölämmitystä"
	},
	"packageId": "060117_8_PANELS_SMA_SB25_HANHWA_QPLUS_BFR-G4.1",
	"nameOfProductGroup": "S",
	"productGroupId": "fortum_s",
	"inverterModel": "SMA SB 2.5",
	"panelModel": "Hanwha Q.PLUS BFR-G4.1",
	"noOfSolarPanels": 8,
	"effectiveArea": 11.68,
	"panelOuterDimensions": {
		"width": 1,
		"height": 1.67,
		"thickness": 0.034,
		"unit": "Meters"
	},
	"peakPower": 2240,
	"price": {
		"productPackage": 2700,
		"installation": 2100,
		"extraMaterialOrMachine": {
			"flatRoof": 735,
			"crane": 480
		},
		"extraWork": {
			"tileRoof": 495,
			"steepRoof": 330
		},
		"subsidies": []
	},
	"noOfInstallmentMonths": 36,
	"startDate": "2017-01-06T00:00:00.000Z",
	"endDate": "2017-12-31T00:00:00.000Z",
	"country": "FI",
	"app": "SODA",
	"createdOn": "2017-10-27T07:10:18.761Z",
	"isActive": true,
	"includedInfo": [{
		"description": {
			"en_GB": "8 paneelia, Q CELLS Q.PLUS BFR-G4.1 280Wp",
			"fi_FI": "8 paneelia, Q CELLS Q.PLUS BFR-G4.1 280Wp",
			"sv_FI": "8 paneelia, Q CELLS Q.PLUS BFR-G4.1 280Wp"
		},
		"category": "StandardMaterial",
		"_id": "59f2dbdaf47bc300121b1cc8"
	}, {
		"description": {
			"en_GB": "Invertteri: SMA SB2.5-1VL-40",
			"fi_FI": "Invertteri: SMA SB2.5-1VL-40",
			"sv_FI": "Invertteri: SMA SB2.5-1VL-40"
		},
		"category": "StandardMaterial",
		"_id": "59f2dbdaf47bc300121b1cc7"
	}, {
		"description": {
			"en_GB": "Kaapelit: AC (2m) ja DC (30m)",
			"fi_FI": "Kaapelit: AC (2m) ja DC (30m)",
			"sv_FI": "Kaapelit: AC (2m) ja DC (30m)"
		},
		"category": "StandardMaterial",
		"_id": "59f2dbdaf47bc300121b1cc6"
	}, {
		"description": {
			"en_GB": "Johdonsuojakytkin: 1 kpl",
			"fi_FI": "Johdonsuojakytkin: 1 kpl",
			"sv_FI": "Johdonsuojakytkin: 1 kpl"
		},
		"category": "StandardMaterial",
		"_id": "59f2dbdaf47bc300121b1cc5"
	}, {
		"description": {
			"en_GB": "8 x Q CELLS Q.PLUS BFR-G4.1 280Wp paneeli",
			"fi_FI": "8 x Q CELLS Q.PLUS BFR-G4.1 280Wp paneeli",
			"sv_FI": "8 x Q CELLS Q.PLUS BFR-G4.1 280Wp paneeli"
		},
		"category": "Equipment",
		"_id": "59f2dbdaf47bc300121b1cc4"
	}, {
		"description": {
			"en_GB": "1 x SMA SB2.5-1VL-40 invertteri",
			"fi_FI": "1 x SMA SB2.5-1VL-40 invertteri",
			"sv_FI": "1 x SMA SB2.5-1VL-40 invertteri"
		},
		"category": "Equipment",
		"_id": "59f2dbdaf47bc300121b1cc3"
	}, {
		"description": {
			"en_GB": "5 vuoden takuun invertterille",
			"fi_FI": "5 vuoden takuun invertterille",
			"sv_FI": "5 vuoden takuun invertterille"
		},
		"category": "Service",
		"_id": "59f2dbdaf47bc300121b1cc2"
	}, {
		"description": {
			"en_GB": "10 valmistustakuun paneeleille",
			"fi_FI": "10 valmistustakuun paneeleille",
			"sv_FI": "10 valmistustakuun paneeleille"
		},
		"category": "Service",
		"_id": "59f2dbdaf47bc300121b1cc1"
	}, {
		"description": {
			"en_GB": "25 vuoden tuotantotehotakuun paneeleille",
			"fi_FI": "25 vuoden tuotantotehotakuun paneeleille",
			"sv_FI": "25 vuoden tuotantotehotakuun paneeleille"
		},
		"category": "Service",
		"_id": "59f2dbdaf47bc300121b1cc0"
	}],
	"currencyUnit": "EUR",
	"peakPowerUnit": "Watts",
	"effectiveAreaUnit": "Square Metre"
}]
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 Mongodb-error
 *     {
 *       "error": "Item not found"
 *     }
 * 
 */


 /**
 * @api {post} /Product SaveSodaProduct
 * @apiVersion 1.0.0
 * @apiName SaveSodaProduct
 * @apiGroup SODA
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 
 * @apiParam {Object}   Request.nameOfPackage  Name of the package.
 * @apiParam {String}   Request.nameOfPackage.en_GB  Name of the package in english.
 * @apiParam {String}   Request.nameOfPackage.fi_FI  Name of the package in finnish.
 * @apiParam {String}   Request.nameOfPackage.sv_FI  Name of the package in sweden.
 * @apiParam {String}   Request.nameOfPackage.sv_SE  Name of the package in sweden.
 * @apiParam {String}   Request.nameOfPackage.nb_No  Name of the package in Norway.
 * @apiParam {String}   Request.nameOfPackage.nn_No  Name of the package in Norway.
 * @apiParam {String}   Request.nameOfPackage.pl_PL  Name of the package in PL.
 * @apiParam {Object}   Request.description  Description of the package.
 * @apiParam {String}   Request.description.en_GB  Description of the package in english.
 * @apiParam {String}   Request.description.fi_FI  Description of the package in finnish.
 * @apiParam {String}   Request.description.sv_FI  Description of the package in sweden.
 * @apiParam {String}   Request.description.sv_SE  Description of the package in sweden.
 * @apiParam {String}   Request.description.nb_No  Description of the package in Norway.
 * @apiParam {String}   Request.description.nn_No  Description of the package in Norway.
 * @apiParam {String}   Request.description.pl_PL  Description of the package in PL.
 * @apiParam {String}   Request.packageId   PackageId.
 * @apiParam {String}   Request.nameOfProductGroup   Name of the product Group.
 * @apiParam {String}   Request.productGroupId   Product Group Id.
 * @apiParam {String}   Request.inverterModel   Name of the inverter model.
 * @apiParam {String}   Request.optimizer   Name of the optimizer.
 * @apiParam {String}   Request.panelModel   Name of the panel model.
 * @apiParam {Number}   Request.noOfSolarPanels   Number of solar panels
 * @apiParam {Number}   Request.effectiveArea   Mention effective area
 * @apiParam {Number}   Request.effectiveAreaUnit   Mention effective area unit ex: Square, Metre
 * @apiParam {Object}   Request.panelOuterDimensions   Panel outdoor diemensions
 * @apiParam {Number}   Request.panelOuterDimensions.width   Panel outdoor width
 * @apiParam {Number}   Request.panelOuterDimensions.height   Panel outdoor height
 * @apiParam {Number}   Request.panelOuterDimensions.thickness   Panel outdoor thickness
 * @apiParam {Number}   Request.panelOuterDimensions.unit   Panel outdoor unit
 * @apiParam {Number}   Request.peakPower   Mention peak power
 * @apiParam {String}   Request.peakPower   Mention peak power unit ex : Square, Metre
 * @apiParam {String}   Request.currencyUnit   Product currency unit ex : EUR, Kr, NOK, PLN
 * @apiParam {Object}   Request.price   Product price
 * @apiParam {Number}   Request.price.productPackage   Product package price 
 * @apiParam {Number}   Request.price.installation   Product installation price 
 * @apiParam {Object}   Request.price.extraMaterialOrMachine   Product extraMaterial Or Machine price 
 * @apiParam {Number}   Request.price.extraMaterialOrMachine.flatRoof   Product  flatroof price 
 * @apiParam {Number}   Request.price.extraMaterialOrMachine.crane   Product crane usage price 
 * @apiParam {Object}   Request.price.extraWork   Product extraMaterial Or Machine price 
 * @apiParam {Number}   Request.price.extraWork.tileRoof   Tile roof charge 
 * @apiParam {Number}   Request.price.extraWork.steepRoof   Steep roof charge 
 * @apiSuccess {Object[]} Request.price.subsidies	    Name of the subsidy product.
 * @apiParam {Object}   Request.price.subsidies.name	    Name of the subsidy product.
 * @apiParam {String}   Request.price.subsidies.name.en_GB  Name of the package in english.
 * @apiParam {String}   Request.price.subsidies.name.fi_FI  Name of the package in finnish.
 * @apiParam {String}   Request.price.subsidies.name.sv_FI  Name of the package in sweden.
 * @apiParam {String}   Request.price.subsidies.name.sv_SE  Name of the package in sweden.
 * @apiParam {String}   Request.price.subsidies.name.nb_No  Name of the package in Norway.
 * @apiParam {String}   Request.price.subsidies.name.nn_No  Name of the package in Norway.
 * @apiParam {String}   Request.price.subsidies.name.pl_PL  Name of the package in PL.
 * @apiParam {Number}   Request.price.subsidies.amount	     Subsidies for this product.
 * @apiParam {Object}   Request.price.standard	     Subsidies for this product
 * @apiParam {Number}   Request.price.standard.packageAndInstallation	     Standard package installation.
 * @apiParam {Number}   Request.price.standard.noOfRails	     Standard package number of rails.
 * @apiParam {Number}   Request.price.standard.sections	     Standard package number of sections.
 * @apiParam {Object}   Request.price.standard.height	     Standard package number of sections height.
 * @apiParam {Number}   Request.price.standard.height.moreThan3dot5AndlessThan4dot5	     moreThan3dot5AndlessThan4dot5.
 * @apiParam {Number}   Request.price.standard.height.moreThan4dot5AndlessThan6	     moreThan4dot5AndlessThan6.
 * 
 * @apiParam {Object}   Request.price.tile	     Subsidies for this product
 * @apiParam {Number}   Request.price.tile.packageAndInstallation	     Tile package installation.
 * @apiParam {Number}   Request.price.tile.noOfRails	     Tile package number of rails.
 * @apiParam {Number}   Request.price.tile.sections	     Tile package number of sections.
 * @apiParam {Object}   Request.price.tile.height	     Tile package number of sections height.
 * @apiParam {Number}   Request.price.tile.height.moreThan3dot5AndlessThan4dot5	     moreThan3dot5AndlessThan4dot5.
 * @apiParam {Number}   Request.price.tile.height.moreThan4dot5AndlessThan6	     moreThan4dot5AndlessThan6.
 * 
 * @apiParam {Object}   Request.price.common	     Common price of the product
 * @apiParam {Object}   Request.price.common.cable	     Product cable details
 * @apiParam {Number}   Request.price.common.cable.moreThan10AndLessThan20	     Cable length.
 * @apiParam {Number}   Request.price.common.cable.moreThan20	     Cable length.
 * @apiParam {Object}   Request.price.common.angle	     Product angle details
 * @apiParam {Number}   Request.price.common.angle.moreThan10AndLessThan30	     Cable angle.
 * @apiParam {Number}   Request.price.common.angle.moreThan30	     Cable angle.
 * @apiParam {Object[]} Request.includedInfo	     Additional included info.
 * @apiParam {Object} Request.includedInfo.description	     Additional included info description.
 * @apiParam {String} Request.includedInfo.description.en_GB	     Additional included info description in english.
 * @apiParam {String} Request.includedInfo.description.fi_FI	     Additional included info description in finnish.
 * @apiParam {String} Request.includedInfo.description.sv_FI	     Additional included info description in sweden.
 * @apiParam {Object[]} Request.includedInfo.category	     Additional included infos category.
 * @apiParam {Object[]} Request.includedInfo._id	     Additional included infos mongodb id.
 
 * @apiParam {Number}   Request.noOfInstallmentMonths   Number of installment months
 * @apiParam {String}   Request.startDate   Start date as string format
 * @apiParam {String}   Request.endDate   End date as string format
 * @apiParam {String}   Request.country   Choosen country
 * @apiParam {Boolean}   Request.isActive   Wether the product is active or not

 * 
 * @apiParamExample {json} Request-Example:
 * {
  "nameOfPackage": {
    "en": "Fortum Solar Package S 8",
    "fi": "Fortum Aurinkopaketti S 8",
    "se": "Fortum Solcellspaket S 8"
  },
  "description": {
    "en": "Ideal solution for small houses and summer cottages.",
    "fi": "Ihanteellinen ratkaisu pienille Omakotitalojen.",
    "se": "Den idealiska lösningen för småhus och fritidshus."
  },
  "packageId": "futureoneprod1",
  "nameOfProductGroup": "S",
  "productGroupId": "fortum_s",
  "inverterModel": "SMA SB 2.5",
  "panelModel": "Hanwha Q.PLUS BFR-G4.1",
  "noOfSolarPanels": 8,
  "effectiveArea": 11.68,
  "effectiveAreaUnit": "Square Metre",
  "panelOuterDimensions": {
    "width": 1,
    "height": 1.67,
    "thickness": 0.034,
    "unit": "Meters"
  },
  "peakPower": 2240,
  "peakPowerUnit": "Watts",
  "currencyUnit": "EUR",
  "price": {
    "productPackage": 2700,
    "installation": 2100,
    "subsidies": [
      
    ],
    "extraMaterialOrMachine": {
      "flatRoof": 735,
      "crane": 480
    },
    "extraWork": {
      "tileRoof": 495,
      "steepRoof": 330
    }
  },
  "noOfInstallmentMonths": 36,
  "startDate": "01-06-2018",
  "endDate": "12-31-2018",
  "isActive": false
}
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
    "__v": 0,
    "app": "SODA",
    "country": "FI",
    "nameOfPackage": {},
    "description": {},
    "packageId": "futureoneproditem",
    "nameOfProductGroup": "S",
    "productGroupId": "fortum_s",
    "inverterModel": "SMA SB 2.5",
    "panelModel": "Hanwha Q.PLUS BFR-G4.1",
    "noOfSolarPanels": 8,
    "effectiveArea": 11.68,
    "panelOuterDimensions": {
        "width": 1,
        "height": 1.67,
        "thickness": 0.034,
        "unit": "Meters"
    },
    "peakPower": 2240,
    "price": {
        "productPackage": 2700,
        "installation": 2100,
        "extraMaterialOrMachine": {
            "flatRoof": 735,
            "crane": 480
        },
        "extraWork": {
            "tileRoof": 495,
            "steepRoof": 330
        },
        "subsidies": []
    },
    "noOfInstallmentMonths": 36,
    "startDate": "2018-01-06T00:00:00.000Z",
    "endDate": "2018-12-31T00:00:00.000Z",
    "_id": "5a2f665f8177d615bc3eb563",
    "createdOn": "2017-12-12T05:17:19.765Z",
    "isActive": false,
    "includedInfo": [],
    "currencyUnit": "EUR",
    "peakPowerUnit": "Watts",
    "effectiveAreaUnit": "Square Metre"
}
 * @apiSuccess {Object}   Request.nameOfPackage  Name of the package.
 * @apiSuccess {String}   Request.nameOfPackage.en_GB  Name of the package in english.
 * @apiSuccess {String}   Request.nameOfPackage.fi_FI  Name of the package in finnish.
 * @apiSuccess {String}   Request.nameOfPackage.sv_FI  Name of the package in sweden.
 * @apiSuccess {String}   Request.nameOfPackage.sv_SE  Name of the package in sweden.
 * @apiSuccess {String}   Request.nameOfPackage.nb_No  Name of the package in Norway.
 * @apiSuccess {String}   Request.nameOfPackage.nn_No  Name of the package in Norway.
 * @apiSuccess {String}   Request.nameOfPackage.pl_PL  Name of the package in PL.
 * @apiSuccess {Object}   Request.description  Description of the package.
 * @apiSuccess {String}   Request.description.en_GB  Description of the package in english.
 * @apiSuccess {String}   Request.description.fi_FI  Description of the package in finnish.
 * @apiSuccess {String}   Request.description.sv_FI  Description of the package in sweden.
 * @apiSuccess {String}   Request.description.sv_SE  Description of the package in sweden.
 * @apiSuccess {String}   Request.description.nb_No  Description of the package in Norway.
 * @apiSuccess {String}   Request.description.nn_No  Description of the package in Norway.
 * @apiSuccess {String}   Request.description.pl_PL  Description of the package in PL.
 * @apiSuccess {String}   Request.packageId   PackageId.
 * @apiSuccess {String}   Request.nameOfProductGroup   Name of the product Group.
 * @apiSuccess {String}   Request.productGroupId   Name of the product Group Id.
 * @apiSuccess {String}   Request.inverterModel   Name of the inverter model.
 * @apiSuccess {String}   Request.optimizer   Name of the optimizer.
 * @apiSuccess {String}   Request.panelModel   Name of the panel model.
 * @apiSuccess {Number}   Request.noOfSolarPanels   Number of solar panels
 * @apiSuccess {Number}   Request.effectiveArea   Mention effective area
 * @apiSuccess {Number}   Request.effectiveAreaUnit   Mention effective area unit ex: Square, Metre
 * @apiSuccess {Object}   Request.panelOuterDimensions   Panel outdoor diemensions
 * @apiSuccess {Number}   Request.panelOuterDimensions.width   Panel outdoor width
 * @apiSuccess {Number}   Request.panelOuterDimensions.height   Panel outdoor height
 * @apiSuccess {Number}   Request.panelOuterDimensions.thickness   Panel outdoor thickness
 * @apiSuccess {Number}   Request.panelOuterDimensions.unit   Panel outdoor unit
 * @apiSuccess {Number}   Request.peakPower   Mention peak power
 * @apiSuccess {String}   Request.peakPower   Mention peak power unit ex : Square, Metre
 * @apiSuccess {String}   Request.currencyUnit   Product currency unit ex : EUR, Kr, NOK, PLN
 * @apiSuccess {Object}   Request.price   Product price
 * @apiSuccess {Number}   Request.price.productPackage   Product package price 
 * @apiSuccess {Number}   Request.price.installation   Product installation price 
 * @apiSuccess {Object}   Request.price.extraMaterialOrMachine   Product extraMaterial Or Machine price 
 * @apiSuccess {Number}   Request.price.extraMaterialOrMachine.flatRoof   Product  flatroof price 
 * @apiSuccess {Number}   Request.price.extraMaterialOrMachine.crane   Product crane usage price 
 * @apiSuccess {Object}   Request.price.extraWork   Product extraMaterial Or Machine price 
 * @apiSuccess {Number}   Request.price.extraWork.tileRoof   Tile roof charge 
 * @apiSuccess {Number}   Request.price.extraWork.steepRoof   Steep roof charge 
 * @apiSuccess {Object[]} Request.price.subsidies	    Subsidy product.
 * @apiSuccess {Object}   Request.price.subsidies.name	    Name of the subsidy product.
 * @apiSuccess {String}   Request.price.subsidies.name.en_GB  Name of the package in english.
 * @apiSuccess {String}   Request.price.subsidies.name.fi_FI  Name of the package in finnish.
 * @apiSuccess {String}   Request.price.subsidies.name.sv_FI  Name of the package in sweden.
 * @apiSuccess {String}   Request.price.subsidies.name.sv_SE  Name of the package in sweden.
 * @apiSuccess {String}   Request.price.subsidies.name.nb_No  Name of the package in Norway.
 * @apiSuccess {String}   Request.price.subsidies.name.nn_No  Name of the package in Norway.
 * @apiSuccess {String}   Request.price.subsidies.name.pl_PL  Name of the package in PL.
 * @apiSuccess {Number}   Request.price.subsidies.amount	     Subsidies for this product.
 * @apiSuccess {Object}   Request.price.standard	     Standrad for this product
 * @apiSuccess {Number}   Request.price.standard.packageAndInstallation	     Standard package installation.
 * @apiSuccess {Number}   Request.price.standard.noOfRails	     Standard package number of rails.
 * @apiSuccess {Number}   Request.price.standard.sections	     Standard package number of sections.
 * @apiSuccess {Object}   Request.price.standard.height	     Standard package number of sections height.
 * @apiSuccess {Number}   Request.price.standard.height.moreThan3dot5AndlessThan4dot5	     moreThan3dot5AndlessThan4dot5.
 * @apiSuccess {Number}   Request.price.standard.height.moreThan4dot5AndlessThan6	     moreThan4dot5AndlessThan6.
 * 
 * @apiSuccess {Object}   Request.price.tile	     Tile for this product
 * @apiSuccess {Number}   Request.price.tile.packageAndInstallation	     Tile package installation.
 * @apiSuccess {Number}   Request.price.tile.noOfRails	     Tile package number of rails.
 * @apiSuccess {Number}   Request.price.tile.sections	     Tile package number of sections.
 * @apiSuccess {Object}   Request.price.tile.height	     Tile package number of sections height.
 * @apiSuccess {Number}   Request.price.tile.height.moreThan3dot5AndlessThan4dot5	     moreThan3dot5AndlessThan4dot5.
 * @apiSuccess {Number}   Request.price.tile.height.moreThan4dot5AndlessThan6	     moreThan4dot5AndlessThan6.
 * 
 * @apiSuccess {Object}   Request.price.common	     Common price of the product
 * @apiSuccess {Object}   Request.price.common.cable	     Product cable details
 * @apiSuccess {Number}   Request.price.common.cable.moreThan10AndLessThan20	     Cable length.
 * @apiSuccess {Number}   Request.price.common.cable.moreThan20	     Cable length.
 * @apiSuccess {Object}   Request.price.common.angle	     Product angle details
 * @apiSuccess {Number}   Request.price.common.angle.moreThan10AndLessThan30	     Cable angle.
 * @apiSuccess {Number}   Request.price.common.angle.moreThan30	     Cable angle.
 * @apiSuccess {Object[]} Request.includedInfo	     Additional included info.
 * @apiSuccess {Object} Request.includedInfo.description	     Additional included info description.
 * @apiSuccess {String} Request.includedInfo.description.en_GB	     Additional included info description in english.
 * @apiSuccess {String} Request.includedInfo.description.fi_FI	     Additional included info description in finnish.
 * @apiSuccess {String} Request.includedInfo.description.sv_FI	     Additional included info description in sweden.
 * @apiSuccess {Object[]} Request.includedInfo.category	     Additional included infos category.
 * @apiSuccess {Object[]} Request.includedInfo._id	     Additional included infos mongodb id.
 
 * @apiSuccess {Number}   Request.noOfInstallmentMonths   Number of installment months
 * @apiSuccess {String}   Request.startDate   Start date as string format
 * @apiSuccess {String}   Request.endDate   End date as string format
 * @apiSuccess {String}   Request.country   Choosen country
 * @apiSuccess {String}   Request.createdOn   Product created date
 * @apiSuccess {String}   Request.modifiedon   Product modified date
 * @apiSuccess {Boolean}   Request.isActive   Wether the product is active or not
 * @apiSuccess {String}   Request.app   App name
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "MongoDB Error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "Not Allowed"
 *     }
 */


 
/**
 * @api {get} /Product?packageId=futureoneproditem GetSodaProductById
 * @apiVersion 1.0.0
 * @apiName GetSodaProductById
 * @apiGroup SODA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} packageId Which package Id we need to get the data
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     [
    {
        "_id": "5a2f665f8177d615bc3eb563",
        "app": "SODA",
        "country": "FI",
        "nameOfPackage": {},
        "description": {},
        "packageId": "futureoneproditem",
        "nameOfProductGroup": "S",
        "productGroupId": "fortum_s",
        "inverterModel": "SMA SB 2.5",
        "panelModel": "Hanwha Q.PLUS BFR-G4.1",
        "noOfSolarPanels": 8,
        "effectiveArea": 11.68,
        "panelOuterDimensions": {
            "width": 1,
            "height": 1.67,
            "thickness": 0.034,
            "unit": "Meters"
        },
        "peakPower": 2240,
        "price": {
            "productPackage": 2700,
            "installation": 2100,
            "extraMaterialOrMachine": {
                "flatRoof": 735,
                "crane": 480
            },
            "extraWork": {
                "tileRoof": 495,
                "steepRoof": 330
            },
            "subsidies": []
        },
        "noOfInstallmentMonths": 36,
        "startDate": "2018-01-06T00:00:00.000Z",
        "endDate": "2018-12-31T00:00:00.000Z",
        "createdOn": "2017-12-12T05:17:19.765Z",
        "isActive": false,
        "includedInfo": [],
        "currencyUnit": "EUR",
        "peakPowerUnit": "Watts",
        "effectiveAreaUnit": "Square Metre"
    }
]


 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 */

 /**
 * @api {put} /Product/:producId UpdateSodaProduct
 * @apiVersion 1.0.0
 * @apiName UpdateSodaProduct
 * @apiGroup SODA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} packageId Which package Id we need to get the data
 * 
 * @apiParam {Object[]} Request Which package Id we need to get the data
 * @apiParam {String} Request.op Mention the operation to do.
 * @apiParam {String} Request.path Mention the data path to change
 * @apiParam {Object} Request.value Mention the data value to change ex: any Object
 * 
 * @apiParamExample {json} Request-Example:
 * [
  {
    "op": "add",
    "path": "/isActive",
    "value": true
  }
]
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
    "_id": "5a214698b60f83241c6923f5",
    "app": "SODA",
    "country": "FI",
    "nameOfPackage": {},
    "description": {},
    "packageId": "futureoneprod1",
    "nameOfProductGroup": "S",
    "productGroupId": "fortum_s",
    "inverterModel": "SMA SB 2.5",
    "panelModel": "Hanwha Q.PLUS BFR-G4.1",
    "noOfSolarPanels": 8,
    "effectiveArea": 11.68,
    "panelOuterDimensions": {
        "width": 1,
        "height": 1.67,
        "thickness": 0.034,
        "unit": "Meters"
    },
    "peakPower": 2240,
    "price": {
        "productPackage": 2700,
        "installation": 2100,
        "extraMaterialOrMachine": {
            "flatRoof": 735,
            "crane": 480
        },
        "extraWork": {
            "tileRoof": 495,
            "steepRoof": 330
        },
        "subsidies": []
    },
    "noOfInstallmentMonths": 36,
    "startDate": "2018-01-06T00:00:00.000Z",
    "endDate": "2018-12-31T00:00:00.000Z",
    "modifiedOn": "2017-12-12T08:56:35.229Z",
    "createdOn": "2017-12-01T12:10:00.588Z",
    "isActive": true,
    "includedInfo": [],
    "currencyUnit": "EUR",
    "peakPowerUnit": "Watts",
    "effectiveAreaUnit": "Square Metre"
}
 * @apiSuccess {Object}   Request.nameOfPackage  Name of the package.
 * @apiSuccess {String}   Request.nameOfPackage.en_GB  Name of the package in english.
 * @apiSuccess {String}   Request.nameOfPackage.fi_FI  Name of the package in finnish.
 * @apiSuccess {String}   Request.nameOfPackage.sv_FI  Name of the package in sweden.
 * @apiSuccess {String}   Request.nameOfPackage.sv_SE  Name of the package in sweden.
 * @apiSuccess {String}   Request.nameOfPackage.nb_No  Name of the package in Norway.
 * @apiSuccess {String}   Request.nameOfPackage.nn_No  Name of the package in Norway.
 * @apiSuccess {String}   Request.nameOfPackage.pl_PL  Name of the package in PL.
 * @apiSuccess {Object}   Request.description  Description of the package.
 * @apiSuccess {String}   Request.description.en_GB  Description of the package in english.
 * @apiSuccess {String}   Request.description.fi_FI  Description of the package in finnish.
 * @apiSuccess {String}   Request.description.sv_FI  Description of the package in sweden.
 * @apiSuccess {String}   Request.description.sv_SE  Description of the package in sweden.
 * @apiSuccess {String}   Request.description.nb_No  Description of the package in Norway.
 * @apiSuccess {String}   Request.description.nn_No  Description of the package in Norway.
 * @apiSuccess {String}   Request.description.pl_PL  Description of the package in PL.
 * @apiSuccess {String}   Request.packageId   PackageId.
 * @apiSuccess {String}   Request.nameOfProductGroup   Name of the product Group.
 * @apiSuccess {String}   Request.productGroupId   Name of the product Group Id.
 * @apiSuccess {String}   Request.inverterModel   Name of the inverter model.
 * @apiSuccess {String}   Request.optimizer   Name of the optimizer.
 * @apiSuccess {String}   Request.panelModel   Name of the panel model.
 * @apiSuccess {Number}   Request.noOfSolarPanels   Number of solar panels
 * @apiSuccess {Number}   Request.effectiveArea   Mention effective area
 * @apiSuccess {Number}   Request.effectiveAreaUnit   Mention effective area unit ex: Square, Metre
 * @apiSuccess {Object}   Request.panelOuterDimensions   Panel outdoor diemensions
 * @apiSuccess {Number}   Request.panelOuterDimensions.width   Panel outdoor width
 * @apiSuccess {Number}   Request.panelOuterDimensions.height   Panel outdoor height
 * @apiSuccess {Number}   Request.panelOuterDimensions.thickness   Panel outdoor thickness
 * @apiSuccess {Number}   Request.panelOuterDimensions.unit   Panel outdoor unit
 * @apiSuccess {Number}   Request.peakPower   Mention peak power
 * @apiSuccess {String}   Request.peakPower   Mention peak power unit ex : Square, Metre
 * @apiSuccess {String}   Request.currencyUnit   Product currency unit ex : EUR, Kr, NOK, PLN
 * @apiSuccess {Object}   Request.price   Product price
 * @apiSuccess {Number}   Request.price.productPackage   Product package price 
 * @apiSuccess {Number}   Request.price.installation   Product installation price 
 * @apiSuccess {Object}   Request.price.extraMaterialOrMachine   Product extraMaterial Or Machine price 
 * @apiSuccess {Number}   Request.price.extraMaterialOrMachine.flatRoof   Product  flatroof price 
 * @apiSuccess {Number}   Request.price.extraMaterialOrMachine.crane   Product crane usage price 
 * @apiSuccess {Object}   Request.price.extraWork   Product extraMaterial Or Machine price 
 * @apiSuccess {Number}   Request.price.extraWork.tileRoof   Tile roof charge 
 * @apiSuccess {Number}   Request.price.extraWork.steepRoof   Steep roof charge 
 * @apiSuccess {Object[]} Request.price.subsidies	    Subsidy product.
 * @apiSuccess {Object}   Request.price.subsidies.name	    Name of the subsidy product.
 * @apiSuccess {String}   Request.price.subsidies.name.en_GB  Name of the package in english.
 * @apiSuccess {String}   Request.price.subsidies.name.fi_FI  Name of the package in finnish.
 * @apiSuccess {String}   Request.price.subsidies.name.sv_FI  Name of the package in sweden.
 * @apiSuccess {String}   Request.price.subsidies.name.sv_SE  Name of the package in sweden.
 * @apiSuccess {String}   Request.price.subsidies.name.nb_No  Name of the package in Norway.
 * @apiSuccess {String}   Request.price.subsidies.name.nn_No  Name of the package in Norway.
 * @apiSuccess {String}   Request.price.subsidies.name.pl_PL  Name of the package in PL.
 * @apiSuccess {Number}   Request.price.subsidies.amount	     Subsidies for this product.
 * @apiSuccess {Object}   Request.price.standard	     Standrad for this product
 * @apiSuccess {Number}   Request.price.standard.packageAndInstallation	     Standard package installation.
 * @apiSuccess {Number}   Request.price.standard.noOfRails	     Standard package number of rails.
 * @apiSuccess {Number}   Request.price.standard.sections	     Standard package number of sections.
 * @apiSuccess {Object}   Request.price.standard.height	     Standard package number of sections height.
 * @apiSuccess {Number}   Request.price.standard.height.moreThan3dot5AndlessThan4dot5	     moreThan3dot5AndlessThan4dot5.
 * @apiSuccess {Number}   Request.price.standard.height.moreThan4dot5AndlessThan6	     moreThan4dot5AndlessThan6.
 * 
 * @apiSuccess {Object}   Request.price.tile	     Tile for this product
 * @apiSuccess {Number}   Request.price.tile.packageAndInstallation	     Tile package installation.
 * @apiSuccess {Number}   Request.price.tile.noOfRails	     Tile package number of rails.
 * @apiSuccess {Number}   Request.price.tile.sections	     Tile package number of sections.
 * @apiSuccess {Object}   Request.price.tile.height	     Tile package number of sections height.
 * @apiSuccess {Number}   Request.price.tile.height.moreThan3dot5AndlessThan4dot5	     moreThan3dot5AndlessThan4dot5.
 * @apiSuccess {Number}   Request.price.tile.height.moreThan4dot5AndlessThan6	     moreThan4dot5AndlessThan6.
 * 
 * @apiSuccess {Object}   Request.price.common	     Common price of the product
 * @apiSuccess {Object}   Request.price.common.cable	     Product cable details
 * @apiSuccess {Number}   Request.price.common.cable.moreThan10AndLessThan20	     Cable length.
 * @apiSuccess {Number}   Request.price.common.cable.moreThan20	     Cable length.
 * @apiSuccess {Object}   Request.price.common.angle	     Product angle details
 * @apiSuccess {Number}   Request.price.common.angle.moreThan10AndLessThan30	     Cable angle.
 * @apiSuccess {Number}   Request.price.common.angle.moreThan30	     Cable angle.
 * @apiSuccess {Object[]} Request.includedInfo	     Additional included info.
 * @apiSuccess {Object} Request.includedInfo.description	     Additional included info description.
 * @apiSuccess {String} Request.includedInfo.description.en_GB	     Additional included info description in english.
 * @apiSuccess {String} Request.includedInfo.description.fi_FI	     Additional included info description in finnish.
 * @apiSuccess {String} Request.includedInfo.description.sv_FI	     Additional included info description in sweden.
 * @apiSuccess {Object[]} Request.includedInfo.category	     Additional included infos category.
 * @apiSuccess {Object[]} Request.includedInfo._id	     Additional included infos mongodb id.
 
 * @apiSuccess {Number}   Request.noOfInstallmentMonths   Number of installment months
 * @apiSuccess {String}   Request.startDate   Start date as string format
 * @apiSuccess {String}   Request.endDate   End date as string format
 * @apiSuccess {String}   Request.country   Choosen country
 * @apiSuccess {String}   Request.createdOn   Product created date
 * @apiSuccess {String}   Request.modifiedon   Product modified date
 * @apiSuccess {Boolean}   Request.isActive   Wether the product is active or not
 * @apiSuccess {String}   Request.app   App name
 *
 ** @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "productNotFound"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 417 MongoDB Error
 *     {
 *       "error": "Mongo Db error"
 *     }
 *  @apiErrorExample Error-Response:
 *     HTTP/1.1 401 Not Allowed
 *     {
 *       "error": "productNotFound"
 *     }
 */


 /**
 * @api {delete} /Product?packageId=futureoneproditem RemoveSodaProduct
 * @apiVersion 1.0.0
 * @apiName RemoveSodaProduct
 * @apiGroup SODA
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} token ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         token:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} packageId Which package Id we need to delete the data
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 204 NO CONTENT
 * 
*  @apiErrorExample Error-Response:
*     HTTP/1.1 404 Not Found
*     {
*       "error": "productNotFound"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 401 Not Allowed
*     {
*       "error": "productNotFound"
*     }
*/