/* eslint-disable */

/**
 * @api {get} /SODA/AddressLead GetAllAddressLeads
 * @apiVersion 1.0.0
 * @apiName GetAllAddressLeads
 * @apiGroup SODA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *
 * @apiSuccessExample Success-Response:
 *   HTTP/1.1 200 OK
 *  [
    {
        "_id": "59c4bb012f2d570012737a8e",
        "country": "FI",
        "street": "RIIHITIE",
        "city": "HELSINKI",
        "zip": "00330",
        "app": "SODA",
        "createdOn": "2017-09-22T07:25:53.916Z",
        "coordinates": [
            24.880001375,
            60.1961884375
        ]
    }
]
 * @apiSuccess {Object[]} Response List of soda address leads
 * @apiSuccess {String} Response._id Corresponding MongodDB entity Id
 * @apiSuccess {String} Response.country Country name
 * @apiSuccess {String} Response.street Street name
 * @apiSuccess {String} Response.city City name
 * @apiSuccess {String} Response.zip Zip code
 * @apiSuccess {String} Response.app [SODA, VODA, HODA]
 * @apiSuccess {String} Response.createdOn Address lead created date
 * @apiSuccess {Array} Response.coordinates Location coordinates
 * 
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Address leads not found"
 *     }
 *  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
 */

 /**
 * @api {post} /SODA/AddressLead CreateAddressLead
 * @apiVersion 1.0.0
 * @apiName createAddressLead
 * @apiGroup SODA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {Object} Request New address lead
 * @apiParam {String} Request.country Country name
 * @apiParam {String} Request.street Street name
 * @apiParam {String} Request.city City name
 * @apiParam {String} Request.zip Zip code
 * @apiParam {String} Request.app [SODA, VODA, HODA]
 * @apiParam {String} Response[].createdOn Address lead created date
 * @apiParam {Array} Response[].coordinates Location coordinates
 * 
 * @apiParamExample {json} Request-Example:
 *   {
        "country": "FI",
        "street": "KÖYHÄMÄENKUJA 13",
        "city": "VANTAA",
        "zip": "01510",
        "app": "SODA",
        "createdOn": "2017-09-15T00:06:32.512Z",
        "coordinates": [
            22.990340250000003,
            60.29421862500001
        ]
    }
 * 
 * @apiSuccessExample Success-Response:
 *   HTTP/1.1 201 Created
 *   {}
 * @apiSuccessExample Success-Response:
 * HTTP/1.1 201 Created
 *   {
    "info": "Address already present, hence skipping the logging- Street: KÖYHÄMÄENKUJA 13 City: VANTAA Zip: 01510"
    }
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Address leads not found"
 *     }
 *  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
 */

 /**
 * @api {delete} /SODA/AddressLead?_id=59bb1988f0402600125820c7 RemoveAddressLead
 * @apiVersion 1.0.0
 * @apiName RemoveAddressLead
 * @apiGroup SODA
 * 
* @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} token ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         token:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * @apiParam {String} _id Mongodb Id of the address lead
 * 
 * @apiSuccessExample Success-Response:
 *   HTTP/1.1 204 No Content
 *   {}
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Address leads not found"
 *     }
 */


 