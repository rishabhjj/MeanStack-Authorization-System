/* eslint-disable */
/**
 * @api {get} /WorkOrder GetAllSodaWorkOrders
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName GetAllSodaWorkOrders
 * @apiGroup SODA.WorkOrder
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *   @apiSuccess {Object[]} Data This is array of Objects
  @apiSuccess {String} Data.accountId This is accountId with extraDesignatedWorkAndMaterial
  @apiSuccess {String} Data.customerId This is the customerId the order createdOn
  @apiSuccess {String} Data.customerNote Customer note for the order
  @apiSuccess {String} Data.contractId Contract Id for the workoder
  @apiSuccess {String} Data.installerId InstalledId for the workoder
  @apiSuccess {String} Data.installerCompany Installer compan for the workoder
  @apiSuccess {Object} Data.externalMarketingPartner External marketing externalMarketingPartner
  @apiSuccess {String} Data.externalMarketingPartner.code External marketer code
  @apiSuccess {Object} Data.deliverySite Enter the delivery site
  @apiSuccess {String} Data.deliverySite.deliverySiteId Enter the delivery site ID
  @apiSuccess {String} Data.deliverySite.street Enter the delivery site street
  @apiSuccess {String} Data.deliverySite.city Enter the delivery site city
  @apiSuccess {String} Data.deliverySite.zip Enter the delivery site zip
  @apiSuccess {Array} Data.deliverySite.coordinates Enter the delivery site coordinates
  @apiSuccess {Object} Data.gridInfo Enter the delivery site gridinfo
  @apiSuccess {String} Data.gridInfo.gridId Enter the delivery site gridinfo gridId
  @apiSuccess {String} Data.gridInfo.gridCompanyName Enter the delivery site gridinfo gridCompanyName 
  @apiSuccess {Object} Data.contactInformation Enter the delivery site contactInformation
  @apiSuccess {String} Data.contactInformation.name Enter the delivery site contactInformation name
  @apiSuccess {String} Data.contactInformation.ssnOrBusinessId Enter the delivery site contactInformation ssnOrBusinessId
  @apiSuccess {String} Data.contactInformation.customerType Enter the delivery site contactInformation customerType
  @apiSuccess {String} Data.contactInformation.phone Enter the delivery site contactInformation phone
  @apiSuccess {String} Data.contactInformation.email Enter the delivery site contactInformation email
  @apiSuccess {String} Data.contactInformation.email Enter the delivery site contactInformation street
  @apiSuccess {String} Data.contactInformation.city Enter the delivery site city
  @apiSuccess {String} Data.contactInformation.zip Enter the delivery site zip
  @apiSuccess {String} Data.roofSupportDistance Enter the workorder roofSupportDistance
  @apiSuccess {String} Data.installationHomeVisit Enter the workorder installationHomeVisit time
  @apiSuccess {String} Data.paymentType Enter the workorder paymentType 'OneTime', 'OneTimeWith15PercentDiscount', 'TenYearMaterialAlone', 'TenYear'
  @apiSuccess {String} Data.lockedBy Enter the workorder lockedBy
  @apiSuccess {Boolean} Data.isLocked Enter the workorder isLocked
  @apiSuccess {String} Data.status Enter the workorder status 'OfferRequestReceived', 'PreliminaryOfferSent', 'PreliminaryOfferApproved', 'AssessmentSiteVisitScheduled', 'AddInstallationPlan', 'InstallationPlanCreated', 'InstallationPlanVerified', 'FinalOfferSent', 'FinalOfferApproved', 'InstallationTimeScheduled', 'AddInstallationReport', 'InstallationReportReady', 'InstallationReportVerified', 'InstallationApproved', 'Cancelled', 'Closed'
  @apiSuccess {String} Data.statebeforecancelled Enter the workorder statebeforecancelled  'OfferRequestReceived', 'PreliminaryOfferSent', 'PreliminaryOfferApproved', 'AssessmentSiteVisitScheduled', 'AddInstallationPlan', 'InstallationPlanCreated', 'InstallationPlanVerified', 'FinalOfferSent', 'FinalOfferApproved', 'InstallationTimeScheduled', 'AddInstallationReport', 'InstallationReportReady', 'InstallationReportVerified', 'InstallationApproved', 'Cancelled'
  @apiSuccess {Boolean} Data.interestedInVPP Enter the workorder interestedInVPP  
  @apiSuccess {String} Data.country Enter the workorder country  'FI', 'SE', 'PL', 'NO'
  @apiSuccess {String} Data.app Enter the workorder country  'SODA', 'FODA', 'VODA', 'HODA'
  @apiSuccess {String} Data.createdOn Enter the workorder createdOn
  @apiSuccess {String} Data.modifiedOn Enter the workorder modifiedOn

  @apiSuccess {Object} Data.benefitCalculations Enter the benefitCalculations
  @apiSuccess {Array} Data.benefitCalculations.monthlySolarElectricityPotential Enter the benefitCalculations monthlySolarElectricityPotential
  @apiSuccess {Number} Data.benefitCalculations.roofArea Enter the benefitCalculations roofArea
  @apiSuccess {String} Data.benefitCalculations.roofAreaUnit Enter the benefitCalculations roofAreaUnit
  @apiSuccess {Number} Data.benefitCalculations.roofAreaSuitableForPanels Enter the benefitCalculations roofAreaSuitableForPanels
  @apiSuccess {Array} Data.benefitCalculations.estimatedMonthlyElectricityConsumption Enter the benefitCalculations estimatedMonthlyElectricityConsumption
  @apiSuccess {String} Data.benefitCalculations.confidenceClassForEstimates Enter the benefitCalculations confidenceClassForEstimates
  @apiSuccess {String} Data.benefitCalculations.roofType Enter the benefitCalculations roofType
  @apiSuccess {Number} Data.benefitCalculations.roofPitchAngle Enter the benefitCalculations roofPitchAngle
  @apiSuccess {String} Data.benefitCalculations.roofMaterial Enter the benefitCalculations roofMaterial
  @apiSuccess {Number} Data.benefitCalculations.roofRidgeAngleFromNorth Enter the benefitCalculations roofRidgeAngleFromNorth
  @apiSuccess {String} Data.benefitCalculations.buildingType Enter the benefitCalculations buildingType
  @apiSuccess {String} Data.benefitCalculations.recommendedProductPackageId Enter the benefitCalculations recommendedProductPackageId
  @apiSuccess {String} Data.benefitCalculations.customerSelectedProductPackageId Enter the benefitCalculations customerSelectedProductPackageId

  @apiSuccess {String} Data.benefitCalculations.heatingType Enter the benefitCalculations heatingType
  @apiSuccess {Number} Data.benefitCalculations.buildYear Enter the benefitCalculations buildYear
  @apiSuccess {Number} Data.benefitCalculations.floors Enter the benefitCalculations floors
  @apiSuccess {Number} Data.benefitCalculations.floorArea Enter the benefitCalculations floorArea
  @apiSuccess {Number} Data.benefitCalculations.yearlyConsumption Enter the benefitCalculations yearlyConsumption
  @apiSuccess {String} Data.benefitCalculations.userEditedFields Enter the benefitCalculations userEditedFields
  @apiSuccess {String} Data.benefitCalculations.selectedBuildingId Enter the benefitCalculations selectedBuildingId
  @apiSuccess {Object} Data.benefitCalculations.customBuilding Enter the benefitCalculations customBuilding
  @apiSuccess {Object[]} Data.benefitCalculations.customBuilding.parts Enter the benefitCalculations customBuilding parts
  @apiSuccess {Array} Data.benefitCalculations.customBuilding.parts.center Enter the benefitCalculations customBuilding parts center
  @apiSuccess {Array} Data.benefitCalculations.customBuilding.parts.dimensions Enter the benefitCalculations customBuilding parts dimensions
  @apiSuccess {Number} Data.benefitCalculations.customBuilding.parts.azimuth Enter the benefitCalculations customBuilding parts azimuth
  @apiSuccess {Number} Data.benefitCalculations.customBuilding.roofArea Enter the benefitCalculations customBuilding  roofArea
  @apiSuccess {Number} Data.benefitCalculations.customBuilding.mainAzimuth Enter the benefitCalculations customBuilding  mainAzimuth

  @apiSuccess {Object} Data.basePrice Enter the basePrice
  @apiSuccess {Number} Data.basePrice.package Enter the basePrice package
  @apiSuccess {Number} Data.basePrice.package Enter the basePrice package
  @apiSuccess {Number} Data.basePrice.installation Enter the basePrice installation
  @apiSuccess {Number} Data.basePrice.total Enter the basePrice total
  @apiSuccess {Number} Data.basePrice.package Enter the basePrice package 
  @apiSuccess {priceCurrency} Data.basePrice.priceCurrency Enter the basePrice priceCurrency 'EUR', 'Kr', 'NOK', 'PLN'

  @apiSuccess {Object[]} Data.basePrice.subsidies Enter the basePrice subsidies 
  @apiSuccess {Number} Data.basePrice.subsidies.amount Enter the basePrice package
  @apiSuccess {Object} Data.basePrice.subsidies.name Enter the basePrice subsidies name 
  @apiSuccess {Object} Data.basePrice.subsidies.name.description Enter the basePrice subsidies name
  @apiSuccess {String} Data.basePrice.subsidies.name.description.en_GB  Name of the subsidies in english.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.fi_FI  Name of the subsidies in finnish.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.sv_FI  Name of the subsidies in sweden.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.sv_SE  Name of the subsidies in sweden.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.nb_No  Name of the subsidies in Norway.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.nn_No  Name of the subsidies in Norway.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.pl_PL  Name of the subsidies in PL

  @apiSuccess {Object} Data.extraDesignatedWorkAndMaterial Enter the extraDesignatedWorkAndMaterial
  @apiSuccess {String} Data.extraDesignatedWorkAndMaterial.designatedItemId Enter the extraDesignatedWorkAndMaterial designatedItemId
  @apiSuccess {String} Data.extraDesignatedWorkAndMaterial.type Enter the extraDesignatedWorkAndMaterial type
  @apiSuccess {Number} Data.extraDesignatedWorkAndMaterial.quantity Enter the extraDesignatedWorkAndMaterial quantity
  @apiSuccess {Number} Data.extraDesignatedWorkAndMaterial.amount Enter the extraDesignatedWorkAndMaterial amount

  @apiSuccess {Object[]} Data.extraNonDesignatedWorkAndMaterial Enter the extraNonDesignatedWorkAndMaterial
  @apiSuccess {String} Data.extraNonDesignatedWorkAndMaterial.title Enter the extraNonDesignatedWorkAndMaterial title
  @apiSuccess {String} Data.extraNonDesignatedWorkAndMaterial.description Enter the extraNonDesignatedWorkAndMaterial description
  @apiSuccess {String} Data.extraNonDesignatedWorkAndMaterial.type Enter the extraNonDesignatedWorkAndMaterial type 'Work', 'Material'
  @apiSuccess {Number} Data.extraNonDesignatedWorkAndMaterial.quantity Enter the extraNonDesignatedWorkAndMaterial quantity
  @apiSuccess {Number} Data.extraNonDesignatedWorkAndMaterial.amount Enter the extraNonDesignatedWorkAndMaterial amount

  @apiSuccess {Object[]} Data.panelInstallationLayout Enter the panelInstallationLayout
  @apiSuccess {String} Data.panelInstallationLayout.name Enter the panelInstallationLayout name
  @apiSuccess {Number} Data.panelInstallationLayout.row Enter the panelInstallationLayout row
  @apiSuccess {Number} Data.panelInstallationLayout.column Enter the panelInstallationLayout column
  @apiSuccess {String} Data.panelInstallationLayout.orientation Enter the panelInstallationLayout 'Portrait', 'Landscape'
  @apiSuccess {Number} Data.panelInstallationLayout.width Enter the panelInstallationLayout width
  @apiSuccess {Number} Data.panelInstallationLayout.height Enter the panelInstallationLayout height
  @apiSuccess {Number} Data.panelInstallationLayout.unit Enter the panelInstallationLayout unit 'm'
  @apiSuccess {Array} Data.panelInstallationLayout.panels Enter the panelInstallationLayout panels [[],[]]

  @apiSuccess {Object} Data.installationPlanChangeLog Enter the installationPlanChangeLog
  @apiSuccess {String} Data.installationPlanChangeLog.createdOn Enter the installationPlanChangeLog createdOn
  @apiSuccess {String} Data.installationPlanChangeLog.createdBy Enter the installationPlanChangeLog createdBy
  @apiSuccess {String} Data.installationPlanChangeLog.modifiedOn Enter the installationPlanChangeLog modifiedOn
  @apiSuccess {String} Data.installationPlanChangeLog.modifiedBy Enter the installationPlanChangeLog modifiedBy
  @apiSuccess {String} Data.installationPlanChangeLog.verifiedOn Enter the installationPlanChangeLog verifiedOn
  @apiSuccess {String} Data.installationPlanChangeLog.verifiedBy Enter the installationPlanChangeLog verifiedBy
  @apiSuccess {Boolean} Data.installationPlanChangeLog.initialized Enter the installationPlanChangeLog initialized
  @apiSuccess {Number} Data.installationPlanChangeLog.status Enter the installationPlanChangeLog status 0, 1

  @apiSuccess {Object} Data.installationReportChangeLog Enter the installationReportChangeLog
  @apiSuccess {String} Data.installationReportChangeLog.createdOn Enter the installationReportChangeLog createdOn
  @apiSuccess {String} Data.installationReportChangeLog.createdBy Enter the installationReportChangeLog createdBy
  @apiSuccess {String} Data.installationReportChangeLog.modifiedOn Enter the installationReportChangeLog modifiedOn
  @apiSuccess {String} Data.installationReportChangeLog.modifiedBy Enter the installationReportChangeLog modifiedBy
  @apiSuccess {String} Data.installationReportChangeLog.verifiedOn Enter the installationReportChangeLog verifiedOn
  @apiSuccess {String} Data.installationReportChangeLog.verifiedBy Enter the installationReportChangeLog verifiedBy
  @apiSuccess {Boolean} Data.installationReportChangeLog.initialized Enter the installationReportChangeLog initialized
  @apiSuccess {Number} Data.installationReportChangeLog.status Enter the installationReportChangeLog status 0, 1

  @apiSuccess {Object} Data.building Enter the building details
  @apiSuccess {Number} Data.building.buildingEdgeheight Enter the building buildingEdgeheight
  @apiSuccess {Number} Data.building.buildingTopheight Enter the building buildingTopheight

  @apiSuccess {Object[]} Data.notesToInstaller Enter the notesToInstaller details
  @apiSuccess {String} Data.notesToInstaller.note Enter the notesToInstaller note
  @apiSuccess {String} Data.notesToInstaller.createdOn Enter the notesToInstaller createdOn

  @apiSuccess {Object[]} Data.installerNotes Enter the installerNotes details
  @apiSuccess {String} Data.installerNotes.note Enter the installerNotes note
  @apiSuccess {String} Data.installerNotes.createdOn Enter the installerNotes createdOn

  @apiSuccess {Object[]} Data.installationPlanNote Enter the installationPlanNote details
  @apiSuccess {String} Data.installationPlanNote.note Enter the installationPlanNote note
  @apiSuccess {String} Data.installationPlanNote.createdOn Enter the installationPlanNote createdOn

  @apiSuccess {Object[]} Data.customerServiceNotes Enter the customerServiceNotes details
  @apiSuccess {String} Data.customerServiceNotes.note Enter the customerServiceNotes note
  @apiSuccess {String} Data.customerServiceNotes.createdOn Enter the customerServiceNotes createdOn

  @apiSuccess {Boolean} Data.craneRequirementOverwritten Enter the craneRequirementOverwritten
  @apiSuccess {Boolean} Data.surplusElectricityWillBeSoldToFortum Enter the surplusElectricityWillBeSoldToFortum

  @apiSuccess {Object} Data.installationNote Enter the installationNote
  @apiSuccess {Object[]} Data.installationNote.installplan Enter the installplan
  @apiSuccess {String} Data.installationNote.installplan.note Enter the installplan note
  @apiSuccess {String} Data.installationNote.installplan.createdOn Enter the installplan createdOn

  @apiSuccess {Object[]} Data.installationNote.roofProperties Enter the installationNote roofProperties
  @apiSuccess {String} Data.installationNote.roofProperties.note Enter the installationNote roofProperties note
  @apiSuccess {String} Data.installationNote.roofProperties.createdOn Enter the installationNote roofProperties createdOn

  @apiSuccess {Object[]} Data.installationNote.panelInfo Enter the installationNote panelInfo
  @apiSuccess {String} Data.installationNote.panelInfo.note Enter the installationNote panelInfo note
  @apiSuccess {String} Data.installationNote.panelInfo.createdOn Enter the installationNote panelInfo createdOn

  @apiSuccess {Object[]} Data.installationNote.panel Enter the panel
  @apiSuccess {String} Data.installationNote.panel.note Enter the panel note
  @apiSuccess {String} Data.installationNote.panel.createdOn Enter the panel createdOn

  @apiSuccess {Object[]} Data.installationNote.wiring Enter the installationNote wiring
  @apiSuccess {String} Data.installationNote.wiring.note Enter the installationNote wiring note
  @apiSuccess {String} Data.installationNote.wiring.createdOn Enter the installationNote wiring createdOn

  @apiSuccess {Object[]} Data.installationNote.inverter Enter the installationNote inverter
  @apiSuccess {String} Data.installationNote.inverter.note Enter the installationNote inverter note
  @apiSuccess {String} Data.installationNote.inverter.createdOn Enter the installationNote inverter createdOn

  @apiSuccess {Object[]} Data.installationNote.switchboard Enter the switchboard
  @apiSuccess {String} Data.installationNote.switchboard.note Enter the switchboard note
  @apiSuccess {String} Data.installationNote.switchboard.createdOn Enter the switchboard createdOn

  @apiSuccess {Object[]} Data.installationNote.materialdelivery Enter the installationNote materialdelivery
  @apiSuccess {String} Data.installationNote.materialdelivery.note Enter the installationNote materialdelivery note
  @apiSuccess {String} Data.installationNote.materialdelivery.createdOn Enter the installationNote wirimaterialdeliveryng createdOn

  @apiSuccess {Object[]} Data.installationNote.pricingInfo Enter the installationNote pricingInfo
  @apiSuccess {String} Data.installationNote.pricingInfo.note Enter the installationNote pricingInfo note
  @apiSuccess {String} Data.installationNote.pricingInfo.createdOn Enter the installationNote pricingInfo createdOn

  @apiSuccess {Object} Data.installation Enter the installation
  @apiSuccess {String} Data.installation.startDate Enter the installation startDate
  @apiSuccess {String} Data.installation.endDate Enter the installation startDate
  @apiSuccess {Number} Data.installation.days Enter the installation days
  @apiSuccess {Number} Data.installation.hours Enter the installation hours

  @apiSuccess {Object} Data.device Enter the device
  @apiSuccess {String} Data.device.inverterSerialNumber Enter the device inverterSerialNumber
  @apiSuccess {String} Data.device.tingcoBoxId Enter the device tingcoBoxId




 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK

  [
    {
        "_id": "59ba355fc738300012b3346e",
        "workOrderNumber": 10905,
        "customerNote": "",
        "deliverySite": {
            "street": "RIILAH2",
            "city": "ESPOO",
            "zip": "02260",
            "coordinates": [
                24.684145266666665,
                60.14239553333333
            ],
            "deliverySiteId": ""
        },
        "contactInformation": {
            "name": "TEST71",
            "ssnOrBusinessId": "10",
            "customerType": "Business",
            "phone": "8883627364",
            "email": "mahadevan.r@cognizant.com"
        },
        "benefitCalculations": {
            "roofArea": 90,
            "roofAreaUnit": "m2",
            "roofAreaSuitableForPanels": 38,
            "confidenceClassForEstimates": "footprint",
            "roofType": "gable",
            "roofMaterial": "other",
            "roofPitchAngle": 18,
            "roofRidgeAngleFromNorth": 77,
            "buildingType": "1110",
            "recommendedProductPackageId": "060117_8_PANELS_SMA_SB25_HANHWA_QPLUS_BFR-G4.1",
            "customerSelectedProductPackageId": "060117_8_PANELS_SMA_SB25_HANHWA_QPLUS_BFR-G4.1",
            "heatingType": "district",
            "buildYear": 1990,
            "floors": 2,
            "selectedBuildingId": "ud9w1sw6y_1",
            "floorArea": 146,
            "yearlyConsumption": 4000,
            "userEditedFields": [],
            "estimatedMonthlyElectricityConsumption": [
                473,
                352,
                386,
                328,
                293,
                242,
                250,
                291,
                324,
                382,
                414,
                432
            ],
            "monthlySolarElectricityPotential": [
                102,
                254,
                542,
                757,
                962,
                933,
                937,
                761,
                519,
                280,
                137,
                66
            ]
        },
        "basePrice": {
            "package": 2700,
            "installation": 2100,
            "total": 5280,
            "priceCurrency": "EUR",
            "subsidies": []
        },
        "country": "FI",
        "app": "SODA",
        "modifiedOn": "2017-09-14T07:53:03.825Z",
        "createdOn": "2017-09-14T07:53:03.825Z",
        "interestedInVPP": false,
        "status": "OfferRequestReceived",
        "isLocked": false,
        "device": {},
        "installation": {},
        "customerServiceNotes": [],
        "installationNote": {
            "pricingInfo": [],
            "materialdelivery": [],
            "switchboard": [],
            "inverter": [],
            "wiring": [],
            "panel": [],
            "panelInfo": [],
            "roofProperties": [],
            "installPlan": []
        },
        "installationPlanNote": [],
        "installerNotes": [],
        "notesToInstaller": [],
        "panelInstallationLayout": [],
        "extraNonDesignatedWorkAndMaterial": [],
        "extraDesignatedWorkAndMaterial": [
            {
                "designatedItemId": "crane",
                "quantity": 1,
                "amount": 480,
                "type": "Material"
            }
        ],
        "installerCompany": "",
        "installerId": "",
        "contractId": "",
        "customerId": "",
        "accountId": ""
    }]

    * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 Mongodb-error
 *     {
 *       "error": "Item not found"
 *     }

 * 
 * */



 /* eslint-disable */
/**
 * @api {post} /WorkOrder SaveSodaWorkOrders
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName SaveSodaWorkOrders
 * @apiGroup SODA.WorkOrder
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 
 * 
 *  @apiParam {Object} Data This is array of Objects
  @apiParam {String} Data.accountId This is accountId with extraDesignatedWorkAndMaterial
  @apiParam {String} Data.customerId This is the customerId the order createdOn
  @apiParam {String} Data.customerNote Customer note for the order
  @apiParam {String} Data.contractId Contract Id for the workoder
  @apiParam {String} Data.installerId InstalledId for the workoder
  @apiParam {String} Data.installerCompany Installer compan for the workoder
  @apiParam {Object} Data.externalMarketingPartner External marketing externalMarketingPartner
  @apiParam {String} Data.externalMarketingPartner.code External marketer code
  @apiParam {Object} Data.deliverySite Enter the delivery site
  @apiParam {String} Data.deliverySite.deliverySiteId Enter the delivery site ID
  @apiParam {String} Data.deliverySite.street Enter the delivery site street
  @apiParam {String} Data.deliverySite.city Enter the delivery site city
  @apiParam {String} Data.deliverySite.zip Enter the delivery site zip
  @apiParam {Array} Data.deliverySite.coordinates Enter the delivery site coordinates
  @apiParam {Object} Data.gridInfo Enter the delivery site gridinfo
  @apiParam {String} Data.gridInfo.gridId Enter the delivery site gridinfo gridId
  @apiParam {String} Data.gridInfo.gridCompanyName Enter the delivery site gridinfo gridCompanyName 
  @apiParam {Object} Data.contactInformation Enter the delivery site contactInformation
  @apiParam {String} Data.contactInformation.name Enter the delivery site contactInformation name
  @apiParam {String} Data.contactInformation.ssnOrBusinessId Enter the delivery site contactInformation ssnOrBusinessId
  @apiParam {String} Data.contactInformation.customerType Enter the delivery site contactInformation customerType
  @apiParam {String} Data.contactInformation.phone Enter the delivery site contactInformation phone
  @apiParam {String} Data.contactInformation.email Enter the delivery site contactInformation email
  @apiParam {String} Data.contactInformation.email Enter the delivery site contactInformation street
  @apiParam {String} Data.contactInformation.city Enter the delivery site city
  @apiParam {String} Data.contactInformation.zip Enter the delivery site zip
  @apiParam {String} Data.roofSupportDistance Enter the workorder roofSupportDistance
  @apiParam {String} Data.installationHomeVisit Enter the workorder installationHomeVisit time
  @apiParam {String} Data.paymentType Enter the workorder paymentType 'OneTime', 'OneTimeWith15PercentDiscount', 'TenYearMaterialAlone', 'TenYear'
  @apiParam {String} Data.lockedBy Enter the workorder lockedBy
  @apiParam {Boolean} Data.isLocked Enter the workorder isLocked
  @apiParam {String} Data.status Enter the workorder status 'OfferRequestReceived', 'PreliminaryOfferSent', 'PreliminaryOfferApproved', 'AssessmentSiteVisitScheduled', 'AddInstallationPlan', 'InstallationPlanCreated', 'InstallationPlanVerified', 'FinalOfferSent', 'FinalOfferApproved', 'InstallationTimeScheduled', 'AddInstallationReport', 'InstallationReportReady', 'InstallationReportVerified', 'InstallationApproved', 'Cancelled', 'Closed'
  @apiParam {String} Data.statebeforecancelled Enter the workorder statebeforecancelled  'OfferRequestReceived', 'PreliminaryOfferSent', 'PreliminaryOfferApproved', 'AssessmentSiteVisitScheduled', 'AddInstallationPlan', 'InstallationPlanCreated', 'InstallationPlanVerified', 'FinalOfferSent', 'FinalOfferApproved', 'InstallationTimeScheduled', 'AddInstallationReport', 'InstallationReportReady', 'InstallationReportVerified', 'InstallationApproved', 'Cancelled'
  @apiParam {Boolean} Data.interestedInVPP Enter the workorder interestedInVPP  
  @apiParam {String} Data.country Enter the workorder country  'FI', 'SE', 'PL', 'NO'
  @apiParam {String} Data.app Enter the workorder country  'SODA', 'FODA', 'VODA', 'HODA'
  @apiParam {String} Data.createdOn Enter the workorder createdOn
  @apiParam {String} Data.modifiedOn Enter the workorder modifiedOn

  @apiParam {Object} Data.benefitCalculations Enter the benefitCalculations
  @apiParam {Array} Data.benefitCalculations.monthlySolarElectricityPotential Enter the benefitCalculations monthlySolarElectricityPotential
  @apiParam {Number} Data.benefitCalculations.roofArea Enter the benefitCalculations roofArea
  @apiParam {String} Data.benefitCalculations.roofAreaUnit Enter the benefitCalculations roofAreaUnit
  @apiParam {Number} Data.benefitCalculations.roofAreaSuitableForPanels Enter the benefitCalculations roofAreaSuitableForPanels
  @apiParam {Array} Data.benefitCalculations.estimatedMonthlyElectricityConsumption Enter the benefitCalculations estimatedMonthlyElectricityConsumption
  @apiParam {String} Data.benefitCalculations.confidenceClassForEstimates Enter the benefitCalculations confidenceClassForEstimates
  @apiParam {String} Data.benefitCalculations.roofType Enter the benefitCalculations roofType
  @apiParam {Number} Data.benefitCalculations.roofPitchAngle Enter the benefitCalculations roofPitchAngle
  @apiParam {String} Data.benefitCalculations.roofMaterial Enter the benefitCalculations roofMaterial
  @apiParam {Number} Data.benefitCalculations.roofRidgeAngleFromNorth Enter the benefitCalculations roofRidgeAngleFromNorth
  @apiParam {String} Data.benefitCalculations.buildingType Enter the benefitCalculations buildingType
  @apiParam {String} Data.benefitCalculations.recommendedProductPackageId Enter the benefitCalculations recommendedProductPackageId
  @apiParam {String} Data.benefitCalculations.customerSelectedProductPackageId Enter the benefitCalculations customerSelectedProductPackageId

  @apiParam {String} Data.benefitCalculations.heatingType Enter the benefitCalculations heatingType
  @apiParam {Number} Data.benefitCalculations.buildYear Enter the benefitCalculations buildYear
  @apiParam {Number} Data.benefitCalculations.floors Enter the benefitCalculations floors
  @apiParam {Number} Data.benefitCalculations.floorArea Enter the benefitCalculations floorArea
  @apiParam {Number} Data.benefitCalculations.yearlyConsumption Enter the benefitCalculations yearlyConsumption
  @apiParam {String} Data.benefitCalculations.userEditedFields Enter the benefitCalculations userEditedFields
  @apiParam {String} Data.benefitCalculations.selectedBuildingId Enter the benefitCalculations selectedBuildingId
  @apiParam {Object} Data.benefitCalculations.customBuilding Enter the benefitCalculations customBuilding
  @apiParam {Object[]} Data.benefitCalculations.customBuilding.parts Enter the benefitCalculations customBuilding parts
  @apiParam {Array} Data.benefitCalculations.customBuilding.parts.center Enter the benefitCalculations customBuilding parts center
  @apiParam {Array} Data.benefitCalculations.customBuilding.parts.dimensions Enter the benefitCalculations customBuilding parts dimensions
  @apiParam {Number} Data.benefitCalculations.customBuilding.parts.azimuth Enter the benefitCalculations customBuilding parts azimuth
  @apiParam {Number} Data.benefitCalculations.customBuilding.roofArea Enter the benefitCalculations customBuilding  roofArea
  @apiParam {Number} Data.benefitCalculations.customBuilding.mainAzimuth Enter the benefitCalculations customBuilding  mainAzimuth

  @apiParam {Object} Data.basePrice Enter the basePrice
  @apiParam {Number} Data.basePrice.package Enter the basePrice package
  @apiParam {Number} Data.basePrice.package Enter the basePrice package
  @apiParam {Number} Data.basePrice.installation Enter the basePrice installation
  @apiParam {Number} Data.basePrice.total Enter the basePrice total
  @apiParam {Number} Data.basePrice.package Enter the basePrice package 
  @apiParam {priceCurrency} Data.basePrice.priceCurrency Enter the basePrice priceCurrency 'EUR', 'Kr', 'NOK', 'PLN'

  @apiParam {Object[]} Data.basePrice.subsidies Enter the basePrice subsidies 
  @apiParam {Number} Data.basePrice.subsidies.amount Enter the basePrice package
  @apiParam {Object} Data.basePrice.subsidies.name Enter the basePrice subsidies name 
  @apiParam {Object} Data.basePrice.subsidies.name.description Enter the basePrice subsidies name
  @apiParam {String} Data.basePrice.subsidies.name.description.en_GB  Name of the subsidies in english.
  @apiParam {String} Data.basePrice.subsidies.name.description.fi_FI  Name of the subsidies in finnish.
  @apiParam {String} Data.basePrice.subsidies.name.description.sv_FI  Name of the subsidies in sweden.
  @apiParam {String} Data.basePrice.subsidies.name.description.sv_SE  Name of the subsidies in sweden.
  @apiParam {String} Data.basePrice.subsidies.name.description.nb_No  Name of the subsidies in Norway.
  @apiParam {String} Data.basePrice.subsidies.name.description.nn_No  Name of the subsidies in Norway.
  @apiParam {String} Data.basePrice.subsidies.name.description.pl_PL  Name of the subsidies in PL

  @apiParam {Object} Data.extraDesignatedWorkAndMaterial Enter the extraDesignatedWorkAndMaterial
  @apiParam {String} Data.extraDesignatedWorkAndMaterial.designatedItemId Enter the extraDesignatedWorkAndMaterial designatedItemId
  @apiParam {String} Data.extraDesignatedWorkAndMaterial.type Enter the extraDesignatedWorkAndMaterial type
  @apiParam {Number} Data.extraDesignatedWorkAndMaterial.quantity Enter the extraDesignatedWorkAndMaterial quantity
  @apiParam {Number} Data.extraDesignatedWorkAndMaterial.amount Enter the extraDesignatedWorkAndMaterial amount

  @apiParam {Object[]} Data.extraNonDesignatedWorkAndMaterial Enter the extraNonDesignatedWorkAndMaterial
  @apiParam {String} Data.extraNonDesignatedWorkAndMaterial.title Enter the extraNonDesignatedWorkAndMaterial title
  @apiParam {String} Data.extraNonDesignatedWorkAndMaterial.description Enter the extraNonDesignatedWorkAndMaterial description
  @apiParam {String} Data.extraNonDesignatedWorkAndMaterial.type Enter the extraNonDesignatedWorkAndMaterial type 'Work', 'Material'
  @apiParam {Number} Data.extraNonDesignatedWorkAndMaterial.quantity Enter the extraNonDesignatedWorkAndMaterial quantity
  @apiParam {Number} Data.extraNonDesignatedWorkAndMaterial.amount Enter the extraNonDesignatedWorkAndMaterial amount

  @apiParam {Object[]} Data.panelInstallationLayout Enter the panelInstallationLayout
  @apiParam {String} Data.panelInstallationLayout.name Enter the panelInstallationLayout name
  @apiParam {Number} Data.panelInstallationLayout.row Enter the panelInstallationLayout row
  @apiParam {Number} Data.panelInstallationLayout.column Enter the panelInstallationLayout column
  @apiParam {String} Data.panelInstallationLayout.orientation Enter the panelInstallationLayout 'Portrait', 'Landscape'
  @apiParam {Number} Data.panelInstallationLayout.width Enter the panelInstallationLayout width
  @apiParam {Number} Data.panelInstallationLayout.height Enter the panelInstallationLayout height
  @apiParam {Number} Data.panelInstallationLayout.unit Enter the panelInstallationLayout unit 'm'
  @apiParam {Array} Data.panelInstallationLayout.panels Enter the panelInstallationLayout panels [[],[]]

  @apiParam {Object} Data.installationPlanChangeLog Enter the installationPlanChangeLog
  @apiParam {String} Data.installationPlanChangeLog.createdOn Enter the installationPlanChangeLog createdOn
  @apiParam {String} Data.installationPlanChangeLog.createdBy Enter the installationPlanChangeLog createdBy
  @apiParam {String} Data.installationPlanChangeLog.modifiedOn Enter the installationPlanChangeLog modifiedOn
  @apiParam {String} Data.installationPlanChangeLog.modifiedBy Enter the installationPlanChangeLog modifiedBy
  @apiParam {String} Data.installationPlanChangeLog.verifiedOn Enter the installationPlanChangeLog verifiedOn
  @apiParam {String} Data.installationPlanChangeLog.verifiedBy Enter the installationPlanChangeLog verifiedBy
  @apiParam {Boolean} Data.installationPlanChangeLog.initialized Enter the installationPlanChangeLog initialized
  @apiParam {Number} Data.installationPlanChangeLog.status Enter the installationPlanChangeLog status 0, 1

  @apiParam {Object} Data.installationReportChangeLog Enter the installationReportChangeLog
  @apiParam {String} Data.installationReportChangeLog.createdOn Enter the installationReportChangeLog createdOn
  @apiParam {String} Data.installationReportChangeLog.createdBy Enter the installationReportChangeLog createdBy
  @apiParam {String} Data.installationReportChangeLog.modifiedOn Enter the installationReportChangeLog modifiedOn
  @apiParam {String} Data.installationReportChangeLog.modifiedBy Enter the installationReportChangeLog modifiedBy
  @apiParam {String} Data.installationReportChangeLog.verifiedOn Enter the installationReportChangeLog verifiedOn
  @apiParam {String} Data.installationReportChangeLog.verifiedBy Enter the installationReportChangeLog verifiedBy
  @apiParam {Boolean} Data.installationReportChangeLog.initialized Enter the installationReportChangeLog initialized
  @apiParam {Number} Data.installationReportChangeLog.status Enter the installationReportChangeLog status 0, 1

  @apiParam {Object} Data.building Enter the building details
  @apiParam {Number} Data.building.buildingEdgeheight Enter the building buildingEdgeheight
  @apiParam {Number} Data.building.buildingTopheight Enter the building buildingTopheight

  @apiParam {Object[]} Data.notesToInstaller Enter the notesToInstaller details
  @apiParam {String} Data.notesToInstaller.note Enter the notesToInstaller note
  @apiParam {String} Data.notesToInstaller.createdOn Enter the notesToInstaller createdOn

  @apiParam {Object[]} Data.installerNotes Enter the installerNotes details
  @apiParam {String} Data.installerNotes.note Enter the installerNotes note
  @apiParam {String} Data.installerNotes.createdOn Enter the installerNotes createdOn

  @apiParam {Object[]} Data.installationPlanNote Enter the installationPlanNote details
  @apiParam {String} Data.installationPlanNote.note Enter the installationPlanNote note
  @apiParam {String} Data.installationPlanNote.createdOn Enter the installationPlanNote createdOn

  @apiParam {Object[]} Data.customerServiceNotes Enter the customerServiceNotes details
  @apiParam {String} Data.customerServiceNotes.note Enter the customerServiceNotes note
  @apiParam {String} Data.customerServiceNotes.createdOn Enter the customerServiceNotes createdOn

  @apiParam {Boolean} Data.craneRequirementOverwritten Enter the craneRequirementOverwritten
  @apiParam {Boolean} Data.surplusElectricityWillBeSoldToFortum Enter the surplusElectricityWillBeSoldToFortum

  @apiParam {Object} Data.installationNote Enter the installationNote
  @apiParam {Object[]} Data.installationNote.installplan Enter the installplan
  @apiParam {String} Data.installationNote.installplan.note Enter the installplan note
  @apiParam {String} Data.installationNote.installplan.createdOn Enter the installplan createdOn

  @apiParam {Object[]} Data.installationNote.roofProperties Enter the installationNote roofProperties
  @apiParam {String} Data.installationNote.roofProperties.note Enter the installationNote roofProperties note
  @apiParam {String} Data.installationNote.roofProperties.createdOn Enter the installationNote roofProperties createdOn

  @apiParam {Object[]} Data.installationNote.panelInfo Enter the installationNote panelInfo
  @apiParam {String} Data.installationNote.panelInfo.note Enter the installationNote panelInfo note
  @apiParam {String} Data.installationNote.panelInfo.createdOn Enter the installationNote panelInfo createdOn

  @apiParam {Object[]} Data.installationNote.panel Enter the panel
  @apiParam {String} Data.installationNote.panel.note Enter the panel note
  @apiParam {String} Data.installationNote.panel.createdOn Enter the panel createdOn

  @apiParam {Object[]} Data.installationNote.wiring Enter the installationNote wiring
  @apiParam {String} Data.installationNote.wiring.note Enter the installationNote wiring note
  @apiParam {String} Data.installationNote.wiring.createdOn Enter the installationNote wiring createdOn

  @apiParam {Object[]} Data.installationNote.inverter Enter the installationNote inverter
  @apiParam {String} Data.installationNote.inverter.note Enter the installationNote inverter note
  @apiParam {String} Data.installationNote.inverter.createdOn Enter the installationNote inverter createdOn

  @apiParam {Object[]} Data.installationNote.switchboard Enter the switchboard
  @apiParam {String} Data.installationNote.switchboard.note Enter the switchboard note
  @apiParam {String} Data.installationNote.switchboard.createdOn Enter the switchboard createdOn

  @apiParam {Object[]} Data.installationNote.materialdelivery Enter the installationNote materialdelivery
  @apiParam {String} Data.installationNote.materialdelivery.note Enter the installationNote materialdelivery note
  @apiParam {String} Data.installationNote.materialdelivery.createdOn Enter the installationNote wirimaterialdeliveryng createdOn

  @apiParam {Object[]} Data.installationNote.pricingInfo Enter the installationNote pricingInfo
  @apiParam {String} Data.installationNote.pricingInfo.note Enter the installationNote pricingInfo note
  @apiParam {String} Data.installationNote.pricingInfo.createdOn Enter the installationNote pricingInfo createdOn

  @apiParam {Object} Data.installation Enter the installation
  @apiParam {String} Data.installation.startDate Enter the installation startDate
  @apiParam {String} Data.installation.endDate Enter the installation startDate
  @apiParam {Number} Data.installation.days Enter the installation days
  @apiParam {Number} Data.installation.hours Enter the installation hours

  @apiParam {Object} Data.device Enter the device
  @apiParam {String} Data.device.inverterSerialNumber Enter the device inverterSerialNumber
  @apiParam {String} Data.device.tingcoBoxId Enter the device tingcoBoxId
 * 
 * 
 * @apiParamExample {json} Request-Example:
 * 
 * 
 * {
  "externalMarketingPartner": {
    "code": "ABC Corp"
  },
  "deliverySite": {
    "street": "Riistapolku 4C",
    "city": "Vantaa",
    "zip": 2120,
    "coordinates": [
      60.1870456,
      24.8338435
    ]
  },
  "gridInfo": {
    "gridId": "",
    "gridCompanyName": ""
  },
    "basePrice": {
      "package": 5555,
        "installation": 2000,
        "total": 11222
  },
    "extraDesignatedWorkAndMaterial": [
      {
        "designatedItemId": "wm1001",
        "quantity": 1,
        "amount": 122
      }],
  "contactInformation": {
    "name": "SODA WO 1",
    "ssnOrBusinessId": "99",
    "customerType": "Consumer",
    "phone": "0400889000",
    "email": "Suresh.SapaniDevarajan@partners.fortum.com"
  },
  "benefitCalculations": {
    "roofArea": 145.8,
    "roofAreaUnit": "m2",
    "roofAreaSuitableForPanels": 125,
    "confidenceClassForEstimates": "lidar",
    "roofType": "gable",
    "roofPitchAngle": 13.6,
    "roofRidgeAngleFromNorth": 175.8,
    "buildingType": "1110",
    "recommendedProductPackageId": "fortum_m18",
    "customerSelectedProductPackageId": "fortum_s18",
    "heatingType": "district",
    "buildYear": 1970,
    "floors": 2,
    "selectedBuildingId": "yuhj82_1",
    "estimatedMonthlyElectricityConsumption": [
      345.4,
      879.3,
      352.6,
      236.8,
      346.2,
      342.3,
      567.2,
      234.5,
      3455546.2,
      546.4,
      542.4
    ],
    "monthlySolarElectricityPotential": [
      345.4,
      879.3,
      352.6,
      236.8,
      346.2,
      342.3,
      567.2,
      234.5,
      3455546.2,
      546.4,
      542.4
    ]
  },
  "status": "OfferRequestReceived"
}
 * 
 * 
  @apiSuccess {Object} Data This is array of Objects
  @apiSuccess {String} Data.accountId This is accountId with extraDesignatedWorkAndMaterial
  @apiSuccess {String} Data.customerId This is the customerId the order createdOn
  @apiSuccess {String} Data.customerNote Customer note for the order
  @apiSuccess {String} Data.contractId Contract Id for the workoder
  @apiSuccess {String} Data.installerId InstalledId for the workoder
  @apiSuccess {String} Data.installerCompany Installer compan for the workoder
  @apiSuccess {Object} Data.externalMarketingPartner External marketing externalMarketingPartner
  @apiSuccess {String} Data.externalMarketingPartner.code External marketer code
  @apiSuccess {Object} Data.deliverySite Enter the delivery site
  @apiSuccess {String} Data.deliverySite.deliverySiteId Enter the delivery site ID
  @apiSuccess {String} Data.deliverySite.street Enter the delivery site street
  @apiSuccess {String} Data.deliverySite.city Enter the delivery site city
  @apiSuccess {String} Data.deliverySite.zip Enter the delivery site zip
  @apiSuccess {Array} Data.deliverySite.coordinates Enter the delivery site coordinates
  @apiSuccess {Object} Data.gridInfo Enter the delivery site gridinfo
  @apiSuccess {String} Data.gridInfo.gridId Enter the delivery site gridinfo gridId
  @apiSuccess {String} Data.gridInfo.gridCompanyName Enter the delivery site gridinfo gridCompanyName 
  @apiSuccess {Object} Data.contactInformation Enter the delivery site contactInformation
  @apiSuccess {String} Data.contactInformation.name Enter the delivery site contactInformation name
  @apiSuccess {String} Data.contactInformation.ssnOrBusinessId Enter the delivery site contactInformation ssnOrBusinessId
  @apiSuccess {String} Data.contactInformation.customerType Enter the delivery site contactInformation customerType
  @apiSuccess {String} Data.contactInformation.phone Enter the delivery site contactInformation phone
  @apiSuccess {String} Data.contactInformation.email Enter the delivery site contactInformation email
  @apiSuccess {String} Data.contactInformation.email Enter the delivery site contactInformation street
  @apiSuccess {String} Data.contactInformation.city Enter the delivery site city
  @apiSuccess {String} Data.contactInformation.zip Enter the delivery site zip
  @apiSuccess {String} Data.roofSupportDistance Enter the workorder roofSupportDistance
  @apiSuccess {String} Data.installationHomeVisit Enter the workorder installationHomeVisit time
  @apiSuccess {String} Data.paymentType Enter the workorder paymentType 'OneTime', 'OneTimeWith15PercentDiscount', 'TenYearMaterialAlone', 'TenYear'
  @apiSuccess {String} Data.lockedBy Enter the workorder lockedBy
  @apiSuccess {Boolean} Data.isLocked Enter the workorder isLocked
  @apiSuccess {String} Data.status Enter the workorder status 'OfferRequestReceived', 'PreliminaryOfferSent', 'PreliminaryOfferApproved', 'AssessmentSiteVisitScheduled', 'AddInstallationPlan', 'InstallationPlanCreated', 'InstallationPlanVerified', 'FinalOfferSent', 'FinalOfferApproved', 'InstallationTimeScheduled', 'AddInstallationReport', 'InstallationReportReady', 'InstallationReportVerified', 'InstallationApproved', 'Cancelled', 'Closed'
  @apiSuccess {String} Data.statebeforecancelled Enter the workorder statebeforecancelled  'OfferRequestReceived', 'PreliminaryOfferSent', 'PreliminaryOfferApproved', 'AssessmentSiteVisitScheduled', 'AddInstallationPlan', 'InstallationPlanCreated', 'InstallationPlanVerified', 'FinalOfferSent', 'FinalOfferApproved', 'InstallationTimeScheduled', 'AddInstallationReport', 'InstallationReportReady', 'InstallationReportVerified', 'InstallationApproved', 'Cancelled'
  @apiSuccess {Boolean} Data.interestedInVPP Enter the workorder interestedInVPP  
  @apiSuccess {String} Data.country Enter the workorder country  'FI', 'SE', 'PL', 'NO'
  @apiSuccess {String} Data.app Enter the workorder country  'SODA', 'FODA', 'VODA', 'HODA'
  @apiSuccess {String} Data.createdOn Enter the workorder createdOn
  @apiSuccess {String} Data.modifiedOn Enter the workorder modifiedOn

  @apiSuccess {Object} Data.benefitCalculations Enter the benefitCalculations
  @apiSuccess {Array} Data.benefitCalculations.monthlySolarElectricityPotential Enter the benefitCalculations monthlySolarElectricityPotential
  @apiSuccess {Number} Data.benefitCalculations.roofArea Enter the benefitCalculations roofArea
  @apiSuccess {String} Data.benefitCalculations.roofAreaUnit Enter the benefitCalculations roofAreaUnit
  @apiSuccess {Number} Data.benefitCalculations.roofAreaSuitableForPanels Enter the benefitCalculations roofAreaSuitableForPanels
  @apiSuccess {Array} Data.benefitCalculations.estimatedMonthlyElectricityConsumption Enter the benefitCalculations estimatedMonthlyElectricityConsumption
  @apiSuccess {String} Data.benefitCalculations.confidenceClassForEstimates Enter the benefitCalculations confidenceClassForEstimates
  @apiSuccess {String} Data.benefitCalculations.roofType Enter the benefitCalculations roofType
  @apiSuccess {Number} Data.benefitCalculations.roofPitchAngle Enter the benefitCalculations roofPitchAngle
  @apiSuccess {String} Data.benefitCalculations.roofMaterial Enter the benefitCalculations roofMaterial
  @apiSuccess {Number} Data.benefitCalculations.roofRidgeAngleFromNorth Enter the benefitCalculations roofRidgeAngleFromNorth
  @apiSuccess {String} Data.benefitCalculations.buildingType Enter the benefitCalculations buildingType
  @apiSuccess {String} Data.benefitCalculations.recommendedProductPackageId Enter the benefitCalculations recommendedProductPackageId
  @apiSuccess {String} Data.benefitCalculations.customerSelectedProductPackageId Enter the benefitCalculations customerSelectedProductPackageId

  @apiSuccess {String} Data.benefitCalculations.heatingType Enter the benefitCalculations heatingType
  @apiSuccess {Number} Data.benefitCalculations.buildYear Enter the benefitCalculations buildYear
  @apiSuccess {Number} Data.benefitCalculations.floors Enter the benefitCalculations floors
  @apiSuccess {Number} Data.benefitCalculations.floorArea Enter the benefitCalculations floorArea
  @apiSuccess {Number} Data.benefitCalculations.yearlyConsumption Enter the benefitCalculations yearlyConsumption
  @apiSuccess {String} Data.benefitCalculations.userEditedFields Enter the benefitCalculations userEditedFields
  @apiSuccess {String} Data.benefitCalculations.selectedBuildingId Enter the benefitCalculations selectedBuildingId
  @apiSuccess {Object} Data.benefitCalculations.customBuilding Enter the benefitCalculations customBuilding
  @apiSuccess {Object[]} Data.benefitCalculations.customBuilding.parts Enter the benefitCalculations customBuilding parts
  @apiSuccess {Array} Data.benefitCalculations.customBuilding.parts.center Enter the benefitCalculations customBuilding parts center
  @apiSuccess {Array} Data.benefitCalculations.customBuilding.parts.dimensions Enter the benefitCalculations customBuilding parts dimensions
  @apiSuccess {Number} Data.benefitCalculations.customBuilding.parts.azimuth Enter the benefitCalculations customBuilding parts azimuth
  @apiSuccess {Number} Data.benefitCalculations.customBuilding.roofArea Enter the benefitCalculations customBuilding  roofArea
  @apiSuccess {Number} Data.benefitCalculations.customBuilding.mainAzimuth Enter the benefitCalculations customBuilding  mainAzimuth

  @apiSuccess {Object} Data.basePrice Enter the basePrice
  @apiSuccess {Number} Data.basePrice.package Enter the basePrice package
  @apiSuccess {Number} Data.basePrice.package Enter the basePrice package
  @apiSuccess {Number} Data.basePrice.installation Enter the basePrice installation
  @apiSuccess {Number} Data.basePrice.total Enter the basePrice total
  @apiSuccess {Number} Data.basePrice.package Enter the basePrice package 
  @apiSuccess {priceCurrency} Data.basePrice.priceCurrency Enter the basePrice priceCurrency 'EUR', 'Kr', 'NOK', 'PLN'

  @apiSuccess {Object[]} Data.basePrice.subsidies Enter the basePrice subsidies 
  @apiSuccess {Number} Data.basePrice.subsidies.amount Enter the basePrice package
  @apiSuccess {Object} Data.basePrice.subsidies.name Enter the basePrice subsidies name 
  @apiSuccess {Object} Data.basePrice.subsidies.name.description Enter the basePrice subsidies name
  @apiSuccess {String} Data.basePrice.subsidies.name.description.en_GB  Name of the subsidies in english.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.fi_FI  Name of the subsidies in finnish.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.sv_FI  Name of the subsidies in sweden.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.sv_SE  Name of the subsidies in sweden.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.nb_No  Name of the subsidies in Norway.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.nn_No  Name of the subsidies in Norway.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.pl_PL  Name of the subsidies in PL

  @apiSuccess {Object} Data.extraDesignatedWorkAndMaterial Enter the extraDesignatedWorkAndMaterial
  @apiSuccess {String} Data.extraDesignatedWorkAndMaterial.designatedItemId Enter the extraDesignatedWorkAndMaterial designatedItemId
  @apiSuccess {String} Data.extraDesignatedWorkAndMaterial.type Enter the extraDesignatedWorkAndMaterial type
  @apiSuccess {Number} Data.extraDesignatedWorkAndMaterial.quantity Enter the extraDesignatedWorkAndMaterial quantity
  @apiSuccess {Number} Data.extraDesignatedWorkAndMaterial.amount Enter the extraDesignatedWorkAndMaterial amount

  @apiSuccess {Object[]} Data.extraNonDesignatedWorkAndMaterial Enter the extraNonDesignatedWorkAndMaterial
  @apiSuccess {String} Data.extraNonDesignatedWorkAndMaterial.title Enter the extraNonDesignatedWorkAndMaterial title
  @apiSuccess {String} Data.extraNonDesignatedWorkAndMaterial.description Enter the extraNonDesignatedWorkAndMaterial description
  @apiSuccess {String} Data.extraNonDesignatedWorkAndMaterial.type Enter the extraNonDesignatedWorkAndMaterial type 'Work', 'Material'
  @apiSuccess {Number} Data.extraNonDesignatedWorkAndMaterial.quantity Enter the extraNonDesignatedWorkAndMaterial quantity
  @apiSuccess {Number} Data.extraNonDesignatedWorkAndMaterial.amount Enter the extraNonDesignatedWorkAndMaterial amount

  @apiSuccess {Object[]} Data.panelInstallationLayout Enter the panelInstallationLayout
  @apiSuccess {String} Data.panelInstallationLayout.name Enter the panelInstallationLayout name
  @apiSuccess {Number} Data.panelInstallationLayout.row Enter the panelInstallationLayout row
  @apiSuccess {Number} Data.panelInstallationLayout.column Enter the panelInstallationLayout column
  @apiSuccess {String} Data.panelInstallationLayout.orientation Enter the panelInstallationLayout 'Portrait', 'Landscape'
  @apiSuccess {Number} Data.panelInstallationLayout.width Enter the panelInstallationLayout width
  @apiSuccess {Number} Data.panelInstallationLayout.height Enter the panelInstallationLayout height
  @apiSuccess {Number} Data.panelInstallationLayout.unit Enter the panelInstallationLayout unit 'm'
  @apiSuccess {Array} Data.panelInstallationLayout.panels Enter the panelInstallationLayout panels [[],[]]

  @apiSuccess {Object} Data.installationPlanChangeLog Enter the installationPlanChangeLog
  @apiSuccess {String} Data.installationPlanChangeLog.createdOn Enter the installationPlanChangeLog createdOn
  @apiSuccess {String} Data.installationPlanChangeLog.createdBy Enter the installationPlanChangeLog createdBy
  @apiSuccess {String} Data.installationPlanChangeLog.modifiedOn Enter the installationPlanChangeLog modifiedOn
  @apiSuccess {String} Data.installationPlanChangeLog.modifiedBy Enter the installationPlanChangeLog modifiedBy
  @apiSuccess {String} Data.installationPlanChangeLog.verifiedOn Enter the installationPlanChangeLog verifiedOn
  @apiSuccess {String} Data.installationPlanChangeLog.verifiedBy Enter the installationPlanChangeLog verifiedBy
  @apiSuccess {Boolean} Data.installationPlanChangeLog.initialized Enter the installationPlanChangeLog initialized
  @apiSuccess {Number} Data.installationPlanChangeLog.status Enter the installationPlanChangeLog status 0, 1

  @apiSuccess {Object} Data.installationReportChangeLog Enter the installationReportChangeLog
  @apiSuccess {String} Data.installationReportChangeLog.createdOn Enter the installationReportChangeLog createdOn
  @apiSuccess {String} Data.installationReportChangeLog.createdBy Enter the installationReportChangeLog createdBy
  @apiSuccess {String} Data.installationReportChangeLog.modifiedOn Enter the installationReportChangeLog modifiedOn
  @apiSuccess {String} Data.installationReportChangeLog.modifiedBy Enter the installationReportChangeLog modifiedBy
  @apiSuccess {String} Data.installationReportChangeLog.verifiedOn Enter the installationReportChangeLog verifiedOn
  @apiSuccess {String} Data.installationReportChangeLog.verifiedBy Enter the installationReportChangeLog verifiedBy
  @apiSuccess {Boolean} Data.installationReportChangeLog.initialized Enter the installationReportChangeLog initialized
  @apiSuccess {Number} Data.installationReportChangeLog.status Enter the installationReportChangeLog status 0, 1

  @apiSuccess {Object} Data.building Enter the building details
  @apiSuccess {Number} Data.building.buildingEdgeheight Enter the building buildingEdgeheight
  @apiSuccess {Number} Data.building.buildingTopheight Enter the building buildingTopheight

  @apiSuccess {Object[]} Data.notesToInstaller Enter the notesToInstaller details
  @apiSuccess {String} Data.notesToInstaller.note Enter the notesToInstaller note
  @apiSuccess {String} Data.notesToInstaller.createdOn Enter the notesToInstaller createdOn

  @apiSuccess {Object[]} Data.installerNotes Enter the installerNotes details
  @apiSuccess {String} Data.installerNotes.note Enter the installerNotes note
  @apiSuccess {String} Data.installerNotes.createdOn Enter the installerNotes createdOn

  @apiSuccess {Object[]} Data.installationPlanNote Enter the installationPlanNote details
  @apiSuccess {String} Data.installationPlanNote.note Enter the installationPlanNote note
  @apiSuccess {String} Data.installationPlanNote.createdOn Enter the installationPlanNote createdOn

  @apiSuccess {Object[]} Data.customerServiceNotes Enter the customerServiceNotes details
  @apiSuccess {String} Data.customerServiceNotes.note Enter the customerServiceNotes note
  @apiSuccess {String} Data.customerServiceNotes.createdOn Enter the customerServiceNotes createdOn

  @apiSuccess {Boolean} Data.craneRequirementOverwritten Enter the craneRequirementOverwritten
  @apiSuccess {Boolean} Data.surplusElectricityWillBeSoldToFortum Enter the surplusElectricityWillBeSoldToFortum

  @apiSuccess {Object} Data.installationNote Enter the installationNote
  @apiSuccess {Object[]} Data.installationNote.installplan Enter the installplan
  @apiSuccess {String} Data.installationNote.installplan.note Enter the installplan note
  @apiSuccess {String} Data.installationNote.installplan.createdOn Enter the installplan createdOn

  @apiSuccess {Object[]} Data.installationNote.roofProperties Enter the installationNote roofProperties
  @apiSuccess {String} Data.installationNote.roofProperties.note Enter the installationNote roofProperties note
  @apiSuccess {String} Data.installationNote.roofProperties.createdOn Enter the installationNote roofProperties createdOn

  @apiSuccess {Object[]} Data.installationNote.panelInfo Enter the installationNote panelInfo
  @apiSuccess {String} Data.installationNote.panelInfo.note Enter the installationNote panelInfo note
  @apiSuccess {String} Data.installationNote.panelInfo.createdOn Enter the installationNote panelInfo createdOn

  @apiSuccess {Object[]} Data.installationNote.panel Enter the panel
  @apiSuccess {String} Data.installationNote.panel.note Enter the panel note
  @apiSuccess {String} Data.installationNote.panel.createdOn Enter the panel createdOn

  @apiSuccess {Object[]} Data.installationNote.wiring Enter the installationNote wiring
  @apiSuccess {String} Data.installationNote.wiring.note Enter the installationNote wiring note
  @apiSuccess {String} Data.installationNote.wiring.createdOn Enter the installationNote wiring createdOn

  @apiSuccess {Object[]} Data.installationNote.inverter Enter the installationNote inverter
  @apiSuccess {String} Data.installationNote.inverter.note Enter the installationNote inverter note
  @apiSuccess {String} Data.installationNote.inverter.createdOn Enter the installationNote inverter createdOn

  @apiSuccess {Object[]} Data.installationNote.switchboard Enter the switchboard
  @apiSuccess {String} Data.installationNote.switchboard.note Enter the switchboard note
  @apiSuccess {String} Data.installationNote.switchboard.createdOn Enter the switchboard createdOn

  @apiSuccess {Object[]} Data.installationNote.materialdelivery Enter the installationNote materialdelivery
  @apiSuccess {String} Data.installationNote.materialdelivery.note Enter the installationNote materialdelivery note
  @apiSuccess {String} Data.installationNote.materialdelivery.createdOn Enter the installationNote wirimaterialdeliveryng createdOn

  @apiSuccess {Object[]} Data.installationNote.pricingInfo Enter the installationNote pricingInfo
  @apiSuccess {String} Data.installationNote.pricingInfo.note Enter the installationNote pricingInfo note
  @apiSuccess {String} Data.installationNote.pricingInfo.createdOn Enter the installationNote pricingInfo createdOn

  @apiSuccess {Object} Data.installation Enter the installation
  @apiSuccess {String} Data.installation.startDate Enter the installation startDate
  @apiSuccess {String} Data.installation.endDate Enter the installation startDate
  @apiSuccess {Number} Data.installation.days Enter the installation days
  @apiSuccess {Number} Data.installation.hours Enter the installation hours

  @apiSuccess {Object} Data.device Enter the device
  @apiSuccess {String} Data.device.inverterSerialNumber Enter the device inverterSerialNumber
  @apiSuccess {String} Data.device.tingcoBoxId Enter the device tingcoBoxId




 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK

  
    {
        "_id": "59ba355fc738300012b3346e",
        "workOrderNumber": 10905,
        "customerNote": "",
        "deliverySite": {
            "street": "RIILAH2",
            "city": "ESPOO",
            "zip": "02260",
            "coordinates": [
                24.684145266666665,
                60.14239553333333
            ],
            "deliverySiteId": ""
        },
        "contactInformation": {
            "name": "TEST71",
            "ssnOrBusinessId": "10",
            "customerType": "Business",
            "phone": "8883627364",
            "email": "mahadevan.r@cognizant.com"
        },
        "benefitCalculations": {
            "roofArea": 90,
            "roofAreaUnit": "m2",
            "roofAreaSuitableForPanels": 38,
            "confidenceClassForEstimates": "footprint",
            "roofType": "gable",
            "roofMaterial": "other",
            "roofPitchAngle": 18,
            "roofRidgeAngleFromNorth": 77,
            "buildingType": "1110",
            "recommendedProductPackageId": "060117_8_PANELS_SMA_SB25_HANHWA_QPLUS_BFR-G4.1",
            "customerSelectedProductPackageId": "060117_8_PANELS_SMA_SB25_HANHWA_QPLUS_BFR-G4.1",
            "heatingType": "district",
            "buildYear": 1990,
            "floors": 2,
            "selectedBuildingId": "ud9w1sw6y_1",
            "floorArea": 146,
            "yearlyConsumption": 4000,
            "userEditedFields": [],
            "estimatedMonthlyElectricityConsumption": [
                473,
                352,
                386,
                328,
                293,
                242,
                250,
                291,
                324,
                382,
                414,
                432
            ],
            "monthlySolarElectricityPotential": [
                102,
                254,
                542,
                757,
                962,
                933,
                937,
                761,
                519,
                280,
                137,
                66
            ]
        },
        "basePrice": {
            "package": 2700,
            "installation": 2100,
            "total": 5280,
            "priceCurrency": "EUR",
            "subsidies": []
        },
        "country": "FI",
        "app": "SODA",
        "modifiedOn": "2017-09-14T07:53:03.825Z",
        "createdOn": "2017-09-14T07:53:03.825Z",
        "interestedInVPP": false,
        "status": "OfferRequestReceived",
        "isLocked": false,
        "device": {},
        "installation": {},
        "customerServiceNotes": [],
        "installationNote": {
            "pricingInfo": [],
            "materialdelivery": [],
            "switchboard": [],
            "inverter": [],
            "wiring": [],
            "panel": [],
            "panelInfo": [],
            "roofProperties": [],
            "installPlan": []
        },
        "installationPlanNote": [],
        "installerNotes": [],
        "notesToInstaller": [],
        "panelInstallationLayout": [],
        "extraNonDesignatedWorkAndMaterial": [],
        "extraDesignatedWorkAndMaterial": [
            {
                "designatedItemId": "crane",
                "quantity": 1,
                "amount": 480,
                "type": "Material"
            }
        ],
        "installerCompany": "",
        "installerId": "",
        "contractId": "",
        "customerId": "",
        "accountId": ""
    }

    * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 Mongodb-error
 *     {
 *       "error": "Item not found"
 *     }

 * 
 * */


  /**
 * @api {put} /WorkOrder/:orderId UpdateSodaWorkOrder
 * @apiVersion 1.0.0
 * @apiName UpdateSodaWorkOrder
 * @apiGroup SODA.WorkOrder
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * @apiParam {String} orderId Which package Id we need to update the data
 * 
 * @apiParam {Object[]} Request Which package Id we need to get the data
 * @apiParam {String} Request.op Mention the operation to do.
 * @apiParam {String} Request.path Mention the data path to change
 * @apiParam {Object} Request.value Mention the data value to change ex: any Object
 * 
 * @apiParamExample {json} Request-Example:
 * [
  {
    "op": "add",
    "path": "/zip",
    "value": "0220"
  }
]

 @apiSuccess {Object} Data This is array of Objects
  @apiSuccess {String} Data.accountId This is accountId with extraDesignatedWorkAndMaterial
  @apiSuccess {String} Data.customerId This is the customerId the order createdOn
  @apiSuccess {String} Data.customerNote Customer note for the order
  @apiSuccess {String} Data.contractId Contract Id for the workoder
  @apiSuccess {String} Data.installerId InstalledId for the workoder
  @apiSuccess {String} Data.installerCompany Installer compan for the workoder
  @apiSuccess {Object} Data.externalMarketingPartner External marketing externalMarketingPartner
  @apiSuccess {String} Data.externalMarketingPartner.code External marketer code
  @apiSuccess {Object} Data.deliverySite Enter the delivery site
  @apiSuccess {String} Data.deliverySite.deliverySiteId Enter the delivery site ID
  @apiSuccess {String} Data.deliverySite.street Enter the delivery site street
  @apiSuccess {String} Data.deliverySite.city Enter the delivery site city
  @apiSuccess {String} Data.deliverySite.zip Enter the delivery site zip
  @apiSuccess {Array} Data.deliverySite.coordinates Enter the delivery site coordinates
  @apiSuccess {Object} Data.gridInfo Enter the delivery site gridinfo
  @apiSuccess {String} Data.gridInfo.gridId Enter the delivery site gridinfo gridId
  @apiSuccess {String} Data.gridInfo.gridCompanyName Enter the delivery site gridinfo gridCompanyName 
  @apiSuccess {Object} Data.contactInformation Enter the delivery site contactInformation
  @apiSuccess {String} Data.contactInformation.name Enter the delivery site contactInformation name
  @apiSuccess {String} Data.contactInformation.ssnOrBusinessId Enter the delivery site contactInformation ssnOrBusinessId
  @apiSuccess {String} Data.contactInformation.customerType Enter the delivery site contactInformation customerType
  @apiSuccess {String} Data.contactInformation.phone Enter the delivery site contactInformation phone
  @apiSuccess {String} Data.contactInformation.email Enter the delivery site contactInformation email
  @apiSuccess {String} Data.contactInformation.email Enter the delivery site contactInformation street
  @apiSuccess {String} Data.contactInformation.city Enter the delivery site city
  @apiSuccess {String} Data.contactInformation.zip Enter the delivery site zip
  @apiSuccess {String} Data.roofSupportDistance Enter the workorder roofSupportDistance
  @apiSuccess {String} Data.installationHomeVisit Enter the workorder installationHomeVisit time
  @apiSuccess {String} Data.paymentType Enter the workorder paymentType 'OneTime', 'OneTimeWith15PercentDiscount', 'TenYearMaterialAlone', 'TenYear'
  @apiSuccess {String} Data.lockedBy Enter the workorder lockedBy
  @apiSuccess {Boolean} Data.isLocked Enter the workorder isLocked
  @apiSuccess {String} Data.status Enter the workorder status 'OfferRequestReceived', 'PreliminaryOfferSent', 'PreliminaryOfferApproved', 'AssessmentSiteVisitScheduled', 'AddInstallationPlan', 'InstallationPlanCreated', 'InstallationPlanVerified', 'FinalOfferSent', 'FinalOfferApproved', 'InstallationTimeScheduled', 'AddInstallationReport', 'InstallationReportReady', 'InstallationReportVerified', 'InstallationApproved', 'Cancelled', 'Closed'
  @apiSuccess {String} Data.statebeforecancelled Enter the workorder statebeforecancelled  'OfferRequestReceived', 'PreliminaryOfferSent', 'PreliminaryOfferApproved', 'AssessmentSiteVisitScheduled', 'AddInstallationPlan', 'InstallationPlanCreated', 'InstallationPlanVerified', 'FinalOfferSent', 'FinalOfferApproved', 'InstallationTimeScheduled', 'AddInstallationReport', 'InstallationReportReady', 'InstallationReportVerified', 'InstallationApproved', 'Cancelled'
  @apiSuccess {Boolean} Data.interestedInVPP Enter the workorder interestedInVPP  
  @apiSuccess {String} Data.country Enter the workorder country  'FI', 'SE', 'PL', 'NO'
  @apiSuccess {String} Data.app Enter the workorder country  'SODA', 'FODA', 'VODA', 'HODA'
  @apiSuccess {String} Data.createdOn Enter the workorder createdOn
  @apiSuccess {String} Data.modifiedOn Enter the workorder modifiedOn

  @apiSuccess {Object} Data.benefitCalculations Enter the benefitCalculations
  @apiSuccess {Array} Data.benefitCalculations.monthlySolarElectricityPotential Enter the benefitCalculations monthlySolarElectricityPotential
  @apiSuccess {Number} Data.benefitCalculations.roofArea Enter the benefitCalculations roofArea
  @apiSuccess {String} Data.benefitCalculations.roofAreaUnit Enter the benefitCalculations roofAreaUnit
  @apiSuccess {Number} Data.benefitCalculations.roofAreaSuitableForPanels Enter the benefitCalculations roofAreaSuitableForPanels
  @apiSuccess {Array} Data.benefitCalculations.estimatedMonthlyElectricityConsumption Enter the benefitCalculations estimatedMonthlyElectricityConsumption
  @apiSuccess {String} Data.benefitCalculations.confidenceClassForEstimates Enter the benefitCalculations confidenceClassForEstimates
  @apiSuccess {String} Data.benefitCalculations.roofType Enter the benefitCalculations roofType
  @apiSuccess {Number} Data.benefitCalculations.roofPitchAngle Enter the benefitCalculations roofPitchAngle
  @apiSuccess {String} Data.benefitCalculations.roofMaterial Enter the benefitCalculations roofMaterial
  @apiSuccess {Number} Data.benefitCalculations.roofRidgeAngleFromNorth Enter the benefitCalculations roofRidgeAngleFromNorth
  @apiSuccess {String} Data.benefitCalculations.buildingType Enter the benefitCalculations buildingType
  @apiSuccess {String} Data.benefitCalculations.recommendedProductPackageId Enter the benefitCalculations recommendedProductPackageId
  @apiSuccess {String} Data.benefitCalculations.customerSelectedProductPackageId Enter the benefitCalculations customerSelectedProductPackageId

  @apiSuccess {String} Data.benefitCalculations.heatingType Enter the benefitCalculations heatingType
  @apiSuccess {Number} Data.benefitCalculations.buildYear Enter the benefitCalculations buildYear
  @apiSuccess {Number} Data.benefitCalculations.floors Enter the benefitCalculations floors
  @apiSuccess {Number} Data.benefitCalculations.floorArea Enter the benefitCalculations floorArea
  @apiSuccess {Number} Data.benefitCalculations.yearlyConsumption Enter the benefitCalculations yearlyConsumption
  @apiSuccess {String} Data.benefitCalculations.userEditedFields Enter the benefitCalculations userEditedFields
  @apiSuccess {String} Data.benefitCalculations.selectedBuildingId Enter the benefitCalculations selectedBuildingId
  @apiSuccess {Object} Data.benefitCalculations.customBuilding Enter the benefitCalculations customBuilding
  @apiSuccess {Object[]} Data.benefitCalculations.customBuilding.parts Enter the benefitCalculations customBuilding parts
  @apiSuccess {Array} Data.benefitCalculations.customBuilding.parts.center Enter the benefitCalculations customBuilding parts center
  @apiSuccess {Array} Data.benefitCalculations.customBuilding.parts.dimensions Enter the benefitCalculations customBuilding parts dimensions
  @apiSuccess {Number} Data.benefitCalculations.customBuilding.parts.azimuth Enter the benefitCalculations customBuilding parts azimuth
  @apiSuccess {Number} Data.benefitCalculations.customBuilding.roofArea Enter the benefitCalculations customBuilding  roofArea
  @apiSuccess {Number} Data.benefitCalculations.customBuilding.mainAzimuth Enter the benefitCalculations customBuilding  mainAzimuth

  @apiSuccess {Object} Data.basePrice Enter the basePrice
  @apiSuccess {Number} Data.basePrice.package Enter the basePrice package
  @apiSuccess {Number} Data.basePrice.package Enter the basePrice package
  @apiSuccess {Number} Data.basePrice.installation Enter the basePrice installation
  @apiSuccess {Number} Data.basePrice.total Enter the basePrice total
  @apiSuccess {Number} Data.basePrice.package Enter the basePrice package 
  @apiSuccess {priceCurrency} Data.basePrice.priceCurrency Enter the basePrice priceCurrency 'EUR', 'Kr', 'NOK', 'PLN'

  @apiSuccess {Object[]} Data.basePrice.subsidies Enter the basePrice subsidies 
  @apiSuccess {Number} Data.basePrice.subsidies.amount Enter the basePrice package
  @apiSuccess {Object} Data.basePrice.subsidies.name Enter the basePrice subsidies name 
  @apiSuccess {Object} Data.basePrice.subsidies.name.description Enter the basePrice subsidies name
  @apiSuccess {String} Data.basePrice.subsidies.name.description.en_GB  Name of the subsidies in english.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.fi_FI  Name of the subsidies in finnish.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.sv_FI  Name of the subsidies in sweden.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.sv_SE  Name of the subsidies in sweden.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.nb_No  Name of the subsidies in Norway.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.nn_No  Name of the subsidies in Norway.
  @apiSuccess {String} Data.basePrice.subsidies.name.description.pl_PL  Name of the subsidies in PL

  @apiSuccess {Object} Data.extraDesignatedWorkAndMaterial Enter the extraDesignatedWorkAndMaterial
  @apiSuccess {String} Data.extraDesignatedWorkAndMaterial.designatedItemId Enter the extraDesignatedWorkAndMaterial designatedItemId
  @apiSuccess {String} Data.extraDesignatedWorkAndMaterial.type Enter the extraDesignatedWorkAndMaterial type
  @apiSuccess {Number} Data.extraDesignatedWorkAndMaterial.quantity Enter the extraDesignatedWorkAndMaterial quantity
  @apiSuccess {Number} Data.extraDesignatedWorkAndMaterial.amount Enter the extraDesignatedWorkAndMaterial amount

  @apiSuccess {Object[]} Data.extraNonDesignatedWorkAndMaterial Enter the extraNonDesignatedWorkAndMaterial
  @apiSuccess {String} Data.extraNonDesignatedWorkAndMaterial.title Enter the extraNonDesignatedWorkAndMaterial title
  @apiSuccess {String} Data.extraNonDesignatedWorkAndMaterial.description Enter the extraNonDesignatedWorkAndMaterial description
  @apiSuccess {String} Data.extraNonDesignatedWorkAndMaterial.type Enter the extraNonDesignatedWorkAndMaterial type 'Work', 'Material'
  @apiSuccess {Number} Data.extraNonDesignatedWorkAndMaterial.quantity Enter the extraNonDesignatedWorkAndMaterial quantity
  @apiSuccess {Number} Data.extraNonDesignatedWorkAndMaterial.amount Enter the extraNonDesignatedWorkAndMaterial amount

  @apiSuccess {Object[]} Data.panelInstallationLayout Enter the panelInstallationLayout
  @apiSuccess {String} Data.panelInstallationLayout.name Enter the panelInstallationLayout name
  @apiSuccess {Number} Data.panelInstallationLayout.row Enter the panelInstallationLayout row
  @apiSuccess {Number} Data.panelInstallationLayout.column Enter the panelInstallationLayout column
  @apiSuccess {String} Data.panelInstallationLayout.orientation Enter the panelInstallationLayout 'Portrait', 'Landscape'
  @apiSuccess {Number} Data.panelInstallationLayout.width Enter the panelInstallationLayout width
  @apiSuccess {Number} Data.panelInstallationLayout.height Enter the panelInstallationLayout height
  @apiSuccess {Number} Data.panelInstallationLayout.unit Enter the panelInstallationLayout unit 'm'
  @apiSuccess {Array} Data.panelInstallationLayout.panels Enter the panelInstallationLayout panels [[],[]]

  @apiSuccess {Object} Data.installationPlanChangeLog Enter the installationPlanChangeLog
  @apiSuccess {String} Data.installationPlanChangeLog.createdOn Enter the installationPlanChangeLog createdOn
  @apiSuccess {String} Data.installationPlanChangeLog.createdBy Enter the installationPlanChangeLog createdBy
  @apiSuccess {String} Data.installationPlanChangeLog.modifiedOn Enter the installationPlanChangeLog modifiedOn
  @apiSuccess {String} Data.installationPlanChangeLog.modifiedBy Enter the installationPlanChangeLog modifiedBy
  @apiSuccess {String} Data.installationPlanChangeLog.verifiedOn Enter the installationPlanChangeLog verifiedOn
  @apiSuccess {String} Data.installationPlanChangeLog.verifiedBy Enter the installationPlanChangeLog verifiedBy
  @apiSuccess {Boolean} Data.installationPlanChangeLog.initialized Enter the installationPlanChangeLog initialized
  @apiSuccess {Number} Data.installationPlanChangeLog.status Enter the installationPlanChangeLog status 0, 1

  @apiSuccess {Object} Data.installationReportChangeLog Enter the installationReportChangeLog
  @apiSuccess {String} Data.installationReportChangeLog.createdOn Enter the installationReportChangeLog createdOn
  @apiSuccess {String} Data.installationReportChangeLog.createdBy Enter the installationReportChangeLog createdBy
  @apiSuccess {String} Data.installationReportChangeLog.modifiedOn Enter the installationReportChangeLog modifiedOn
  @apiSuccess {String} Data.installationReportChangeLog.modifiedBy Enter the installationReportChangeLog modifiedBy
  @apiSuccess {String} Data.installationReportChangeLog.verifiedOn Enter the installationReportChangeLog verifiedOn
  @apiSuccess {String} Data.installationReportChangeLog.verifiedBy Enter the installationReportChangeLog verifiedBy
  @apiSuccess {Boolean} Data.installationReportChangeLog.initialized Enter the installationReportChangeLog initialized
  @apiSuccess {Number} Data.installationReportChangeLog.status Enter the installationReportChangeLog status 0, 1

  @apiSuccess {Object} Data.building Enter the building details
  @apiSuccess {Number} Data.building.buildingEdgeheight Enter the building buildingEdgeheight
  @apiSuccess {Number} Data.building.buildingTopheight Enter the building buildingTopheight

  @apiSuccess {Object[]} Data.notesToInstaller Enter the notesToInstaller details
  @apiSuccess {String} Data.notesToInstaller.note Enter the notesToInstaller note
  @apiSuccess {String} Data.notesToInstaller.createdOn Enter the notesToInstaller createdOn

  @apiSuccess {Object[]} Data.installerNotes Enter the installerNotes details
  @apiSuccess {String} Data.installerNotes.note Enter the installerNotes note
  @apiSuccess {String} Data.installerNotes.createdOn Enter the installerNotes createdOn

  @apiSuccess {Object[]} Data.installationPlanNote Enter the installationPlanNote details
  @apiSuccess {String} Data.installationPlanNote.note Enter the installationPlanNote note
  @apiSuccess {String} Data.installationPlanNote.createdOn Enter the installationPlanNote createdOn

  @apiSuccess {Object[]} Data.customerServiceNotes Enter the customerServiceNotes details
  @apiSuccess {String} Data.customerServiceNotes.note Enter the customerServiceNotes note
  @apiSuccess {String} Data.customerServiceNotes.createdOn Enter the customerServiceNotes createdOn

  @apiSuccess {Boolean} Data.craneRequirementOverwritten Enter the craneRequirementOverwritten
  @apiSuccess {Boolean} Data.surplusElectricityWillBeSoldToFortum Enter the surplusElectricityWillBeSoldToFortum

  @apiSuccess {Object} Data.installationNote Enter the installationNote
  @apiSuccess {Object[]} Data.installationNote.installplan Enter the installplan
  @apiSuccess {String} Data.installationNote.installplan.note Enter the installplan note
  @apiSuccess {String} Data.installationNote.installplan.createdOn Enter the installplan createdOn

  @apiSuccess {Object[]} Data.installationNote.roofProperties Enter the installationNote roofProperties
  @apiSuccess {String} Data.installationNote.roofProperties.note Enter the installationNote roofProperties note
  @apiSuccess {String} Data.installationNote.roofProperties.createdOn Enter the installationNote roofProperties createdOn

  @apiSuccess {Object[]} Data.installationNote.panelInfo Enter the installationNote panelInfo
  @apiSuccess {String} Data.installationNote.panelInfo.note Enter the installationNote panelInfo note
  @apiSuccess {String} Data.installationNote.panelInfo.createdOn Enter the installationNote panelInfo createdOn

  @apiSuccess {Object[]} Data.installationNote.panel Enter the panel
  @apiSuccess {String} Data.installationNote.panel.note Enter the panel note
  @apiSuccess {String} Data.installationNote.panel.createdOn Enter the panel createdOn

  @apiSuccess {Object[]} Data.installationNote.wiring Enter the installationNote wiring
  @apiSuccess {String} Data.installationNote.wiring.note Enter the installationNote wiring note
  @apiSuccess {String} Data.installationNote.wiring.createdOn Enter the installationNote wiring createdOn

  @apiSuccess {Object[]} Data.installationNote.inverter Enter the installationNote inverter
  @apiSuccess {String} Data.installationNote.inverter.note Enter the installationNote inverter note
  @apiSuccess {String} Data.installationNote.inverter.createdOn Enter the installationNote inverter createdOn

  @apiSuccess {Object[]} Data.installationNote.switchboard Enter the switchboard
  @apiSuccess {String} Data.installationNote.switchboard.note Enter the switchboard note
  @apiSuccess {String} Data.installationNote.switchboard.createdOn Enter the switchboard createdOn

  @apiSuccess {Object[]} Data.installationNote.materialdelivery Enter the installationNote materialdelivery
  @apiSuccess {String} Data.installationNote.materialdelivery.note Enter the installationNote materialdelivery note
  @apiSuccess {String} Data.installationNote.materialdelivery.createdOn Enter the installationNote wirimaterialdeliveryng createdOn

  @apiSuccess {Object[]} Data.installationNote.pricingInfo Enter the installationNote pricingInfo
  @apiSuccess {String} Data.installationNote.pricingInfo.note Enter the installationNote pricingInfo note
  @apiSuccess {String} Data.installationNote.pricingInfo.createdOn Enter the installationNote pricingInfo createdOn

  @apiSuccess {Object} Data.installation Enter the installation
  @apiSuccess {String} Data.installation.startDate Enter the installation startDate
  @apiSuccess {String} Data.installation.endDate Enter the installation startDate
  @apiSuccess {Number} Data.installation.days Enter the installation days
  @apiSuccess {Number} Data.installation.hours Enter the installation hours

  @apiSuccess {Object} Data.device Enter the device
  @apiSuccess {String} Data.device.inverterSerialNumber Enter the device inverterSerialNumber
  @apiSuccess {String} Data.device.tingcoBoxId Enter the device tingcoBoxId




 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK

  
    {
        "_id": "59ba355fc738300012b3346e",
        "workOrderNumber": 10905,
        "customerNote": "",
        "deliverySite": {
            "street": "RIILAH2",
            "city": "ESPOO",
            "zip": "02260",
            "coordinates": [
                24.684145266666665,
                60.14239553333333
            ],
            "deliverySiteId": ""
        },
        "contactInformation": {
            "name": "TEST71",
            "ssnOrBusinessId": "10",
            "customerType": "Business",
            "phone": "8883627364",
            "email": "mahadevan.r@cognizant.com"
        },
        "benefitCalculations": {
            "roofArea": 90,
            "roofAreaUnit": "m2",
            "roofAreaSuitableForPanels": 38,
            "confidenceClassForEstimates": "footprint",
            "roofType": "gable",
            "roofMaterial": "other",
            "roofPitchAngle": 18,
            "roofRidgeAngleFromNorth": 77,
            "buildingType": "1110",
            "recommendedProductPackageId": "060117_8_PANELS_SMA_SB25_HANHWA_QPLUS_BFR-G4.1",
            "customerSelectedProductPackageId": "060117_8_PANELS_SMA_SB25_HANHWA_QPLUS_BFR-G4.1",
            "heatingType": "district",
            "buildYear": 1990,
            "floors": 2,
            "selectedBuildingId": "ud9w1sw6y_1",
            "floorArea": 146,
            "yearlyConsumption": 4000,
            "userEditedFields": [],
            "estimatedMonthlyElectricityConsumption": [
                473,
                352,
                386,
                328,
                293,
                242,
                250,
                291,
                324,
                382,
                414,
                432
            ],
            "monthlySolarElectricityPotential": [
                102,
                254,
                542,
                757,
                962,
                933,
                937,
                761,
                519,
                280,
                137,
                66
            ]
        },
        "basePrice": {
            "package": 2700,
            "installation": 2100,
            "total": 5280,
            "priceCurrency": "EUR",
            "subsidies": []
        },
        "country": "FI",
        "app": "SODA",
        "modifiedOn": "2017-09-14T07:53:03.825Z",
        "createdOn": "2017-09-14T07:53:03.825Z",
        "interestedInVPP": false,
        "status": "OfferRequestReceived",
        "isLocked": false,
        "device": {},
        "installation": {},
        "customerServiceNotes": [],
        "installationNote": {
            "pricingInfo": [],
            "materialdelivery": [],
            "switchboard": [],
            "inverter": [],
            "wiring": [],
            "panel": [],
            "panelInfo": [],
            "roofProperties": [],
            "installPlan": []
        },
        "installationPlanNote": [],
        "installerNotes": [],
        "notesToInstaller": [],
        "panelInstallationLayout": [],
        "extraNonDesignatedWorkAndMaterial": [],
        "extraDesignatedWorkAndMaterial": [
            {
                "designatedItemId": "crane",
                "quantity": 1,
                "amount": 480,
                "type": "Material"
            }
        ],
        "installerCompany": "",
        "installerId": "",
        "contractId": "",
        "customerId": "",
        "accountId": ""
    }

    * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 Mongodb-error
 *     {
 *       "error": "Item not found"
 *     }

 * 
 * */


 /**
 * @api {delete} /WorkOrder RemoveSodaWorkOrder
 * @apiVersion 1.0.0
 * @apiName RemoveSodaWorkOrder
 * @apiGroup SODA.WorkOrder
 * 
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} token ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         token:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 204 NO CONTENT
 * 
*  @apiErrorExample Error-Response:
*     HTTP/1.1 404 Not Found
*     {
*       "error": "productNotFound"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 401 Not Allowed
*     {
*       "error": "productNotFound"
*     }
*/