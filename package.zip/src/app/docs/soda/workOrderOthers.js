/* eslint-disable */

/**
 * @api {get} /search?:searchquery SearchWorkOrders
 * @apiVersion 1.0.0
 * @apiName SearchWorkOrders
 * @apiGroup SODA.WorkOrder
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * @apiParam {String} searchquery Custom search query
 *
 * @apiSuccessExample Success-Response:
 *   HTTP/1.1 200 OK
 *  [
        {
            "_id": "5a38b5df738a4300252acf2e",
            "workOrderNumber": 10000001085,
            "deliverySite": {
                "zip": "02260",
                "city": "ESPOO",
                "street": "RIILAH2 24A"
            },
            "contactInformation": {
                "name": "TEST70"
            },
            "country": "FI",
            "app": "SODA",
            "modifiedOn": "2017-12-19T06:54:08.824Z",
            "status": "InstallationReportVerified",
            "customerId": "5656"
        }
    ]
  @apiSuccess {Object} Data This is array of Objects
  @apiSuccess {String} Data._id This is id of the Item
  @apiSuccess {String} Data.workOrderNumber This is the workOrderNumber
  @apiSuccess {Object} Data.deliverySite deliverySite details
  @apiSuccess {String} Data.deliverySite.zip zip
  @apiSuccess {String} Data.deliverySite.city city
  @apiSuccess {String} Data.deliverySite.street street
  @apiSuccess {Object} Data.contactInformation contactInformation details
  @apiSuccess {String} Data.contactInformation.name contactInformation
 * @apiSuccess {String}   Request.country   Choosen country
 * @apiSuccess {String}   Request.modifiedon   Modified date
 * @apiSuccess {String}   Request.status   status
 * @apiSuccess {String}   Request.app   App name
 * @apiSuccess {String}   Request.customerId   customerId
 * 
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": Search  not found"
 *     }
 *  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
 */


 /**
 * @api {get} /WorkOrder/Summary WorkOrderSummary
 * @apiVersion 1.0.0
 * @apiName WorkOrderSummary
 * @apiGroup SODA.WorkOrder
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 *
 * @apiSuccessExample Success-Response:
 *   HTTP/1.1 200 OK
 *  [
    {
        "_id": "FinalOfferSent",
        "total": 1
    },
    {
        "_id": "AddInstallationPlan",
        "total": 23
    },
    {
        "_id": "Closed",
        "total": 380
    },
    {
        "_id": "InstallationTimeScheduled",
        "total": 18
    },
    {
        "_id": "InstallationReportVerified",
        "total": 34
    },
    {
        "_id": "InstallationReportReady",
        "total": 67
    },
    {
        "_id": "InstallationPlanCreated",
        "total": 69
    },
    {
        "_id": "Cancelled",
        "total": 0
    },
    {
        "_id": "InstallationPlanVerified",
        "total": 31
    },
    {
        "_id": "OfferRequestReceived",
        "total": 0
    },
    {
        "_id": "PreliminaryOfferApproved",
        "total": 225
    },
    {
        "_id": "InstallationApproved",
        "total": 61
    },
    {
        "_id": "AssessmentSiteVisitScheduled",
        "total": 17
    },
    {
        "_id": "PreliminaryOfferSent",
        "total": 0
    }
]
 * 
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Summary not found"
 *     }
 *  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
 */



 /**
 * @api {get} /Notes/:_id GetWorkOrderNotes
 * @apiVersion 1.0.0
 * @apiName GetWorkOrderNotes
 * @apiGroup SODA.WorkOrder
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * @apiParam {String} _id Id of the order in mongodb
 *
 * @apiSuccessExample Success-Response:
 *   HTTP/1.1 200 OK
 *  {
    "_id": "59ba355fc738300012b3346e",
    "customerNote": "",
    "country": "FI",
    "customerServiceNotes": [],
    "installerNotes": [],
    "notesToInstaller": []
}
  @apiSuccess {Object} Data This is array of Objects
  @apiSuccess {String} Data._id This is id of the Item
  @apiSuccess {String} Data.customerNote This is the customerNote
  @apiSuccess {Object[]} Data.installerNotes Enter the installerNotes details
  @apiSuccess {String} Data.installerNotes.note Enter the installerNotes note
  @apiSuccess {String} Data.installerNotes.createdOn Enter the installerNotes createdOn
  @apiSuccess {Object[]} Data.notesToInstaller Enter the notesToInstaller details
  @apiSuccess {String} Data.notesToInstaller.note Enter the notesToInstaller note
  @apiSuccess {String} Data.notesToInstaller.createdOn Enter the notesToInstaller createdOn
  @apiSuccess {Object[]} Data.customerServiceNotes Enter the customerServiceNotes details
  @apiSuccess {String} Data.customerServiceNotes.note Enter the customerServiceNotes note
  @apiSuccess {String} Data.customerServiceNotes.createdOn Enter the customerServiceNotes createdOn
  @apiSuccess {String}   Request.country   Choosen country

 * 
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": Notes not found"
 *     }
 *  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
 */



 /**
 * @api {get} /reporting WorkOrderReporting
 * @apiVersion 1.0.0
 * @apiName WorkOrderReporting
 * @apiGroup SODA.WorkOrder
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * @apiParam {String} _id Id of the order in mongodb
 *
 * @apiSuccessExample Success-Response:
 *   HTTP/1.1 200 OK
 *  [
    {
        "_id": "59ba355fc738300012b3346e",
        "workOrderNumber": 10905,
        "deliverySite": {
            "street": "RIILAH2",
            "city": "ESPOO",
            "zip": "02260"
        },
        "contactInformation": {
            "name": "TEST71"
        },
        "country": "FI",
        "modifiedOn": "2017-09-14T07:53:03.825Z",
        "createdOn": "2017-09-14T07:53:03.825Z",
        "status": "OfferRequestReceived",
        "customerId": ""
    }
  @apiSuccess {Object} Data This is array of Objects
  @apiSuccess {String} Data._id This is id of the Item
  @apiSuccess {String} Data.workOrderNumber This is the workOrderNumber
  @apiSuccess {Object} Data.deliverySite deliverySite details
  @apiSuccess {String} Data.deliverySite.zip zip
  @apiSuccess {String} Data.deliverySite.city city
  @apiSuccess {String} Data.deliverySite.street street
  @apiSuccess {Object} Data.contactInformation contactInformation details
  @apiSuccess {String} Data.contactInformation.name contactInformation
* @apiSuccess {String} Data.country   Choosen country
* @apiSuccess {String} Data.modifiedon   Modified date
* @apiSuccess {String} Data.createdon   Created date
* @apiSuccess {String} Data.status   status
* @apiSuccess {String} Data.app   App name
* @apiSuccess {String} Data.customerId   customerId

 * 
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": Reporting not found"
 *     }
 *  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
 */