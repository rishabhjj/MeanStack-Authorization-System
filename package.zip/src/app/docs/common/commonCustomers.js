/* eslint-disable */
/**
 * @api {get} /Customers?ssn="ssnnumber" GetCustomerID
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName GetCustomerID
 * @apiGroup Common.Customer
 * 
 * @apiParam {String} ssn SSn number of the customer
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
 { 'customerId': '' }
 *
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 DB-error
 *     {
 *       "error": "Item not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 422 Error
 *     {
 *       
 *     }
 */


 /**
 * @api {put} /Customers?id="customerid" UpdateCustomerID
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName UpdateCustomerID
 * @apiGroup Common.Customer
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 
@apiParam {String} id customerid
@apiParam {Object} Data Response Data
@apiParam {String} Data.contractId contractId
@apiParam {String} Data.OrderReceived OrderReceived

 * 
 * @apiParamExample {json} Request-Example:
 * {
  "contractId":"nissanleaf",
  "OrderReceived":"1990",
}


 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 204 OK
 *  
{  }

 *
 *
 *
 * @apiErrorExample Error-Response:
*     HTTP/1.1 400 Not Found
*     {
*       "error": "not found"
*     } * @apiErrorExample Error-Response:
*     HTTP/1.1 400 Not Found
*     {
*       "error": " not found"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 403 Invalid Role
*    { "info": "Invalid role" }
 */

