/* eslint-disable */
/**
 * @api {get} /Items GetItems
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName GetItems
 * @apiGroup Common.Items
 * 
 * @apiParam {String} ssn SSn number of the customer
 * 
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"VODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 200 OK
 *  
[
    {
        "_id": "5a311fefeb59dc00254722d5",
        "modifiedOn": "2017-12-13T12:41:19.416Z",
        "app": "HODA",
        "country": "FI",
        "itemServiceNumber": "03-01-01-001",
        "description": {
            "en_GB": "Charge Amps HALO Wall box, power 3,7 kW type1",
            "fi_FI": "Charge Amps HALO Wall box, power 3,7 kW type1"
        },
        "itemType": "Item",
        "status": "Active",
        "createdOn": "2017-12-13T12:41:19.416Z",
        "isAssetNumber": true
    }
]
 *
 * @apiSuccess {Object[]} Data Response data
 * @apiSuccess{String} Data._id Mongodb ID
 * @apiSuccess {String} Data.modifiedOn modifiedOn data
 * @apiSuccess {String} Data.app app
 * @apiSuccess {String} Data.country country
 * @apiSuccess {String} Data.itemServiceNumber itemServiceNumber
 * @apiSuccess {String} Data.itemType itemType
 * @apiSuccess {String} Data.status status
 * @apiSuccess {String} Data.createdOn createdOn
 * @apiSuccess {Boolean} Data.isAssetNumber isAssetNumber
 * @apiSuccess {Object} Data.description description
 * @apiSuccess {String} Data.description.en_GB description en_GB
 * @apiSuccess {String} Data.description.fi_FI description fi_FI
 * 
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Counrty /APP 
 *     {
 *       "error": "Country or App not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "Service not found"
 *     }
 * @apiErrorExample Error-Response:
 *     HTTP/1.1 417 DB-error
 *     {
 *       "error": "Item not found"
 *     }
 */


 /**
 * @api {post} /Items CreateItems
 * @apiHeader {String} Accept Data Accept type (ex:application/json)
 * @apiHeader {String} App App name(ex:SODA, VODA, HODA)
 * @apiHeader {String} Authorization App name(ex:Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1)
 * @apiHeader {String} Content-Type ex:application/json
 * @apiHeader {String} Country ex:FI
 * @apiHeader {String} X-Request-Id ex:7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA
 * 
 * @apiVersion 1.0.0
 * @apiName CreateItems
 * @apiGroup Common.Items
 * @apiHeaderExample {json} Header-Example:
 *     {
         Accept:"application/json",
         App:"SODA",
         Authorization:"Bearer 53c0352d-0fd7-3d80-a5a6-b6ed32c929c1",
         Content-Type:"application/json",
         Country:"FI",
         X-Request-Id:"7ACBF30E-5B02-4A6D-9793-EE3D1A2E54BA"
 *     }
 * 
 * 
@apiParam {Object[]} Data Response data
 * @apiParam {String} Data.itemServiceNumber itemServiceNumber
 * @apiParam {String} Data.itemType itemType
 * @apiParam {String} Data.status status
 * @apiParam {Boolean} Data.isAssetNumber isAssetNumber
 * @apiParam {Object} Data.description description
 * @apiParam {String} Data.description.en_GB description en_GB
 * @apiParam {String} Data.description.fi_FI description fi_FI

 * 
 * @apiParamExample {json} Request-Example:
 * {
        "itemServiceNumber": "03-01-01-001",
        "description": {
            "en_GB": "Charge Amps HALO Wall box, power 3,7 kW type1",
            "fi_FI": "Charge Amps HALO Wall box, power 3,7 kW type1"
        },
        "itemType": "Item",
        "status": "Active",
        "isAssetNumber": true
}
@apiSuccess {Object} Data Response data
 * @apiSuccess{String} Data._id Mongodb ID
 * @apiSuccess {String} Data.modifiedOn modifiedOn data
 * @apiSuccess {String} Data.app app
 * @apiSuccess {String} Data.country country
 * @apiSuccess {String} Data.itemServiceNumber itemServiceNumber
 * @apiSuccess {String} Data.itemType itemType
 * @apiSuccess {String} Data.status status
 * @apiSuccess {String} Data.createdOn createdOn
 * @apiSuccess {Boolean} Data.isAssetNumber isAssetNumber
 * @apiSuccess {Object} Data.description description
 * @apiSuccess {String} Data.description.en_GB description en_GB
 * @apiSuccess {String} Data.description.fi_FI description fi_FI

 * 
 * 
 * @apiSuccessExample Success-Response:
 *  HTTP/1.1 204 OK
 *  
{
        "_id": "5a311fefeb59dc00254722d5",
        "modifiedOn": "2017-12-13T12:41:19.416Z",
        "app": "HODA",
        "country": "FI",
        "itemServiceNumber": "03-01-01-001",
        "description": {
            "en_GB": "Charge Amps HALO Wall box, power 3,7 kW type1",
            "fi_FI": "Charge Amps HALO Wall box, power 3,7 kW type1"
        },
        "itemType": "Item",
        "status": "Active",
        "createdOn": "2017-12-13T12:41:19.416Z",
        "isAssetNumber": true
    }

 *
 *
 *
 * @apiErrorExample Error-Response:
*     HTTP/1.1 400 Not Found
*     {
*       "error": "not found"
*     } * @apiErrorExample Error-Response:
*     HTTP/1.1 400 Not Found
*     {
*       "error": " not found"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 417 MongoDB Error
*     {
*       "error": "MongoDB Error"
*     }
*  @apiErrorExample Error-Response:
*     HTTP/1.1 403 Invalid Role
*    { "info": "Invalid role" }
 */

