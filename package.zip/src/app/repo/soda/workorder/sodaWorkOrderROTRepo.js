let CryptoJS = require('crypto-js')
let archival = require('../../../helpers/archival/archive')

export const saveWorkOrderROT = (ROT, req, res) => {
  req.archival.request.resourceName = 'Workorder_ROT_' + req.method
  if (req.country !== 'SE' || req.app !== 'SODA') {
    archival.log(req.archival, {}, 403, req.env, req.processName, req.receivedTime, req.requestId)
    res.status(403).send()
  } else {
    req.queryForMongoose = {}
    req.queryForMongoose.workOrderServiceKey = req.params.id

    ROT.find(req.queryForMongoose, '-__v', function (err, data) {
      if (err) {
        let message = { 'error': 'Error occured...' }
        archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
        res.status(417).send(message)
      } else
      if (data.length > 0) {
        let info = { 'info': 'ROT already available for Work Order Service Key: ' + req.params.id }
        archival.log(req.archival, info, 417, req.env, req.processName, req.receivedTime, req.requestId)
        res.status(417).send(info)
      } else {
        req.body.workOrderServiceKey = req.params.id
        var rot = new ROT(req.body)
        if ((req.body.allocation !== undefined) && (req.body.allocation.length > 3)) {
          res.status(417).send('Only 3 persons information alone allowed...')
        } else {
          if ((rot.allocation !== undefined) && (rot.allocation.length > 0)) {
            for (let i = 0; i < rot.allocation.length; i++) {
              var secretPhrase = 'aa31g-3f61f53-j135-4dbb-b2e8-e8bf88ffde3f'
              rot.allocation[i].ssn = CryptoJS.AES.encrypt(rot.allocation[i].ssn, secretPhrase)
            }

            rot.save(function (err) {
              if (err) {
                archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
                res.status(417).send(err)
              } else {
                archival.log(req.archival, rot, 201, req.env, req.processName, req.receivedTime, req.requestId)
                res.status(201).send(rot)
              }
            })
          } else {
            rot.rot = false
            rot.save(function (err) {
              if (err) {
                archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
                res.status(417).send(err)
              } else {
                archival.log(req.archival, rot, 201, req.env, req.processName, req.receivedTime, req.requestId)
                res.status(201).send(rot)
              }
            })
          }
        }
      }
    })
  }
}

export const getWorkOrdersROT = (ROT, req, res) => {
  req.archival.request.resourceName = 'Workorder_ROT_' + req.method
  if (req.country !== 'SE' || req.app !== 'SODA') {
    res.status(403).send()
  } else {
    req.queryForMongoose = {}
    req.queryForMongoose.workOrderServiceKey = req.params.id

    ROT.find(req.queryForMongoose, '-__v', function (err, data) {
      if (err) {
        archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
        res.status(417).send({ 'error': 'Error occured...' })
      } else {
        if (data != null && data.length > 0) {
          if ((data[0].allocation !== undefined) && (data[0].allocation.length > 0)) {
            for (let i = 0; i < data[0].allocation.length; i++) {
              var secretPhrase = 'aa31g-3f61f53-j135-4dbb-b2e8-e8bf88ffde3f'
              let decryptedData = CryptoJS.AES.decrypt(data[0].allocation[i].ssn, secretPhrase)
              data[0].allocation[i].ssn = decryptedData.toString(CryptoJS.enc.Utf8)
            }
          }
          archival.log(req.archival, data, 200, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(200).send(data)
        } else {
          let empty = []
          archival.log(req.archival, empty, 200, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(200).send(empty)
        }
      }
    })
  }
}
export const deleteWorkOrderROT = (ROT, Audit, req, res) => {
  req.archival.request.resourceName = 'Workorder_ROT_' + req.method
  if (req.country !== 'SE' || req.app !== 'SODA' || req.role !== 'CUSTOMERSERVICE') {
    res.status(403).send()
  } else {
    req.queryForMongoose = {}
    req.queryForMongoose._id = req.params.id

    ROT.findOneAndRemove(req.queryForMongoose, '-__v', function (err, data) {
      if (err) {
        archival.log(req.archival, err, 204, req.env, req.processName, req.receivedTime, req.requestId)
        res.status(417).send({ 'error': 'Error occured...' })
      } else {
        archival.log(req.archival, { 'info': 'Removed' }, 204, req.env, req.processName, req.receivedTime, req.requestId)
        res.status(204).send({ 'info': 'Removed' })
      }
    })
  }
}

export const updateWorkOrderROT = (ROT, Audit, req, res) => {
  req.archival.request.resourceName = 'Workorder_ROT_' + req.method
  // Check the role & token
  if (req.country !== 'SE' || req.app !== 'SODA') {
    res.status(403).send({ 'error': 'Country or App is not allowed for ROT' })
  } else {
    if (req.role === 'CUSTOMERSERVICE') {
      var patches = req.body
      patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })

      var id = req.params.id
      ROT.findById(id, '-__v', function (err, rotDoc) {
        if (err) {
          if (err.name === 'CastError' && err.path === '_id') {
            res.status(404).send({ 'error': 'Not found' })
          } else {
            res.status(417).send({ 'error': 'Error occured...' })
          }
        } else {
          if (rotDoc == null) {
            res.status(404).send()
          } else {
            for (var i = 0, len = patches.length; i < len; i++) {
              var element = patches[i].path
              let isAllocationUpdate = element.search(new RegExp('allocation', 'i'))
              if (isAllocationUpdate === 1) {
                var secretPhrase = 'aa31g-3f61f53-j135-4dbb-b2e8-e8bf88ffde3f'
                let evalue = CryptoJS.AES.encrypt(patches[i].value.ssn, secretPhrase)
                patches[i].value.ssn = evalue.toString()
              }
            }

            rotDoc.patch(patches, function (err) {
              if (err) { res.status(417).send(err) } else {
                // Logging into Audit
                var data = new Audit()
                data.docName = 'ROT'
                data.docId = rotDoc._id
                data.userId = ''
                data.info = patches
                var audit = new Audit(data)
                audit.save()
                // End of Audit logging

                res.status(200).send()
              }
            })
          }
        }
      })
    } else {
      res.status(401).send({ 'error': 'Not allowed' })
    }
  }
}
