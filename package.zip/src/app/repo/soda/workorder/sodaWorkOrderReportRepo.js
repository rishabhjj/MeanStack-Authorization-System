let logger = require('../../../helpers/logger/log')
let moment = require('moment')

export const getWorkOrderReports = (VWorkorder, req, res) => {
  try {
    let query = {}
    let start = new Date()
    let end = new Date()
    if (req.query.startDate !== undefined) { start = new Date(req.query.startDate) }
    if (req.query.endDate !== undefined) { end = moment(new Date(req.query.endDate)).add(1, 'days').format() }
    if (req.query.startDate || req.query.endDate) {
      query.modifiedOn = { '$gte': start, '$lte': end }
    }
    query.country = req.country
    query.app = req.app

    VWorkorder.find(query, {
      _id: 1,
      'workOrderNumber': 1,
      'externalMarketingPartner': 1,
      'customerId': 1,
      'contactInformation.name': 1,
      'deliverySite.street': 1,
      'deliverySite.city': 1,
      'deliverySite.zip': 1,
      'status': 1,
      'createdOn': 1,
      'modifiedOn': 1,
      'country': 1
    }, '-__v', function (err, wo) {
      if (err) {
        res.status(417).send(err)
      } else {
        res.json(wo)
      }
    })
  } catch (err) {
    logger.error(req, res, err, 'SODA-WORKORDER-REPORT-GET')
  }
}
