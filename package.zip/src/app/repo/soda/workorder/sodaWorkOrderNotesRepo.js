let archival = require('../../../helpers/archival/archive')

export const getWorkOrderNotes = (Workorder, req, res) => {
  var id = req.params.id
  Workorder.findById(id, { _id: 1, country: 1, customerNote: 1, installerNotes: 1, notesToInstaller: 1, customerServiceNotes: 1 }, '-__v', function (err, wo) {
    if (err) {
      if (err.name === 'CastError' && err.path === '_id') {
        res.status(404).send()
      } else {
        res.status(417).send(err)
      }
    } else {
      if (req.country !== wo.country) {
        archival.log(req.archival, { 'error': 'Country is not matching' }, 403, req.env, req.processName, req.receivedTime, req.requestId)
        res.status(403).send({ 'error': 'Country is not matching' })
      } else {
        archival.log(req.archival, wo, 200, req.env, req.processName, req.receivedTime, req.requestId)
        res.json(wo)
      }
    }
  })
}
