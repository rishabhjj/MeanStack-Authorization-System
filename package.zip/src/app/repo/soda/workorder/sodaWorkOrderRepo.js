import { sodaAgeingPatch } from '../ageing/sodaAgeing'

let archival = require('./../../../helpers/archival/archive')
let customerServiceMailer = require('../../../../Routes/Messaging/SODA/CustomerService/sendCustomerServiceMail')
let customerMailer = require('../../../../Routes/Messaging/SODA/Customer/sendCustomerMail')
let requestReceived = require('../../../../Routes/Messaging/SODA/CustomerService/requestReceived')
let mail = require('../../../../Routes/Messaging/SODA/sendMail')
// let reporting = require('../../../../../route/soda/workorder/soda-workorder-report-get')

export const setQuery = (req, res, next) => {
  const query = {}
  if (req.query.accountId) { query.accountId = req.query.accountId }
  if (req.query._id) { query._id = req.query._id }
  if (req.query.customerId) { query.customerId = req.query.customerId }
  if (req.query.installerId) { query.installerId = req.query.installerId }
  if (req.query.status) { query.status = req.query.status }
  if (req.query.workOrderNumber) { query.workOrderNumber = req.query.workOrderNumber }
  query.country = req.country
  query.app = req.app
  req.queryForMongoose = query
  next()
}

export const updateWorkOrder = (Workorder, Audit, SODAAgeing, ROT, req, res) => {
  var patches = req.body
  patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })
  var id = req.params.id
  Workorder.findById(id, '-__v', function (err, wo) {
    if (err) {
      if (err.name === 'CastError' && err.path === '_id') {
        res.status(404).send()
      } else {
        res.status(417).send(err)
      }
    } else {
      if (wo == null) {
        res.status(404).send()
      } else {
        let existingStatus = wo.status
        let isInstallationPlanInitalized = false
        if (wo.installationPlanChangeLog !== undefined && wo.installationPlanChangeLog.initialized !== undefined) {
          isInstallationPlanInitalized = true
        }

        let isInstallationReportInitalized = false
        if (wo.installationReportChangeLog !== undefined && wo.installationReportChangeLog.initialized !== undefined) {
          isInstallationReportInitalized = true
        }

        var result = -1
        var targetStatus = 'NONE'
        var isStatusUpdate = -1

        if (req.noCountryAppValidation !== true) {
          // Check whether user country & wo country matches
          if (req.country !== wo.country || req.app !== wo.app) {
            res.status(403).send({ 'error': 'Country or App is not matching' })
          }
        }

        req.user = req.user !== undefined ? req.user : ''

        for (var i = 0, len = patches.length; i < len; i++) {
          var element = patches[i].path
          isStatusUpdate = element.search(new RegExp('status', 'i'))
          if (isStatusUpdate === 1) {
            targetStatus = patches[i].value

            if (targetStatus === 'InstallationPlanCreated' && isInstallationPlanInitalized === false) {
              patches.push({
                'op': 'add',
                'path': '/installationPlanChangeLog',
                'value': {
                  'createdBy': req.user,
                  'createdOn': new Date(),
                  'status': 1,
                  'initialized': true
                }
              })
            } else if (targetStatus === 'InstallationPlanCreated') {
              patches.push({
                'op': 'add', 'path': '/installationPlanChangeLog/status', 'value': 1
              })
              patches.push({
                'op': 'add', 'path': '/installationPlanChangeLog/modifiedBy', 'value': req.user
              })
              patches.push({
                'op': 'add', 'path': '/installationPlanChangeLog/modifiedOn', 'value': new Date()
              })
            } else if (targetStatus === 'InstallationPlanVerified') {
              patches.push({
                'op': 'add', 'path': '/installationPlanChangeLog/status', 'value': 0
              })
              patches.push({
                'op': 'add', 'path': '/installationPlanChangeLog/modifiedBy', 'value': req.user
              })
              patches.push({
                'op': 'add', 'path': '/installationPlanChangeLog/modifiedOn', 'value': new Date()
              })
              patches.push({
                'op': 'add', 'path': '/installationPlanChangeLog/verifiedBy', 'value': req.user
              })
              patches.push({
                'op': 'add', 'path': '/installationPlanChangeLog/verifiedOn', 'value': new Date()
              })
            } else if (targetStatus === 'InstallationReportReady' && isInstallationReportInitalized === false) {
              patches.push({
                'op': 'add',
                'path': '/installationReportChangeLog',
                'value': {
                  'createdBy': req.user,
                  'createdOn': new Date(),
                  'status': 1,
                  'initialized': true
                }
              })
            } else if (targetStatus === 'InstallationReportReady') {
              patches.push({
                'op': 'add', 'path': '/installationReportChangeLog/status', 'value': 1
              })
              patches.push({
                'op': 'add', 'path': '/installationReportChangeLog/modifiedBy', 'value': req.user
              })
              patches.push({
                'op': 'add', 'path': '/installationReportChangeLog/modifiedOn', 'value': new Date()
              })
            } else if (targetStatus === 'InstallationReportVerified') {
              patches.push({
                'op': 'add', 'path': '/installationReportChangeLog/status', 'value': 0
              })
              patches.push({
                'op': 'add', 'path': '/installationReportChangeLog/modifiedBy', 'value': req.user
              })
              patches.push({
                'op': 'add', 'path': '/installationReportChangeLog/modifiedOn', 'value': new Date()
              })
              patches.push({
                'op': 'add', 'path': '/installationReportChangeLog/verifiedBy', 'value': req.user
              })
              patches.push({
                'op': 'add', 'path': '/installationReportChangeLog/verifiedOn', 'value': new Date()
              })
            }
          }
        }

        // Is Home Visit or Installation visit Cancelled?
        for (var j = 0, le = patches.length; j < le; j++) {
          element = patches[j].path
          let isScheduledPlanningOrInstallationVisitTimeCancelled = element.search(new RegExp('isScheduledTimeCancelled', 'i'))
          if (isScheduledPlanningOrInstallationVisitTimeCancelled === 1) {
            req.isScheduledTimeCancelled = true
          }
        }

        if (result === -1) {
          wo.patch(patches, function (err, doc) {
            if (err) { res.status(417).send(err) } else {
              // Sending mails
              let isScheduleCancellation = req.isScheduledTimeCancelled
              mail.send(doc, req.country, targetStatus, existingStatus, isScheduleCancellation, ROT)

              // Logging into Audit
              var data = new Audit()
              data.docName = 'WorkOrder'
              data.docId = wo._id
              data.userId = ''
              data.info = patches
              var audit = new Audit(data)
              audit.save()
              // End of Audit logging
              if (targetStatus !== 'NONE' && (targetStatus !== existingStatus)) {
                let emp = wo.externalMarketingPartner !== undefined ? wo.externalMarketingPartner.code : ''
                sodaAgeingPatch(SODAAgeing, wo.status, wo.workOrderNumber, wo.contactInformation.name, wo.country, wo.createdOn, emp, wo._id, req, res)
              }
              res.status(202).send(doc)
            }
          })
        }
      }
    }
  })
}

export const saveWorkOrder = (Workorder, SODAAgeing, ROT, SAddressLead, req, res) => {
  var data = {}
  data.accountId = req.body.accountId
  data.customerNote = req.body.customerNote
  data.deliverySite = req.body.deliverySite
  data.contactInformation = req.body.contactInformation
  data.benefitCalculations = req.body.benefitCalculations
  data.externalMarketingPartner = req.body.externalMarketingPartner
  data.gridInfo = req.body.gridInfo
  data.basePrice = req.body.basePrice
  data.extraDesignatedWorkAndMaterial = req.body.extraDesignatedWorkAndMaterial
  data.status = req.body.status
  data.country = req.country
  data.app = req.app
  data.createdOn = new Date()
  data.modifiedOn = new Date()
  if (req.body.interestedInVPP !== undefined) {
    data.interestedInVPP = req.body.interestedInVPP
  }

  data.contactInformation.name = (data.contactInformation.name).toUpperCase()
  data.deliverySite.street = (data.deliverySite.street).toUpperCase()
  if (data.deliverySite.city !== undefined && data.deliverySite.city !== null) {
    data.deliverySite.city = (data.deliverySite.city).toUpperCase()
  }

  var wo = new Workorder(data)
  wo.save(function (err) {
    if (err) {
      res.status(417).send(err)
    } else {
 //     let mailData = { 'name': data.contactInformation.name, 'email': data.contactInformation.email, 'serviceKey': data._id, 'status': data.status }
      let customer = process.env.SODA_SEND_MAIL_TO_CUSTOMER || 'TRUE'
      //    let installer = process.env.SODA_SEND_MAIL_TO_INSTALLER_COMPANY || 'TRUE'
      let cs = process.env.SODA_SEND_MAIL_TO_CUSTOMER_SERVICE_TEAM || 'TRUE'

      /// /// Get WOM ID for newly created WO
      let query = {}
      query._id = wo._id
      let woe = ''
      Workorder.find(query, '-__v', function (err, workorderResponse) {
        let mailData = { 'name': workorderResponse[0].contactInformation.name, 'email': workorderResponse[0].contactInformation.email, 'serviceKey': workorderResponse[0]._id, 'status': workorderResponse[0].status }
        let woData = data
        if (err) {

        } else {
          if (workorderResponse) {
            woe = workorderResponse[0].workOrderNumber
            woData = workorderResponse[0]
          }
          if (cs.toUpperCase() === 'TRUE') {
            if (req.country === 'FI' || req.country === 'SE') {
              //        requestReceived.post(data, woe, req.country)
              requestReceived.post(woData, woe, req.country)
            } else {
              let customerServiceMailerData = { 'name': data.contactInformation.name, 'woe': 'WOE: - ' + woe, 'serviceKey': woData._id, 'status': data.status }
              customerServiceMailer.post(customerServiceMailerData, req.country)
            }
          }
          if (customer.toUpperCase() === 'TRUE') {
            customerMailer.post(mailData, req.country)
          }
        }
      })

      var ageingData = {}
      ageingData.name = wo.contactInformation.name
      ageingData.workOrderServiceKey = wo._id
      ageingData.workOrderNumber = wo.workOrderNumber
      if (wo.externalMarketingPartner !== undefined) { ageingData.emp = wo.externalMarketingPartner.code };
      ageingData.offerRequestReceived = wo.createdOn
      ageingData.currentStatus = 'OfferRequestReceived'
      ageingData.country = wo.country
      ageingData.modifiedOn = wo.createdOn

      var ageing = new SODAAgeing(ageingData)
      ageing.save()

      // Remove Address from Lead once WO is created
      let addressLeadQuery = {}
      addressLeadQuery.street = wo.deliverySite.street
      addressLeadQuery.city = wo.deliverySite.city
      addressLeadQuery.zip = wo.deliverySite.zip

      SAddressLead.remove(addressLeadQuery, function (err, data) {
        if (err) {
          console.log(err)
        }
      })

      archival.log(req.archival, wo, 201, req.env, req.processName, req.receivedTime, req.requestId)
      res.status(201).send(wo)
    }
  })
}

export const getWorkOrders = (Workorder, req, res) => {
  if (req.queryForMongoose._id === undefined && req.headers.token === undefined) {
    res.status(401).send({ 'error': 'WO ID is missing' })
  } else if (req.queryForMongoose._id === undefined && req.headers.token !== undefined && req.headers.token !== 'A88D982A-FC81-4EA9-BEB3-189AA0808B78') {
    res.status(403).send({ 'error': 'Invalid Token' })
  } else {
    Workorder.find(req.queryForMongoose, '-__v', function (err, logs) {
      if (err) {
        if (err.name === 'CastError' && err.path === '_id') {
          let response = []
          archival.log(req.archival, response, 200, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(200).send(response)
        } else {
          archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(417).send(err)
        }
      } else {
        archival.log(req.archival, logs, 200, req.env, req.processName, req.receivedTime, req.requestId)
        res.json(logs)
      }
    })
  }
}

export const deleteWorkOrder = () => {
  if (req.headers.token !== undefined && req.headers.token === 'A88D982A-FC81-4EA9-BEB3-189AA0808B78') {
    Workorder.remove(req.queryForMongoose, function (err, logs) {
      if (err) {
        archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
        res.status(417).send(err)
      } else {
        archival.log(req.archival, { 'info': 'Removed' }, 204, req.env, req.processName, req.receivedTime, req.requestId)
        res.status(204).send({ 'info': 'Removed' })
      }
    })
  } else {
    archival.log(req.archival, { 'error': 'Not allowed' }, 401, req.env, req.processName, req.receivedTime, req.requestId)
    res.status(401).send({ 'error': 'Not allowed' })
  }
}
