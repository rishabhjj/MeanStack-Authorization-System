let mongoose = require('mongoose')
let archival = require('../../../helpers/archival/archive')

export const searchWorkOrder = (Workorder, req, res) => {
  req.archival.request.resourceName = 'Workorder_Search_' + req.method
  if (req.role === 'CUSTOMERSERVICE' || req.role === 'INSTALLER') {
    if (req.query.searchText || req.query.latest) {
      var name = req.query.searchText
      if (name === undefined || name == null) {
        name = ''
      }
      var limit = req.query.limit
      var limitSize = 25
      var skip = req.query.skip
      var skipSize = 0
      if (limit !== undefined || limit != null) {
        limitSize = parseInt(limit)
      }

      if (skipSize !== undefined || skipSize != null) {
        skipSize = parseInt(skip)
      }

      var totalRecords = 0
      var isValidObjectId = mongoose.Types.ObjectId.isValid(name)
      var oid = 'zzzzzzzzzzzz'
      if (isValidObjectId) {
        oid = req.query.searchText
      }

      var wom = req.query.searchText
      if (wom !== undefined) {
        wom = wom.toUpperCase()
      }

      if (wom !== undefined && wom.includes('WOE')) {
        wom = wom.replace('WOE', '')
        var womQuery = {}
        womQuery.country = req.header('country')
        womQuery.app = req.header('app')
        womQuery.workOrderNumber = wom

        Workorder.find(womQuery, { _id: 1, 'country': 1, 'app': 1, 'contactInformation.name': 1, 'workOrderNumber': 1, 'customerId': 1, 'status': 1, 'lockedBy': 1, 'deliverySite.street': 1, 'deliverySite.city': 1, 'deliverySite.zip': 1, 'modifiedOn': 1 }, '-__v', function (err, logs) {
          if (err) {
            archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
            res.status(417).send(err)
          } else {
            if (req.role === 'INSTALLER') {
              if (logs.length > 0) {
                if (logs[0].status.toLowerCase() === 'offerrequestreceived' ||
                                    logs[0].status.toLowerCase() === 'preliminaryoffersent' ||
                                    logs[0].status.toLowerCase() === 'finaloffersent' ||
                                    logs[0].status.toLowerCase() === 'installationapproved' ||
                                    logs[0].status.toLowerCase() === 'closed' ||
                                    logs[0].status.toLowerCase() === 'cancelled') { // Cancelled
                  let data = []
                  res.append('totalRecords', 0)
                  archival.log(req.archival, data, 200, req.env, req.processName, req.receivedTime, req.requestId)
                  res.json(data)
                } else {
                  res.append('totalRecords', logs.length)
                  archival.log(req.archival, logs, 200, req.env, req.processName, req.receivedTime, req.requestId)
                  res.json(logs)
                }
              } else {
                res.append('totalRecords', logs.length)
                archival.log(req.archival, logs, 200, req.env, req.processName, req.receivedTime, req.requestId)
                res.json(logs)
              }
            } else {
              res.append('totalRecords', logs.length)
              archival.log(req.archival, logs, 200, req.env, req.processName, req.receivedTime, req.requestId)
              res.json(logs)
            }
          }
        })
      } else {
        if ((req.query.searchText !== undefined) && (req.role === 'INSTALLER')) { // Installer role user should not receive WO with these statuses
          if (req.query.searchText.toLowerCase() === 'offerrequestreceived' || req.query.searchText.toLowerCase() === 'preliminaryoffersent' ||
                        req.query.searchText.toLowerCase() === 'finaloffersent' || req.query.searchText.toLowerCase() === 'cancelled' ||
                        req.query.searchText.toLowerCase() === 'installationapproved' || req.query.searchText.toLowerCase() === 'closed') {
            name = 'aaaa-bbbb-ccc-zz--xx-yy'
          }
        }

        var str1 = '.*'
        var str2 = str1.concat(name)
        var str3 = str2.concat('.*')

        if ((req.query.latest !== undefined) && (req.role === 'INSTALLER')) {
          Workorder.count({
            $and: [{ 'country': req.country, 'app': req.app }, { 'status': { $not: { $eq: 'OfferRequestReceived' } } }, { 'status': { $not: { $eq: 'PreliminaryOfferSent' } } }, { 'status': { $not: { $eq: 'FinalOfferSent' } } }, { 'status': { $not: { $eq: 'InstallationApproved' } } }, { 'status': { $not: { $eq: 'Closed' } } }, { 'status': { $not: { $eq: 'Cancelled' } } }]
          }, function (err, count) {
            if (err) {
              console.log(err)
            } else {
              totalRecords = count
              Workorder.find({
                $and: [{ 'country': req.country, 'app': req.app }, { 'status': { $not: { $eq: 'OfferRequestReceived' } } }, { 'status': { $not: { $eq: 'PreliminaryOfferSent' } } }, { 'status': { $not: { $eq: 'FinalOfferSent' } } }, { 'status': { $not: { $eq: 'InstallationApproved' } } }, { 'status': { $not: { $eq: 'Closed' } } }, { 'status': { $not: { $eq: 'Cancelled' } } }]
              },
              { _id: 1, 'country': 1, 'app': 1, 'contactInformation.name': 1, 'workOrderNumber': 1, 'customerId': 1, 'status': 1, 'deliverySite.street': 1, 'deliverySite.city': 1, 'deliverySite.zip': 1, 'modifiedOn': 1 }, function (err, doc) {
                if (err) {
                  archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
                  res.status(417).send(err)
                } else {
                  res.append('totalRecords', totalRecords)
                  archival.log(req.archival, doc, 200, req.env, req.processName, req.receivedTime, req.requestId)
                  res.json(doc)
                }
              }).skip(skipSize).limit(limitSize).sort({ modifiedOn: -1 })
            }
          })
        } else if ((str3 !== undefined) && (req.role === 'INSTALLER')) {
          Workorder.count({
            $and: [{ 'country': req.country, 'app': req.app }, { 'status': { $not: { $eq: 'OfferRequestReceived' } } }, { 'status': { $not: { $eq: 'PreliminaryOfferSent' } } }, { 'status': { $not: { $eq: 'FinalOfferSent' } } }, { 'status': { $not: { $eq: 'InstallationApproved' } } }, { 'status': { $not: { $eq: 'closed' } } }, { 'status': { $not: { $eq: 'Cancelled' } } }, {
              $or: [
                { 'contactInformation.name': { $regex: str3.toUpperCase() } },
                { 'contactInformation.ssnOrBusinessId': { $regex: str3 } },
                { 'deliverySite.street': { $regex: str3.toUpperCase() } },
                { 'deliverySite.city': { $regex: str3.toUpperCase() } },
                { 'deliverySite.zip': { $regex: str3 } },
                { 'status': { $regex: str3 } },
                { 'customerId': { $regex: str3 } },
                { '_id': oid }
              ]
            }]
          }, function (err, count) {
            if (err) {
              console.log(err)
            } else {
              totalRecords = count
              Workorder.find({
                $and: [{ 'country': req.country, 'app': req.app }, { 'status': { $not: { $eq: 'OfferRequestReceived' } } }, { 'status': { $not: { $eq: 'PreliminaryOfferSent' } } }, { 'status': { $not: { $eq: 'FinalOfferSent' } } }, { 'status': { $not: { $eq: 'InstallationApproved' } } }, { 'status': { $not: { $eq: 'Closed' } } }, { 'status': { $not: { $eq: 'Cancelled' } } }, {
                  $or: [
                    { 'contactInformation.name': { $regex: str3.toUpperCase() } },
                    { 'contactInformation.ssnOrBusinessId': { $regex: str3 } },
                    { 'deliverySite.street': { $regex: str3.toUpperCase() } },
                    { 'deliverySite.city': { $regex: str3.toUpperCase() } },
                    { 'deliverySite.zip': { $regex: str3 } },
                    { 'status': { $regex: str3 } },
                    { 'customerId': { $regex: str3 } },
                    { '_id': oid }
                  ]
                }]
              },
              { _id: 1, 'country': 1, 'app': 1, 'contactInformation.name': 1, 'workOrderNumber': 1, 'customerId': 1, 'status': 1, 'deliverySite.street': 1, 'deliverySite.city': 1, 'deliverySite.zip': 1, 'modifiedOn': 1 }, function (err, doc) {
                if (err) {
                  archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
                  res.status(417).send(err)
                } else {
                  res.append('totalRecords', totalRecords)
                  archival.log(req.archival, doc, 200, req.env, req.processName, req.receivedTime, req.requestId)
                  res.json(doc)
                }
              }).skip(skipSize).limit(limitSize).sort({ modifiedOn: -1 })
            }
          })
        } else {
          Workorder.count(
            {
              $and: [
                { 'country': req.country },
                { 'app': req.app },
                {
                  $or: [
                    { 'contactInformation.name': { $regex: str3.toUpperCase() } },
                    { 'contactInformation.ssnOrBusinessId': { $regex: str3 } },
                    { 'deliverySite.street': { $regex: str3.toUpperCase() } },
                    { 'deliverySite.city': { $regex: str3.toUpperCase() } },
                    { 'deliverySite.zip': { $regex: str3 } },
                    { 'lockedBy': { $regex: str3 } },
                    { 'status': { $regex: str3 } },
                    { 'customerId': { $regex: str3 } },
                    { '_id': oid }
                  ]
                }
              ]
            }
            , function (err, count) {
              if (err) {
                console.log(err)
              } else {
                totalRecords = count

                Workorder.find(
                  {
                    $and: [
                      { 'country': req.country },
                      { 'app': req.app },
                      {
                        $or: [
                          { 'contactInformation.name': { $regex: str3.toUpperCase() } },
                          { 'contactInformation.ssnOrBusinessId': { $regex: str3 } },
                          { 'deliverySite.street': { $regex: str3.toUpperCase() } },
                          { 'deliverySite.city': { $regex: str3.toUpperCase() } },
                          { 'deliverySite.zip': { $regex: str3 } },
                          { 'lockedBy': { $regex: str3 } },
                          { 'status': { $regex: str3 } },
                          { 'customerId': { $regex: str3 } },
                          { '_id': oid }
                        ]
                      }
                    ]
                  }
                  ,
                  { _id: 1, 'country': 1, 'app': 1, 'contactInformation.name': 1, 'workOrderNumber': 1, 'customerId': 1, 'status': 1, 'lockedBy': 1, 'deliverySite.street': 1, 'deliverySite.city': 1, 'deliverySite.zip': 1, 'modifiedOn': 1 }, function (err, doc) {
                    if (err) {
                      archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
                      res.status(417).send(err)
                    } else {
                      res.append('totalRecords', totalRecords)
                      archival.log(req.archival, doc, 200, req.env, req.processName, req.receivedTime, req.requestId)
                      res.json(doc)
                    }
                  }).skip(skipSize).limit(limitSize).sort({ modifiedOn: -1 })
              }
            })
        }
      }
    } else {
      let message = { 'error': 'Query String is missing' }
      archival.log(req.archival, message, 417, req.env, req.processName, req.receivedTime, req.requestId)
      res.status(417).send(message)
    }
  } else {
    archival.log(req.archival, {}, 401, req.env, req.processName, req.receivedTime, req.requestId)
    res.status(401).send()
  }
}
