export const setQuery = (req, res, next) => {
  let query = {}
  if (req.query.category) { query.category = req.query.category }
  if (req.query._id) { query._id = req.query._id }
  query.country = req.country
  query.app = req.app
  req.queryForMongoose = query
  next()
}

export const updateProductFeature = (ProductFeature, req, res) => {
  if (req.role === 'BUSINESS') {
    var patches = req.body
    var id = req.params.id
    ProductFeature.findById(id, '-__v', function (err, featureDoc) {
      if (err) {
        if (err.name === 'CastError' && err.path === '_id') {
          res.status(404).send()
        } else {
          res.status(417).send(err)
        }
      } else {
        // Check whether user country & product country matches
        if (req.country !== featureDoc.country || req.app !== featureDoc.app) {
          res.status(403).send({ 'error': 'Country or App is not matching' })
        } else {
          featureDoc.patch(patches, function (err, doc) {
            if (err) { res.status(417).send(err) } else {
              res.status(202).send(doc)
            }
          })
        }
      }
    })
  } else {
    res.status(401).send({ 'error': 'Not allowed' })
  }
}

export const getProductFeatureList = (ProductFeature, req, res) => {
  ProductFeature.find(req.queryForMongoose, '-__v', function (err, data) {
    if (err) { res.status(417).send(err) } else { res.json(data) }
  }).sort({ category: 1 })
}

export const saveProductFeature = (ProductFeature, req, res) => {
  if (req.role === 'BUSINESS') {
    let data = {}
    data = req.body
    data.country = req.country
    data.app = req.app
    const feature = new ProductFeature(data)
    feature.save(function (err) {
      if (err) {
        res.status(417).send(err)
      } else {
        res.status(201).send(feature)
      }
    })
  } else {
    res.status(401).send({ 'error': 'Not allowed' })
  }
}

export const deleteProductFeature = (ProductFeature, req, res) => {
  if ((req.query._id !== undefined && req.role === 'BUSINESS') || (req.headers.token !== undefined && req.headers.token === 'A88D982A-FC81-4EA9-BEB3-189AA0808B78')) {
    ProductFeature.remove(req.queryForMongoose, function (err, data) {
      if (err) { res.status(417).send(err) } else { res.status(204).send({ 'info': 'Removed' }) }
    })
  } else {
    res.status(401).send({ 'error': 'Not allowed' })
  }
}
