import { consoleLogger } from './../../../../app/helpers/logger/log'
import { CompleteProcess } from './../../../../app/helpers/utilities/utility'

export function setQuery (req, res, next) {
  try {
    var query = {}
    query.country = req.country
    query.app = req.app
    if (req.query.packageId !== undefined) {
      query.packageId = req.query.packageId
    } else if (req.query.includeInvalidProducts === undefined || req.query.includeInvalidProducts === 'false') {
      var today = new Date()
      today.setHours(0)
      today.setMinutes(0)
      today.setSeconds(0)
      today.setMilliseconds(0)
      query.isActive = true
      query.startDate = { '$lte': today }
      query.endDate = { '$gte': today }
    }

    if (req.query._id) { query._id = req.query._id }
    req.filterCondition = query
    next()
  } catch (err) {
    consoleLogger(req, res, err, 'SODA-PRODUCT-GET')
  }
}

export function getProducts (Product, req, res) {
  try {
    Product.find(req.filterCondition, '-__v', function (err, data) {
      if (err) {
        CompleteProcess(req, res, err, 417)
      } else {
        CompleteProcess(req, res, data, 200)
      }
    }).sort({ noOfSolarPanels: 1 })
  } catch (err) {
    consoleLogger(req, res, err, 'SODA - PRODUCTS - GET')
  }
}

export function removeProduct (Product, req, res) {
  try {
    if (req.headers.token !== undefined && req.headers.token === 'A88D982A-FC81-4EA9-BEB3-189AA0808B78') {
      Product.remove(req.filterCondition, function (err, data) {
        if (err) {
          CompleteProcess(req, res, err, 417)
        } else {
          CompleteProcess(req, res, {}, 204)
        }
      })
    } else {
      CompleteProcess(req, res, { 'error': 'Not allowed' }, 401)
    }
  } catch (err) {
    consoleLogger(req, res, err, 'SODA-PRODUCT-DELETE')
  }
}

export const updateProduct = (Product, Audit, req, res) => {
  try {
    if (req.role === 'BUSINESS') {
      let patches = req.body
      let id = req.params.id
      patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })
      Product.findById(id, '-__v', (err, product) => {
        if (err) {
          if (err.name === 'CastError' && err.path === '_id') {
            res.status(404).send()
          } else {
            res.status(417).send(err)
          }
        } else {
          if (product == null) {
            res.status(404).send()
          } else {
            // Check whether user country & product country matches
            if (req.country !== product.country || req.app !== product.app) {
              res.status(403).send({ 'error': 'Country or App is not matching' })
            } else {
              product.patch(patches, (err) => {
                if (err) { res.status(417).send(err) } else {
                  // Logging into Audit
                  let data = {}
                  data.docName = 'Product'
                  data.docId = product._id
                  data.userId = ''
                  data.info = patches
                  let audit = new Audit(data)
                  audit.save()
                  // End of Audit logging
                  res.status(200).send(product)
                }
              })
            }
          }
        }
      })
    } else {
      res.status(401).send({ 'error': 'Not allowed' })
    }
  } catch (err) {
  }
}

export const saveProduct = (Product, req, res) => {
  if (req.role === 'BUSINESS') {
    const packageId = { packageId: req.body.packageId }
    Product.find(packageId, '-__v', function (err, data) {
      if (err) { res.status(500).send({ 'error': 'Error occured...' }) } else
      if (data.length > 0) {
        res.status(417).send({ 'info': 'Package ID: ' + packageId.packageId + ' already exists' })
      } else {
        const product = new Product(req.body)
        product.country = req.country
        product.app = req.app
        product.save(function (err) {
          if (err) {
            res.status(417).send(err)
          } else {
            res.status(201).send(product)
          }
        })
      }
    })
  } else {
    res.status(401).send({ 'error': 'Not allowed' })
  }
}
