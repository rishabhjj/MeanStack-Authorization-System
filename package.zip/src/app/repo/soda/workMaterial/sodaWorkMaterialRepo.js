export const setQuery = (req, res, next) => {
  var query = {}
  if (req.query.type) { query.type = req.query.type }
  if (req.query._id) { query._id = req.query._id }
  if (req.query.isCalculated) { query.isCalculated = req.query.isCalculated }
  query.country = req.country
  query.app = req.app

  req.queryForMongoose = query
  next()
}

export const updatetWorkMaterial = (WorkMaterial, req, res) => {
  if (req.role === 'BUSINESS') {
    let patches = req.body
    let id = req.params.id
    WorkMaterial.findById(id, '-__v', function (err, workMaterialDoc) {
      if (err) {
        if (err.name === 'CastError' && err.path === '_id') {
          res.status(404).send()
        } else {
          res.status(417).send(err)
        }
      } else {
        // Check whether user country & product country matches
        if (req.country !== workMaterialDoc.country || req.app !== workMaterialDoc.app) {
          res.status(403).send({ 'error': 'Country or App is not matching' })
        } else {
          workMaterialDoc.patch(patches, function (err, doc) {
            if (err) { res.status(417).send(err) } else {
              res.status(202).send(doc)
            }
          })
        }
      }
    })
  } else {
    res.status(401).send('Not allowed')
  }
}

export const saveWorkMaterial = (WorkMaterial, req, res) => {
  if (req.role === 'BUSINESS') {
    req.queryForMongoose.workMaterialId = req.body.workMaterialId
    WorkMaterial.find(req.queryForMongoose, '-__v', function (err, data) {
      if (err) { res.status(500).send('Error occured...') } else
      if (data.length > 0) {
        res.status(417).send('WorkMaterial ID: ' + req.body.workMaterialId + ' already exists')
      } else {
        let workMaterial = new WorkMaterial(req.body)
        workMaterial.country = req.country
        workMaterial.app = req.app

        workMaterial.save(function (err) {
          if (err) {
            res.status(417).send(err)
          } else {
            res.status(201).send(workMaterial)
          }
        })
      }
    })
  } else {
    res.status(401).send('Not allowed')
  }
}

export const getWorkMaterialList = (WorkMaterial, req, res) => {
  WorkMaterial.find(req.queryForMongoose, '-__v', function (err, data) {
    if (err) { res.status(417).send(err) } else { res.json(data) }
  }).sort({ type: 1, measurementUnit: 1 })
}

export const deleteWorkMaterial = (WorkMaterial, req, res) => {
  if ((req.query._id !== undefined && req.role === 'BUSINESS') || (req.headers.token !== undefined && req.headers.token === 'A88D982A-FC81-4EA9-BEB3-189AA0808B78')) {
    WorkMaterial.remove(req.queryForMongoose, function (err, data) {
      if (err) { res.status(417).send(err) } else { res.status(204).send('Removed') }
    })
  } else {
    res.status(401).send('Not allowed')
  }
}
