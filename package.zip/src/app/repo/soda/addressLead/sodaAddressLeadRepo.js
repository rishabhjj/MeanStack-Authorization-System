import moment from 'moment'
import { consoleLogger } from './../../../../app/helpers/logger/log'
import { CompleteProcess } from './../../../../app/helpers/utilities/utility'

export function setQuery (req, res, next) {
  var query = {}
  if (req.query._id !== undefined) { query._id = req.query._id }

  let start = new Date()
  let end = new Date()

  if (req.query.startDate) { start = new Date(req.query.startDate) }
  if (req.query.endDate) {
    end = moment(new Date(req.query.endDate)).add(1, 'days').format()
  }
  if (req.query.startDate || req.query.endDate) {
    query.createdOn = { '$gte': start, '$lte': end }
  }

  query.country = req.country
  query.app = req.app
  req.filterCondition = query
  next()
}

export function getAddressLead (AddressLead, req, res) {
  try {
    AddressLead.find(req.filterCondition, '-__v', function (err, data) {
      if (err) {
        CompleteProcess(req, res, err, 417)
      } else {
        CompleteProcess(req, res, data, 200)
      }
    })
  } catch (err) {
    consoleLogger(req, res, err, 'SODA-ADDRESS-LEAD-GET')
  }
}

export function createAddressLead (AddressLead, req, res) {
  try {
    let query = {}
    if (req.body.street !== undefined) {
      query.street = (req.body.street).toUpperCase()
    }
    if (req.body.city !== undefined) {
      query.city = (req.body.city).toUpperCase()
    }
    query.zip = req.body.zip

    AddressLead.find(query, '-__v', function (err, logs) {
      if (err) {
        console.log('Address logging error' + err)
      } else {
        if (logs.length === 0) {
          if (req.body.street !== undefined) {
            req.body.street = (req.body.street).toUpperCase()
          }
          if (req.body.city !== undefined) {
            req.body.city = (req.body.city).toUpperCase()
          }

          var address = new AddressLead(req.body)
          address.country = req.country
          address.save(function (err) {
            if (err) {
              CompleteProcess(req, res, err, 417)
            } else {
              CompleteProcess(req, res, {}, 201)
            }
          })
        } else {
          let info = { 'info': 'Address already present, hence skipping the logging- Street: ' + req.body.street + ' City: ' + req.body.city + ' Zip: ' + req.body.zip }
          CompleteProcess(req, res, info, 201)
        }
      }
    })
  } catch (err) {
    consoleLogger(req, res, err, 'SODA-ADDRESS-LEAD-POST')
  }
}

export function removeAddressLead (AddressLead, req, res) {
  try {
    if (req.headers.token !== undefined && req.headers.token === 'A88D982A-FC81-4EA9-BEB3-189AA0808B78') {
      AddressLead.remove(req.filterCondition, function (err, data) {
        if (err) {
          CompleteProcess(req, res, err, 417)
        } else {
          CompleteProcess(req, res, {}, 204)
        }
      })
    } else {
      let message = { 'info': 'Not allowed' }
      CompleteProcess(req, res, message, 403)
    }
  } catch (err) {
    consoleLogger(req, res, err, 'SODA-ADDRESS-LEAD-DELETE')
  }
}
