export const sodaAgeingPatch = (SODAAgeing, status, workOrderNumber, name, country, createdOn, emp, id, req, res) => {
    let ageingQuery = {}
    ageingQuery.workOrderServiceKey = id
    SODAAgeing.find(ageingQuery, '-__v', function (err, ageingDoc) {
        if (err || ageingDoc.length === 0) {
            let ageingData = {};
            ageingData.name = name
            ageingData.workOrderServiceKey = id
            ageingData.workOrderNumber = workOrderNumber
            ageingData.emp = emp
            ageingData.offerRequestReceived = createdOn
            ageingData.createdOn = createdOn
            ageingData.currentStatus = status
            ageingData.country = country
            //appendStatus(status, ageingPatch);
            var ageing = new SODAAgeing(ageingData)
            ageing.save()
        } else {
            let mid = ageingDoc[0]._id
            SODAAgeing.findById(mid, '-__v', function (err, ageingDoc) {
                if (!err && ageingDoc != null) {
                    let ageingPatch = []
                    ageingPatch.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })
                    ageingPatch.push({ 'op': 'add', 'path': '/currentStatus', 'value': status })
                    appendStatus(status, ageingPatch)

                    ageingDoc.patch(ageingPatch, function (err, ageingDocResult) {
                        console.log(err)
                    })
                }
            })
        }
    })

    function appendStatus(status, ageingPatch) {
        if (status === 'PreliminaryOfferSent') {
            ageingPatch.push({ 'op': 'add', 'path': '/preliminaryOfferSent', 'value': new Date() })
        } else if (status === 'PreliminaryOfferApproved') {
            ageingPatch.push({ 'op': 'add', 'path': '/preliminaryOfferApproved', 'value': new Date() })
        } else if (status === 'AssessmentSiteVisitScheduled') {
            ageingPatch.push({ 'op': 'add', 'path': '/assessmentSiteVisitScheduled', 'value': new Date() })
        } else if (status === 'AddInstallationPlan') {
            ageingPatch.push({ 'op': 'add', 'path': '/addInstallationPlan', 'value': new Date() })
        } else if (status === 'InstallationPlanCreated') {
            ageingPatch.push({ 'op': 'add', 'path': '/installationPlanCreated', 'value': new Date() })
        } else if (status === 'InstallationPlanVerified') {
            ageingPatch.push({ 'op': 'add', 'path': '/installationPlanVerified', 'value': new Date() })
        } else if (status === 'FinalOfferSent') {
            ageingPatch.push({ 'op': 'add', 'path': '/finalOfferSent', 'value': new Date() })
        } else if (status === 'FinalOfferApproved') {
            ageingPatch.push({ 'op': 'add', 'path': '/finalOfferApproved', 'value': new Date() })
        } else if (status === 'InstallationTimeScheduled') {
            ageingPatch.push({ 'op': 'add', 'path': '/installationTimeScheduled', 'value': new Date() })
        } else if (status === 'AddInstallationReport') {
            ageingPatch.push({ 'op': 'add', 'path': '/addInstallationReport', 'value': new Date() })
        } else if (status === 'InstallationReportReady') {
            ageingPatch.push({ 'op': 'add', 'path': '/installationReportReady', 'value': new Date() })
        } else if (status === 'InstallationReportVerified') {
            ageingPatch.push({ 'op': 'add', 'path': '/installationReportVerified', 'value': new Date() })
        } else if (status === 'InstallationApproved') {
            ageingPatch.push({ 'op': 'add', 'path': '/installationApproved', 'value': new Date() })
        } else if (status === 'Cancelled') {
            ageingPatch.push({ 'op': 'add', 'path': '/cancelled', 'value': new Date() })
        } else if (status === 'Closed') {
            ageingPatch.push({ 'op': 'add', 'path': '/closed', 'value': new Date() })
        }

        return ageingPatch
    }
}

