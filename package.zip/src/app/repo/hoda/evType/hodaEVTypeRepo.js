import { consoleLogger } from './../../../../app/helpers/logger/log'
import { CompleteProcess } from './../../../../app/helpers/utilities/utility'

export function setQuery (req, res, next) {
  var query = {}
  if (req.query._id !== undefined) { query._id = req.query._id }
  if (req.query.evId !== undefined) { query.evId = req.query.evId }

  query.country = req.country
  query.app = req.app
  req.filterCondition = query
  next()
}

export function getEVTypes (EVType, req, res) {
  try {
    EVType.find(req.filterCondition, '-__v', function (err, doc) {
      if (err) {
        if (err.name === 'CastError' && err.path === '_id') {
          let response = []
          CompleteProcess(req, res, response, 200)
        } else {
          CompleteProcess(req, res, err, 417)
        }
      } else {
        CompleteProcess(req, res, doc, 200)
      }
    })
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-EV-TYPE-GET')
  }
}

export function createEVType (EVType, req, res) {
  try {
    if (req.role === 'BUSINESS') {
      req.query.evId = req.body.evId
      if (req.query.evId !== undefined) {
        EVType.find(req.query, '-__v', function (err, evType) {
          if (err) { res.status(417).send('Error occured...') } else {
            if (evType.length > 0) {
              let info = 'EVType: ' + req.body.evId + ' already exists'
              CompleteProcess(req, res, { 'error': info }, 417)
            } else {
              let data = new EVType(req.body)
              data.country = req.country
              data.app = req.app

              let ev = new EVType(data)
              ev.save(function (err) {
                if (err) {
                  CompleteProcess(req, res, err, 417)
                } else {
                  CompleteProcess(req, res, ev, 201)
                }
              })
            }
          }
        })
      } else {
        res.status(400).send()
      }
    } else {
      res.status(403).send({ 'info': 'Invalid role' })
    }
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-EV-TYPE-POST')
  }
}

export function updateEVType (EVType, req, res) {
  try {
    let patches = req.body
    patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })

    if (req.role === 'BUSINESS') {
      if (req.params.id !== undefined) {
        EVType.findById(req.params.id, '-__v', function (err, ev) {
          if (err) {
            if (err.name === 'CastError' && err.path === '_id') {
              CompleteProcess(req, res, {}, 404)
            } else {
              CompleteProcess(req, res, err, 417)
            }
          } else {
            if (ev === null) {
              CompleteProcess(req, res, {}, 404)
            } else {
              if (req.country === ev.country && req.app === ev.app) {
                ev.patch(patches, function (err, doc) {
                  if (err) {
                    CompleteProcess(req, res, err, 417)
                  } else {
                    CompleteProcess(req, res, doc, 202)
                  }
                })
              } else {
                let info = { 'error': 'Country or App is not matching' }
                CompleteProcess(req, res, info, 403)
              }
            }
          }
        })
      } else {
        res.status(400).send({ 'info': 'code is missing' })
      }
    } else {
      res.status(403).send({ 'info': 'Invalid role' })
    }
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-EV-TYPE-PATCH')
  }
}

export function deleteEVTypes (EVType, req, res) {
  try {
    if (req.role === 'BUSINESS') {
      if (req.params.id !== undefined) {
        let query = {}
        query.country = req.country
        query.app = req.app
        query._id = req.params.id

        EVType.remove(query, function (err, evType) {
          if (err) {
            CompleteProcess(req, res, err, 417)
          } else {
            let info = { 'info': 'EV Type is: ' + req.query.evId + 'removed' }
            CompleteProcess(req, res, info, 204)
          }
        })
      } else {
        CompleteProcess(req, res, { 'info': 'evId is missing' }, 400)
      }
    } else {
      res.status(403).send({ 'info': 'Invalid role' })
    }
  } catch (err) {
    consoleLogger(req, res, err, 'VODA-EV-TYPE-DELETE')
  }
}
