import { consoleLogger } from './../../../../app/helpers/logger/log'
import { CompleteProcess } from './../../../../app/helpers/utilities/utility'

export function setQuery (req, res, next) {
  var query = {}
  if (req.query._id !== undefined) { query._id = req.query._id }

  query.country = req.country
  query.app = req.app
  req.filterCondition = query
  next()
}

export function getContacts (Contact, req, res) {
  try {
    Contact.find(req.filterCondition, '-__v', function (err, doc) {
      if (err) {
        if (err.name === 'CastError' && err.path === '_id') {
          let response = []
          CompleteProcess(req, res, response, 200)
        } else {
          CompleteProcess(req, res, err, 417)
        }
      } else {
        CompleteProcess(req, res, doc, 200)
      }
    })
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-CONTACT-GET')
  }
}

export function createContact (Contact, req, res) {
  try {
    let contact = new Contact(req.body)
    contact.country = req.country
    contact.app = req.app
    contact.save((err) => {
      if (err) {
        CompleteProcess(req, res, err, 417)
      } else {
        CompleteProcess(req, res, contact, 201)
      }
    })
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-CONTACT-POST')
  }
}
