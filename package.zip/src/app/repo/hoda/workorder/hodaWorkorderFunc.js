import mongoose from 'mongoose'

export function getWOByWOE (woe, Workorder, country, app) {
  return new Promise((resolve, reject) => {
    woe = woe.replace('WOE', '')
    let query = {}
    query.country = country
    query.app = app
    query.hodaOrderNumber = woe

    Workorder.find(query, { _id: 1, 'country': 1, 'app': 1, 'createdOn': 1, 'statusChangeOn': 1, 'customer.firstName': 1, 'customer.lastName': 1, 'hodaOrderNumber': 1, 'sentToInstallerOn': 1, 'status': 1, 'modifiedOn': 1 }, '-__v', function (err, doc) {
      if (err) {
        reject(err)
      } else {
        resolve(doc)
      }
    })
  })
}

export function findWorkorders (text, Workorder, limit, skip, country, app) {
  return new Promise((resolve, reject) => {
    let limitSize = limit === undefined ? 25 : parseInt(limit)
    let skipSize = skip === undefined ? 0 : parseInt(skip)
    let id = (text !== undefined && mongoose.Types.ObjectId.isValid(text)) ? text : 'zzzzzzzzzzzz'
    let textWithOutCaseChange = text === undefined ? '' : text
    text = text === undefined ? '' : text.toUpperCase()

    var str1 = '.*'
    var str2 = str1.concat(text)
    var str3 = str2.concat('.*')
    // TODO - SSN Search won't work because of encrypt

    Workorder.find(
      {
        $and: [
          { 'country': country },
          { 'app': app },
          {
            $or: [
              { 'customer.firstName': { $regex: str3 } },
              { 'customer.lastName': { $regex: str3 } },
              { 'ssn': { $regex: str3 } },
              { 'deliverySite.address.street': { $regex: str3 } },
              { 'deliverySite.address.city': { $regex: str3 } },
              { 'deliverySite.address.zip': { $regex: str3 } },
              { 'status': textWithOutCaseChange },
              { 'customer.customerId': { $regex: str3 } },
              { '_id': id }
            ]
          }
        ]
      },
      { _id: 1, 'country': 1, 'app': 1, 'createdOn': 1, 'statusChangeOn': 1, 'customer.firstName': 1, 'customer.lastName': 1, 'hodaOrderNumber': 1, 'sentToInstallerOn': 1, 'status': 1, 'modifiedOn': 1 }, '-__v', function (err, doc) {
        if (err) {
          reject(err)
        } else {
          resolve(doc)
        }
      }).skip(skipSize).limit(limitSize).sort({ modifiedOn: -1 })
  })
}

export function getWorkordersCount (text, Workorder, country, app) {
  return new Promise((resolve, reject) => {
    let id = (text !== undefined && mongoose.Types.ObjectId.isValid(text)) ? text : 'zzzzzzzzzzzz'
    let textWithOutCaseChange = text === undefined ? '' : text
    text = text === undefined ? '' : text.toUpperCase()
    var str1 = '.*'
    var str2 = str1.concat(text)
    var str3 = str2.concat('.*')
    // TODO - SSN Search won't work because of encrypt

    Workorder.count(
      {
        $and: [
          { 'country': country },
          { 'app': app },
          {
            $or: [
              { 'customer.firstName': { $regex: str3 } },
              { 'customer.lastName': { $regex: str3 } },
              { 'ssn': { $regex: str3 } },
              { 'deliverySite.address.street': { $regex: str3 } },
              { 'deliverySite.address.city': { $regex: str3 } },
              { 'deliverySite.address.zip': { $regex: str3 } },
              { 'status': textWithOutCaseChange },
              { 'customer.customerId': { $regex: str3 } },
              { '_id': id }
            ]
          }
        ]
      }, function (err, count) {
        if (err) {
          reject(err)
        } else {
          resolve(count)
        }
      })
  })
}
