import { error, consoleLogger } from './../../../../app/helpers/logger/log'
import { CompleteProcess } from './../../../../app/helpers/utilities/utility'
import { encrypt, decrypt } from './../../../../app/helpers/crypt/crypt'
// import { sendMails } from './../../../messaging/hoda/customer/hodaCustomerMessaging'
import { getWOByWOE, findWorkorders, getWorkordersCount } from './../../../../app/repo/hoda/workorder/hodaWorkorderFunc'
import moment from 'moment'
import { pushWorkorder } from './../../shared/EmpowerFunc'
import { sendMail } from './../../../messaging/hoda/hodaMessaging'
import { createServiceAddress } from './../../shared/MaximoFunc'

export function setQuery (req, res, next) {
  try {
    var query = {}
    if (req.query._id !== undefined) { query._id = req.query._id }
    if (req.query.hodaOrderNumber !== undefined) { query.hodaOrderNumber = req.query.hodaOrderNumber }
    if (req.query.status !== undefined) { query.status = req.query.status }

    query.country = req.country
    query.app = req.app
    req.filterCondition = query
    next()
  } catch (err) {
    error(req, res, err, 'HODA-WORKORDER-GET')
  }
}

export function getWorkorders (Workorder, req, res) {
  try {
    if (req.filterCondition._id === undefined && req.headers.token === undefined) {
      res.status(401).send({ 'error': 'WO ID is missing' })
    } else if (req.filterCondition._id === undefined && req.headers.token !== undefined && req.headers.token !== 'A88D982A-FC81-4EA9-BEB3-189AA0808B78') {
      res.status(403).send({ 'error': 'Invalid Token' })
    } else {
      Workorder.find(req.filterCondition, '-__v', function (err, doc) {
        if (err) {
          if (err.name === 'CastError' && err.path === '_id') {
            let response = []
            CompleteProcess(req, res, response, 200)
          } else {
            CompleteProcess(req, res, err, 417)
          }
        } else {
          if (doc.length > 0) {
            for (let i = 0; i < doc.length; i++) {
              if (doc[i].customer !== undefined && doc[i].customer.ssn !== undefined) {
                let ssn = decrypt(doc[i].customer.ssn)
                doc[i].customer.ssn = ssn
              }
            }
          }
          CompleteProcess(req, res, doc, 200)
        }
      })
    }
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-WORKORDERS-GET')
  }
}

export function createWorkorder (Workorder, req, res) {
  try {
    let workorder = new Workorder(req.body)
    workorder.country = req.country
    workorder.app = req.app
    workorder.createdOn = new Date()
    workorder.createdBy = req.user
    workorder.createdByUserRole = req.role
    workorder.modifiedOn = new Date()

    if (req.body.customer !== undefined && req.body.customer.ssn !== undefined) {
      let ssn = (req.body.customer.ssn).toUpperCase()
      workorder.customer.ssn = encrypt(ssn)
    }
    if (req.body.customer !== undefined && req.body.customer.firstName !== undefined) {
      workorder.customer.firstName = (req.body.customer.firstName).toUpperCase()
    }
    if (req.body.customer !== undefined && req.body.customer.lastName !== undefined) {
      workorder.customer.lastName = (req.body.customer.lastName).toUpperCase()
    }
    if (req.body.customer !== undefined && req.body.customer.address !== undefined && req.body.customer.address.street !== undefined) {
      workorder.customer.address.street = (req.body.customer.address.street).toUpperCase()
    }
    if (req.body.customer !== undefined && req.body.customer.address !== undefined && req.body.customer.address.city !== undefined) {
      workorder.customer.address.city = (req.body.customer.address.city).toUpperCase()
    }
    if (req.body.deliverySite !== undefined && req.body.deliverySite.address !== undefined && req.body.deliverySite.address.street !== undefined) {
      workorder.deliverySite.address.street = (req.body.deliverySite.address.street).toUpperCase()
    }
    if (req.body.deliverySite !== undefined && req.body.deliverySite.address !== undefined && req.body.deliverySite.address.city !== undefined) {
      workorder.deliverySite.address.city = (req.body.deliverySite.address.city).toUpperCase()
    }

    workorder.save(function (err) {
      if (err) {
        CompleteProcess(req, res, err, 417)
      } else {
        let isFICustomer = process.env.HODA_FI_SEND_MAIL_TO_CUSTOMER || 'TRUE'
        let isNOCustomer = process.env.HODA_NO_SEND_MAIL_TO_CUSTOMER || 'TRUE'
        if ((isNOCustomer && req.country === 'NO') || (isFICustomer && req.country === 'FI')) {
          sendMail(workorder, req.country, req.app, 'CUSTOMER', false)
        }

        CompleteProcess(req, res, workorder, 201)
      }
    })
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-WORKORDER-POST')
  }
}

export function updateSiteInfo (Workorder, req, res) {
  try {
    if (req.params.id !== undefined && (req.body !== undefined && req.body.siteInfo !== undefined)) {
      Workorder.findById(req.params.id, '-__v', function (err, wo) {
        if (err) {
          if (err.name === 'CastError' && err.path === '_id') {
            CompleteProcess(req, res, {}, 404)
          } else {
            CompleteProcess(req, res, err, 417)
          }
        } else {
          if (wo === null) {
            CompleteProcess(req, res, {}, 404)
          } else {
            if (req.country === wo.country && req.app === wo.app && (wo.status === 'OrderReceived' || wo.status === 'InCompleteOrder')) {
              let patches = []
              patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })
              if (req.body.siteInfo.totalCablingDistance !== undefined) {
                patches.push({ 'op': 'add', 'path': '/siteInfo/totalCablingDistance', 'value': req.body.siteInfo.totalCablingDistance })
              }
              if (req.body.siteInfo.outsideCablingDistance !== undefined) {
                patches.push({ 'op': 'add', 'path': '/siteInfo/outsideCablingDistance', 'value': req.body.siteInfo.outsideCablingDistance })
              }
              if (req.body.siteInfo.cabling !== undefined) {
                patches.push({ 'op': 'add', 'path': '/siteInfo/cabling', 'value': req.body.siteInfo.cabling })
              }
              if (req.body.siteInfo.groundSurface !== undefined) {
                patches.push({ 'op': 'add', 'path': '/siteInfo/groundSurface', 'value': req.body.siteInfo.groundSurface })
              }
              if (req.body.siteInfo.numberOfInlets !== undefined) {
                patches.push({ 'op': 'add', 'path': '/siteInfo/numberOfInlets', 'value': req.body.siteInfo.numberOfInlets })
              }
              if (req.body.siteInfo.isMountingLocationAwayFromHouse !== undefined) {
                patches.push({ 'op': 'add', 'path': '/siteInfo/isMountingLocationAwayFromHouse', 'value': req.body.siteInfo.isMountingLocationAwayFromHouse })
              }
              if (req.body.siteInfo.wallMaterial !== undefined) {
                patches.push({ 'op': 'add', 'path': '/siteInfo/wallMaterial', 'value': req.body.siteInfo.wallMaterial })
              }
              if (req.body.siteInfo.description !== undefined) {
                patches.push({ 'op': 'add', 'path': '/siteInfo/description', 'value': req.body.siteInfo.description })
              }
              if (req.body.siteInfo.excavation !== undefined) {
                patches.push({ 'op': 'add', 'path': '/siteInfo/excavation', 'value': req.body.siteInfo.excavation })
              }

              wo.patch(patches, function (err, doc) {
                if (err) {
                  CompleteProcess(req, res, err, 417)
                } else {
                  CompleteProcess(req, res, wo, 200)
                }
              })
            } else {
              let info = { 'error': 'Country, App is not matching Or WO in not updatable status' }
              CompleteProcess(req, res, info, 403)
            }
          }
        }
      })
    } else {
      res.status(400).send({ 'info': 'Workorder key / Invalid body is missing' })
    }
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-WORKORDER-PUT')
  }
}

export function updatePaymentType (Workorder, req, res) {
  try {
    if (req.params.id !== undefined && (req.body !== undefined && req.body.pricing !== undefined)) {
      Workorder.findById(req.params.id, '-__v', function (err, wo) {
        if (err) {
          if (err.name === 'CastError' && err.path === '_id') {
            CompleteProcess(req, res, {}, 404)
          } else {
            CompleteProcess(req, res, err, 417)
          }
        } else {
          if (wo === null) {
            CompleteProcess(req, res, {}, 404)
          } else {
            if (req.country === wo.country && req.app === wo.app && (wo.status === 'OrderReceived' || wo.status === 'InCompleteOrder') &&
              req.body.pricing.paymentPlan !== undefined) {
              let patches = []
              let isProcess = false
              patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })
              patches.push({ 'op': 'add', 'path': '/pricing/paymentPlan', 'value': req.body.pricing.paymentPlan })
              patches.push({ 'op': 'replace', 'path': '/pricing/discounts', 'value': [] })

              if (req.body.pricing.paymentPlan === 'Subscription' && req.body.pricing.subscription !== undefined &&
                req.body.pricing.subscription.fee !== undefined) {
                isProcess = true
                patches.push({ 'op': 'add', 'path': '/pricing/subscription', 'value': req.body.pricing.subscription })

                // Remove Buy payment type related fields
                if (wo.pricing.buy !== undefined) {
                  patches.push({ 'op': 'remove', 'path': '/pricing/buy', 'value': null })
                }
              } else if (req.body.pricing.paymentPlan === 'Buy' && req.body.pricing.buy !== undefined &&
                req.body.pricing.buy.buyType !== undefined && req.body.pricing.buy.package !== undefined &&
                req.body.pricing.buy.installation !== undefined) {
                isProcess = true
                patches.push({
                  'op': 'add',
                  'path': '/pricing/buy',
                  'value': {
                    'buyType': req.body.pricing.buy.buyType,
                    'package': req.body.pricing.buy.package,
                    'installation': req.body.pricing.buy.installation
                  }
                })

                if (req.body.pricing.buy.buyType === 'FULL PAYMENT') {
                  patches.push({ 'op': 'remove', 'path': '/pricing/buy/numberOfMonthlyInstallments', 'value': null })
                  patches.push({ 'op': 'remove', 'path': '/pricing/buy/installmentComponents', 'value': null })
                } else if (req.body.pricing.buy.numberOfMonthlyInstallments !== undefined &&
                  req.body.pricing.buy.installmentComponents !== undefined && req.body.pricing.buy.buyType === 'INSTALLMENT') {
                  patches.push({ 'op': 'add', 'path': '/pricing/buy/numberOfMonthlyInstallments', 'value': req.body.pricing.buy.numberOfMonthlyInstallments })
                  patches.push({ 'op': 'add', 'path': '/pricing/buy/installmentComponents', 'value': req.body.pricing.buy.installmentComponents })
                } else {
                  isProcess = false
                }

                // Remove subscription payment type related fields
                if (wo.pricing.subscription !== undefined) {
                  patches.push({ 'op': 'remove', 'path': '/pricing/subscription', 'value': null })
                }
              }

              // Not validating whether provided Discount is applicable or not
              if (req.body.pricing.discounts !== undefined && req.body.pricing.discounts.length > 0) {
                for (let i = 0; i < req.body.pricing.discounts.length; i++) {
                  if (req.body.pricing.discounts[i].code !== undefined && req.body.pricing.discounts[i].amount !== undefined) {
                    patches.push({
                      'op': 'add',
                      'path': '/pricing/discounts/',
                      'value': {
                        'code': req.body.pricing.discounts[i].code,
                        'amount': req.body.pricing.discounts[i].amount,
                        'addedBy': req.user
                      }
                    })
                  }
                }
              }

              if (isProcess) {
                wo.patch(patches, function (err, doc) {
                  if (err) {
                    CompleteProcess(req, res, err, 417)
                  } else {
                    CompleteProcess(req, res, wo, 200)
                  }
                })
              } else {
                CompleteProcess(req, res, {}, 400)
              }
            } else {
              let info = { 'error': 'Country, App is not matching Or WO in not updatable status' }
              CompleteProcess(req, res, info, 403)
            }
          }
        }
      })
    } else {
      res.status(400).send({ 'info': 'Workorder key / Invalid body is missing' })
    }
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-WORKORDER-PUT')
  }
}

export function updateStatusToValidOrder (Workorder, req, res) {
  try {
    if (req.params.id !== undefined) {
      Workorder.findById(req.params.id, '-__v', function (err, wo) {
        if (err) {
          if (err.name === 'CastError' && err.path === '_id') {
            CompleteProcess(req, res, {}, 404)
          } else {
            CompleteProcess(req, res, err, 417)
          }
        } else {
          if (wo === null) {
            CompleteProcess(req, res, {}, 404)
          } else {
            if (req.country === wo.country && req.app === wo.app && (wo.status === 'OrderReceived' || wo.status === 'InCompleteOrder')) {
              let patches = []
              patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })
              patches.push({ 'op': 'add', 'path': '/status', 'value': 'ValidOrder' })
              patches.push({ 'op': 'add', 'path': '/statusChangeOn', 'value': new Date() })

              wo.patch(patches, function (err, doc) {
                if (err) {
                  CompleteProcess(req, res, err, 417)
                } else {
                  let isFICustomer = process.env.HODA_FI_SEND_MAIL_TO_CUSTOMER || 'TRUE'
                  let isNOCustomer = process.env.HODA_NO_SEND_MAIL_TO_CUSTOMER || 'TRUE'

                  if ((isNOCustomer && req.country === 'NO') || (isFICustomer && req.country === 'FI')) {
                    sendMail(doc, req.country, req.app, 'CUSTOMER', false)
                  }

                  let isFICustomerService = process.env.HODA_FI_SEND_MAIL_TO_CUSTOMER_SERVICE_TEAM || 'TRUE'
                  if (isFICustomerService === 'TRUE' && doc.country === 'FI') {
                    sendMail(doc, doc.country, doc.app, 'CS', false)
                  }

                  CompleteProcess(req, res, doc, 200)
                }
              })
            } else {
              let info = { 'error': 'Country, App is not matching Or WO in not updatable status' }
              CompleteProcess(req, res, info, 403)
            }
          }
        }
      })
    } else {
      res.status(400).send({ 'info': 'Workorder key is missing' })
    }
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-WORKORDER-PUT')
  }
}

export function updateWorkorder (Workorder, req, res) {
  try {
    let patches = req.body
    patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })

    if (req.role === 'CUSTOMERSERVICE' || req.role === 'INSTALLER' || req.role === 'INSTALLERSUPERVISOR') {
      if (req.params.id !== undefined) {
        Workorder.findById(req.params.id, '-__v', function (err, wo) {
          if (err) {
            if (err.name === 'CastError' && err.path === '_id') {
              CompleteProcess(req, res, err, 404)
            } else {
              CompleteProcess(req, res, err, 417)
            }
          } else {
            if (wo === null) {
              CompleteProcess(req, res, {}, 404)
            } else {
              if (req.country === wo.country && req.app === wo.app) {
                // Encrypt SSN if present
                let existingStatus = wo.status
                let targetStatus = 'NONE'
                let existingCampaignId = wo.campaignId
                let targetCampaignId = wo.campaignId
                let isStatusUpdate = 0
                for (let i = 0, len = patches.length; i < len; i++) {
                  let element = patches[i].path
                  let statusUpdate = element.search(new RegExp('status', 'i'))
                  if (statusUpdate === 1) {
                    isStatusUpdate = 1
                    targetStatus = patches[i].value
                    patches.push({ 'op': 'add', 'path': '/statusChangeOn', 'value': new Date() })
                  }

                  let isSSNUpdate = element.search(new RegExp('customer/ssn', 'i'))
                  if (isSSNUpdate === 1) {
                    let ssn = encrypt(patches[i].value)
                    patches.push({ 'op': 'add', 'path': '/customer/ssn', 'value': ssn.toString() })
                  }

                  let isCampaignUpdate = element.search(new RegExp('campaignId', 'i'))
                  if (isCampaignUpdate === 1) {
                    targetCampaignId = patches[i].value
                  }
                }

                if (wo.country === 'FI' && isStatusUpdate === 1 && targetStatus === 'SentToInstaller' && (existingStatus !== targetStatus)) {
                  // Call Empower API first then update the WO status, if country = FI
                  pushWorkorder(wo, 'hc_install', req.country, req.app)
                    .then(result => {
                      if (result.statusCode === 200) {
                        wo.patch(patches, function (err, doc) {
                          if (err) {
                            CompleteProcess(req, res, err, 417)
                          } else {
                            let isFinlandInstaller = process.env.HODA_FI_SEND_MAIL_TO_INSTALLER_COMPANY || 'TRUE'

                            if (targetStatus === 'SentToInstaller' && isFinlandInstaller === 'TRUE') {
                              sendMail(doc, req.country, req.app, 'INSTALLER', false)
                            }
                            if (doc.customer !== undefined && doc.customer.ssn !== undefined) {
                              doc.customer.ssn = decrypt(doc.customer.ssn)
                            }

                            createServiceAddress(doc, req.country, req.app)
                              .then((result, w = doc) => {
                                CompleteProcess(req, res, doc, 202)
                              })
                              .catch((error, w = doc) => {
                                console.log('Error in .... HODA-WORKORDER-CREATE-SERVICE-ADDRESS' + error)
                                CompleteProcess(req, res, doc, 202)
                              })
                          }
                        })
                      } else {
                        console.log(result)
                        CompleteProcess(req, result, 'Error in Sending data to Empower', 417)
                      }
                    })
                    .catch(error => console.log(error))
                } else {
                  wo.patch(patches, function (err, doc) {
                    if (err) {
                      CompleteProcess(req, res, err, 417)
                    } else {
                      let isNorwayInstaller = process.env.HODA_NO_SEND_MAIL_TO_INSTALLER_COMPANY || 'TRUE'
                      let isFICustomerService = process.env.HODA_FI_SEND_MAIL_TO_CUSTOMER_SERVICE_TEAM || 'TRUE'
                      let isProductChanged = existingCampaignId !== targetCampaignId
                      let isMailSendingConditionMet = ((existingCampaignId !== targetCampaignId) || (existingStatus !== targetStatus))

                      // Customer
                      let isFICustomer = process.env.HODA_FI_SEND_MAIL_TO_CUSTOMER || 'TRUE'
                      let isNOCustomer = process.env.HODA_NO_SEND_MAIL_TO_CUSTOMER || 'TRUE'

                      if (((isNOCustomer && req.country === 'NO') || (isFICustomer && req.country === 'FI')) && isMailSendingConditionMet) {
                        sendMail(doc, req.country, req.app, 'CUSTOMER', isProductChanged)
                      }

                      // Installer - Norway
                      if ((isNorwayInstaller === 'TRUE' && doc.country === 'NO') && targetStatus === 'SentToInstaller' && isMailSendingConditionMet) {
                        sendMail(doc, req.country, req.app, 'INSTALLER', false)
                      }

                      // Customer Service - FI
                      if (isFICustomerService === 'TRUE' && doc.country === 'FI' && isMailSendingConditionMet) {
                        sendMail(doc, doc.country, doc.app, 'CS', isProductChanged)
                      }

                      if (doc.customer !== undefined && doc.customer.ssn !== undefined) {
                        doc.customer.ssn = decrypt(doc.customer.ssn)
                      }

                      if (targetStatus === 'SentToInstaller' && req.country === 'FI' && (existingStatus !== targetStatus)) {
                        createServiceAddress(doc, req.country, req.app)
                          .then((result, w = doc) => {
                            CompleteProcess(req, res, doc, 202)
                          })
                          .catch((error, w = doc) => {
                            console.log('Error in .... HODA-WORKORDER-CREATE-SERVICE-ADDRESS' + error)
                            CompleteProcess(req, res, doc, 202)
                          })
                      } else {
                        CompleteProcess(req, res, doc, 202)
                      }
                    }
                  })
                }
              } else {
                CompleteProcess(req, res, { 'error': 'Country or App is not matching' }, 403)
              }
            }
          }
        })
      } else {
        CompleteProcess(req, res, { 'info': 'Workorder key is missing' }, 400)
      }
    } else {
      CompleteProcess(req, res, { 'info': 'Invalid role' }, 403)
    }
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-WORKORDER-PATCH')
  }
}

export function search (Workorder, req, res) {
  try {
    if (req.role === 'CUSTOMERSERVICE') {
      if (req.query.searchText !== undefined && req.query.searchText.includes('WOE')) {
        getWOByWOE(req.query.searchText, Workorder, req.country, req.app)
          .then(result => {
            res.append('totalRecords', result.length)
            CompleteProcess(req, res, result, 200)
          })
          .catch(err => {
            CompleteProcess(req, res, { 'info': err.message }, 417)
          })
      } else {
        let data = []
        let count = 0
        let woData = findWorkorders(req.query.searchText, Workorder, req.query.limit, req.query.skip, req.country, req.app).then(result => {
          data = result
        })
          .catch(err => {
            CompleteProcess(req, res, { 'info': err.message }, 417)
          })

        let woCount = getWorkordersCount(req.query.searchText, Workorder, req.country, req.app).then(result => {
          count = result
        })
          .catch(err => {
            CompleteProcess(req, res, { 'info': err.message }, 417)
          })

        Promise.all([woData, woCount]).then(() => {
          res.append('totalRecords', count)
          CompleteProcess(req, res, data, 200)
        })
      }
    } else {
      CompleteProcess(req, res, {}, 401)
    }
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-WORKORDER-SEARCH-GET')
  }
}

export function summary (Workorder, req, res) {
  try {
    if (req.role === 'CUSTOMERSERVICE') {
      var agg = [{ $match: { 'country': req.country, 'app': req.app } }, { $group: { _id: '$status', total: { $sum: 1 } } }]
      Workorder.aggregate(agg, function (err, data) {
        if (err) {
          CompleteProcess(req, res, err, 417)
        } else {
          CompleteProcess(req, res, data, 200)
        }
      })
    } else {
      CompleteProcess(req, res, {}, 401)
    }
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-WORKORDER-SUMMARY-GET')
  }
}

export function processPendingWorkorders (Workorder, sourceStatus, targetStatus, req, res) {
  try {
    let query = {}
    let waitingHours = process.env.HODA_WO_PENDING_WAITING_HOURS || 48

    if (targetStatus === 'InstallerYetToConfirm' & req.country === 'NO') {
      waitingHours = process.env.HODA_NO_WO_PENDING_FOR_INSTALLER_WAITING_HOURS || 24
    }
    query.createdOn = moment().add(-(waitingHours), 'hours')

    query.status = sourceStatus
    Workorder.find({ createdOn: { $lte: query.createdOn }, status: query.status }, '-__v', function (err, doc) {
      if (err) {
        if (err.name === 'CastError' && err.path === '_id') {
          res.status(200).send([])
        } else {
          res.status(417).send(err)
        }
      } else {
        if (doc.country !== 'FI' && targetStatus === 'InstallerYetToConfirm') {
          setStatusToRequestedStatus(Workorder, doc, sourceStatus, targetStatus, waitingHours)
            .then(result => {
              res.status(200).send(result)
            })
            .catch(err => {
              res.status(417).send({ 'info': err.message })
            })
        }
      }
    })
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-WORKORDERS-JOBS')
  }
}

function setStatusToRequestedStatus (Workorder, doc, sourceStatus, targetStatus, waitingHours) {
  return new Promise((resolve, reject) => {
    let count = doc.length
    for (let i = 0; i < doc.length; i++) {
      let patches = []
      patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })
      patches.push({ 'op': 'add', 'path': '/statusChangeOn', 'value': new Date() })
      patches.push({ 'op': 'add', 'path': '/status', 'value': targetStatus })
      patches.push({ 'op': 'add', 'path': '/customerServiceNotes/', 'value': { 'createdBy': 'Scheduler', 'note': 'Moved to ' + targetStatus + 'status from  ' + sourceStatus + ' as pending more than ' + waitingHours + ' hours' } })

      doc[i].patch(patches, function (err, wo) {
        if (err) {
          console.log(err)
        } else {
          // Customer
          let isFICustomer = process.env.HODA_FI_SEND_MAIL_TO_CUSTOMER || 'TRUE'
          let isNOCustomer = process.env.HODA_NO_SEND_MAIL_TO_CUSTOMER || 'TRUE'

          if ((isNOCustomer && wo.country === 'NO') || (isFICustomer && wo.country === 'FI')) {
            sendMail(wo/*  */, wo.country, wo.app, 'CUSTOMER', false)

            // Customer Service - FI
            let isFICustomerService = process.env.HODA_FI_SEND_MAIL_TO_CUSTOMER_SERVICE_TEAM || 'TRUE'
            if (isFICustomerService === 'TRUE' && wo.country === 'FI') {
              sendMail(wo, wo.country, wo.app, 'CS', false)
            }
          }
        }
      })
    }
    if (count === doc.length) {
      resolve('No of Wo updated: ' + count)
    }
  })
}
