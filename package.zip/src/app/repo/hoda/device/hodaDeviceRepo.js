import { consoleLogger } from './../../../../app/helpers/logger/log'
import { CompleteProcess } from './../../../../app/helpers/utilities/utility'
let Client = require('node-rest-client').Client

export function getCharger (req, res) {
  try {
    if (req.query.unitId === undefined) {
      let message = { 'error': 'unitId is required' }
      CompleteProcess(req, res, message, 400)
    } else {
      if (req.role === 'INSTALLER') {
        let url = req.tingcore
        let companyId = 'Fortum Norway'
        let token = (req.header('Authorization') !== undefined) ? req.header('Authorization') : ''
        if (req.country === 'FI') {
          companyId = 'Fortum Finland'
        }

        var client = new Client()
        var args = {
          headers: { 'Authorization': token } // request headers
        }

        url = url + '/api/v1/chargers?unitId=' + req.query.unitId + '&companyId=' + companyId
        client.get(url, args, function (data, response) {
          if (response.statusCode === 200) {
            CompleteProcess(req, res, data, 200)
          } else {
            CompleteProcess(req, res, data, response.statusCode)
          }
        })
      } else {
        let message = { 'error': 'Not allowed role' }
        CompleteProcess(req, res, message, 413)
      }
    }
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-DEVICE-CHARGER-GET')
  }
}

export function deviceMapping (chargerId, req, res) {
  try {
    if (req.role === 'INSTALLER') {
      let url = req.tingcore
      let companyId = 'Fortum Norway'
      let token = (req.header('Authorization') !== undefined) ? req.header('Authorization') : ''
      if (req.country === 'FI') {
        companyId = 'Fortum Finland'
      }

      var client = new Client()
      var args = {
        data: {
          'companyId': companyId,
          'contractId': req.body.contractId,
          'chargerId': chargerId
        },
        headers: { 'Accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': token } // request headers
      }

      url = url + '/api/v1/mappings'
      client.post(url, args, function (data, response) {
        if (response.statusCode === 200) {
          CompleteProcess(req, res, data, 200)
        } else {
          CompleteProcess(req, res, data, response.statusCode)
        }
      })
    } else {
      let message = { 'error': 'Not allowed role' }
      CompleteProcess(req, res, message, 413)
    }
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-DEVICE-PAIRING-POST')
  }
}

export function deleteMapping (chargerId, req, res) {
  try {
    if (req.role === 'INSTALLER') {
      let url = req.tingcore
      let token = (req.header('Authorization') !== undefined) ? req.header('Authorization') : ''

      var client = new Client()
      var args = {
        data: {
        },
        headers: { 'Accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': token } // request headers
      }

      url = url + '/api/v1/mappings/' + chargerId
      client.delete(url, args, function (data, response) {
        if (response.statusCode === 200) {
          CompleteProcess(req, res, data, 200)
        } else {
          CompleteProcess(req, res, data, response.statusCode)
        }
      })
    } else {
      let message = { 'error': 'Not allowed role' }
      CompleteProcess(req, res, message, 413)
    }
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-DEVICE-PAIRING-POST')
  }
}
