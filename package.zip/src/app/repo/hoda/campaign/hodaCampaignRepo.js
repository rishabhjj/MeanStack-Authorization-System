import { consoleLogger } from './../../../../app/helpers/logger/log'
import { CompleteProcess } from './../../../../app/helpers/utilities/utility'

export function setQuery (req, res, next) {
  var query = {}
  if (req.query._id !== undefined) { query._id = req.query._id }
  if (req.query.campaignId !== undefined) { query.campaignId = req.query.campaignId }

  query.country = req.country
  query.app = req.app
  req.filterCondition = query
  next()
}

export function getCampaigns (Campaign, req, res) {
  try {
    Campaign.find(req.filterCondition, '-__v', function (err, doc) {
      if (err) {
        if (err.name === 'CastError' && err.path === '_id') {
          let response = []
          CompleteProcess(req, res, response, 200)
        } else {
          CompleteProcess(req, res, err, 417)
        }
      } else {
        CompleteProcess(req, res, doc, 200)
      }
    }).sort({ sequence: 1 })
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-CAMPAIGN-GET')
  }
}

export function createCampaign (Campaign, req, res) {
  try {
    if (req.role === 'BUSINESS') {
      req.query.campaignId = req.body.campaignId
      if (req.query.campaignId !== undefined) {
        Campaign.find(req.query, '-__v', function (err, campaignPackage) {
          if (err) { res.status(417).send('Error occured...') } else {
            if (campaignPackage.length > 0) {
              let info = 'Campaign: ' + req.body.campaignId + ' already exists'
              CompleteProcess(req, res, { 'error': info }, 417)
            } else {
              let campaign = new Campaign(req.body)
              campaign.country = req.country
              campaign.app = req.app
              if (req.country === 'NO' && req.body.kWhPerMonth === undefined) {
                campaign.kWhPerMonth = 0
              }

              campaign.save(function (err) {
                if (err) {
                  CompleteProcess(req, res, err, 417)
                } else {
                  CompleteProcess(req, res, campaign, 201)
                }
              })
            }
          }
        })
      } else {
        res.status(400).send()
      }
    } else {
      res.status(403).send({ 'info': 'Invalid role' })
    }
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-CAMPAIGN-POST')
  }
}

export function updateCampaign (Campaign, req, res) {
  try {
    let patches = req.body
    patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })

    if (req.role === 'BUSINESS') {
      if (req.params.id !== undefined) {
        Campaign.findById(req.params.id, '-__v', function (err, campaign) {
          if (err) {
            if (err.name === 'CastError' && err.path === '_id') {
              CompleteProcess(req, res, {}, 404)
            } else {
              CompleteProcess(req, res, err, 417)
            }
          } else {
            if (campaign === null) {
              CompleteProcess(req, res, {}, 404)
            } else {
              if (req.country === campaign.country && req.app === campaign.app) {
                campaign.patch(patches, function (err, doc) {
                  if (err) {
                    CompleteProcess(req, res, err, 417)
                  } else {
                    CompleteProcess(req, res, doc, 202)
                  }
                })
              } else {
                let info = { 'error': 'Country or App is not matching' }
                CompleteProcess(req, res, info, 403)
              }
            }
          }
        })
      } else {
        res.status(400).send({ 'info': '_id is missing' })
      }
    } else {
      res.status(403).send({ 'info': 'Invalid role' })
    }
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-CAMPAIGN-PATCH')
  }
}
