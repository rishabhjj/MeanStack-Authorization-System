import Campaign from './../../../models/hoda/hodaCampaignModel'

export function getCampaignById (id, country,app) {
  return new Promise((resolve, reject) => {
    let query = {}
    query.country = country
    query.app = app
    query.campaignId = id

    Campaign.find(query, '-__v', function (err, doc) {
      if (err) {
        reject(err)
      } else {
        resolve(doc)
      }
    })
  })
}
