let archival = require('../../../helpers/archival/archive')
let logger = require('../../../helpers/logger/log')

export const setQuery = (req, res, next) => {
  var query = {}
  if (req.query._id !== undefined) { query._id = req.query._id }
  if (req.query.code !== undefined) { query.code = req.query.code }

  query.country = req.country
  query.app = req.app
  req.filterCondition = query
  next()
}

export const getPostalCode = (PostalCode, req, res) => {
  try {
    PostalCode.find(req.filterCondition, '-__v', function (err, doc) {
      if (err) {
        if (err.name === 'CastError' && err.path === '_id') {
          let response = []
          archival.log(req.archival, {}, 200, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(200).send(response)
        } else {
          archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(417).send(err)
        }
      } else {
        archival.log(req.archival, doc, 200, req.env, req.processName, req.receivedTime, req.requestId)
        if (doc.length > 0) {
          res.status(200).send({ 'isAllowed': 1 })
        } else {
          res.status(200).send({ 'isAllowed': 0 })
        }
      }
    })
  } catch (err) {
    logger.error(req, res, err, 'VODA-POSTAL-CODE-GET')
  }
}

export const savePostalCode = (PostalCode, req, res) => {
  try {
    if (req.role === 'BUSINESS') {
      req.query.code = req.body.code
      if (req.query.code !== undefined) {
        PostalCode.find(req.query, '-__v', function (err, data) {
          if (err) { res.status(417).send('Error occured...') } else {
            if (data.length > 0) {
              let info = 'PostalCode: ' + req.body.code + ' already exists'
              archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
              res.status(417).send({ 'error': info })
            } else {
              let data = new PostalCode(req.body)
              data.country = req.country
              data.app = req.app

              let postalCode = new PostalCode(data)
              postalCode.save(function (err) {
                if (err) {
                  archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
                  res.status(417).send(err)
                } else {
                  archival.log(req.archival, postalCode, 201, req.env, req.processName, req.receivedTime, req.requestId)
                  res.status(201).send(postalCode)
                }
              })
            }
          }
        })
      } else {
        res.status(400).send()
      }
    } else {
      res.status(403).send({ 'info': 'Invalid role' })
    }
  } catch (err) {
    logger.error(req, res, err, 'VODA-POSTAL-CODE-POST')
  }
}

export const getPostalCodeList = (PostalCode, req, res) => {
  try {
    if (req.role === 'BUSINESS') {
      let query = {}
      query.country = req.country
      query.app = req.app

      PostalCode.find(query, { __v: 0 }, function (err, doc) {
        if (err) {
          archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(417).send(err)
        } else {
          archival.log(req.archival, doc, 200, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(200).send(doc)
        }
      })
    } else {
      res.status(403).send({ 'info': 'Invalid role' })
    }
  } catch (err) {
    logger.error(req, res, err, 'VODA-POSTAL-CODE-LIST-GET')
  }
}

export const deletePostalCode = (PostalCode, req, res) => {
  try {
    if (req.role === 'BUSINESS') {
      if (req.params.id !== undefined) {
        let query = {}
        query.country = req.country
        query.app = req.app
        query.code = req.params.id

        PostalCode.remove(query, function (err, pc) {
          if (err) {
            archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
            res.status(417).send(err)
          } else {
            let info = { 'info': 'postal code is: ' + req.query.code + 'removed' }
            archival.log(req.archival, info, 204, req.env, req.processName, req.receivedTime, req.requestId)
            res.status(204).send(info)
          }
        })
      } else {
        res.status(400).send({ 'info': 'code is missing' })
      }
    } else {
      res.status(403).send({ 'info': 'Invalid role' })
    }
  } catch (err) {
    logger.error(req, res, err, 'VODA-POSTAL-CODE-DELETE')
  }
}

export const updatePostalCode = (PostalCode, req, res) => {
  try {
    let patches = req.body
    patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })

    if (req.role === 'BUSINESS') {
      if (req.params.id !== undefined) {
        PostalCode.findById(req.params.id, '-__v', function (err, pc) {
          if (err) {
            if (err.name === 'CastError' && err.path === '_id') {
              archival.log(req.archival, {}, 404, req.env, req.processName, req.receivedTime, req.requestId)
              res.status(404).send()
            } else {
              archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
              res.status(417).send(err)
            }
          } else {
            if (pc == null) {
              archival.log(req.archival, {}, 404, req.env, req.processName, req.receivedTime, req.requestId)
              res.status(404).send()
            } else {
              if (req.country === pc.country && req.app === pc.app) {
                pc.patch(patches, function (err, doc) {
                  if (err) {
                    archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
                    res.status(417).send(err)
                  } else {
                    archival.log(req.archival, doc, 202, req.env, req.processName, req.receivedTime, req.requestId)
                    res.status(202).send(doc)
                  }
                })
              } else {
                let info = { 'error': 'Country or App is not matching' }
                archival.log(req.archival, info, 403, req.env, req.processName, req.receivedTime, req.requestId)
                res.status(403).send(info)
              }
            }
          }
        })
      } else {
        res.status(400).send({ 'info': 'code is missing' })
      }
    } else {
      res.status(403).send({ 'info': 'Invalid role' })
    }
  } catch (err) {
    logger.error(req, res, err, 'VODA-POSTAL-CODE-PATCH')
  }
}
