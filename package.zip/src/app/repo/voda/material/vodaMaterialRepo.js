import { log } from './../../../helpers/archival/archive'
import { error } from './../../../helpers/logger/log'

export const setQuery = (req, res, next) => {
  var query = {}
  if (req.query._id !== undefined) { query._id = req.query._id }
  if (req.query.materialId !== undefined) { query.materialId = req.query.materialId }

  query.country = req.country
  query.app = req.app
  req.filterCondition = query
  next()
}

export const getVodaMaterial = (Material, req, res) => {
  try {
    Material.find(req.filterCondition, '-__v', function (err, doc) {
      if (err) {
        if (err.name === 'CastError' && err.path === '_id') {
          let response = []
          log(req.archival, {}, 200, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(200).send(response)
        } else {
          log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(417).send(err)
        }
      } else {
        log(req.archival, doc, 200, req.env, req.processName, req.receivedTime, req.requestId)
        res.json(doc)
      }
    })
  } catch (err) {
    error(req, res, err, 'VODA-MATERIAL-GET')
  }
}

export const saveVodaMaterial = (VMaterial, req, res) => {
  req.query.materialId = req.body.materialId
  VMaterial.find(req.query, '-__v', function (err, data) {
    try {
      if (err) { res.status(417).send('Error occured...') } else
      if (data.length > 0) {
        let info = 'Material ID: ' + req.body.materialId + ' already exists'
        log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
        res.status(417).send({ 'error': info })
      } else {
        let data = new VMaterial(req.body)
        data.country = req.country
        data.app = req.app
        data.createdOn = new Date()
        data.modifiedOn = new Date()

        let material = new VMaterial(data)
        material.save(function (err) {
          if (err) {
            log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
            res.status(417).send(err)
          } else {
            log(req.archival, material, 201, req.env, req.processName, req.receivedTime, req.requestId)
            res.status(201).send(material)
          }
        })
      }
    } catch (err) {
      error(req, res, err, 'VODA-MATERIAL-POST')
    }
  })
}

export const deleteVodaMaterial = (Material, req, res) => {
  try {
    if (req.headers.token !== undefined && req.headers.token === 'A88D982A-FC81-4EA9-BEB3-189AA0808B78') {
      Material.remove(req.filterCondition, function (err, logs) {
        if (err) {
          log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(417).send(err)
        } else {
          let info = { 'info': 'Removed' }
          log(req.archival, info, 204, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(204).send(info)
        }
      })
    } else {
      let info = { 'error': 'Not allowed' }
      log(req.archival, info, 401, req.env, req.processName, req.receivedTime, req.requestId)
      res.status(401).send()
    }
  } catch (err) {
    error(req, res, err, 'VODA-MATERIAL-DELETE')
  }
}

export const updateVodaMaterial = (Material, Audit, id, req, res) => {
  try {
    let patches = req.body
    patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })

    Material.findById(id, '-__v', function (err, material) {
      if (err) {
        if (err.name === 'CastError' && err.path === '_id') {
          log(req.archival, {}, 404, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(404).send()
        } else {
          log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(417).send(err)
        }
      } else {
        if (req.country === material.country && req.app === material.app) {
          if (material == null) {
            log(req.archival, {}, 404, req.env, req.processName, req.receivedTime, req.requestId)
            res.status(404).send()
          } else {
            material.patch(patches, function (err, doc) {
              if (err) {
                log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
                res.status(417).send(err)
              } else {
                // Logging into Audit
                var data = new Audit()
                data.docName = 'Material'
                data.docId = material._id
                data.userId = req.user
                data.process = 'VODA'
                data.info = patches
                data.country = req.country
                data.app = req.app
                var audit = new Audit(data)
                audit.save()
                log(req.archival, doc, 202, req.env, req.processName, req.receivedTime, req.requestId)
                res.status(202).send(doc)
              }
            })
          }
        } else {
          let info = { 'error': 'Country or App is not matching' }
          log(req.archival, info, 403, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(403).send(info)
        }
      }
    })
  } catch (err) {
    error(req, res, err, 'VODA-MATERIAL-PATCH')
  }
}
