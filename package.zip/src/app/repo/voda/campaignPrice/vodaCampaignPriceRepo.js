import { consoleLogger } from './../../../helpers/logger/log'
import { CompleteProcess } from './../../../../app/helpers/utilities/utility'

export function setQuery (req, res, next) {
  var query = {}
  if (req.query._id !== undefined) { query._id = req.query._id }

  query.country = req.country
  query.app = req.app
  query.campaign = 'Current'
  req.filterCondition = query
  next()
}

export function getCampaignPrice (CampaignPrice, req, res) {
  try {
    CampaignPrice.find(req.filterCondition, { __v: 0, campaign: 0, _id: 0 }, function (err, doc) {
      if (err) {
        if (err.name === 'CastError' && err.path === '_id') {
          let response = []
          CompleteProcess(req, res, response, 200)
        } else {
          CompleteProcess(req, res, err, 417)
        }
      } else {
        CompleteProcess(req, res, doc, 200)
      }
    })
  } catch (err) {
    consoleLogger(req, res, err, 'VODA-CAMPAIGN-PRICE-GET')
  }
}

export function createCampaignPrice (CampaignPrice, req, res) {
  req.query.campaign = 'Current'
  CampaignPrice.find(req.query, '-__v', function (err, data) {
    try {
      if (err) { res.status(417).send('Error occured...') } else
      if (data.length > 0) {
        let info = 'CampaignPrice already exists and use Patch action if you want update pricing'
        CompleteProcess(req, res, { 'error': info }, 417)
      } else {
        let data = new CampaignPrice(req.body)
        data.country = req.country
        data.app = req.app
        data.modifiedOn = new Date()

        let campaignPrice = new CampaignPrice(data)
        campaignPrice.save(function (err) {
          if (err) {
            CompleteProcess(req, res, err, 417)
          } else {
            CompleteProcess(req, res, campaignPrice, 201)
          }
        })
      }
    } catch (err) {
      consoleLogger(req, res, err, 'VODA-CAMPAIGN-PRICE-POST')
    }
  })
}

export function updateCampaignPrice (CampaignPrice, Audit, req, res) {
  try {
    let patches = req.body
    patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })

    CampaignPrice.find(req.query, '-__v', function (err, campaign) {
      if (err) {
        CompleteProcess(req, res, err, 417)
      } else {
        if (campaign.length > 0) {
          if (req.country === campaign[0].country && req.app === campaign[0].app && (req.headers.token !== undefined && req.headers.token === 'fa65c133-e735-39d4-b509-5dmfe71d7a63')) {
            campaign[0].patch(patches, function (err, doc) {
              if (err) {
                CompleteProcess(req, res, err, 417)
              } else {
                CompleteProcess(req, res, doc, 202)
              }
            })
          } else {
            let info = { 'error': 'Token / Country / App is not matching' }
            CompleteProcess(req, res, info, 403)
          }
        } else {
          CompleteProcess(req, res, {}, 404)
        }
      }
    })
  } catch (err) {
    consoleLogger(req, res, err, 'VODA-CAMPAIGN-PRICE-PATCH')
  }
}
