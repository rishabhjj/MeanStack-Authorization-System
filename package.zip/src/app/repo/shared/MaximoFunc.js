import { error } from './../../helpers/logger/log'
import Maximo from './../../models/shared/iMaximoModel'

function getStaticData (country) {
  return new Promise((resolve, reject) => {
    try {
      let data = {}

      let env = process.env.ENV || 'TEST'
      if (country === 'FI') {
        data.orgId = 'CSEUR'
        data.siteId = 'CSFI'
      } else if (country === 'SE') {
        data.orgId = 'CSSEK'
        data.siteId = 'CSSV'
      } else if (country === 'NO') {
        data.orgId = 'CSPLN'
        data.siteId = 'CSPL'
      } else if (country === 'PL') {
        data.orgId = 'CSNOK'
        data.siteId = 'CSNOK'
      }
      data.classStructureId = env === 'PROD' ? '4859' : '4859'
      resolve(data)
    } catch (err) {
      error(undefined, undefined, err, 'FUNC-STATIC-DATA')
      reject(new Error('something went wrong...FUNC-STATIC-DATA '))
    }
  })
}

export function transformData (wo, country, app) {
  return new Promise((resolve, reject) => {
    try {
      let data = {
        'orgId': undefined,
        'siteId': undefined,
        'classStructureId': undefined,
        'streetName': undefined,
        'city': undefined,
        'postalCode': undefined,
        'country': country,
        'app': app,
        'addressCode': undefined

      }
      getStaticData(country).then((result, d = data, w = wo) => {
        data.orgId = result.orgId
        data.siteId = result.siteId
        data.classStructureId = result.classStructureId

        if (app === 'HODA') {
          data.streetName = (wo.deliverySite !== undefined && wo.deliverySite.address !== undefined && wo.deliverySite.address.street !== undefined) ? wo.deliverySite.address.street : undefined
          data.city = (wo.deliverySite !== undefined && wo.deliverySite.address !== undefined && wo.deliverySite.address.city !== undefined) ? wo.deliverySite.address.city : undefined
          data.postalCode = (wo.deliverySite !== undefined && wo.deliverySite.address !== undefined && wo.deliverySite.address.zip !== undefined) ? wo.deliverySite.address.zip : undefined
          data.addressCode = (wo.deliverySite !== undefined && wo.deliverySite.deliverySiteId !== undefined) ? wo.deliverySite.deliverySiteId : undefined
        } else if (app === 'VODA') {

        }
        resolve(data)
      }).catch(error => {
        error(undefined, undefined, error, 'FUNC-TRANSFORM-DATA')
        reject(new Error('something went wrong...FUNC-TRANSFORM-DATA '))
      })
    } catch (err) {
      error(undefined, undefined, error, 'FUNC-TRANSFORM-DATA')
      reject(new Error('something went wrong...FUNC-TRANSFORM-DATA '))
    }
  })
}

export function createServiceAddress (workorder, country, app) {
  return new Promise((resolve, reject) => {
    try {
      transformData(workorder, country, app).then((inbound) => {
        let maximo = new Maximo({
          'common': {
            'orgId': inbound.orgId,
            'siteId': inbound.siteId,
            'classStructureId': inbound.classStructureId
          },
          'serviceAddress': {
            inbound
          },
          'country': inbound.country,
          'app': inbound.app
        })
        maximo.save(function (err) {
          if (err) {
            reject(new Error(err))
          } else {
            resolve(maximo)
          }
        })
      }).catch(error => {
        error(undefined, undefined, error, 'FUNC-TRANSFORM-DATA')
        reject(new Error('something went wrong...FUNC-TRANSFORM-DATA '))
      })
    } catch (err) {
      error(undefined, undefined, err, 'FUNC-MAXIMO-CREATE-SERVICEADDRESS')
    }
  })
}

/*
export function createLocation (workorder, country, app) {
  return new Promise((resolve, reject) => {
    try {
      transformData(workorder, country, app).then((inbound) => {
        let maximo = new Maximo({
          'serviceAddress': {
            inbound
          },
          'country': inbound.country,
          'app': inbound.app
        })
        maximo.save(function (err) {
          if (err) {
            reject(new Error(err))
          } else {
            resolve(maximo)
          }
        })
      }).catch(error => {
        error(undefined, undefined, error, 'FUNC-TRANSFORM-DATA')
        reject(new Error('something went wrong...FUNC-TRANSFORM-DATA '))
      })
    } catch (err) {
      error(undefined, undefined, err, 'FUNC-MAXIMO-CREATE-SERVICEADDRESS')
    }
  })
}
*/
