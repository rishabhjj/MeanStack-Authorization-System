import { consoleLogger } from './../../../app/helpers/logger/log'
import { CompleteProcess } from './../../../app/helpers/utilities/utility'

export function getItemsOfCampaign (item, hodaCampaign, req, res) {
  try {
    if (req.params.id !== undefined) {
      let query = {}
      query.campaignId = req.params.id
      let data = {
        'basic': [],
        'optional': []
      }
      let basic = getItems(item, hodaCampaign, req.params.id, 'HODA', 'Basic')
        .then(result => {
          data.basic = result
        })
        .catch(err => {
          CompleteProcess(req, res, { 'info': err.message }, 417)
        })

      let optional = getItems(item, hodaCampaign, req.params.id, 'HODA', 'Optional')
        .then(result => {
          data.optional = result
        })
        .catch(err => {
          CompleteProcess(req, res, { 'info': err.message }, 417)
        })

      Promise.all([basic, optional]).then(() => {
        CompleteProcess(req, res, data, 200)
      })
    } else {
      res.status(400).send({ 'info': 'Campaign ID is missing' })
    }
  } catch (err) {
    consoleLogger(req, res, err, 'CAMPAIGN-ITEMS-GET')
  }
}

function getItems (item, campaign, campaignId, app, type = 'Basic') {
  return new Promise((resolve, reject) => {
    let query = {}
    query.campaignId = campaignId
    let items = []
    if (app === 'HODA') {
      campaign.find(query, '-__v', function (err, doc) {
        if (err) {
          reject(err)
        } else {
          if (doc.length > 0) {
            let fields = { '_id': 1, 'itemServiceNumber': 1, 'description': 1, 'itemType': 1, 'isAssetNumber': 1 }

            if (type === 'Basic') {
              if (doc[0].installation !== undefined && doc[0].installation.basic !== undefined &&
                                doc[0].installation.basic.services.length > 0) {
                for (let i = 0; i < doc[0].installation.basic.services.length; i++) {
                  items.push(doc[0].installation.basic.services[i].serviceItemId)
                }
              }

              if (doc[0].installation !== undefined && doc[0].installation.basic !== undefined &&
                                doc[0].installation.basic.items.length > 0) {
                for (let i = 0; i < doc[0].installation.basic.items.length; i++) {
                  items.push(doc[0].installation.basic.items[i].itemId)
                }
              }
            } else {
              fields = { '_id': 1, 'itemServiceNumber': 1, 'description': 1, 'itemType': 1, 'orderUnit': 1, 'unitCost': 1, 'currency': 1, 'isAssetNumber': 1 }
              if (doc[0].installation !== undefined && doc[0].installation.optional !== undefined &&
                                doc[0].installation.optional.services.length > 0) {
                for (let i = 0; i < doc[0].installation.optional.services.length; i++) {
                  items.push(doc[0].installation.optional.services[i].serviceItemId)
                }
              }

              if (doc[0].installation !== undefined && doc[0].installation.optional !== undefined &&
                                doc[0].installation.optional.items.length > 0) {
                for (let i = 0; i < doc[0].installation.optional.items.length; i++) {
                  items.push(doc[0].installation.optional.items[i].itemId)
                }
              }
            }

            item.find({ itemServiceNumber: { $in: items } }, fields, function (err, doc) {
              if (err) {
                if (err.name === 'CastError' && err.path === '_id') {
                  let response = []
                  resolve(response)
                } else {
                  reject(err)
                }
              } else {
                resolve(doc)
              }
            })
          } else {
            resolve(items)
          }
        }
      })
    } else {
      throw new Error('Not supported')
    }
  })
}
