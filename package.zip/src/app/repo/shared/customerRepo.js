import { consoleLogger } from './../../../app/helpers/logger/log'
import { CompleteProcess } from './../../../app/helpers/utilities/utility'
let Client = require('node-rest-client').Client

export function getCustomer (req, res) {
  try {
    if (req.query.ssn === undefined) {
      res.status(422).send()
    } else {
      let subscriptionKey = process.env.CBUS_API_MANAGMENT_KEY || 'b0bbfb0cc4b945eb928dafe41235bc78'
      let url = process.env.CBUS_API_MANAGMENT_URL || 'https://testapi.fortum.com'
      url = url + '/v2/Onlineuser?ssn=' + req.query.ssn

      var client = new Client()
      var args = {
        headers: { 'X-Request-ID': '1', 'Ocp-Apim-Subscription-Key': subscriptionKey, 'RequestingSystem': 'JODA', 'TargetSystem': 'Forum' }
      }

      client.get(url, args, function (data, response) {
        try {
          if (response.statusCode === 200) {
            if (data.forum !== undefined) {
              if (data.forum.privateCustomers.length > 0) {
                let response = { 'customerId': data.forum.privateCustomers[0].customerID }
                CompleteProcess(req, res, response, 200)
              }
            }
          } else {
            if (response.statusCode === 417 && (data.faultCode === '101' || data.faultCode === '102')) {
              let customerResponse = { 'customerId': '' }
              CompleteProcess(req, res, customerResponse, 200)
            } else {
              let fault = { 'error': data.faultMessage }
              CompleteProcess(req, res, fault, response.statusCode)
            }
          }
        } catch (err) {
          consoleLogger(req, res, err, 'CUSTOMERS-GET')
        }
      })
    }
  } catch (err) {
    consoleLogger(req, res, err, 'CUSTOMERS-GET')
  }
}

export function updateCustomer (workorder, requiredStatus, req, res) {
  try {
    req.archival = {
      'request': {
        'content': req.body,
        'headers': {
          'requestId': '',
          'country': req.header('country'),
          'app': req.header('app'),
          'user': '',
          'role': ''
        },
        'method': req.method,
        'requestUri': req.originalUrl,
        'resourceName': req.resourceName,
        'queryString': req.query
      },
      'response': {
        'statusCode': '',
        'content': {
        }
      }
    }

    let id = req.params.id
    if ((req.header('Authorization') !== undefined) && (req.header('Authorization').toLowerCase() === 'bearer fa65c133-e735-39d4-b509-5dmfe71d7a63')) {
      if (req.body.contractId !== undefined && req.body.deliverysiteId !== undefined) {
        workorder.find({ 'customer.customerId': id, status: requiredStatus }, '-__v', function (err, doc) {
          if (err) {
            CompleteProcess(req, res, err, 417)
          } else {
            if (doc.length === 0) {
              CompleteProcess(req, res, err, 404)
            } else if (doc.length > 1) {
              let response = { 'info': 'Number of workorder matched for that customer id is: ' + doc.length }
              CompleteProcess(req, res, response, 409)
            } else {
              let patches = []
              patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })
              patches.push({ 'op': 'add', 'path': '/contractId', 'value': req.body.contractId })
              patches.push({ 'op': 'add', 'path': '/deliverySite/deliverysiteId', 'value': req.body.deliverysiteId })

              if (req.app === 'VODA') {
                patches.push({ 'op': 'add', 'path': '/notes/', 'value': { 'createdBy': 'BizTalk Integration', 'note': 'Updated Contract & DeliverySite ID' } })
              } else if (req.app === 'HODA') {
                if (req.body.contractSeqNo !== undefined) {
                  patches.push({ 'op': 'add', 'path': '/contractSeqNo', 'value': req.body.contractSeqNo })
                }
                patches.push({ 'op': 'add', 'path': '/customerServiceNotes/', 'value': { 'createdBy': 'BizTalk Integration', 'note': 'Updated Contract, Contract Seq. No. & DeliverySite ID' } })
              }

              doc[0].patch(patches, function (err, wo) {
                if (err) {
                  CompleteProcess(req, res, err, 417)
                } else {
                  CompleteProcess(req, res, {}, 204)
                }
              })
            }
          }
        })
      } else {
        CompleteProcess(req, res, {}, 400)
      }
    } else {
      CompleteProcess(req, res, {}, 403)
    }
  } catch (err) {
    consoleLogger(req, res, err, 'CUSTOMER-PATCH')
  }
}
