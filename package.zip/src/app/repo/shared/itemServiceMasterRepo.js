import { error, consoleLogger } from './../../../app/helpers/logger/log'
import { CompleteProcess } from './../../../app/helpers/utilities/utility'
import request from 'superagent-es6-promise'

export function setQuery (req, res, next) {
  try {
    if (req.method !== 'OPTIONS') {
      var query = {}
      if (req.query._id !== undefined) { query._id = req.query._id }
      if (req.query.status !== undefined) { query.status = req.query.status }
      if (req.query.itemType !== undefined) { query.itemType = req.query.itemType }

      query.country = req.country
      query.app = req.app
      req.filterCondition = query
      if (req.header('Token') !== undefined && req.header('Token') === 'fff65c133-yu35-32d4-t509-5335vfg4552-234ddf3') {
        next()
      } else {
        let err = { 'message': 'Not Allowed' }
        error(req, res, err, 'ITEMS')
      }
    } else {
      next()
    }
  } catch (err) {
    error(req, res, err, 'ITEMS')
  }
}

export function getItems (item, req, res) {
  try {
    item.find(req.filterCondition, '-__v', function (err, doc) {
      if (err) {
        if (err.name === 'CastError' && err.path === '_id') {
          let response = []
          CompleteProcess(req, res, response, 200)
        } else {
          CompleteProcess(req, res, err, 417)
        }
      } else {
        CompleteProcess(req, res, doc, 200)
      }
    })
  } catch (err) {
    consoleLogger(req, res, err, 'ITEMS-GET')
  }
}

export function createItem (Item, req, res) {
  try {
    req.query.itemServiceNumber = req.body.itemServiceNumber
    if (req.query.itemServiceNumber !== undefined) {
      Item.find(req.query, '-__v', function (err, item) {
        if (err) { res.status(417).send('Error occured...') } else {
          if (item.length > 0) {
            let info = 'Item or Service Item: ' + req.body.itemServiceNumber + ' already exists'
            CompleteProcess(req, res, { 'error': info }, 417)
          } else {
            let item = new Item(req.body)
            item.country = req.country
            item.app = req.app
            item.createdOn = new Date()
            item.modifiedOn = new Date()
            item.save(function (err) {
              if (err) {
                CompleteProcess(req, res, err, 417)
              } else {
                CompleteProcess(req, res, item, 201)
              }
            })
          }
        }
      })
    }
  } catch (err) {
    consoleLogger(req, res, err, 'ITEM-POST')
  }
}

export function syncItems (item, req, res) {
  getMaximoItems(item, req, res)
    .then((result, Item = item, i = req, j = res) => {
      // loop the result and insert into DB if it is not available
      let body = JSON.parse(result.text)

      for (let n = 0; n < body.length; n++) {
        let query = { itemServiceNumber: body[n].itemNumber }

        Item.find(query, '-__v', function (err, doc) {
          if (err) {
          } else {
            if (doc.length > 0) {
              console.log(doc[0].itemServiceNumber + 'is already avaialble')
            } else {
              //      console.log('NOT AVAILABLE: ' + query.itemServiceNumber)
            }
          }
        })
      }

      CompleteProcess(req, res, body, 200)
    }).catch((error, i = req, j = res) => {
      CompleteProcess(req, res, error.body, error.status)
    })
}
function getMaximoItems (req, res) {
  return new Promise((resolve, reject) => {
    try {
      let azureAPIRootURL = process.env.CBUS_API_MANAGMENT_URL || 'https://testapi.fortum.com'
      //    let azureAPI = azureAPIRootURL + '/maximo/v1/MasterData'
      // statusDate=2018-01-04

      let today = new Date()
      let year = today.getFullYear()
      let month = today.getMonth() + 1
      let date = today.getDate()
      let statusDate = year + '-' + month + '-' + date
      // statusDate format is YYYY-MM-DD
    //  statusDate = '2018-01-04'
      let azureAPI = azureAPIRootURL + '/maximo/v1/MasterData?statusDate=' + statusDate
      let azureKey = process.env.CBUS_API_MANAGMENT_KEY || '3f7b92e86ed64d6193aec0f73704a545'
      let id = Math.floor((Math.random() * 1222222222200) + 1)

      request
        .get(azureAPI)
        .set('RequestId', id)
        .set('Ocp-Apim-Subscription-Key', azureKey)
        .set('RequestingSystem', 'JODA')
        .set('TargetSystem', 'MAXIMO')
        .set('Content-Type', 'application/json')
        .set('Accept', 'application/json')
        .then(function (res) {
          resolve(res)
        }, function (error) {
          reject(error)
        })
    } catch (err) {
      consoleLogger(req, res, err, 'ITEM-SYNC')
    }
  })
}
