import { error, consoleLogger } from './../../../app/helpers/logger/log'
import { CompleteProcess } from './../../../app/helpers/utilities/utility'

export function setQuery (req, res, next) {
  try {
    var query = {}
    if (req.query._id !== undefined) { query._id = req.query._id }

    query.country = req.country
    query.app = req.app
    req.filterCondition = query
    next()
  } catch (err) {
    error(req, res, err, 'PAYMENT-TYPES-GET')
  }
}

export function getPaymentTypes (paymentType, req, res) {
  try {
    paymentType.find(req.filterCondition, '-__v', function (err, doc) {
      if (err) {
        if (err.name === 'CastError' && err.path === '_id') {
          let response = []
          CompleteProcess(req, res, response, 200)
        } else {
          CompleteProcess(req, res, err, 417)
        }
      } else {
        CompleteProcess(req, res, doc, 200)
      }
    })
  } catch (err) {
    consoleLogger(req, res, err, 'PAYMENT-TYPES-GET')
  }
}

export function createPaymentType (PaymentType, req, res) {
  try {
    if (req.role === 'BUSINESS') {
      let paymentType = new PaymentType(req.body)
      paymentType.country = req.country
      paymentType.app = req.app
      paymentType.createdOn = new Date()
      paymentType.modifiedOn = new Date()

      if (req.body.fullPayment !== undefined && req.body.installments !== undefined && req.body.subscription !== undefined) {
        let query = {}
        query.country = req.country
        query.app = req.app

        if (req.body.installments.length > 0 && req.body.installmentsComponents === undefined) {
          let message = { 'error': 'Installments Components can not be empty when Installment is allowed' }
          CompleteProcess(req, res, message, 400)
        } else {
          PaymentType.remove(query, function (err, pt) {
            if (err) {
              CompleteProcess(req, res, err, 417)
            } else {
              paymentType.save(function (err) {
                if (err) {
                  CompleteProcess(req, res, err, 417)
                } else {
                  CompleteProcess(req, res, paymentType, 201)
                }
              })
            }
          })
        }
      } else {
        CompleteProcess(req, res, {}, 400)
      }
    } else {
      res.status(403).send({ 'info': 'Invalid role' })
    }
  } catch (err) {
    consoleLogger(req, res, err, 'PAYMENT-TYPES-POST')
  }
}

export function updatePaymentType (paymentType, req, res) {
  try {
    let patches = req.body
    patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })

    if (req.role === 'BUSINESS') {
      if (req.params.id !== undefined) {
        paymentType.findById(req.params.id, '-__v', function (err, pt) {
          if (err) {
            if (err.name === 'CastError' && err.path === '_id') {
              CompleteProcess(req, res, {}, 404)
            } else {
              CompleteProcess(req, res, err, 417)
            }
          } else {
            if (pt === null) {
              CompleteProcess(req, res, {}, 404)
            } else {
              if (req.country === pt.country && req.app === pt.app) {
                pt.patch(patches, function (err, doc) {
                  if (err) {
                    CompleteProcess(req, res, err, 417)
                  } else {
                    CompleteProcess(req, res, doc, 202)
                  }
                })
              } else {
                let info = { 'error': 'Country or App is not matching' }
                CompleteProcess(req, res, info, 403)
              }
            }
          }
        })
      } else {
        res.status(400).send({ 'info': '_id is missing' })
      }
    } else {
      res.status(403).send({ 'info': 'Invalid role' })
    }
  } catch (err) {
    consoleLogger(req, res, err, 'HODA-PAYMENT-TYPES-PATCH')
  }
}
