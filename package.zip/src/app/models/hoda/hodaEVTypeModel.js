let mongoose = require('mongoose')
let Schema = mongoose.Schema
let patcher = require('mongoose-json-patch')

let HODAEVTypeModel = new Schema({
  evId: { type: String },
  type: { type: String },
  years: { type: [String] },
  country: { type: String, enum: ['NO'], default: 'NO' },
  app: { type: String, enum: ['HODA'], default: 'HODA' },
  modifiedOn: { type: Date },
  createdOn: { type: Date, default: Date.now }
})

HODAEVTypeModel.plugin(patcher)

module.exports = mongoose.model('HODA-EV-Type', HODAEVTypeModel)
