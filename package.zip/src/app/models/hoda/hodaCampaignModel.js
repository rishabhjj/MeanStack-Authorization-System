import mongoose from 'mongoose'
import patcher from 'mongoose-json-patch'

let Schema = mongoose.Schema

let nameSchema = new Schema({
  _id: false,
  en_GB: { type: String },
  fi_FI: { type: String },
  sv_FI: { type: String },
  sv_SE: { type: String },
  nb_NO: { type: String },
  nn_NO: { type: String },
  pl_PL: { type: String }
})

let chargingStationSchema = new Schema({
  _id: false,
  modelOfChargingStation: { type: nameSchema },
  description: { type: nameSchema },
  cableLength: { type: String },
  charing: { type: String },
  voltage: { type: String },
  plug: { type: String },
  weight: { type: String },
  ipCode: { type: String },
  light: { type: String },
  url: { type: String }
})

let buySchema = new Schema({
  _id: false,
  material: { type: Number },
  installation: { type: Number }
})

let pricingSchema = new Schema({
  _id: false,
  subscription: { type: Number },
  buy: { type: buySchema },
  currency: { type: String, enum: ['EUR', 'Kr', 'NOK', 'PLN'] }
})

let itemSchema = new Schema({
  _id: false,
  itemId: { type: String },
  itemType: { type: String, enum: ['CHARGER', 'OTHER'], default: 'OTHER' }
})

let serviceItemSchema = new Schema({
  _id: false,
  serviceItemId: { type: String }
})

let ItemsandServicesSchema = new Schema({
  _id: false,
  items: { type: [itemSchema] },
  services: { type: [serviceItemSchema] }
})

let allowedItemsAndServicesSchema = new Schema({
  _id: false,
  basic: { type: ItemsandServicesSchema },
  optional: { type: ItemsandServicesSchema }
})

let HODACampaignModel = new Schema({
  campaignId: { type: String },
  campaignName: { type: String, required: [true, 'campaignName is required'] },
  kWhPerMonth: { type: Number, required: [true, 'kWhPerMonth is required'] },
  power: { type: String, required: [true, 'power is required'] },
  type: { type: String, enum: ['Type1', 'Type2', 'NoType'], required: [true, 'type is required'] },
  description: { type: nameSchema, required: [true, 'description is required'] },
  chargingStation: { type: chargingStationSchema, required: [true, 'chargingStation is required'] },
  pricing: { type: pricingSchema, required: [true, 'pricing is required'] },
  taxRebate: { type: Number },
  installation: { type: allowedItemsAndServicesSchema, required: [true, 'installation is required'] },
  additionalFeatures: { type: [nameSchema] },
  isActive: { type: Boolean, default: false },
  isVisible: { type: Boolean, default: true },
  startDate: { type: Date },
  endDate: { type: Date },
  country: { type: String, enum: ['NO', 'FI'] },
  sequence: { type: String, enum: [11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35] },
  app: { type: String, enum: ['HODA'], default: 'HODA' },
  modifiedOn: { type: Date },
  createdOn: { type: Date, default: Date.now }
})

HODACampaignModel.plugin(patcher)

module.exports = mongoose.model('HODA-Campaign', HODACampaignModel)
