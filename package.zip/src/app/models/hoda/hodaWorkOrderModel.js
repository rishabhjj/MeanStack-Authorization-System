let mongoose = require('mongoose')
let Schema = mongoose.Schema
let patcher = require('mongoose-json-patch')
let autoIncrement = require('mongoose-auto-increment')

let dbURL = process.env.MONGODB_URI || 'mongodb://heroku_7bg5gkf0:tetu942nofsj6bq4q54rl6g185@ds161518.mlab.com:61518/heroku_7bg5gkf0'

mongoose.Promise = global.Promise
let db = mongoose.connect(dbURL, { useMongoClient: true })
autoIncrement.initialize(db)

let addressSchema = new Schema({
  _id: false,
  street: { type: String, required: [true, 'Street is required'] },
  postalPlace: { type: String },
  city: { type: String, required: [true, 'City is required'] },
  zip: { type: String, required: [true, 'Zip is required'] }
})

let contactInfoSchema = new Schema({
  _id: false,
  phone: { type: String },
  email: { type: String }
})

let customerSchema = new Schema({
  _id: false,
  firstName: { type: String },
  lastName: { type: String },
  ssn: { type: String },
  customerId: { type: String },
  dateOfBirth: { type: Date },
  address: { type: addressSchema, required: [true, 'Customer Address is required'] },
  contactInfo: { type: contactInfoSchema, required: [true, 'Contact Info is required'] }
})

let deliverySiteSchema = new Schema({
  _id: false,
  deliverySiteId: { type: String },
  isDeliverySiteAddressSameAsContactAddress: { type: String, enum: ['Yes', 'No'], required: [true, 'DeliverySite Address Same As Contact Address is required field'] },
  buildingType: { type: String, enum: ['VillaOrSemiDetached', 'Other'], required: [true, 'Building Type is required field'] },
  address: { type: addressSchema }
})

let evSchema = new Schema({
  _id: false,
  type: { type: String },
  year: { type: String },
  description: { type: String }
})

let siteInfoSchema = new Schema({
  _id: false,
  totalCablingDistance: { type: Number },
  outsideCablingDistance: { type: Number },
  cabling: { type: String, enum: ['InsideOrSurface', 'Outside', 'CustomerTakesCare'] },
  groundSurface: { type: String, enum: ['OpenGround', 'Tiling', 'Tarmac'] },
  numberOfInlets: { type: Number },
  isMountingLocationAwayFromHouse: { type: Boolean },
  wallMaterial: { type: String },
  description: { type: String },
  excavation: { type: String, enum: ['fortum', 'customer'] }
})

let discountSchema = new Schema({
  _id: false,
  code: { type: String, required: [true, 'Discount Code is required field'] },
  amount: { type: Number, required: [true, 'amount is required'] },
  addedBy: { type: String }
})

let extraItemsSchema = new Schema({
  _id: false,
  itemId: { type: String, required: [true, 'Maximo Item ID is required'] },
  units: { type: Number, required: [true, 'Units is required'] },
  costPerUnit: { type: Number, required: [true, 'Cost Per Unit is required'] },
  totalAmount: { type: Number, required: [true, 'Total amount is required'] }
})

let extraServicesSchema = new Schema({
  _id: false,
  serviceItemId: { type: String, required: [true, 'Maximo Service Item ID is required'] },
  amount: { type: Number, required: [true, 'Amount is required'] },
  description: { type: String }
})

let extraItemsAndServicesSchema = new Schema({
  _id: false,
  items: { type: [extraItemsSchema] },
  services: { type: [extraServicesSchema] }
})

let installmentComponentsSchema = new Schema({
  _id: false,
  material: { type: Boolean, default: true },
  installation: { type: Boolean, default: true },
  extraMaterial: { type: Boolean, default: true },
  extraWork: { type: Boolean, default: true }
})

let buySchema = new Schema({
  _id: false,
  buyType: { type: String, enum: ['FULL PAYMENT', 'INSTALLMENT'], required: [true, 'Buy Type is required field'] },
  package: { type: Number, required: [true, 'Package is required'] },
  installation: { type: Number, required: [true, 'Installation is required'] },
  numberOfMonthlyInstallments: { type: Number },
  installmentComponents: { type: installmentComponentsSchema }
})

let subscriptionSchema = new Schema({
  _id: false,
  fee: { type: Number },
  paymentCycle: { type: String, enum: ['MONTHLY'], default: 'MONTHLY' }
})

let priceSchema = new Schema({
  _id: false,
  paymentPlan: { type: String, enum: ['Subscription', 'Buy'], required: [true, 'Payment Plan is required field'] },
  buy: { type: buySchema },
  subscription: { type: subscriptionSchema },
  extraItemsAndServices: { type: extraItemsAndServicesSchema },
  discounts: { type: [discountSchema] },
  currency: { type: String, enum: ['EUR', 'Kr', 'NOK', 'PLN'], required: [true, 'Currency is required field'] }
})

let rangeSchema = new Schema({
  _id: false,
  startDate: { type: Date },
  endDate: { type: Date },
  date: { type: Date },
  startTime: { type: String },
  endTime: { type: String }
})

let installationSchema = new Schema({
  _id: false,
  devicePickUpLocation: { type: String },
  installerCompany: { type: String },
  installer: { type: String },
  agreedVisitScheduleRange: { type: rangeSchema },
  actualInstallationDateTime: { type: Date }
})

let noteSchema = new Schema({
  _id: false,
  note: { type: String },
  createdBy: { type: String },
  createdOn: { type: Date, default: Date.now }
})

let assetSchema = new Schema({
  _id: false,
  itemId: { type: String },
  itemDescription: { type: String },
  serialNumber: { type: String }
})

let partnerServicesSchema = new Schema({
  _id: false,
  installationTime: { type: Number, enum: [0, 0.5, 1, 1.5, 2, 2.0, 2.5] },
  connectionTime: { type: Number, enum: [0, 0.5, 1, 1.5, 2, 2.0, 2.5] },
  cablingTime: { type: Number, enum: [0, 0.5, 1, 1.5, 2, 2.0, 2.5] }
})

let tingcoreStatusSchema = new Schema({
  _id: false,
  isAvailable: { type: Boolean },
  isOutOfService: { type: Boolean }
})

let connectorsSchema = new Schema({
  _id: false,
  id: { type: String },
  name: { type: String },
  status: { type: tingcoreStatusSchema }
})

let tingcoreSchema = new Schema({
  _id: false,
  id: { type: String },
  name: { type: String },
  description: { type: String },
  status: { type: tingcoreStatusSchema },
  connectors: { type: [connectorsSchema] },
  mappingId: { type: String }
})

let HWorkOrderModel = new Schema({
  ev: { type: evSchema },
  customer: { type: customerSchema, required: [true, 'customer is required field'] },
  deliverySite: { type: deliverySiteSchema, required: [true, 'deliverySite is required field'] },
  contractId: { type: String },
  contractSeqNo: { type: Number },
  campaignId: { type: String, required: [true, 'Campaign Id is required field'] },
  campaignChangeNotes: { type: [noteSchema] },
  customerServiceNotes: { type: [noteSchema] },
  installerNotes: { type: [noteSchema] },
  installation: { type: installationSchema },
  plugType: { type: String, enum: ['Type1', 'Type2', 'NoType'] },
  siteInfo: { type: siteInfoSchema, default: {} },
  assets: { type: [assetSchema], default: {} },
  partnerServices: { type: partnerServicesSchema, default: {} },
  pricing: { type: priceSchema, required: [true, 'pricing is required field'] },
  status: { type: String, enum: ['OrderReceived', 'InCompleteOrder', 'ValidOrder', 'SentToInstaller', 'ResendToInstaller', 'InstallerYetToConfirm', 'ReceivedByInstaller', 'TimeScheduled', 'Returned', 'WaitingForFinalDocumentation', 'Installed', 'Completed', 'ReadyForInvoicing', 'Cancelled'], default: 'OrderReceived' },
  statebeforecancelled: { type: String, enum: ['OrderReceived', 'InCompleteOrder', 'ValidOrder', 'SentToInstaller', 'ResendToInstaller', 'InstallerYetToConfirm', 'ReceivedByInstaller', 'TimeScheduled', 'Returned', 'WaitingForFinalDocumentation', 'Installed', 'Completed', 'ReadyForInvoicing', 'Cancelled'] },
  statusChangeOn: { type: Date },
  sentToInstallerOn: { type: Date },
  iTingcore: { type: tingcoreSchema },
  app: { type: String, enum: ['HODA'], default: 'HODA' },
  country: { type: String, enum: ['FI', 'NO'] },
  ts_tc_gdpr: { type: String, enum: ['AGREE', 'NOT_AGREE'], required: [true, 'I have read the terms of service, terms of cancellation and Data Privacy Policy (GDPR) is required field'] },
  isExcavationPrice: { type: Boolean, default: false },
  createdBy: { type: String },
  createdByUserRole: { type: String },
  modifiedOn: { type: Date },
  createdOn: { type: Date, default: Date.now }
})

HWorkOrderModel.plugin(patcher)
HWorkOrderModel.plugin(autoIncrement.plugin, { model: 'HODA-WorkOrder', field: 'hodaOrderNumber', startAt: 1000, incrementBy: 1 })

module.exports = mongoose.model('HODA-WorkOrder', HWorkOrderModel)
