import mongoose from 'mongoose'

let Schema = mongoose.Schema

let HomeChargeContactModel = new Schema({
  firstName: { type: String, required: [true, 'firstName is required'] },
  lastName: { type: String, required: [true, 'lastName is required'] },
  phoneNumber: { type: String, required: [true, 'phoneNumber is required'] },
  emailId: { type: String, required: [true, 'emailId is required'] },
  note: { type: String },
  packageId: { type: String },
  app: { type: String, enum: ['HODA'], default: 'HODA' },
  country: { type: String, enum: ['FI', 'NO'] },
  createdOn: { type: Date, default: Date.now }
})

module.exports = mongoose.model('HODA-Contact', HomeChargeContactModel)
