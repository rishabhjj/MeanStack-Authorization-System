let mongoose = require('mongoose')
let Schema = mongoose.Schema

let AuditModel = new Schema({
  docName: { type: String },
  app: { type: String, enum: ['SODA', 'VODA'], default: 'SODA' },
  country: { type: String },
  docId: { type: String },
  userId: { type: String },
  createdOn: { type: Date, default: Date.now },
  info: { type: Schema.Types.Mixed }
})

module.exports = mongoose.model('Audit', AuditModel)
