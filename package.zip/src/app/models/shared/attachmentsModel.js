let mongoose = require('mongoose')
let Schema = mongoose.Schema

let additionalVPPDataSchema = new Schema({
  _id: false,
  key: { type: String, enum: ['CANCEL', 'RETURN', 'REPORT'] },
  reasonCancellation: { type: String, enum: ['Fortum', 'Customer', 'FixedTermContract', 'DoesNotUseNightElectricity'] },
  cancellationNote: { type: String },
  returnReason: { type: String, enum: ['Absent', 'NoAccess', 'Customer', 'Impossible'] },
  returnNote: { type: String }
})

let additionalHCDataSchema = new Schema({
  _id: false,
  key: { type: String, enum: ['CANCEL', 'RETURN', 'CABINET', 'FUSE_DEVICELIST', 'MOUNTING_LOCATION', 'ADDITIONAL_INSTALLER', 'ADDITIONAL_ATTACHMENT', 'OTHER', 'SWITCHBOARD', 'CHARGING_STATION', 'RISK_ANALYSIS', 'CONFORMITY_DECLARATION', 'EXTRA_COST'] },
  reasonCancellation: { type: String, enum: ['Fortum', 'Customer', 'CreditCheckRejected', 'InstallationNotPossible', 'CustomerNotAvailableAtAgreedTime'] },
  cancellationNote: { type: String },
  returnReason: { type: String, enum: ['Absent', 'NoAccess', 'Customer', 'Impossible'] },
  returnNote: { type: String }
})

let additionalSolarDataSchema = new Schema({
  _id: false,
  key: { type: String, enum: ['PLAN', 'REPORT', 'HAND-OVER'] },
  referenceId: { type: String }
})

let AttachmentsModel = new Schema({
  workorderId: { type: String },
  title: { type: String },
  description: { type: String },
  rotateAngle: { type: Number },
  createdOn: { type: Date, default: Date.now },
  hc: { type: additionalHCDataSchema, default: {} },
  vpp: { type: additionalVPPDataSchema, default: {} },
  solar: { type: additionalSolarDataSchema, default: {} },
  category: { type: String, enum: ['Panel', 'Wiring', 'Inverter', 'Switchboard', 'MaterialDelivery', 'HandOver'] },
  country: { type: String, enum: ['FI', 'SE', 'PL', 'NO'] },
  app: { type: String, enum: ['VODA', 'HODA', 'SODA'] }
})

module.exports = mongoose.model('Attachments', AttachmentsModel)
