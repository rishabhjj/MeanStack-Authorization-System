import mongoose from 'mongoose'
import patcher from 'mongoose-json-patch'

let Schema = mongoose.Schema

let componentsSchema = new Schema({
  _id: false,
  material: { type: Boolean, default: true },
  installation: { type: Boolean, default: true },
  extraMaterial: { type: Boolean, default: true },
  extraWork: { type: Boolean, default: true }
})

let PaymentTypesModel = new Schema({
  fullPayment: { type: Boolean, default: true },
  installments: { type: [Number] },
  installmentsComponents: { type: componentsSchema },
  subscription: { type: Boolean, default: false },
  country: { type: String, enum: ['FI', 'SE', 'PL', 'NO'] },
  app: { type: String, enum: ['SODA', 'BODA', 'VODA', 'HODA'] },
  modifiedOn: { type: Date },
  createdOn: { type: Date, default: Date.now }
})

PaymentTypesModel.plugin(patcher)

module.exports = mongoose.model('Payment-Types', PaymentTypesModel)
