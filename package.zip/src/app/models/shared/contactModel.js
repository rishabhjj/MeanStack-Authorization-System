let mongoose = require('mongoose')
let Schema = mongoose.Schema

let ContactModel = new Schema({
  name: { type: String, required: [true, 'Name is required'] },
  email: { type: String },
  phone: { type: String, required: [true, 'Phone is required'] },
  businessId: { type: String },
  customerNote: { type: String },
  noContract: { type: String },
  createdOn: { type: Date, default: Date.now },
  country: { type: String, enum: ['FI', 'SE', 'PL', 'NO'], default: 'FI' },
  app: { type: String, enum: ['SODA', 'LODA', 'VODA', 'BODA'], default: 'SODA' }
})

module.exports = mongoose.model('contact', ContactModel)
