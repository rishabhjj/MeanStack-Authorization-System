let mongoose = require('mongoose')
let Schema = mongoose.Schema

let descriptionSchema = new Schema({
  _id: false,
  en_GB: { type: String },
  fi_FI: { type: String },
  sv_FI: { type: String },
  sv_SE: { type: String },
  nb_NO: { type: String },
  nn_NO: { type: String },
  pl_PL: { type: String }
})

let SpecificationSchema = new Schema({
  _id: false,
  height: { type: Number },
  thickness: { type: Number },
  width: { type: Number },
  dimensionsUnit: { type: String },
  weight: { type: String },
  peakPower: { type: String },
  warranty: { type: String },
  wifi: { type: String },
  zigBee: { type: String },
  bluetooth: { type: String },
  plugType: { type: String },
  firmware: { type: String }
})

let ItemServiceModel = new Schema({
  contractNumber: { type: String, required: [true, 'contractNumber is required'] },
  itemServiceNumber: { type: String, required: [true, 'itemServiceNumber is required'] },
  itemType: { type: String, enum: ['Item', 'Service'], required: [true, 'itemType is required'] },
  orderUnit: { type: String, required: [true, 'orderUnit is required'] },
  issueUnit: { type: String },
  unitCost: { type: Number },
  vendor: { type: String },
  vendorName: { type: String },
  rotating: { type: Number },
  commodityGroup: { type: String },
  commodity: { type: String },
  status: { type: String, enum: ['Active', 'PENDING'], required: [true, 'status is required'] },
  itemSetId: { type: String, enum: ['CSEUR', 'CSSEK', 'CSNOK', 'CSPLN'] },
  classStructureId: { type: String, required: [true, 'classStructureId is required'] },
  specifications: { type: SpecificationSchema },
  manufacturer: { type: String },
  manufacturerName: { type: String },
  modelNumber: { type: String },
  orgId: { type: String },
  country: { type: String, enum: ['FI', 'SE', 'NO', 'PL'], required: [true, 'country is required'] },
  description: { type: descriptionSchema, required: [true, 'description is required'] },
  parent: { type: String },
  glCode: { type: String },
  companyCode: { type: String },
  multiplier: { type: Number },
  statusDate: { type: Date },
  revisionNumber: { type: Number },
  isAssetNumber: { type: Boolean, default: false },
  app: { type: String, enum: ['SODA', 'VODA', 'HODA'], required: [true, 'app is required'] },
  createdOn: { type: Date, default: Date.now },
  modifiedOn: { type: Date }
})

module.exports = mongoose.model('Items-Services-Master', ItemServiceModel)

/*
  currency: { type: String }
*/
