import mongoose from 'mongoose'
import patcher from 'mongoose-json-patch'

let Schema = mongoose.Schema

let faultSchema = new Schema({
  _id: false,
  faultCode: { type: String },
  faultMessage: { type: String },
  createdOn: { type: Date, default: Date.now }
})

let serviceAddressInboundSchema = new Schema({
  _id: false,
  streetName: { type: String },
  city: { type: String },
  postalCode: { type: String },
  country: { type: String, enum: ['FI', 'SE', 'PL', 'NO'] },
  addressCode: { type: String, required: [true, 'addressCode is required'] }
})

let serviceAddressOutboundSchema = new Schema({
  _id: false,
  faults: { type: [faultSchema] },
  addressCode: { type: String },
  serviceAddressId: { type: String },
  createdOn: { type: Date }
})

let serviceAddressSchema = new Schema({
  _id: false,
  inbound: { type: serviceAddressInboundSchema, default: {} },
  outbound: { type: serviceAddressOutboundSchema, default: {} }
})

let locationOutboundSchema = new Schema({
  _id: false,
  faults: { type: [faultSchema] },
  addressCode: { type: String },
  serviceAddressId: { type: String },
  createdOn: { type: Date }
})

let locationInboundSchema = new Schema({
  _id: false,
  streetName: { type: String },
  city: { type: String },
  postalCode: { type: String },
  country: { type: String, enum: ['FI', 'SE', 'PL', 'NO'] },
  addressCode: { type: String, required: [true, 'addressCode is required'] }
})

let locationSchema = new Schema({
  _id: false,
  inbound: { type: locationInboundSchema, default: {} },
  outbound: { type: locationOutboundSchema, default: {} }
})

let commonSchema = new Schema({
  _id: false,
  orgId: { type: String, enum: ['CSEUR', 'CSSEK', 'CSPLN', 'CSNOK'], required: [true, 'orgId is required'] },
  siteId: { type: String, enum: ['CSFI', 'CSSV', 'CSNO', 'CSPL'], required: [true, 'siteId is required'] },
  classStructureId: { type: String, required: [true, 'classStructureId is required'] }
})

let MaximoModel = new Schema({
  common: { type: commonSchema },
  serviceAddress: { type: serviceAddressSchema },
  location: { type: locationSchema },
  country: { type: String, enum: ['FI', 'SE', 'PL', 'NO'] },
  app: { type: String, enum: ['SODA', 'BODA', 'VODA', 'HODA'] },
  modifiedOn: { type: Date },
  createdOn: { type: Date, default: Date.now }
})

MaximoModel.plugin(patcher)

module.exports = mongoose.model('iMaximo', MaximoModel)
