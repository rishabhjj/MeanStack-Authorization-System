let mongoose = require('mongoose')
let Schema = mongoose.Schema

let MailLogsModel = new Schema({
  app: { type: String, enum: ['SODA', 'VODA', 'HODA'] },
  country: { type: String, enum: ['FI', 'SE', 'NO', 'PL'] },
  createdOn: { type: Date, default: Date.now },
  role: { type: String, enum: ['CUSTOMER', 'CS', 'INSTALLER'] },
  wo: { type: String },
  status: { type: String },
  template: { type: String },
  email: { type: String },
  statusCode: { type: String },
  refId: { type: String }
})

module.exports = mongoose.model('MailLogs', MailLogsModel)
