let mongoose = require('mongoose')
let Schema = mongoose.Schema

let AddressLeadModel = new Schema({
  street: { type: String },
  city: { type: String },
  zip: { type: String },
  coordinates: { type: [Number] },
  createdOn: { type: Date, default: Date.now },
  country: { type: String, enum: ['FI', 'SE', 'PL', 'NO'] },
  app: { type: String, enum: ['SODA'], default: 'SODA' }

})

module.exports = mongoose.model('SODA-AddressLead', AddressLeadModel)
