let mongoose = require('mongoose')
let Schema = mongoose.Schema
let patcher = require('mongoose-json-patch')
let autoIncrement = require('mongoose-auto-increment')

let dbURL = process.env.MONGODB_URI || 'mongodb://heroku_7bg5gkf0:tetu942nofsj6bq4q54rl6g185@ds161518.mlab.com:61518/heroku_7bg5gkf0'
// let db = mongoose.createConnection(dbURL)

mongoose.Promise = global.Promise
let db = mongoose.connect(dbURL, { useMongoClient: true })

autoIncrement.initialize(db)

let deliverySiteSchema = new Schema({
  _id: false,
  deliverySiteId: { type: String, default: '' },
  street: { type: String, required: [true, 'street is required'] },
  city: { type: String },
  zip: { type: String },
  coordinates: { type: [Number], required: [true, 'coordinates is required'] }
})

let externalMarketingPartnerSchema = new Schema({
  _id: false,
  code: { type: String }
})

let partsSchema = new Schema({
  _id: false,
  center: { type: [Number] },
  dimensions: { type: [Number] },
  azimuth: { type: Number }
})

let customBuildingSchema = new Schema({
  _id: false,
  parts: { type: [partsSchema] },
  roofArea: { type: Number },
  mainAzimuth: { type: Number }
})

let benefitCalculationsSchema = new Schema({
  _id: false,
  monthlySolarElectricityPotential: { type: [Number], required: [true, 'monthlySolarElectricityPotential is required'] },
  roofArea: { type: Number, required: [true, 'roofArea is required'] },
  roofAreaUnit: { type: String, required: [true, 'roofAreaUnit is required'] },
  roofAreaSuitableForPanels: { type: Number, required: [true, 'roofAreaSuitableForPanels is required'] },
  estimatedMonthlyElectricityConsumption: { type: [Number], required: [true, 'estimatedMonthlyElectricityConsumption is required'] },
  confidenceClassForEstimates: { type: String, required: [true, 'confidenceClassForEstimates is required'] },
  roofType: { type: String, required: [true, 'roofType is required'] },
  roofPitchAngle: { type: Number, required: [true, 'roofPitchAngle is required'] },
  roofMaterial: { type: String },
  roofRidgeAngleFromNorth: { type: Number, required: [true, 'roofRidgeAngleFromNorth is required'] },
  buildingType: { type: String, required: [true, 'buildingType is required'] },
  recommendedProductPackageId: { type: String, required: [true, 'recommendedProductPackageId is required'] },
  customerSelectedProductPackageId: { type: String, required: [true, 'customerSelectedProductPackageId is required'] },
  heatingType: { type: String, required: [true, 'heatingType is required'] },
  buildYear: { type: Number, required: [true, 'buildYear is required'] },
  floors: { type: Number, required: [true, 'floors is required'] },
  floorArea: { type: Number },
  yearlyConsumption: { type: Number },
  seamGap: { type: Number },
  userEditedFields: { type: [String] },
  selectedBuildingId: { type: String },
  customBuilding: { type: customBuildingSchema },
  customerPreviouslySelectedPackageId: { type: String }
})

let nameSchema = new Schema({
  _id: false,
  en_GB: { type: String },
  fi_FI: { type: String },
  sv_FI: { type: String },
  sv_SE: { type: String },
  nb_NO: { type: String },
  nn_NO: { type: String },
  pl_PL: { type: String }
})

let subsidiesSchema = new Schema({
  _id: false,
  name: { type: nameSchema, required: [true, 'name is required'] },
  amount: { type: Number, required: [true, 'amount is required'] }
})

let extraSchema = new Schema({
  _id: false,
  title: { type: String },
  description: { type: String, required: [true, 'description is required'] },
  type: { type: String, enum: ['Work', 'Material'], required: [true, 'type is required'] },
  quantity: { type: Number },
  amount: { type: Number, required: [true, 'amount is required'] }
})

let extraDesignatedSchema = new Schema({
  _id: false,
  designatedItemId: { type: String, required: [true, 'designatedItemId is required'] },
  type: { type: String, enum: ['Work', 'Material'] },
  quantity: { type: Number, required: [true, 'quantity is required'] },
  amount: { type: Number, required: [true, 'amount is required'] }
})

let priceSchema = new Schema({
  _id: false,
  package: { type: Number, required: [true, 'Package is required'] },
  installation: { type: Number, required: [true, 'Installation is required'] },
  total: { type: Number, required: [true, 'Total is required'] },
  subsidies: { type: [subsidiesSchema] },
  priceCurrency: { type: String, enum: ['EUR', 'Kr', 'NOK', 'PLN'], default: 'EUR' }
})

let contactInformationSchema = new Schema({
  _id: false,
  name: { type: String, required: [true, 'name is required'] },
  ssnOrBusinessId: { type: String },
  customerType: { type: String, enum: ['Consumer', 'Business'], required: [true, 'customerType is required'] },
  phone: { type: String, required: [true, 'phone is required'] },
  email: { type: String },
  street: { type: String },
  city: { type: String },
  zip: { type: String }
})

let rowArray = new Schema({
  _id: false,
  rowData: [Number]
})
let panelInstallationLayoutSchema = new Schema({
  _id: false,
  name: { type: String, default: '' },
  row: { type: Number },
  column: { type: Number },
  orientation: { type: String, enum: ['Portrait', 'Landscape'] },
  width: { type: Number },
  height: { type: Number },
  unit: { type: String, enum: ['m'], default: 'm' },
  panels: { type: [rowArray] }
})

let gridSchema = new Schema({
  _id: false,
  gridId: { type: String },
  gridCompanyName: { type: String }
})

let buildingSchema = new Schema({
  _id: false,
  buildingEdgeheight: { type: Number },
  buildingTopheight: { type: Number }
})

let noteSchema = new Schema({
  _id: false,
  note: { type: String },
  createdOn: { type: Date, default: Date.now }
})

let installationPlanReportChangeLogSchema = new Schema({
  _id: false,
  createdOn: { type: Date },
  createdBy: { type: String },
  modifiedOn: { type: Date },
  modifiedBy: { type: String },
  verifiedOn: { type: Date },
  verifiedBy: { type: String },
  initialized: { type: Boolean },
  status: { type: Number, enum: [0, 1] }
})
// 0 Verified
// 1 'Waiting verification'

let installationNoteSchema = new Schema({
  _id: false,
  installPlan: { type: [noteSchema] },
  roofProperties: { type: [noteSchema] },
  panelInfo: { type: [noteSchema] },
  panel: { type: [noteSchema] },
  wiring: { type: [noteSchema] },
  inverter: { type: [noteSchema] },
  switchboard: { type: [noteSchema] },
  materialdelivery: { type: [noteSchema] },
  pricingInfo: { type: [noteSchema] }
})

let installationSchema = new Schema({
  _id: false,
  startDate: { type: Date },
  endDate: { type: Date },
  days: { type: Number },
  hours: { type: Number }
})

let deviceSchema = new Schema({
  _id: false,
  inverterSerialNumber: { type: String },
  tingcoBoxId: { type: String }
})

let WorkOrderModel = new Schema({
  accountId: { type: String, default: '' },
  customerId: { type: String, default: '' },
  customerNote: { type: String },
  contractId: { type: String, default: '' },
  installerId: { type: String, default: '' },
  installerCompany: { type: String, default: '' },
  externalMarketingPartner: { type: externalMarketingPartnerSchema },
  deliverySite: { type: deliverySiteSchema, required: [true, 'deliverySite is required'] },
  gridInfo: { type: gridSchema },
  contactInformation: { type: contactInformationSchema, required: [true, 'contactInformation is required'] },
  benefitCalculations: { type: benefitCalculationsSchema, required: [true, 'benefitCalculations is required'] },
  basePrice: { type: priceSchema },
  extraDesignatedWorkAndMaterial: { type: [extraDesignatedSchema] },
  extraNonDesignatedWorkAndMaterial: { type: [extraSchema] },
  panelInstallationLayout: { type: [panelInstallationLayoutSchema] },
  installationPlanChangeLog: { type: installationPlanReportChangeLogSchema },
  installationReportChangeLog: { type: installationPlanReportChangeLogSchema },
  building: { type: buildingSchema },
  notesToInstaller: { type: [noteSchema] },
  installerNotes: { type: [noteSchema] },
  installationPlanNote: { type: [noteSchema] },
  craneRequirementOverwritten: { type: Boolean },
  surplusElectricityWillBeSoldToFortum: { type: Boolean },
  installationNote: { type: installationNoteSchema, default: {} },
  customerServiceNotes: { type: [noteSchema] },
  roofSupportDistance: { type: String },
  assessmentHomeVisit: { type: Date },
  installationHomeVisit: { type: Date },
  installation: { type: installationSchema, default: {} },
  paymentType: { type: String, enum: ['OneTime', 'OneTimeWith15PercentDiscount', 'TenYearMaterialAlone', 'TenYear'] },
  device: { type: deviceSchema, default: {} },
  lockedBy: { type: String },
  isLocked: { type: Boolean, default: false },
  status: { type: String, enum: ['OfferRequestReceived', 'PreliminaryOfferSent', 'PreliminaryOfferApproved', 'AssessmentSiteVisitScheduled', 'AddInstallationPlan', 'InstallationPlanCreated', 'InstallationPlanVerified', 'FinalOfferSent', 'FinalOfferApproved', 'InstallationTimeScheduled', 'AddInstallationReport', 'InstallationReportReady', 'InstallationReportVerified', 'InstallationApproved', 'Cancelled', 'Closed'], default: 'OfferRequestReceived' },
  statebeforecancelled: { type: String, enum: ['OfferRequestReceived', 'PreliminaryOfferSent', 'PreliminaryOfferApproved', 'AssessmentSiteVisitScheduled', 'AddInstallationPlan', 'InstallationPlanCreated', 'InstallationPlanVerified', 'FinalOfferSent', 'FinalOfferApproved', 'InstallationTimeScheduled', 'AddInstallationReport', 'InstallationReportReady', 'InstallationReportVerified', 'InstallationApproved', 'Cancelled'] },
  interestedInVPP: { type: Boolean, default: false },
  createdOn: { type: Date, default: Date.now },
  country: { type: String, enum: ['FI', 'SE', 'PL', 'NO'] },
  app: { type: String, enum: ['SODA', 'FODA', 'VODA', 'BODA'] },
  modifiedOn: { type: Date }

})

WorkOrderModel.plugin(patcher)
WorkOrderModel.plugin(autoIncrement.plugin, { model: 'WorkOrder', field: 'workOrderNumber', startAt: 1000, incrementBy: 1 })

module.exports = mongoose.model('WorkOrder', WorkOrderModel)
