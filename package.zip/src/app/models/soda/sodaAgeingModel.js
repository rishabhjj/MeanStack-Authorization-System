let mongoose = require('mongoose')
let Schema = mongoose.Schema
let patcher = require('mongoose-json-patch')

let sAgeingModel = new Schema({
  name: { type: String },
  workOrderServiceKey: { type: String },
  workOrderNumber: { type: String },
  emp: { type: String, default: '' },
  offerRequestReceived: { type: Date },
  preliminaryOfferSent: { type: Date },
  preliminaryOfferApproved: { type: Date },
  assessmentSiteVisitScheduled: { type: Date },
  addInstallationPlan: { type: Date },
  installationPlanCreated: { type: Date },
  installationPlanVerified: { type: Date },
  finalOfferSent: { type: Date },
  finalOfferApproved: { type: Date },
  installationTimeScheduled: { type: Date },
  addInstallationReport: { type: Date },
  installationReportReady: { type: Date },
  installationReportVerified: { type: Date },
  installationApproved: { type: Date },
  cancelled: { type: Date },
  closed: { type: Date },
  currentStatus: { type: String },
  country: { type: String, enum: ['FI', 'SE', 'PL', 'NO'] },
  app: { type: String, enum: ['SODA'], default: 'SODA' },
  createdOn: { type: Date, default: Date.now },
  modifiedOn: { type: Date }
})

sAgeingModel.plugin(patcher)
module.exports = mongoose.model('SODA-Ageing', sAgeingModel)
