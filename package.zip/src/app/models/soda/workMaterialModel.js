let mongoose = require('mongoose')
let Schema = mongoose.Schema
let patcher = require('mongoose-json-patch')

let nameSchema = new Schema({
  _id: false,
  en_GB: { type: String },
  fi_FI: { type: String },
  sv_FI: { type: String },
  sv_SE: { type: String },
  nb_NO: { type: String },
  nn_NO: { type: String },
  pl_PL: { type: String }
})

let WorkMaterialModel = new Schema({
  workMaterialId: { type: String },
  title: { type: nameSchema, required: [true, 'name is required'] },
  description: { type: nameSchema, required: [true, 'name is required'] },
  type: { type: String, enum: ['Work', 'Material'] },
  measurementUnit: { type: String, enum: ['Quantity', 'Non Quantity', 'Meter', 'KM', 'Calculated'] },
  isCalculated: { type: Boolean, default: false },
  isRemovable: { type: Boolean, default: true },
  isPackageSpecific: { type: Boolean, default: false },
  perUnitPrice: { type: Number },
  formula: { type: String },
  country: { type: String, enum: ['FI', 'SE', 'PL', 'NO'] },
  app: {type: String, enum: ['SODA', 'FODA', 'VODA', 'BODA']}
})

WorkMaterialModel.plugin(patcher)

module.exports = mongoose.model('workMaterial', WorkMaterialModel)
