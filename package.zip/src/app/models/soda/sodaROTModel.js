let mongoose = require('mongoose')
let Schema = mongoose.Schema
let patcher = require('mongoose-json-patch')

let allocationSchema = new Schema({
  _id: false,
  name: { type: String },
  ssn: { type: String },
  amount: { type: Number }
})

let ROTModel = new Schema({
  workOrderServiceKey: { type: String },
  propertyDetail: { type: String },
  rot: { type: Boolean },
  allocation: { type: [allocationSchema] },
  createdOn: { type: Date, default: Date.now },
  modifiedOn: { type: Date }
})

ROTModel.plugin(patcher)
module.exports = mongoose.model('rot', ROTModel)
