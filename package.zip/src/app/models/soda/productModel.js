let mongoose = require('mongoose')
let Schema = mongoose.Schema
let patcher = require('mongoose-json-patch')

let nameSchema = new Schema({
  _id: false,
  en_GB: { type: String },
  fi_FI: { type: String },
  sv_FI: { type: String },
  sv_SE: { type: String },
  nb_NO: { type: String },
  nn_NO: { type: String },
  pl_PL: { type: String }
})

let subsidiesSchema = new Schema({
  _id: false,
  name: { type: nameSchema, required: [true, 'name is required'] },
  amount: { type: Number, required: [true, 'amount is required'] }
})

let itemSchema = new Schema({
  _id: false,
  itemId: { type: String },
  itemType: { type: String, enum: ['PANEL', 'INVERTER', 'TINGOBOX', 'OTHER'], default: 'OTHER' }
})

let serviceItemSchema = new Schema({
  _id: false,
  serviceItemId: { type: String }
})

let ItemsandServicesSchema = new Schema({
  _id: false,
  items: { type: [itemSchema] },
  services: { type: [serviceItemSchema] }
})

let allowedItemsAndServicesSchema = new Schema({
  _id: false,
  basic: { type: ItemsandServicesSchema },
  optional: { type: ItemsandServicesSchema }
})

let extraMaterialOrMachineSchema = new Schema({
  _id: false,
  flatRoof: { type: Number },
  crane: { type: Number }
})

let extraWorkSchema = new Schema({
  _id: false,
  tileRoof: { type: Number },
  steepRoof: { type: Number }
})

let heightSchema = new Schema({
  _id: false,
  moreThan3dot5AndlessThan4dot5: { type: Number },
  moreThan4dot5AndlessThan6: { type: Number }
})

let bundledPriceSchema = new Schema({
  _id: false,
  packageAndInstallation: { type: Number },
  noOfRails: { type: Number },
  sections: { type: Number },
  height: { type: heightSchema }
})

let cablePriceSchema = new Schema({
  _id: false,
  moreThan10AndLessThan20: { type: Number },
  moreThan20: { type: Number }
})

let anglePriceSchema = new Schema({
  _id: false,
  moreThan15lessThan30: { type: Number },
  moreThan30: { type: Number }
})

let commonPriceSchema = new Schema({
  _id: false,
  cable: { type: cablePriceSchema },
  angle: { type: anglePriceSchema }
})

let pricingSchema = new Schema({
  _id: false,
  productPackage: { type: Number },
  installation: { type: Number },
  subsidies: { type: [subsidiesSchema] },
  extraMaterialOrMachine: { type: extraMaterialOrMachineSchema },
  extraWork: { type: extraWorkSchema },
  standard: { type: bundledPriceSchema },
  tile: { type: bundledPriceSchema },
  common: { type: commonPriceSchema }
})

let panelOuterDimensionsSchema = new Schema({
  _id: false,
  width: { type: Number, required: [true, 'width is required'] },
  height: { type: Number, required: [true, 'height is required'] },
  thickness: { type: Number, required: [true, 'thickness is required'] },
  unit: { type: String, enum: ['Meters', 'm', 'M'], default: 'Meters' }
})

let includedInfoSchema = new Schema({
  description: { type: nameSchema, required: [true, 'description is required'] },
  category: { type: String, enum: ['Equipment', 'Service', 'AdditionalBenefit', 'StandardMaterial', 'StandardInstallationWork'] }
})

let ProductModel = new Schema({
  nameOfPackage: { type: nameSchema, required: [true, 'nameOfPackage is required'] },
  description: { type: nameSchema, required: [true, 'description is required'] },
  packageId: { type: String, required: [true, 'packageId is required'] },
  nameOfProductGroup: { type: String, required: [true, 'nameOfProductGroup is required'] },
  campaignItems: { type: allowedItemsAndServicesSchema },
  productGroupId: { type: String, required: [true, 'productGroupId is required'] },
  inverterModel: { type: String, required: [true, 'inverterModel is required'] },
  optimizer: { type: String },
  panelModel: { type: String, required: [true, 'panelModel is required'] },
  noOfSolarPanels: { type: Number, required: [true, 'noOfSolarPanels is required'] },
  effectiveArea: { type: Number, required: [true, 'effectiveArea is required'] },
  effectiveAreaUnit: { type: String, enum: ['Square Metre'], default: 'Square Metre' },
  panelOuterDimensions: { type: panelOuterDimensionsSchema, required: [true, 'panelOuterDimensions is required'] },
  peakPower: { type: Number, required: [true, 'peakPower is required'] },
  peakPowerUnit: { type: String, enum: ['Watts'], default: 'Watts' },
  currencyUnit: { type: String, enum: ['EUR', 'Kr', 'NOK', 'PLN'], default: 'EUR' },
  price: { type: pricingSchema, required: [true, 'price is required'] },
  noOfInstallmentMonths: { type: Number },
  includedInfo: { type: [includedInfoSchema] },
  isActive: { type: Boolean, default: false },
  startDate: { type: Date, required: [true, 'startDate is required'] },
  endDate: { type: Date, required: [true, 'endDate is required'] },
  createdOn: { type: Date, default: Date.now },
  country: { type: String, enum: ['FI', 'SE', 'PL', 'NO'] },
  app: { type: String, enum: ['SODA', 'FODA', 'VODA', 'BODA'] },
  modifiedOn: { type: Date }
})

ProductModel.plugin(patcher)

module.exports = mongoose.model('Product', ProductModel)
