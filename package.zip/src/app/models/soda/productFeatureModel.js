let mongoose = require('mongoose')
let Schema = mongoose.Schema
let patcher = require('mongoose-json-patch')

let featureSchema = new Schema({
  _id: false,
  en_GB: { type: String },
  fi_FI: { type: String },
  sv_FI: { type: String },
  sv_SE: { type: String },
  nb_NO: { type: String },
  nn_NO: { type: String },
  pl_PL: { type: String }
})

let ProductFeatureModel = new Schema({
  description: { type: featureSchema, required: [true, 'description is required'] },
  category: { type: String, enum: ['Equipment', 'Service', 'AdditionalBenefit', 'StandardMaterial', 'StandardInstallationWork'] },
  country: { type: String, enum: ['FI', 'SE', 'PL', 'NO'] },
  app: { type: String, enum: ['SODA'], default: 'SODA' }
})

ProductFeatureModel.plugin(patcher)

module.exports = mongoose.model('productFeatures', ProductFeatureModel)
