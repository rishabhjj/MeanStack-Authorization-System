let mongoose = require('mongoose')
let Schema = mongoose.Schema

let deliverySiteSchema = new Schema({
  _id: false,
  street: { type: String },
  city: { type: String },
  zip: { type: String },
  deliverySiteId: { type: String }
})

let nameSchema = new Schema({
  _id: false,
  en_GB: { type: String },
  fi_FI: { type: String },
  sv_FI: { type: String },
  sv_SE: { type: String },
  nb_NO: { type: String },
  nn_NO: { type: String },
  pl_PL: { type: String }
})

let DeliverySiteModel = new Schema({
  _id: false,
  customerId: { type: String },
  deliverySiteAddress: { type: deliverySiteSchema },
  yearOfInstallation: { type: String },
  noOfPanels: { type: Number },
  inverterModel: { type: String },
  panelModel: { type: String },
  packageName: { type: nameSchema },
  peakPower: { type: Number },
  peakPowerUnit: { type: String }
})

module.exports = mongoose.model('deliverySite', DeliverySiteModel)
