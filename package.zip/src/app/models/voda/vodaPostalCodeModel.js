let mongoose = require('mongoose')
let Schema = mongoose.Schema
let patcher = require('mongoose-json-patch')

let VODAPostalCodeModel = new Schema({
  code: { type: String },
  country: { type: String, enum: ['FI'], default: 'FI' },
  app: { type: String, enum: ['VODA'], default: 'VODA' },
  modifiedOn: { type: Date },
  createdOn: { type: Date, default: Date.now }
})

VODAPostalCodeModel.plugin(patcher)

module.exports = mongoose.model('VODA-Postal-Code', VODAPostalCodeModel)
