let mongoose = require('mongoose')
let Schema = mongoose.Schema
let patcher = require('mongoose-json-patch')

let vakaaSchema = new Schema({
  _id: false,
  vakyleisen: { type: Number },
  vakyopv: { type: Number },
  vakyoyo: { type: Number },
  vakkausitp: { type: Number },
  vakkausimu: { type: Number }
})

let kestoSchema = new Schema({
  _id: false,
  myyen: { type: Number },
  myspv: { type: Number },
  mysyo: { type: Number },
  myktp: { type: Number },
  mykyo: { type: Number }
})

let takuuSchema = new Schema({
  _id: false,
  lyleise: { type: Number },
  lyopv: { type: Number },
  lyoyo: { type: Number },
  lkausitp: { type: Number },
  lkausimu: { type: Number }
})

var vodaCampaignPriceModel = new Schema({
  vakaa: { type: vakaaSchema, required: [true, 'Vakaa price is required'] },
  kesto: { type: kestoSchema, required: [true, 'Kesto price is required'] },
  takuu: { type: takuuSchema, required: [true, 'Takuu price is required'] },
  campaign: { type: String, enum: ['Current'], default: 'Current' },
  country: { type: String, enum: ['FI', 'SE', 'PL', 'NO'] },
  app: { type: String, enum: ['VODA'], default: 'VODA' },
  modifiedOn: { type: Date }
})

vodaCampaignPriceModel.plugin(patcher)
module.exports = mongoose.model('VODA-Campaign-Price', vodaCampaignPriceModel)
