let mongoose = require('mongoose')
let Schema = mongoose.Schema
let patcher = require('mongoose-json-patch')

var vAgeingModel = new Schema({
  name: { type: String },
  workOrderServiceKey: { type: String },
  workOrderNumber: { type: String },
  createdBy: { type: String, default: '' },
  createdByUserRole: { type: String },
  orderReceived: { type: Date },
  waitingForInstallation: { type: Date },
  completed: { type: Date },
  timeScheduled: { type: Date },
  returned: { type: Date },
  cancelled: { type: Date },
  currentStatus: { type: String },
  country: { type: String, enum: ['FI', 'SE', 'PL', 'NO'] },
  app: { type: String, enum: ['VODA'], default: 'VODA' },
  createdOn: { type: Date, default: Date.now },
  modifiedOn: { type: Date }
})

vAgeingModel.plugin(patcher)
module.exports = mongoose.model('VODA-Ageing', vAgeingModel)
