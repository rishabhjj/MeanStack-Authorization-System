let mongoose = require('mongoose')
let Schema = mongoose.Schema
let patcher = require('mongoose-json-patch')
let autoIncrement = require('mongoose-auto-increment')

let dbURL = process.env.MONGODB_URI || 'mongodb://heroku_7bg5gkf0:tetu942nofsj6bq4q54rl6g185@ds161518.mlab.com:61518/heroku_7bg5gkf0'
// let db = mongoose.createConnection(dbURL)

mongoose.Promise = global.Promise
let db = mongoose.connect(dbURL, { useMongoClient: true })

autoIncrement.initialize(db)

let addressSchema = new Schema({
  _id: false,
  street: { type: String, required: [true, 'street is required'] },
  postalPlace: { type: String },
  city: { type: String },
  zip: { type: String, required: [true, 'Zip is required'] }
})

let contactInfoSchema = new Schema({
  _id: false,
  phone: { type: String },
  email: { type: String },
  additionalContactNumber: { type: String }
})

let additionalPartsSchema = new Schema({
  _id: false,
  antenna: { type: String, enum: ['Yes', 'No'] },
  currectClamps: { type: String, enum: ['Yes', 'No'] }
})

let customerSchema = new Schema({
  _id: false,
  customerId: { type: String },
  name: { type: String },
  lastName: { type: String },
  address: { type: addressSchema },
  contactInfo: { type: contactInfoSchema }
})

let deliverySiteSchema = new Schema({
  _id: false,
  isDeliverySiteAddressSameAsContactAddress: { type: String, enum: ['Yes', 'No'], required: [true, 'DeliverySite Address Same As Contact Address is required field'] },
  deliverysiteId: { type: String },
  address: { type: addressSchema }
})

let faultDeviceSchema = new Schema({
  _id: false,
  deviceId: { type: String },
  faultCode: { type: String }
})

let faultDeviceListSchema = new Schema({
  _id: false,
  devices: { type: [faultDeviceSchema] }
})

let rangeSchema = new Schema({
  _id: false,
  startDate: { type: Date },
  endDate: { type: Date },
  date: { type: Date },
  startTime: { type: String },
  endTime: { type: String }
})

let installationSchema = new Schema({
  _id: false,
  installerCompany: { type: String },
  installer: { type: String },
  agreedVisitScheduleRange: { type: rangeSchema },
  actualInstallationDateTime: { type: Date }
})

var noteSchema = new Schema({
  _id: false,
  note: { type: String },
  createdBy: { type: String },
  createdOn: { type: Date, default: Date.now }
})

var extraMaterialSchema = new Schema({
  _id: false,
  materialId: { type: String, required: [true, 'materialId is required'] },
  quantity: { type: Number, required: [true, 'quantity is required'] }
})

var deviceStatusSchema = new Schema({
  _id: false,
  registerDevice: { type: String, enum: ['NotCompleted', 'Completed'], default: 'NotCompleted' },
  settingType: { type: String, enum: ['NotCompleted', 'Completed'], default: 'NotCompleted' },
  createDeviceSetting: { type: String, enum: ['NotCompleted', 'Completed'], default: 'NotCompleted' },
  connection: { type: String, enum: ['Passed', 'Failed', 'YetToBeConnected'], default: 'YetToBeConnected' },
  setFailSafeOff: { type: String, enum: ['NotCompleted', 'Completed'], default: 'NotCompleted' },
  setRelayOn: { type: String, enum: ['NotCompleted', 'Completed'], default: 'NotCompleted' },
  setRelayOff: { type: String, enum: ['NotCompleted', 'Completed'], default: 'NotCompleted' },
  setFailSafeOn: { type: String, enum: ['NotCompleted', 'Completed'], default: 'NotCompleted' },
  signalStrength: { type: Number }
})
let vakaaSchema = new Schema({
  _id: false,
  vakyleisen: { type: Number },
  vakyopv: { type: Number },
  vakyoyo: { type: Number },
  vakkausitp: { type: Number },
  vakkausimu: { type: Number }
})

let kestoSchema = new Schema({
  _id: false,
  myyen: { type: Number },
  myspv: { type: Number },
  mysyo: { type: Number },
  myktp: { type: Number },
  mykyo: { type: Number }
})

let takuuSchema = new Schema({
  _id: false,
  lyleise: { type: Number },
  lyopv: { type: Number },
  lyoyo: { type: Number },
  lkausitp: { type: Number },
  lkausimu: { type: Number }
})

var selfServiceSchema = new Schema({
  _id: false,
  package: { type: String, enum: ['VAKAA', 'KESTO', 'TARKKA', 'TAKUU'] },
  endCurrentContract: { type: String, enum: ['Yes', 'No'], required: [true, 'endCurrentContract is required'] },
  purposeOfRequest: { type: String, enum: ['PRODUCTCHANGE', 'MOVING', 'PROVIDERCHANGE', 'ANOTHERLOCATION'], required: [true, 'purposeOfRequest is required'] },
  oldAddress: { type: addressSchema },
  oldContractEndDate: { type: Date },
  newContractStartDate: { type: Date },
  measurementMethod: { type: String, enum: ['Yleissähkö', 'Yösähkö', 'Kausisähkö'] },
  vakaa: { type: vakaaSchema },
  kesto: { type: kestoSchema },
  takuu: { type: takuuSchema }
})

let VWorkOrderModel = new Schema({
  customer: { type: customerSchema },
  deliverySite: { type: deliverySiteSchema, required: [true, 'deliverySite is required field'] },
  contractId: { type: String },
  ssn: { type: String },
  companyId: { type: String, enum: ['Fortum Finland', 'Fortum Sweden', 'Fortum Poland '], required: [true, 'Fortum Company Name is required'] },
  installation: { type: installationSchema },
  additionalParts: { type: additionalPartsSchema },
  deviceId: { type: String },
  multiplier: { type: Number },
  clampCT: { type: Number },
  led: { type: String, enum: ['1000', '10000'] },
  readingMethod: { type: String, enum: ['Current Clamp', 'Led'] },
  installationMethod: { type: String, enum: ['DIN', 'Empty Slot'] },
  device: { type: deviceStatusSchema, default: {} },
  selfService: { type: selfServiceSchema },
  saleAgentId: { type: String },
  faultDevices: { type: [faultDeviceListSchema] },
  notes: { type: [noteSchema] },
  installatorNotes: { type: [noteSchema] },
  additionalInformation: { type: String },
  extraInfoForInstallation: { type: String },
  deviceSettingId: { type: String },
  status: { type: String, enum: ['OrderReceived', 'InstallerYetToReceive', 'WaitingForInstallation', 'Completed', 'TimeScheduled', 'Returned', 'Cancelled'], default: 'OrderReceived' },
  statebeforecancelled: { type: String, enum: ['OrderReceived', 'InstallerYetToReceive', 'WaitingForInstallation', 'Completed', 'TimeScheduled', 'Returned', 'Cancelled'] },
  statusChangeOn: { type: Date },
  sentToInstallerOn: { type: Date },
  AccessibilityForTechnician: { type: String, enum: ['InsideTheBuilding', 'OutsideTheBuilding'] },
  termsAccepted: { type: String, enum: ['Yes', 'No'] },
  extraMaterial: { type: [extraMaterialSchema] },
  country: { type: String, enum: ['FI'] },
  app: { type: String, enum: ['VODA'] },
  modifiedOn: { type: Date },
  createdOn: { type: Date, default: Date.now },
  createdBy: { type: String },
  createdByUserRole: { type: String }
})

VWorkOrderModel.plugin(patcher)
VWorkOrderModel.plugin(autoIncrement.plugin, { model: 'VODA-WorkOrder', field: 'vodaOrderNumber', startAt: 1000, incrementBy: 1 })

module.exports = mongoose.model('VODA-WorkOrder', VWorkOrderModel)
