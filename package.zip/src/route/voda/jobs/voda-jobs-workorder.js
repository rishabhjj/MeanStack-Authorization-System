let express = require('express')
let push = require('./../../../route/voda/jobs/voda-jobs-wo-push-to-installer').patch
let orderReceived = require('./../../../route/voda/jobs/voda-jobs-wo-kpi-notification').orderReceived

let routes = function (Workorder, VODAAgeing, Attachments) {
  let router = express.Router()

  router.route('/pushtoinstaller')
    .post(function (req, res) {
      push(req, res, Workorder, VODAAgeing, Attachments)
    })

  router.route('/kpi/OrderReceived')
    .get(function (req, res) {
      orderReceived(req, res, Workorder)
    })

  return router
}

module.exports = routes
