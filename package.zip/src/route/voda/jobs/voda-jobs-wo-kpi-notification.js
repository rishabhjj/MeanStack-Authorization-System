let moment = require('moment')
let logger = require('./../../../app/helpers/logger/log')

function orderReceived (req, res, Workorder) {
  try {
    let query = {}
    let vodaWaitingDays = (process.env.VODA_WO_WAITING_DAYS || 6)
    query.createdOn = moment().add(-(vodaWaitingDays), 'days').hours(-24).minutes(0).seconds(0)
    query.status = 'OrderReceived'

    Workorder.find({ createdOn: { $lte: query.createdOn }, status: query.status }, { _id: 1, 'country': 1, 'app': 1, 'createdOn': 1, 'createdBy': 1, 'vodaOrderNumber': 1 }, '-__v',
      function (err, doc) {
        if (err) {
          res.status(417).send(err)
        } else {
          res.status(200).send(doc)
        }
      })
  } catch (err) {
    logger.error(req, res, err, 'VODA-JOBS-WORKORDER-KPI-ORDER-RECEIVED')
  }
}

module.exports = {
  orderReceived
}
