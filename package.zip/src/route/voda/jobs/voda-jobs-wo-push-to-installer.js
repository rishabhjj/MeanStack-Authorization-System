let moment = require('moment')
let logger = require('./../../../app/helpers/logger/log')
let empower = require('./../../../route/voda/functions/voda-func-empower')
let ageing = require('./../../../route/voda/workorder/voda-workorder-ageing')

let customerMailer = require('./../../../Routes/Messaging/VODA/Customer/vodaCustomerMail')
let InstallerMailer = require('./../../../Routes/Messaging/VODA/Installer/sentToInstaller')

function patch (req, res, VWorkorder, VODAAgeing, Attachments) {
  try {
    let query = {}
    let vodaWaitingDays = process.env.VODA_WO_WAITING_DAYS || 0
    query.createdOn = moment().add(-(vodaWaitingDays), 'days').hours(0).minutes(0).seconds(0)
    query.status = 'OrderReceived'

    VWorkorder.find({ createdOn: { $lte: query.createdOn }, status: query.status }, '-__v', function (err, doc) {
      if (err) {
        res.status(417).send(err)
      } else {
        let count = 0
        var updateWO = function (doc) {
          return new Promise((resolve, reject) => {
            if (doc.length > 0) {
              for (let i = 0; i < doc.length; i++) {
                if (doc[i].status === 'OrderReceived' && doc[i].contractId !== undefined && doc[i].deliverySite.deliverysiteId !== undefined) {
                  let patches = []
                  patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })
                  patches.push({ 'op': 'add', 'path': '/status', 'value': 'WaitingForInstallation' })
                  patches.push({ 'op': 'add', 'path': '/notes/', 'value': { 'createdBy': 'Scheduler', 'note': 'Sent to Installer after waiting period by scheduler job.' } })

                  doc[i].patch(patches, function (err, wo) {
                    if (err) {
                      reject(err)
                    } else {
                      ageing.patch(VODAAgeing, wo)

                      let country = 'FI'
                      let processName = 'VODA' + '_' + country
                      let receivedTime = new Date()

                      let archival = {
                        'request': {
                          'content': patches,
                          'headers': {
                            'requestId': '000',
                            'country': wo.country,
                            'app': wo.app,
                            'user': 'Schduler',
                            'role': 'Schduler'
                          },
                          'method': 'POST',
                          'requestUri': '',
                          'resourceName': 'Workorder.Empower',
                          'queryString': ''
                        },
                        'response': {
                          'statusCode': '',
                          'content': {
                          }
                        }
                      }
                      empower.post(archival, wo, country, req.env, processName, receivedTime)

                      let sendMailToFinlandCustomer = process.env.VODA_FI_SEND_MAIL_TO_CUSTOMER || 'TRUE'
                      if (sendMailToFinlandCustomer.toUpperCase() === 'TRUE') {
                        customerMailer.post(wo, country, Attachments)
                      }

                      let sendMailToFinlandInstaller = process.env.VODA_FI_SEND_MAIL_TO_INSTALLER_COMPANY || 'TRUE'
                      if (sendMailToFinlandInstaller === 'TRUE') {
                        InstallerMailer.post(wo, country)
                      }
                      count = count + 1
                    }
                  })
                }
                if ((i + 1) === doc.length) {
                  resolve(count)
                }
              }
            } else {
              resolve(count)
            }
          })
        }

        updateWO(doc).then((val) => res.status(200).send({ 'info': 'No of Workorders updated: ' + val }))
          .catch((err) => res.status(417).send({ 'error': err }))
      }
    })
  } catch (err) {
    logger.error(req, res, err, 'VODA-JOBS-WORKORDER-PUSH-TO-INSTALLER')
  }
}

module.exports = {
  patch
}
