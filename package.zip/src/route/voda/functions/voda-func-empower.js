import { error } from './../../../app/helpers/logger/log'
import request from 'superagent-es6-promise'
import { archive } from './../../../app/helpers/archival/archive'

export function pushWorkorder (workorder, task, country, app) {
  return new Promise((resolve, reject) => {
    try {
      let joda = process.env.ENV_ADMIN_URL || 'https://retail-joda-dev-fi.herokuapp.com'
      let url = joda + '/hoda/workorder/' + workorder._id
      let azureAPIRootURL = process.env.CBUS_API_MANAGMENT_URL || 'https://testapi.fortum.com'
      let azureAPI = azureAPIRootURL + '/Empower/WorkOrderService'
      let azureKey = process.env.CBUS_API_MANAGMENT_KEY || '3f7b92e86ed64d6193aec0f73704a545'
      let id = Math.floor((Math.random() * 1222222222200) + 1)
      let woe = ''
      let customerId = ''
      let customerName = ''
      let accessibilityForTechnician = ''
      let notes = ''

      let customerAddress = workorder.customer.address.street !== undefined ? workorder.customer.address.street : ''
      let customerAddressZipCode = workorder.customer.address.zip !== undefined ? workorder.customer.address.zip : ''
      let customerAddressCity = workorder.customer.address.city !== undefined ? workorder.customer.address.city : ''
      let customerPhoneNumber = workorder.customer.contactInfo.phone !== undefined ? workorder.customer.contactInfo.phone : ''
      let customerEmailId = workorder.customer.contactInfo.email !== undefined ? workorder.customer.contactInfo.email : ''
      let deliverySiteId = workorder.deliverySite.address.deiverySiteId !== undefined ? workorder.deliverySite.address.deiverySiteId : ''
      let deliveryAddress = workorder.deliverySite.address.street !== undefined ? workorder.deliverySite.address.street : ''
      let deliveryAddressZipCode = workorder.deliverySite.address.zip !== undefined ? workorder.deliverySite.address.zip : ''
      let deliveryAddressCity = workorder.deliverySite.address.city !== undefined ? workorder.deliverySite.address.city : ''

      if (app === 'VODA') {
        woe = workorder.vodaOrderNumber
        customerId = workorder.customer.customerId !== undefined ? workorder.customer.customerId : ''
        let firstName = workorder.customer.name !== undefined ? workorder.customer.name : ''
        let lastName = workorder.customer.lastName !== undefined ? workorder.customer.lastName : ''
        customerName = `${firstName} ${lastName}`
        accessibilityForTechnician = workorder.AccessibilityForTechnician !== undefined ? workorder.AccessibilityForTechnician : ''
        if (workorder.notes !== undefined && workorder.notes.length > 0) {
          for (let n = 0; n >= workorder.notes.length; n++) {
            notes = notes + workorder.notes[0].note + ' '
          }
        }
      } else if (app === 'HODA') {
        woe = workorder.hodaOrderNumber
        customerId = workorder.customer.customerId !== undefined ? workorder.customer.customerId : ''
        let firstName = workorder.customer.firstName !== undefined ? workorder.customer.firstName : ''
        let lastName = workorder.customer.lastName !== undefined ? workorder.customer.lastName : ''
        customerName = `${firstName} ${lastName}`
        if (workorder.customerServiceNotes !== undefined && workorder.customerServiceNotes.length > 0) {
          for (let n = 0; n >= workorder.customerServiceNotes.length; n++) {
            notes = notes + workorder.customerServiceNotes[0].note + ' '
          }
        }
      }

      let message = {
        'order': {
          'url': url,
          'messageID': id,
          'createdDateTime': new Date(),
          'order_number': 'WOE' + woe,
          'customer': {
            'customer_number': customerId,
            'customer_name': customerName,
            'customer_address': customerAddress,
            'customer_zipcode': customerAddressZipCode,
            'customer_postal_place': customerAddressCity,
            'customer_phone_number': customerPhoneNumber,
            'customer_email': customerEmailId
          },
          'delivery': {
            'delivery_site_address': deliveryAddress,
            'delivery_site_zipcode': deliveryAddressZipCode,
            'delivery_site_postal_place': deliveryAddressCity,
            'delivery_site_ID': deliverySiteId
          },
          'product': {
            'selected_installation_product': task
          },
          'extra_info_for_installation': notes,
          'accessibility_for_technician': accessibilityForTechnician
        }
      }

      let archiveContent = {
        'request': {
          'content': message,
          'headers': {
            'requestId': id,
            'country': country,
            'app': app,
            'user': '',
            'role': ''
          },
          'method': 'POST',
          'requestUri': azureAPI,
          'resourceName': 'Empower-WO',
          'queryString': ''
        },
        'response': {
          'statusCode': '',
          'content': {
          }
        }
      }

      let env = process.env.ENV || 'TEST'
      let processName = app + '_' + country

      request
        .post(azureAPI)
        .send(message)
        .set('RequestId', id)
        .set('Ocp-Apim-Subscription-Key', azureKey)
        .set('RequestingSystem', app)
        .set('TargetSystem', 'Empower')
        .set('Content-Type', 'application/json')
        .set('Accept', 'application/json')
        .then(function (res) {
          archive(archiveContent, res.body, res.statusCode, env, processName, null, id)
          resolve(res)
        }, function (error) {
          archive(archiveContent, error.body, error.statusCode, env, processName, null, id)
          console.log(error)
          reject(error)
        })
    } catch (err) {
      error(undefined, undefined, err, 'FUNC-EMPOWER')
    }
  })
}
