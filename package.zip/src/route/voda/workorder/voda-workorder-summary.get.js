let archival = require('./../../../app/helpers/archival/archive')
let logger = require('./../../../app/helpers/logger/log')

function get (VWorkorder, req, res) {
  try {
    if (req.role === 'CUSTOMERSERVICE') {
      var agg = [{ $match: { 'country': req.country, 'app': req.app } }, { $group: { _id: '$status', total: { $sum: 1 } } }]
      VWorkorder.aggregate(agg, function (err, data) {
        if (err) {
          archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(417).send(err)
        } else {
          archival.log(req.archival, data, 200, req.env, req.processName, req.receivedTime, req.requestId)
          res.json(data)
        }
      })
    } else {
      archival.log(req.archival, '', 401, req.env, req.processName, req.receivedTime, req.requestId)
      res.status(401).send()
    }
  } catch (err) {
    logger.error(req, res, err, 'VODA-WORKORDER-SUMMARY-GET')
  }
}

module.exports = {
  get: get
}
