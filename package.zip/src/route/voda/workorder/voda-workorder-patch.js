import { getCancellationInfo } from './../../../route/voda/workorder/voda-workorder-func'
import { CompleteProcess } from './../../../app/helpers/utilities/utility'
import { consoleLogger } from './../../../app/helpers/logger/log'
import { pushWorkorder } from './../../../app/repo/shared/EmpowerFunc'
let crypt = require('./../../../app/helpers/crypt/crypt')
let ageing = require('./../../../route/voda/workorder/voda-workorder-ageing')

let customerMailer = require('./../../../Routes/Messaging/VODA/Customer/vodaCustomerMail')
let mailToInstaller = require('./../../../Routes/Messaging/VODA/Installer/sentToInstaller')
let customerServiceMailer = require('./../../../Routes/Messaging/VODA/CustomerService/sentToCustomerService')

export function patch (VWorkorder, VODAAgeing, Attachments, Audit, id, req, res) {
  try {
    let patches = req.body
    patches.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })

    VWorkorder.findById(id, '-__v', function (err, wo) {
      if (err) {
        if (err.name === 'CastError' && err.path === '_id') {
          CompleteProcess(req, res, {}, 404)
        } else {
          CompleteProcess(req, res, err, 417)
        }
      } else {
        if (wo == null) {
          CompleteProcess(req, res, {}, 404)
        } else {
          if (req.country === wo.country && req.app === wo.app) {
            let existingStatus = wo.status
            let targetStatus = 'NONE'
            for (var i = 0, len = patches.length; i < len; i++) {
              var element = patches[i].path
              let isStatusUpdate = element.search(new RegExp('status', 'i'))
              if (isStatusUpdate === 1) {
                targetStatus = patches[i].value
                patches.push({ 'op': 'add', 'path': '/statusChangeOn', 'value': new Date() })
              }

              let isSSNUpdate = element.search(new RegExp('ssn', 'i'))
              if (isSSNUpdate === 1) {
                let ssn = crypt.encrypt(patches[i].value)
                patches.push({ 'op': 'add', 'path': '/ssn', 'value': ssn.toString() })
              }
            }
            let sendFinlandInstallerMail = process.env.VODA_FI_SEND_MAIL_TO_INSTALLER_COMPANY || 'TRUE'

            if (wo.country === 'FI' && (targetStatus === 'WaitingForInstallation' && (existingStatus !== targetStatus))) {
              // Call Empower API first then update the WO status, if country = FI & status is SentToInstaller
              pushWorkorder(wo, 'vpp_install', req.country, req.app)
                .then(result => {
                  if (result.statusCode === 200) {
                    wo.patch(patches, function (err, doc) {
                      if (err) {
                        CompleteProcess(req, res, err, 417)
                      } else {
                        if (targetStatus === 'WaitingForInstallation' && sendFinlandInstallerMail === 'TRUE') {
                          mailToInstaller.post(doc, req.country, undefined)
                        }

                        if (doc.ssn !== undefined) {
                          let ssn = crypt.decrypt(doc.ssn)
                          doc.ssn = ssn
                        }
                        ageing.patch(VODAAgeing, wo)
                        CompleteProcess(req, res, doc, 202)
                      }
                    })
                  } else {
                    console.log(result)
                    CompleteProcess(req, result, 'Error in Sending data to Empower', 417)
                  }
                })
                .catch(error => console.log(error))
            } else {
              wo.patch(patches, function (err, doc) {
                if (err) {
                  CompleteProcess(req, res, err, 417)
                } else {
                  let sendFinlandCustomerMail = process.env.VODA_FI_SEND_MAIL_TO_CUSTOMER || 'TRUE'
                  if (sendFinlandCustomerMail.toUpperCase() === 'TRUE' && req.country === 'FI' && existingStatus !== 'InstallerYetToReceive') {
                    customerMailer.post(doc, req.country, Attachments)
                  }

                  if (targetStatus === 'Cancelled' && sendFinlandInstallerMail === 'TRUE') {
                    getCancellationInfo(doc, Attachments, req.country, req.app)
                      .then(result => {
                        mailToInstaller.post(doc, req.country, result)
                      })
                      .catch(err => {
                        console.log(err)
                      })
                  }
                  let sendFinlandCSMail = process.env.VODA_FI_SEND_MAIL_TO_CUSTOMER_SERVICE_TEAM || 'TRUE'
                  if ((targetStatus === 'Cancelled' || targetStatus === 'Returned') && req.country === 'FI' && sendFinlandCSMail === 'TRUE') {
                    customerServiceMailer.post(doc, req.country, Attachments)
                  }

                  ageing.patch(VODAAgeing, wo)

                  if (doc.ssn !== undefined) {
                    let ssn = crypt.decrypt(doc.ssn)
                    doc.ssn = ssn
                  }
                  CompleteProcess(req, res, doc, 202)
                }
              })
            }
          } else {
            let message = { 'error': 'Country or App is not matching' }
            CompleteProcess(req, res, message, 403)
          }
        }
      }
    })
  } catch (err) {
    consoleLogger(undefined, undefined, err, 'VODA-WORKORDER-PATCH')
  }
}
