let decrypt = require('./../../../app/helpers/crypt/crypt').decrypt
let archival = require('./../../../app/helpers/archival/archive')
let logger = require('./../../../app/helpers/logger/log')

function get (Workorder, req, res) {
  try {
    if (req.filterCondition._id === undefined && req.headers.token === undefined) {
      res.status(401).send({ 'error': 'WO ID is missing' })
    } else if (req.filterCondition._id === undefined && req.headers.token !== undefined && req.headers.token !== 'A88D982A-FC81-4EA9-BEB3-189AA0808B78') {
      res.status(403).send({ 'error': 'Invalid Token' })
    } else {
      Workorder.find(req.filterCondition, '-__v', function (err, doc) {
        if (err) {
          if (err.name === 'CastError' && err.path === '_id') {
            let response = []
            res.status(200).send(response)
          } else {
            res.status(417).send(err)
          }
        } else {
          if (doc.length > 0) {
            for (let i = 0; i < doc.length; i++) {
              if (doc[i].ssn !== undefined) {
                let ssn = decrypt(doc[i].ssn)
                doc[i].ssn = ssn
              }
            }
          }
          archival.log(req.archival, doc, 200, req.env, req.processName, req.receivedTime, req.requestId)
          res.json(doc)
        }
      })
    }
  } catch (err) {
    logger.error(req, res, err, 'VODA-WORKORDER-GET')
  }
}

module.exports = {
  get: get
}
