import express from 'express'
import {getCancelledRetured} from './../../../route/voda/workorder/voda-workorder-cancelled-retured-report-get'
let retrive = require('./../../../route/voda/workorder/voda-workorder-get').get
let create = require('./../../../route/voda/workorder/voda-workorder-post').post
let update = require('./../../../route/voda/workorder/voda-workorder-patch').patch
let summary = require('./../../../route/voda/workorder/voda-workorder-summary.get').get
let search = require('./../../../route/voda/workorder/voda-workorder-search-get').get
let remove = require('./../../../route/voda/workorder/voda-workorder-delete').remove

let filter = require('./../../../route/voda/workorder/voda-workorder-filter')
let ageing = require('./../../../route/voda/workorder/voda-workorder-ageing').get
let reporting = require('./../../../route/voda/workorder/voda-workorder-report-get').get
let logger = require('./../../../app/helpers/logger/log')
let utility = require('./../../../app/helpers/utilities/utility')

let routes = function (Workorder, VODAAgeing, Attachments, Audit) {
  try {
    let router = express.Router()

    router.use(function (req, res, next) {
      utility.isValid(req, res, next, 'Workorder')
    })

    router.use(function (req, res, next) {
      filter.setQuery(req, res, next)
    })

    router.route('/:id')
      .patch(function (req, res) {
        let id = req.params.id
        update(Workorder, VODAAgeing, Attachments, Audit, id, req, res)
      })

    router.route('/')
      .get(function (req, res) {
        retrive(Workorder, req, res)
      })
      .post(function (req, res) {
        create(Workorder, VODAAgeing, Attachments, req, res)
      })
      .delete(function (req, res) {
        remove(Workorder, req, res)
      })

    router.route('/summary')
      .get(function (req, res) {
        req.archival.request.resourceName = 'Workorder_Summary_' + req.method
        summary(Workorder, req, res)
      })

    router.route('/search')
      .get(function (req, res) {
        req.archival.request.resourceName = 'Workorder_Search_' + req.method
        search(Workorder, req, res)
      })

    router.route('/ageing')
      .get(function (req, res) {
        ageing(VODAAgeing, req, res)
      })

    router.use('/reporting', function (req, res, next) {
      filter.setQueryForAgeingReport(req, res, next)
    })

    router.route('/reporting')
      .get(function (req, res) {
        reporting(Workorder, req, res)
      })

    router.use('/reporting/cancelledReturned', function (req, res, next) {
      filter.setQueryForCancelledReturnedReport(req, res, next)
    })

    router.route('/reporting/cancelledReturned')
      .get(function (req, res) {
        getCancelledRetured(Attachments, req, res)
      })

    return router
  } catch (err) {
    logger.error(undefined, undefined, err, 'VODA-WORKORDER')
  }
}
module.exports = routes
