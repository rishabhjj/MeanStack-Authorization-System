import { CompleteProcess } from './../../../app/helpers/utilities/utility'
import { consoleLogger } from './../../../app/helpers/logger/log'
import moment from 'moment'

export function getCancelledRetured (Attachments, req, res) {
  try {
    let start = moment(new Date()).add(-100000, 'days').format()
    let end = new Date()

    if (req.query.startDate !== undefined) { start = new Date(req.query.startDate) }
    if (req.query.endDate !== undefined) { end = moment(new Date(req.query.endDate)).add(1, 'days').format() }
    let createdOn = { '$gte': start, '$lte': end }

    Attachments.find({
      $and: [
        { 'country': req.country },
        { 'app': req.app },
        { 'createdOn': createdOn },
        { 'vpp.key': { $not: { $eq: 'REPORT' } } }
      ]
    }, {
      _id: 1,
      'workorderId': 1,
      'vpp.key': 1,
      'vpp.reasonCancellation': 1,
      'vpp.cancellationNote': 1,
      'vpp.returnReason': 1,
      'vpp.returnNote': 1,
      'country': 1,
      'createdOn': 1
    }, '-__v', function (err, doc) {
      if (err) {
        CompleteProcess(req, res, err, 417)
      } else {
        CompleteProcess(req, res, doc, 200)
      }
    })
  } catch (err) {
    consoleLogger(req, res, err, 'VODA-WORKORDER-REPORT-CANCELLED-RETURNED-GET')
  }
}
