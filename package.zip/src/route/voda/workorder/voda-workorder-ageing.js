let logger = require('./../../../app/helpers/logger/log')
let moment = require('moment')

function get (VODAAgeing, req, res) {
  try {
    var query = {}
    let start = new Date()
    let end = new Date()

    if (req.query.startDate !== undefined) { start = new Date(req.query.startDate) }
    if (req.query.endDate !== undefined) { end = moment(new Date(req.query.endDate)).add(1, 'days').format() }
    if (req.query.startDate || req.query.endDate) {
      query.modifiedOn = { '$gte': start, '$lte': end }
    }

    query.country = req.country
    query.app = req.app

    VODAAgeing.find(query, '-__v', function (err, doc) {
      if (err) {
        res.status(417).send(err)
      } else {
        res.json(doc)
      }
    })
  } catch (err) {
    logger.error(undefined, undefined, err, 'VODA-WORKORDER-AGEING-GET')
  }
}

function post (VODAAgeing, wo) {
  try {
    let ageingData = new VODAAgeing()
    ageingData.name = wo.customer.name
    ageingData.workOrderServiceKey = wo._id
    ageingData.workOrderNumber = wo.vodaOrderNumber
    ageingData.createdBy = wo.createdBy
    ageingData.orderReceived = wo.createdOn
    ageingData.currentStatus = 'OrderReceived'
    ageingData.country = wo.country
    ageingData.modifiedOn = wo.createdOn

    let ageing = new VODAAgeing(ageingData)
    ageing.save()
  } catch (err) {
    logger.error(undefined, undefined, err, 'VODA-WORKORDER-AGEING-POST')
  }
}

function patch (VODAAgeing, wo) {
  try {
    let ageingQuery = {}
    ageingQuery.workOrderServiceKey = wo._id
    VODAAgeing.find(ageingQuery, '-__v', function (err, ageingDoc) {
      if (err || ageingDoc.length === 0) {
        let ageingData = new VODAAgeing()
        ageingData.name = wo.customer.name
        ageingData.workOrderServiceKey = wo._id
        ageingData.workOrderNumber = wo.vodaOrderNumber
        ageingData.createdBy = wo.createdBy
        ageingData.createdByUserRole = wo.createdByUserRole
        ageingData.orderReceived = wo.createdOn
        ageingData.currentStatus = wo.status
        ageingData.country = wo.country
        ageingData.modifiedOn = wo.createdOn
        let ageing = new VODAAgeing(ageingData)
        ageing.save()
      } else {
        let mid = ageingDoc[0]._id
        VODAAgeing.findById(mid, '-__v', function (err, ageingDoc) {
          if (!err && ageingDoc != null) {
            let ageingPatch = []
            ageingPatch.push({ 'op': 'add', 'path': '/modifiedOn', 'value': new Date() })
            ageingPatch.push({ 'op': 'add', 'path': '/currentStatus', 'value': wo.status })

            switch (wo.status) {
              case 'OrderReceived':
                ageingPatch.push({ 'op': 'add', 'path': '/orderReceived', 'value': new Date() })
                break
              case 'WaitingForInstallation':
                ageingPatch.push({ 'op': 'add', 'path': '/waitingForInstallation', 'value': new Date() })
                break
              case 'Completed':
                ageingPatch.push({ 'op': 'add', 'path': '/completed', 'value': new Date() })
                break
              case 'TimeScheduled':
                ageingPatch.push({ 'op': 'add', 'path': '/timeScheduled', 'value': new Date() })
                break
              case 'Returned':
                ageingPatch.push({ 'op': 'add', 'path': '/returned', 'value': new Date() })
                break
              case 'Cancelled':
                ageingPatch.push({ 'op': 'add', 'path': '/cancelled', 'value': new Date() })
                break
              default:
            }

            ageingDoc.patch(ageingPatch, function (err, ageingDocResult) {
              if (err) {
                logger.error(undefined, undefined, err, 'VODA-WORKORDER-AGEING-PATCH')
              }
            })
          }
        })
      }
    })
  } catch (err) {
    logger.consoleLog(err, 'VODA-WORKORDER-AGEING')
  }
}

module.exports = {
  get,
  post,
  patch
}
