let archival = require('./../../../app/helpers/archival/archive')
let logger = require('./../../../app/helpers/logger/log')

function remove (VWorkorder, req, res) {
  try {
    if (req.headers.token !== undefined && req.headers.token === 'A88D982A-FC81-4EA9-BEB3-189AA0808B78') {
      VWorkorder.remove(req.filterCondition, function (err, logs) {
        if (err) {
          archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(417).send(err)
        } else {
          archival.log(req.archival, logs, 204, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(204).send({ 'info': 'Removed' })
        }
      })
    } else {
      archival.log(req.archival, '', 401, req.env, req.processName, req.receivedTime, req.requestId)
      res.status(401).send({ 'error': 'Not allowed' })
    }
  } catch (err) {
    logger.error(req, res, err, 'VODA-WORKORDER-DELETE')
  }
}

module.exports = {
  remove
}
