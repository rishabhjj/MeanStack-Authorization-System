
let customerMailer = require('./../../../Routes/Messaging/VODA/Customer/vodaCustomerMail')
let customerServiceMailer = require('./../../../Routes/Messaging/VODA/CustomerService/sentToCustomerService')
let crypt = require('./../../../app/helpers/crypt/crypt')
let archival = require('./../../../app/helpers/archival/archive')
let ageing = require('./../../../route/voda/workorder/voda-workorder-ageing')
let logger = require('./../../../app/helpers/logger/log')

function post (VWorkorder, VODAAgeing, Attachments, req, res) {
  try {
    let data = new VWorkorder()
    data = req.body
    data.country = req.country
    data.app = req.app
    data.createdOn = new Date()
    data.createdBy = req.user
    data.createdByUserRole = req.role
    data.modifiedOn = new Date()
    data.statusChangeOn = new Date()

    if (req.body.customer !== undefined && req.body.customer.name !== undefined) {
      data.customer.name = (req.body.customer.name).toUpperCase()
    }
    if (req.body.customer !== undefined && req.body.customer.lastName !== undefined) {
      data.customer.lastName = (req.body.customer.lastName).toUpperCase()
    }
    if (req.body.customer !== undefined && req.body.customer.address !== undefined && req.body.customer.address.street !== undefined) {
      data.customer.address.street = (req.body.customer.address.street).toUpperCase()
    }
    if (req.body.customer !== undefined && req.body.customer.address !== undefined && req.body.customer.address.city !== undefined) {
      data.customer.address.city = (req.body.customer.address.city).toUpperCase()
    }
    if (req.body.deliverySite !== undefined && req.body.deliverySite.address !== undefined && req.body.deliverySite.address.street !== undefined) {
      data.deliverySite.address.street = (req.body.deliverySite.address.street).toUpperCase()
    }
    if (req.body.deliverySite !== undefined && req.body.deliverySite.address !== undefined && req.body.deliverySite.address.city !== undefined) {
      data.deliverySite.address.city = (req.body.deliverySite.address.city).toUpperCase()
    }

    if (req.body.ssn !== undefined) {
      let ssn = (req.body.ssn).toUpperCase()
      data.ssn = crypt.encrypt(ssn)
    }

    let wo = new VWorkorder(data)
    wo.save(function (err) {
      if (err) {
        res.status(417).send(err)
      } else {
        // Customer mail
        let sendFinlandCustomerMail = process.env.VODA_FI_SEND_MAIL_TO_CUSTOMER || 'TRUE'
        if (sendFinlandCustomerMail.toUpperCase() === 'TRUE' && req.country === 'FI') {
          customerMailer.post(data, req.country, Attachments)
        }

        let sendFinlandCSMail = process.env.VODA_FI_SEND_MAIL_TO_CUSTOMER_SERVICE_TEAM || 'TRUE'
        if (req.country === 'FI' && sendFinlandCSMail === 'TRUE') {
          customerServiceMailer.post(wo, req.country, Attachments)
        }

        // Below lines of code is needed to fix Circular reference error while archiving the request/response
        if (req.body.ssn !== undefined) {
          req.archival.request.content.ssn = crypt.decrypt(wo.ssn)
        }

        ageing.post(VODAAgeing, wo)
        archival.log(req.archival, wo, 201, req.env, req.processName, req.receivedTime, req.requestId)
        res.status(201).send(wo)
      }
    })
  } catch (err) {
    logger.log(req, res, err, 'Voda.WO.Post')
  }
}

module.exports = {
  post: post
}
