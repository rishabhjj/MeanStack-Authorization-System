export function getCancellationInfo (data, Attachments, country, app) {
  return new Promise((resolve, reject) => {
    let query = {}
    query.workorderId = data._id
    let reason = 'Refer the WO for further details'
    Attachments.find(query, '-__v', function (err, doc) {
      if (err || doc.length === 0) {
        resolve(reason)
      } else {
        if (data.status === 'Cancelled') {
          let reasonCancellation = doc[doc.length - 1].vpp.reasonCancellation !== undefined ? doc[doc.length - 1].vpp.reasonCancellation : ''
          let cancellationNote = doc[doc.length - 1].vpp.cancellationNote !== undefined ? doc[doc.length - 1].vpp.cancellationNote : ''
          reason = 'Cancelled Reason: ' + reasonCancellation + ' & additional Note: ' + cancellationNote
          resolve(reason)
        }
      }
    })
  })
}
