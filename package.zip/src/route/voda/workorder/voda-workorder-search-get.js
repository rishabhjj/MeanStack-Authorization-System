// let crypt = require('./../../../app/helpers/crypt/crypt')
let archival = require('./../../../app/helpers/archival/archive')
let logger = require('./../../../app/helpers/logger/log')
let mongoose = require('mongoose')

function get (VWorkorder, req, res) {
  try {
    if (req.role === 'CUSTOMERSERVICE') {
      if (req.query.searchText || req.query.latest) {
        var searchText = req.query.searchText
        if (searchText === undefined || searchText == null) {
          searchText = ''
        }
        var limit = req.query.limit
        var limitSize = 25
        var skip = req.query.skip
        var skipSize = 0
        if (limit !== undefined || limit != null) {
          limitSize = parseInt(limit)
        }

        if (skipSize !== undefined || skipSize != null) {
          skipSize = parseInt(skip)
        }

        var totalRecords = 0
        var isValidObjectId = mongoose.Types.ObjectId.isValid(searchText)
        var oid = 'zzzzzzzzzzzz'
        if (isValidObjectId) {
          oid = req.query.searchText
        }

        var wom = req.query.searchText
        if (wom !== undefined) {
          wom = wom.toUpperCase()
        }

        if (wom !== undefined && wom.includes('WOE')) {
          wom = wom.replace('WOE', '')
          var womQuery = {}
          womQuery.country = req.header('country')
          womQuery.app = req.header('app')
          womQuery.vodaOrderNumber = wom

          VWorkorder.find(womQuery, { _id: 1, 'country': 1, 'app': 1, 'createdOn': 1, 'statusChangeOn': 1, 'customer.name': 1,'customer.lastName': 1, 'vodaOrderNumber': 1, 'sentToInstallerOn': 1, 'status': 1, 'installation': 1, 'modifiedOn': 1 }, '-__v', function (err, logs) {
            if (err) {
              archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
              res.status(417).send(err)
            } else {
              res.append('totalRecords', logs.length)
              archival.log(req.archival, logs, 200, req.env, req.processName, req.receivedTime, req.requestId)
              res.json(logs)
            }
          })
        } else {
          var str1 = '.*'
          var str2 = str1.concat(searchText)
          var str3 = str2.concat('.*')

          //   let encryptedSSN = crypt.encrypt(str3)

          VWorkorder.count(
            {
              $and: [
                { 'country': req.country },
                { 'app': req.app },
                {
                  $or: [
                    { 'customer.name': { $regex: str3.toUpperCase() } },
                    { 'customer.lastName': { $regex: str3.toUpperCase() } },
                    { 'ssn': { $regex: str3 } },
                    { 'deliverySite.address.street': { $regex: str3.toUpperCase() } },
                    { 'deliverySite.address.city': { $regex: str3.toUpperCase() } },
                    { 'deliverySite.address.zip': { $regex: str3 } },
                    { 'status': { $regex: str3 } },
                    { 'customer.customerId': { $regex: str3 } },
                    { '_id': oid }
                  ]
                }
              ]
            }
            , function (err, count) {
              if (err) {
                logger.error(req, res, err, 'VODA-WORKORDER-SEARCH-GET')
              } else {
                totalRecords = count
                VWorkorder.find(
                  {
                    $and: [
                      { 'country': req.country },
                      { 'app': req.app },
                      {
                        $or: [
                          { 'customer.name': { $regex: str3.toUpperCase() } },
                          { 'customer.lastName': { $regex: str3.toUpperCase() } },
                          { 'ssn': { $regex: str3 } },
                          { 'deliverySite.address.street': { $regex: str3.toUpperCase() } },
                          { 'deliverySite.address.city': { $regex: str3.toUpperCase() } },
                          { 'deliverySite.address.zip': { $regex: str3 } },
                          { 'status': { $regex: str3 } },
                          { 'customer.customerId': { $regex: str3 } },
                          { '_id': oid }
                        ]
                      }
                    ]
                  }
                  ,
                  { _id: 1, 'country': 1, 'app': 1, 'createdOn': 1, 'statusChangeOn': 1, 'sentToInstallerOn': 1, 'customer.name': 1,'customer.lastName': 1, 'vodaOrderNumber': 1, 'status': 1, 'installation': 1, 'modifiedOn': 1 }, function (err, doc) {
                    if (err) {
                      archival.log(req.archival, err, 417, req.env, req.processName, req.receivedTime, req.requestId)
                      res.status(417).send(err)
                    } else {
                      res.append('totalRecords', totalRecords)
                      archival.log(req.archival, doc, 200, req.env, req.processName, req.receivedTime, req.requestId)
                      res.json(doc)
                    }
                  }).skip(skipSize).limit(limitSize).sort({ modifiedOn: -1 })
              }
            })
        }
      } else {
        let message = { 'error': 'Query String is missing' }
        archival.log(req.archival, message, 417, req.env, req.processName, req.receivedTime, req.requestId)
        res.status(417).send(message)
      }
    } else {
      archival.log(req.archival, '', 401, req.env, req.processName, req.receivedTime, req.requestId)
      res.status(401).send()
    }
  } catch (err) {
    logger.error(undefined, undefined, err, 'VODA-WORKORDER-SEARCH-GET')
  }
}

module.exports = {
  get
}
