let moment = require('moment')
let logger = require('./../../../app/helpers/logger/log')

function setQuery (req, res, next) {
  try {
    var query = {}
    if (req.query._id !== undefined) { query._id = req.query._id }
    if (req.query.workOrderNumber !== undefined) { query.workOrderNumber = req.query.workOrderNumber }
    if (req.query.customerId !== undefined) { query.customerId = req.query.customerId }
    if (req.query.installerId !== undefined) { query.installerId = req.query.installerId }
    if (req.query.status !== undefined) { query.status = req.query.status }

    query.country = req.country
    query.app = req.app
    req.filterCondition = query
    next()
  } catch (err) {
    logger.error(req, res, err, 'VODA-WORKORDER-GET')
  }
}

function setQueryForAgeingReport (req, res, next) {
  try {
    var query = {}
    let start = new Date()
    let end = new Date()
    if (req.query.startDate !== undefined) { start = new Date(req.query.startDate) }
    if (req.query.endDate !== undefined) { end = moment(new Date(req.query.endDate)).add(1, 'days').format() }
    if (req.query.startDate || req.query.endDate) {
      query.modifiedOn = { '$gte': start, '$lte': end }
    }

    query.country = req.country
    query.app = req.app
    req.filterCondition = query
    next()
  } catch (err) {
    logger.error(req, res, err, 'VODA-WORKORDER-REPORT-GET')
  }
}

function setQueryForCancelledReturnedReport (req, res, next) {
  try {
    var query = {}
    let start = new Date()
    let end = new Date()
    if (req.query.startDate !== undefined) { start = new Date(req.query.startDate) }
    if (req.query.endDate !== undefined) { end = moment(new Date(req.query.endDate)).add(1, 'days').format() }
    if (req.query.startDate || req.query.endDate) {
      query.createdOn = { '$gte': start, '$lte': end }
    }

    query.country = req.country
    query.app = req.app
    req.filterCondition = query
    next()
  } catch (err) {
    logger.error(req, res, err, 'VODA-WORKORDER-REPORT-CANCELLED-RETURNED-GET')
  }
}

module.exports = {
  setQuery,
  setQueryForAgeingReport,
  setQueryForCancelledReturnedReport
}
