let logger = require('./../../../app/helpers/logger/log')

function get (Workorder, req, res) {
  try {
    Workorder.find(req.filterCondition, {
      _id: 1,
      'vodaOrderNumber': 1,
      'customer.customerId': 1,
      'customer.contactInfo.phone': 1,
      'customer.contactInfo.email': 1,
      'customer.name': 1,
      'customer.lastName': 1,
      'deliverySite.address.street': 1,
      'deliverySite.address.city': 1,
      'deliverySite.address.zip': 1,
      'installation.agreedVisitScheduleRange.startDate': 1,
      'installation.agreedVisitScheduleRange.endDate': 1,
      'installation.agreedVisitScheduleRange.startTime': 1,
      'installation.agreedVisitScheduleRange.endTime': 1,
      'installatorNotes': 1,
      'status': 1,
      'createdOn': 1,
      'modifiedOn': 1,
      'createdBy': 1,
      'createdByUserRole': 1,
      'country': 1
    }, '-__v', function (err, doc) {
      if (err) {
        res.status(417).send(err)
      } else {
        res.json(doc)
      }
    })
  } catch (err) {
    logger.error(req, res, err, 'VODA-WORKORDER-REPORT-GET')
  }
}

module.exports = {
  get
}
