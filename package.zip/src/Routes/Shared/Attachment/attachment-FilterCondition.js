
function setQuery (req, res, next) {
  var query = {}
  query.workorderId = req.query.workorderId
  query.docId = req.query.docId
  query.country = req.country

  query.app = req.app
  req.filterCondition = query
  next()
}

module.exports = {
  setQuery: setQuery
}
