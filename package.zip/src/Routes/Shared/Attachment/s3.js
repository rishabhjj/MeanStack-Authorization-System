/* eslint-disable */
let AWS = require('aws-sdk')
let converter = require('./../../Library/base64ArrayBuffer')

function DownloadImage (fileName, req, res) {
  let params = {
    Key: fileName,
    Bucket: process.env.BUCKETEER_BUCKET_NAME || 'bucketeer-14da2fd3-eb9c-49bc-824a-5299467c2380'
  }

  let s3 = new AWS.S3({
    accessKeyId: process.env.BUCKETEER_AWS_ACCESS_KEY_ID || 'AKIAJDHWKPJO7MGBEG7Q',
    secretAccessKey: process.env.BUCKETEER_AWS_SECRET_ACCESS_KEY || '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',
    region: 'eu-west-1'
  })

  // let s3Bucket = new AWS.S3({ params: { Bucket: process.env.BUCKETEER_BUCKET_NAME || 'bucketeer-14da2fd3-eb9c-49bc-824a-5299467c2380' } })

  s3.getObject(params, function put (err, data) {
    if (err) {
      console.log('S3 error: GET while trying to retrive filename: ' + fileName + ' ' + err, err.stack)
      res.status(417).send({ 'error': 'Error occurred while retriving the image...' })
    } else {
      //    let base64 = 'data:' + data.ContentType + ';base64,' + converter.base64ArrayBuffer(data.Body)
      //       res.status(200).send("data:" + data.ContentType + ";base64," + converter.base64ArrayBuffer(data.Body));
      res.status(200).send({ 'doctype': data.ContentType, 'base64': converter.base64ArrayBuffer(data.Body) })
      // res.status(200).send(converter.base64ArrayBuffer(data.Body));
    }
  })
}

function DeleteImage (fileName, req, res) {
  var params = {
    Key: fileName,
    Bucket: process.env.BUCKETEER_BUCKET_NAME || 'bucketeer-14da2fd3-eb9c-49bc-824a-5299467c2380'
  }

  var s3 = new AWS.S3({
    accessKeyId: process.env.BUCKETEER_AWS_ACCESS_KEY_ID || 'AKIAJDHWKPJO7MGBEG7Q',
    secretAccessKey: process.env.BUCKETEER_AWS_SECRET_ACCESS_KEY || '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',
    region: 'eu-west-1'
  })

  // var s3Bucket = new AWS.S3({ params: { Bucket: process.env.BUCKETEER_BUCKET_NAME || 'bucketeer-14da2fd3-eb9c-49bc-824a-5299467c2380' } })

  s3.deleteObject(params, function put (err, data) {
    if (err) {
      console.log('S3 error: DELETE while trying to delete filename: ' + fileName + ' ' + err, err.stack)
      res.status(417).send({ 'error': 'Error occurred while trying to delete the image from S3..' })
    } else {
      res.status(204).send({ 'info': 'Removed' })
    }
  })
}

function UploadImage (req, res, input, id) {
  var s3 = new AWS.S3({
    accessKeyId: process.env.BUCKETEER_AWS_ACCESS_KEY_ID || 'AKIAJDHWKPJO7MGBEG7Q',
    secretAccessKey: process.env.BUCKETEER_AWS_SECRET_ACCESS_KEY || 'eCJTvcAh0Z4Tl0tUF9RMrKBwigK3nWYDHQG3mdSF',
    region: 'eu-west-1'

  })

  let buf = new Buffer(input.base64.replace(/^data:image\/\w+;base64,/, ''), 'base64')

  var data = {
    Bucket: process.env.BUCKETEER_BUCKET_NAME || 'bucketeer-14da2fd3-eb9c-49bc-824a-5299467c2380',
    Key: input.key,
    Body: buf,
    ContentEncoding: 'base64',
    ContentType: input.doctype
  }

  s3.putObject(data, function (err, result) {
    if (err) {
      console.log('S3 error: POST ' + err, err.stack)
      res.status(417).send({ 'error': 'Error occurred while storing the image...' })
    } else {
      res.status(201).send({ '_id': id.toString() })
    }
  })
}

module.exports = {
  DownloadImage: DownloadImage,
  UploadImage: UploadImage,
  DeleteImage: DeleteImage
}
