let express = require('express')
let authorize = require('./../Utilities/authorize')
let utility = require('./../Utilities/utility')
let filter = require('./attachment-FilterCondition')
let list = require('./attachments-List-Get')
let s3 = require('./s3')
let moment = require('moment')

let routes = function (Attachments, Audit) {
  let AttachmentRouter = express.Router()

  AttachmentRouter.use(function (req, res, next) {
    utility.validateHeader(req, res, next)
  })

  AttachmentRouter.use(function (req, res, next) {
    utility.queryStringToLowerCase(req, res, next)
  })

  AttachmentRouter.use(function (req, res, next) {
    filter.setQuery(req, res, next)
  })

  // Authentication & Authorization 
  AttachmentRouter.use(function (req, res, next) {
    let bearerToken = (req.header('Authorization') !== undefined) ? req.header('Authorization') : ''
    authorize.token(req.env, bearerToken, req, res, next)
  })

  AttachmentRouter.route('/')
    .get(function (req, res) {
      if (req.query.workorderId !== undefined) {
        list.get(Attachments, req, res)
      } else {
        if (req.headers.token !== undefined && req.headers.token === 'B88D982A-FC81-4EA9-BEB3-129AA0808B78') {
          var query = {}
          let start = new Date()
          let end = new Date()
          if (req.query.startDate !== undefined) { start = new Date(req.query.startDate) }
          if (req.query.endDate !== undefined) { end = moment(new Date(req.query.endDate)).add(1, 'days').format() }
          if (req.query.startDate || req.query.endDate) {
            query.createdOn = { '$gte': start, '$lte': end }
          }

          query.country = req.country
          query.app = req.app
          req.filterCondition = query

          list.get(Attachments, req, res)
        } else {
          res.status(422).send({ 'error': 'Missing Work Order ID' })
        }
      }
    })

  AttachmentRouter.route('/Image')
    .get(function (req, res) {
      if (req.query.workorderId === undefined || req.query.docId === undefined) {
        res.status(422).send({ 'error': 'Missing Work Order ID or docId' })
      } else {
        let fileName = req.app + '_' + req.country + '_WO_' + req.query.workorderId + '_' + req.query.docId
        s3.DownloadImage(fileName, req, res)
      }
    })
    .post(function (req, res) {
      if (req.body.workorderId === undefined || req.body.doctype === undefined || req.body.base64 === undefined) {
        res.status(422).send({ 'error': 'Body fields are not valid or incomplete' })
      } else {
        let isContinue = false
        if (req.app === 'VODA' && req.body.vpp !== undefined) {
          if (req.body.vpp.key !== undefined) {
            isContinue = true
          }
        } else if (req.app === 'SODA' && req.body.solar !== undefined) {
          if (req.body.solar.key !== undefined) {
            isContinue = true
          }
        } else if (req.app === 'HODA' && req.body.hc !== undefined) {
          if (req.body.hc.key !== undefined) {
            isContinue = true
          }
        }
        if (isContinue) {
          let attachment = new Attachments(req.body)
          attachment.country = req.country
          attachment.app = req.app

          attachment.save(function (err) {
            if (err) {
              res.status(417).send(err)
            } else {
              let id = req.app + '_' + req.country + '_WO_' + attachment.workorderId + '_' + attachment._id
              let data = { 'key': id, 'base64': req.body.base64, 'doctype': req.body.doctype }
              let woId = attachment._id
              s3.UploadImage(req, res, data, woId)
            }
          })
        } else {
          res.status(422).send({ 'error': 'Process related additional fields are missing' })
        }
      }
    })
    .delete(function (req, res) {
      if (req.query.workorderId === undefined || req.query.docId === undefined) {
        res.status(422).send({ 'error': 'Missing Work Order ID or docId' })
      } else {
        var filterCondition = {}
        filterCondition._id = req.query.docId
        filterCondition.workorderId = req.query.workorderId

        Attachments.remove(filterCondition, function (err, logs) {
          if (err) {
            res.status(417).send(err)
          } else {
            let fileName = req.app + '_' + req.country + '_WO_' + req.query.workorderId + '_' + req.query.docId
            s3.DeleteImage(fileName, req, res)
          }
        })
      }
    })

  return AttachmentRouter
}
module.exports = routes
