function get (Attachments, req, res) {
  Attachments.find(req.filterCondition, '-__v', function (err, doc) {
    if (err) {
      if (err.name === 'CastError' && err.path === '_id') {
        let response = []
        res.status(200).send(response)
      } else {
        res.status(417).send(err)
      }
    } else {
      res.status(200).send(doc)
    }
  })
}

module.exports = {
  get: get
}
