var express = require('express')
var thankYouMailer = require('./../../Messaging/thankYou')
var contactReceived = require('./../../Messaging/requestReceivedMktCS')
let moment = require('moment')

var routes = function (Contact) {
  var contactRouter = express.Router()

  // Change the queryString to lowercase and reads queryStrings, sets it to query field [middleware]
  contactRouter.use(function (req, res, next) {
    for (var key in req.query) {
      req.query[key.toLowerCase()] = req.query[key]
    }

    // Check & Set Country Code, but OPTIONS type call alone will be excluded
    if (req.method !== 'OPTIONS') {
      if (req.header('country') !== undefined && req.header('app') !== undefined) {
        req.country = req.header('country').toUpperCase()
        req.app = req.header('app').toUpperCase()

        let query = {}
        let start = new Date()
        let end = new Date()
        if (req.query.startDate !== undefined) { start = new Date(req.query.startDate) }
        if (req.query.endDate !== undefined) { end = moment(new Date(req.query.endDate)).add(1, 'days').format() }
        if (req.query.startDate || req.query.endDate) {
          query.createdOn = { '$gte': start, '$lte': end }
        }
        if (req.query._id) { query._id = req.query._id }
        query.app = req.app
        query.country = req.country
        req.queryForMongoose = query

        next()
      } else {
        res.status(400).send({ 'error': 'Country or App is missing' })
      }
    } else {
      next()
    }
  })

  contactRouter.route('/')
    .post(function (req, res) {
      var contact = new Contact(req.body)
      contact.country = req.country
      contact.app = req.app
      contact.save(function (err) {
        if (err) {
          res.status(417).send(err)
        } else {
          var mailData = { 'name': req.body.name, 'email': req.body.email }
          if (req.body.email !== undefined) {
            thankYouMailer.post(mailData, req.country, req.app)
          }

          contactReceived.post(req.body, req.country, req.app)

          res.status(201).send()
        }
      })
    })
    .get(function (req, res) {
      Contact.find(req.queryForMongoose, '-__v', function (err, data) {
        if (err) { res.status(417).send(err) } else { res.json(data) }
      })
    })
    .delete(function (req, res) {
      if (req.headers.token !== undefined && req.headers.token === 'A88D982A-FC81-4EA9-BEB3-189AA0808B78') {
        Contact.remove(req.queryForMongoose, function (err, data) {
          if (err) { res.status(417).send(err) } else { res.status(204).send('Removed') }
        })
      } else {
        res.status(401).send('Not allowed')
      }
    })
  return contactRouter
}

module.exports = routes
