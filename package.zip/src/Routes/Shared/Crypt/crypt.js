let CryptoJS = require('crypto-js')

function encrypt (value) {
  var secretPhrase = 'aa31g-3f61f53-j135-4dbb-b2e8-e8bf88ffde3f'
  let encrpytedValue = CryptoJS.AES.encrypt(value, secretPhrase)
  return encrpytedValue
}

function decrypt (value) {
  var secretPhrase = 'aa31g-3f61f53-j135-4dbb-b2e8-e8bf88ffde3f'
  let decryptedData = CryptoJS.AES.decrypt(value, secretPhrase)
  let convertedValue = decryptedData.toString(CryptoJS.enc.Utf8)
  return convertedValue
}

module.exports = {
  encrypt: encrypt,
  decrypt: decrypt
}
