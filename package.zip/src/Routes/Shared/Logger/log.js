let Client = require('node-rest-client').Client

function log (req, res, err, fileName = 'Not Specified') {
  console.log('ERROR in fileName: ' + fileName + '  ' + err)
  res.status(417).send(err.message)
}

function consoleLog (err, fileName = 'Not Specified') {
  console.log('ERROR in fileName: ' + fileName + '  ' + err)
}

function dashboard (environment, requestIdData, statusCodeData, resourceNameData, actionMethodData, queryStringData, requestingSystemData,
  targetSystemData, authorizationData, receivedTimeData, reponseReturnedTimeData, additionalDetailsData, ipData, processTimeData) {
  let client = new Client()
  let args = {
    data: {
      'requestId': requestIdData,
      'statusCode': statusCodeData.toString(),
      'resourceName': resourceNameData,
      'actionMethod': actionMethodData,
      'queryString': JSON.stringify(queryStringData),
      'requestingSystem': requestingSystemData,
      'targetSystem': targetSystemData,
      'authorization': authorizationData,
      'receivedTime': receivedTimeData.toString(),
      'reponseReturnedTime': reponseReturnedTimeData.toString(),
      'additionalDetails': additionalDetailsData,
      'ip': ipData,
      'processTime': processTimeData.toString()
    },
    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
  }

  let loggerUri = 'https://fortum-testapi-logger.azurewebsites.net/api/logger'

  if (environment === 'PROD') {
    loggerUri = 'https://fortum-api-logger.azurewebsites.net/api/logger'
  }

  client.post(loggerUri, args, function (data, response) {
    /// To-do: Where to log incase of any issue???
  })
}

module.exports = {
  log: log,
  consoleLog: consoleLog,
  dashboard: dashboard
}
