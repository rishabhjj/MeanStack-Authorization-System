var express = require('express')

var routes = function (Audit) {
  var auditRouter = express.Router()

  // Change the queryString to lowercase [middleware]  
  auditRouter.use(function (req, res, next) {
    for (var key in req.query) {
      req.query[key.toLowerCase()] = req.query[key]
    }
    next()
  })

  // Reads queryStrings & sets it to query field [middleware]  
  auditRouter.use(function (req, res, next) {
    var query = {}
    if (req.query.docName) { query.docName = req.query.docName }
    if (req.query.docId) { query.docId = req.query.docId }
    req.queryForMongoose = query
    next()
  })

  auditRouter.route('/')
    .get(function (req, res) {
      Audit.find(req.queryForMongoose, '-__v', function (err, data) {
        if (err) {
          res.status(417).send(err)
        } else {
          res.json(data)
        }
      })
    })
    .delete(function (req, res) {
      if (req.headers.token !== undefined && req.headers.token === 'A88D982A-FC81-4EA9-BEB3-189AA0808B78') {
        Audit.remove(req.queryForMongoose, function (err, data) {
          if (err) { res.status(417).send(err) } else { res.status(204).send('Removed') }
        })
      } else {
        res.status(401).send('Not allowed')
      }
    })
  return auditRouter
}

module.exports = routes
