let authorize = require('./authorize')

function isValid (req, res, next, resourceName = 'NONE') {
  try {
    if (req.method !== 'OPTIONS') {
      if (req.header('country') !== undefined && req.header('app') !== undefined) {
        // Convert Query String fields into LowerCase
        for (var key in req.query) {
          req.query[key.toLowerCase()] = req.query[key]
        }

        // Assign Request Header fields value into request Object
        req.country = req.header('country').toUpperCase()
        req.app = req.header('app').toUpperCase()
        req.resourceName = resourceName + '_' + req.method
        req.processName = req.app + '_' + req.country
        req.receivedTime = new Date()
        req.requestId = req.header('X-Request-Id')

        // Authenticate & Authorize
        let bearerToken = (req.header('Authorization') !== undefined) ? req.header('Authorization') : undefined
        authorize.token(req.env, bearerToken, req, res, next)
      } else {
        res.status(400).send({ 'error': 'Country or App is missing' })
      }
    } else {
      next()
    }
  } catch (err) {
    console.log('ERROR in Utility:' + err)
    res.status(417).send(err.message)
  }
}

function queryStringToLowerCase (req, res, next) {
  for (var key in req.query) {
    req.query[key.toLowerCase()] = req.query[key]
  }
  next()
}

function validateHeader (req, res, next) {
  if (req.method !== 'OPTIONS') {
    if (req.header('country') !== undefined && req.header('app') !== undefined) {
      req.country = req.header('country').toUpperCase()
      req.app = req.header('app').toUpperCase()
      next()
    } else {
      res.status(400).send({ 'error': 'Country or App is missing' })
    }
  } else {
    next()
  }
}

module.exports = {
  isValid: isValid,
  validateHeader: validateHeader,
  queryStringToLowerCase: queryStringToLowerCase
}
