let Client = require('node-rest-client').Client

function token (environment, token, req, res, next) {
  // API Archival
  req.archival = {
    'request': {
      'content': req.body,
      'headers': {
        'requestId': req.requestId,
        'country': req.header('country'),
        'app': req.header('app'),
        'user': '',
        'role': ''
      },
      'method': req.method,
      'requestUri': req.originalUrl,
      'resourceName': req.resourceName,
      'queryString': req.query
    },
    'response': {
      'statusCode': '',
      'content': {
      }
    }
  }
  let url = 'https://login-test.fortum.com/oauth2/userinfo'

  if (environment === 'PROD') {
    url = 'https://login.fortum.com/oauth2/userinfo'
  } else if (environment === 'QA') {
    url = 'https://login-qa.fortum.com/oauth2/userinfo'
  }

  if (req.method === 'PATCH' || req.method === 'PUT' || req.method === 'DELETE' ||
        (req.method === 'GET' && (req.header('Authorization') !== undefined) && token !== undefined) ||
        (req.method === 'POST' && (req.header('Authorization') !== undefined) && token !== undefined)) {
    token = ''
    if (req.header('Authorization') !== undefined) {
      token = req.header('Authorization')
    }
    var client = new Client()
    var args = {
      headers: { 'Authorization': token } // request headers 
    }

    client.get(url, args, function (data, response) {
      if (response.statusCode === 200) {
        let userType = data.employeetype !== undefined ? (data.employeetype).trim() : ''
        let userCountry = (userType !== '') ? userType.substring(0, 2) : ''
        req.userCountry = userCountry
        if (userCountry !== req.country) {
          res.status(403).send()
        } else {
          let familyName = data.family_name !== undefined ? data.family_name : ''

          req.user = data.given_name + ' ' + familyName

          if (userType === 'FICCCC' || userType === 'SECCCC') {
            req.role = 'CUSTOMERSERVICE'
            req.user = data.sub + ' (' + req.user + ')'
          } else if (userType === 'FIINST' || userType === 'SEINST') {
            req.role = 'INSTALLER'
            req.user = data.sub + ' (' + data.installeragentid + ')'
          } else if ((userType === 'FIINST' || userType === 'SEINST') && (data.role !== undefined && data.role === 'InstallerAdmin')) {
            req.role = 'INSTALLERSUPERVISOR'
            req.user = data.sub + ' (' + data.installeragentid + ')'
          } else if (userType === 'FIBUS' || userType === 'SEBUS') {
            req.role = 'BUSINESS'
            req.user = data.sub + ' (' + req.user + ')'
          } else if (userType === 'FIEMP' || userType === 'SEEMP') {
            req.role = 'EMP'
            req.user = data.salesagentid !== undefined ? data.salesagentid : req.user
          } else {
            req.role = 'CUSTOMER'
          }
          req.archival.request.headers.user = req.user
          req.archival.request.headers.role = req.role
          next()
        }
      } else {
        res.status(401).send('Authorize API')
      }
    })
  } else {
    req.role = 'CUSTOMER'
    req.user = 'Anonymous'
    next()
  }
}

module.exports = {
  token: token
}
