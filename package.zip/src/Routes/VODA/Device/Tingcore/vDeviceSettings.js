let express = require('express')
let Client = require('node-rest-client').Client
let utility = require('./../../../Shared/Utilities/utility')
let tingcore = require('./tingcoreEnvironment')
let tingcoreSettingTypes = require('./tingcoreSettingTypes')
let logger = require('./../../../../app/helpers/logger/log')
let archival = require('./../../../Shared/Archival/archive')

let routes = function (Audit) {
  let vSettingsRouter = express.Router()

  vSettingsRouter.use(function (req, res, next) {
    utility.isValid(req, res, next, 'Device.Settings')
  })

  vSettingsRouter.use(function (req, res, next) {
    tingcore.environment(req, res, next)
  })

  vSettingsRouter.route('/')
    .post(function (req, res) {
      try {
        if (req.body.deviceId !== undefined) {
          let url = req.tingcore
          let token = (req.header('Authorization') !== undefined) ? req.header('Authorization') : ''
          let client = new Client()

          if (req.role === 'INSTALLER') {
            let settingTypesId = tingcoreSettingTypes.settingTypes(req.env, 'FAIL_SAFE_SETTING_TYPE')
            let args = {
              data: {
                'value': '0',
                'type': url + '/settingTypes/' + settingTypesId,
                'device': url + '/devices/' + req.body.deviceId
              },
              headers: { 'Accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': token } // request headers 
            }

            client.post(url + '/settings', args, function (data, response) {
              try {
                archival.log(req.archival, data, response.statusCode, req.env, req.processName, req.receivedTime, req.requestId)
                if (response.statusCode === 201) {
                  let guid = data._links.self.href
                  let indexValue = guid.indexOf('/settings/')
                  let idValue = guid.substring(indexValue + 10, guid.length)

                  res.status(201).send({ 'id': idValue })
                } else {
                  res.status(response.statusCode).send(data)
                }
              } catch (err) {
                logger.log(req, res, err)
              }
            })
          } else {
            let message = { 'error': 'Not allowed role' }
            archival.log(req.archival, message, 422, req.env, req.processName, req.receivedTime, req.requestId)
            res.status(422).send(message)
          }
        } else {
          let errorMessage = { 'error': 'Invalid body content' }
          archival.log(req.archival, errorMessage, 422, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(422).send(errorMessage)
        }
      } catch (err) {
        logger.log(req, res, err)
      }
    })
  return vSettingsRouter
}
module.exports = routes
