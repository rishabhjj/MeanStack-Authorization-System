function environment (req, res, next) {
  req.tingcore = 'https://flexipower-install-api-test.tingcore-infra.com'

  if (req.env === 'PROD') {
    req.tingcore = 'https://flexipower-install-api.tingcore-infra.com'
  } else if (req.env === 'QA') {
    req.tingcore = 'https://flexipower-install-api-stage.tingcore-infra.com'
  }
  next()
}

module.exports = {
  environment: environment
}
