let express = require('express')
let Client = require('node-rest-client').Client
let utility = require('./../../../Shared/Utilities/utility')
let tingcore = require('./tingcoreEnvironment')
let logger = require('./../../../../app/helpers/logger/log')
let archival = require('./../../../Shared/Archival/archive')

let routes = function (Audit) {
  let vDeviceConnectionRouter = express.Router()

  vDeviceConnectionRouter.use(function (req, res, next) {
    utility.isValid(req, res, next, 'Device.Connection')
  })

  vDeviceConnectionRouter.use(function (req, res, next) {
    tingcore.environment(req, res, next)
  })

  vDeviceConnectionRouter.route('/')
    .get(function (req, res) {
      try {
        if (req.query.deviceId === undefined) {
          let message = { 'error': 'Device Id is required' }
          archival.log(req.archival, message, 422, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(400).send(message)
        } else {
          if (req.role === 'INSTALLER') {
            let url = req.tingcore
            let token = (req.header('Authorization') !== undefined) ? req.header('Authorization') : ''

            var client = new Client()
            var args = {
              headers: { 'Authorization': token } // request headers 
            }

            let deviceId = req.query.deviceId
            //  deviceId = 863586039685122; // Hard Code for now
            url = url + '/devices/' + deviceId + '/connection'
            client.get(url, args, function (data, response) {
              let jd = JSON.parse(data)
              archival.log(req.archival, jd, response.statusCode, req.env, req.processName, req.receivedTime, req.requestId)
              if (response.statusCode === 200) {
                if (jd.connected === true) {
                  res.status(200).send({ 'isConnected': 1 })
                } else {
                  res.status(response.statusCode).send({ 'isConnected': 0 })
                }
              } else {
                res.status(response.statusCode).send({ 'isConnected': 0 })
              }
            })
          } else {
            let message = { 'error': 'Not allowed role' }
            archival.log(req.archival, message, 422, req.env, req.processName, req.receivedTime, req.requestId)
            res.status(422).send(message)
          }
        }
      } catch (err) {
        logger.log(req, res, err)
      }
    })
  return vDeviceConnectionRouter
}
module.exports = routes
