let express = require('express')
let Client = require('node-rest-client').Client
let utility = require('./../../../Shared/Utilities/utility')
let tingcore = require('./tingcoreEnvironment')
let logger = require('./../../../../app/helpers/logger/log')
let archival = require('./../../../Shared/Archival/archive')

let routes = function (Audit) {
  let vDeviceFailSafeRouter = express.Router()

  vDeviceFailSafeRouter.use(function (req, res, next) {
    utility.isValid(req, res, next, 'Device.FailSafe')
  })

  vDeviceFailSafeRouter.use(function (req, res, next) {
    tingcore.environment(req, res, next)
  })

  vDeviceFailSafeRouter.route('/:id')
    .patch(function (req, res) {
      try {
        let url = req.tingcore
        let token = (req.header('Authorization') !== undefined) ? req.header('Authorization') : ''
        let client = new Client()

        if (req.role === 'INSTALLER') {
          let args = {
            data: {
              'value': req.body.value
            },
            headers: { 'Accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': token } // request headers 
          }

          let id = req.params.id

          url = url + '/settings/' + id
          client.patch(url, args, function (data, response) {
            try {
              archival.log(req.archival, data, response.statusCode, req.env, req.processName, req.receivedTime, req.requestId)
              if (response.statusCode === 200) {
                res.status(200).send({ 'settingType': data.settingType, 'value': data.value })
              } else {
                res.status(response.statusCode).send(data)
              }
            } catch (err) {
              logger.log(req, res, err)
            }
          })
        } else {
          let message = { 'error': 'Not allowed role' }
          archival.log(req.archival, message, 422, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(422).send(message)
        }
      } catch (err) {
        logger.log(req, res, err)
      }
    })
  return vDeviceFailSafeRouter
}
module.exports = routes
