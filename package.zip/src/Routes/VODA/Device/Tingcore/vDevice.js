let express = require('express')
let Client = require('node-rest-client').Client

let utility = require('./../../../Shared/Utilities/utility')
let tingcore = require('./tingcoreEnvironment')
let logger = require('./../../../../app/helpers/logger/log')
let archival = require('./../../../Shared/Archival/archive')

let routes = function (Audit) {
  let vDeviceRouter = express.Router()

  vDeviceRouter.use(function (req, res, next) {
    utility.isValid(req, res, next, 'Device')
  })

  vDeviceRouter.use(function (req, res, next) {
    tingcore.environment(req, res, next)
  })

  vDeviceRouter.route('/')
    .post(function (req, res) {
      try {
        if (req.body.deviceId !== undefined && req.body.contractId !== undefined) {
          let url = req.tingcore
          let token = (req.header('Authorization') !== undefined) ? req.header('Authorization') : ''
          let client = new Client()
          let companyId = ''
          let isContinue = false

          if (req.role === 'INSTALLER' && req.userCountry === 'FI') {
            companyId = 'Fortum Finland'
            isContinue = true
          }

          if (isContinue) {
            let args = {
              data: {
                'id': req.body.deviceId,
                'correctionFactor': {
                  'multiplier': 1,
                  'constant': 0,
                  'unit': 'kW'
                },
                'contract': {
                  'contractId': req.body.contractId,
                  'companyId': companyId
                },
                'type': url + '/deviceTypes/deviceTypes/a9d042a0-a16f-4f89-81e1-115b46c6caf2'
              },
              headers: { 'Accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': token } // request headers 
            }

            client.post(url + '/devices', args, function (data, response) {
              try {
                archival.log(req.archival, data, response.statusCode, req.env, req.processName, req.receivedTime, req.requestId)
                if (response.statusCode === 201) {
                  res.status(201).send({})
                } else {
                  res.status(response.statusCode).send(data)
                }
              } catch (err) {
                logger.log(req, res, err)
              }
            })
          }
        } else {
          res.status(422).send({ 'error': 'Body content is not as per required' })
        }
      } catch (err) {
        logger.log(req, res, err)
      }
    })
  return vDeviceRouter
}
module.exports = routes
