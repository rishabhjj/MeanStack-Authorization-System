let express = require('express')
let Client = require('node-rest-client').Client
let utility = require('./../../../Shared/Utilities/utility')
let tingcore = require('./tingcoreEnvironment')
let logger = require('./../../../../app/helpers/logger/log')
let archival = require('./../../../Shared/Archival/archive')

let routes = function (Audit) {
  let vDeviceRelayRouter = express.Router()

  vDeviceRelayRouter.use(function (req, res, next) {
    utility.isValid(req, res, next, 'Device.Relay')
  })

  vDeviceRelayRouter.use(function (req, res, next) {
    tingcore.environment(req, res, next)
  })

  vDeviceRelayRouter.route('/')
    .post(function (req, res) {
      try {
        if (req.body.deviceId === undefined && req.body.value === undefined) {
          let message = { 'error': 'Device Id is required' }
          archival.log(req.archival, message, 422, req.env, req.processName, req.receivedTime, req.requestId)
          res.status(400).send(message)
        } else {
          let url = req.tingcore
          let token = (req.header('Authorization') !== undefined) ? req.header('Authorization') : ''
          let client = new Client()
          let enable = false
          if (req.body.value === 1) {
            enable = true
          }

          if (req.role === 'INSTALLER') {
            let args = {
              data: {
                'type': 'PROD_WATER_HEATER',
                'enableRelay1': enable,
                'enableRelay2': enable
              },
              headers: { 'Accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': token } // request headers 
            }

            url = url + '/devices/' + req.body.deviceId + '/commands'
            client.post(url, args, function (data, response) {
              try {
                archival.log(req.archival, data, response.statusCode, req.env, req.processName, req.receivedTime, req.requestId)
                if (response.statusCode === 200) {
                  res.status(200).send({})
                } else {
                  res.status(response.statusCode).send(data)
                }
              } catch (err) {
                logger.log(req, res, err)
              }
            })
          } else {
            let message = { 'error': 'Not allowed role' }
            archival.log(req.archival, message, 422, req.env, req.processName, req.receivedTime, req.requestId)
            res.status(422).send(message)
          }
        }
      } catch (err) {
        logger.log(req, res, err)
      }
    })
  return vDeviceRelayRouter
}
module.exports = routes
