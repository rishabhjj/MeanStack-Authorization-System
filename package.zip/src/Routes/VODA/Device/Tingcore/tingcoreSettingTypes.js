function settingTypes (environment, type) {
  let value = ''

  if (environment === 'PROD') {
    if (type === 'CLAMP_CT') {
      value = 'fb52f363-631b-11e7-a490-0aa01c0b9072'
    } else if (type === 'LED') {
      value = 'fb52f3a8-631b-11e7-a490-0aa01c0b9072'
    } else if (type === 'FAIL_SAFE_SETTING_TYPE') {
      value = 'fb52f3ef-631b-11e7-a490-0aa01c0b9072'
    } else if (type === 'FAIL_SAFE_SETTING') {
      value = 'd82e1c4a-9a22-4886-af1c-2f44607a238a'
    }
  } else if (environment === 'QA') {
    if (type === 'CLAMP_CT') {
      value = '6951f2f7-5b47-11e7-8e05-0a6f6e1c70ec'
    } else if (type === 'LED') {
      value = '6951f33b-5b47-11e7-8e05-0a6f6e1c70ec'
    } else if (type === 'FAIL_SAFE_SETTING_TYPE') {
      value = '6951f37f-5b47-11e7-8e05-0a6f6e1c70ec'
    } else if (type === 'FAIL_SAFE_SETTING') {
      value = '81122407-ac72-49ac-9b36-0d0b6b9f9e8b'
    }
  } else {
    if (type === 'CLAMP_CT') {
      value = 'c68bf40e-51a8-11e7-ba06-0a2e9b1e128e'
    } else if (type === 'LED') {
      value = 'c68bf453-51a8-11e7-ba06-0a2e9b1e128e'
    } else if (type === 'FAIL_SAFE_SETTING_TYPE') {
      value = 'c68bf49b-51a8-11e7-ba06-0a2e9b1e128e'
    } else if (type === 'FAIL_SAFE_SETTING') {
      value = '16c52019-dacd-483c-9c72-1ded68faec5e'
    }
  }

  return value
}

module.exports = {
  settingTypes: settingTypes
}
