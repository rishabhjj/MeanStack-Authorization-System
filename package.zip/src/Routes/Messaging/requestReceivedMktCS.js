let sendGridKey = process.env.SENDGRID_API_KEY || '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'
let MailLogger = require('./../../app/helpers/logger/log').mailLogger

function post (data, country, application) {
  country = country.toUpperCase()
  application = application.toUpperCase()

  let customerServiceEmail = process.env.MARKETING_customerServiceEmail || 'Suresh.SapaniDeletajan@partners.fortum.com'
  let sub = 'Yhteydenottopyyntö Fortum Aurinkopaketista (Marketing Site)'
  let email = (data.email === undefined) ? '' : data.email
  let customerNote = (data.customerNote === undefined) ? '' : data.customerNote
  let noContract = (data.noContract === undefined) ? '' : data.noContract
  let fromEmail = 'Noreply.markets@fortum.com'
  let template = 'b8192879-e18d-4afb-83df-05d0cdb86a95'

  if (country === 'FI' && application === 'LODA') {
    sub = 'Yhteydenottopyyntö Fortum Aurinkolatauksesta (Marketing Site)'
  }
  if (country === 'FI' && application === 'HODA') {
    sub = 'Fortum Kotilataus: Yhteydenottopyyntö lähetetty (Marketing Site)'
  }

  if (country === 'SE') {
    customerServiceEmail = process.env.MARKETING_CS_SE_EMAIL || 'Suresh.SapaniDeletajan@partners.fortum.com'
    sub = 'Intresseanmälan från fortum.se/sol'
    fromEmail = 'Noreply.markets@fortum.com'
    sendGridKey = process.env.SENDGRID_API_SE_KEY || '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'
    template = '08242273-7b56-4508-863b-cf7a0676c7c0'
  }

  let sg = require('sendgrid')(sendGridKey)

  let request = sg.emptyRequest({
    method: 'POST',
    path: '/v3/mail/send',
    body: {
      personalizations: [
        {
          to: [
            {
              email: customerServiceEmail
            }
          ],
          'substitutions': {
            '-name-': data.name,
            '-businessId-': data.businessId,
            '-phone-': data.phone,
            '-email-': email,
            '-customerNote-': customerNote,
            '-noContract-': noContract

          },
          subject: sub
        }
      ],
      from: {
        email: fromEmail
      },
      template_id: template
    }
  })

  // With promise
  sg.API(request)
    .then(response => {
      MailLogger(application, country, customerServiceEmail, template, response.statusCode, '', 'Marketing', 'CS', response.headers)
      console.log(' HTTP Status Code: ' + response.statusCode)
    })
    .catch(error => {
      MailLogger(application, country, customerServiceEmail, template, error.response.statusCode, '', 'Marketing', 'CS', error.headers)
      console.log(error.response.statusCode)
    })
}

exports.post = post
