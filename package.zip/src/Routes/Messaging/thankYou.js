var request = require('superagent')
let MailLogger = require('./../../app/helpers/logger/log').mailLogger

function post (mailData, country, application) {
  if (application === undefined) {
    application = 'SODA'
  }

  country = country.toUpperCase()
  application = application.toUpperCase()
  let subject = 'Kiitos mielenkiinnostasi Fortum Aurinkopakettia kohtaan'
  let sender = 'Fortum Asiakaspalvelu'
  let ocp = '3f7b92e86ed64d6193aec0f73704a545'
  let azureURL = 'https://testapi.fortum.com/avaus/v1/Message'
  let env = process.env.ENV || 'NonProd'

  if (env === 'PROD') {
    ocp = '199cb400e02d4b968f9de50c81bc07aa'
    azureURL = 'https://api.fortum.com/avaus/v1/Message'
  }

  var str1 = '<table><tbody><tr><td  style=text-align: left><p style=text-align: left;>Hei '
  var str2 = mailData.name
  var str3 = str1.concat(str2)
  var str4 = str3.concat('! ')
  var str5 = '</p><p style=text-align: left;>Kiitos mielenkiinnostasi Fortum Aurinkopakettia kohtaan.</p><p style=text-align: left;>Olemme vastaanottaneet yhteydenottopyyntösi ja asiantuntijamme ovat sinuun yhteydessä lähipäivinä. Tarvittaessa voit olla meihin yhteydessä vielä myös puhelimitse numeroon 0200 99330 (arkisin 9-17) tai sähköpostitse osoitteeseen aurinkopaketti@fortum.com.</p><p style=text-align: left;>Aurinkoisin terveisin,</p><p style=text-align: left;>Fortum asiakaspalvelu</p></td></tr></tbody></table>'
  var messageContent = str4.concat(str5)
  var messageTempalteId = 502
  let language = 'FI'

  if (country === 'FI' && application === 'LODA') {
    str1 = '<table><tbody><tr><td  style=text-align: left><p style=text-align: left;>Hei '
    str2 = mailData.name
    str3 = str1.concat(str2)
    str4 = str3.concat('! ')
    str5 = '</p><p style=text-align: left;>Kiitos mielenkiinnostasi Fortum Aurinkolatausta kohtaan.</p><p style=text-align: left;>Asiakaspalvelumme on sinuun yhteydessä kun palvelu julkaistaan. Tarvittaessa voit olla meihin yhteydessä vielä myös puhelimitse numeroon 0200 99330 (pvm/mpm, ma-pe klo 9-17) tai sähköpostitse osoitteeseen lahisahko@fortum.com.</p><p style=text-align: left;>Aurinkoisin terveisin,</p><p style=text-align: left;>Fortum asiakaspalvelu</br>www.fortum.fi/aurinkolataus</p></td></tr></tbody></table>'
    messageContent = str4.concat(str5)
    subject = 'Fortum Aurinkolataus: Yhteydenottopyyntö lähetetty'
    messageTempalteId = 502
    language = 'FI'
  }

  if (country === 'FI' && application === 'HODA') {
    str1 = '<table><tbody><tr><td  style=text-align: left><p style=text-align: left;>Hei '
    str2 = mailData.name
    str3 = str1.concat(str2)
    str4 = str3.concat('! ')
    str5 = '</p><p style=text-align: left;>Kiitos mielenkiinnostasi Fortum Charge & Drive -kotilatausta kohtaan.</p><p style=text-align: left;>Olemme vastaanottaneet yhteydenottopyyntösi ja asiakaspalvelumme on sinuun yhteydessä mahdollisimman pikaisesti. Tarvittaessa voit olla meihin yhteydessä myös puhelimitse numeroon 0200 99330 (pvm/mpm, ma-pe klo 9-17). </p><p style=text-align: left;>Aurinkoisin terveisin,</p><p style=text-align: left;>Fortum asiakaspalvelu</br>www.fortum.fi/kotilataus</p></td></tr></tbody></table>'
    messageContent = str4.concat(str5)
    subject = 'Kiitos mielenkiinnostasi Fortum Charge & Drive Kotilatausta kohtaan'
    messageTempalteId = 502
    language = 'FI'
  }

  if (country === 'SE') {
    str1 = '<table><tbody><tr><td  style=text-align: left><p style=text-align: left;>Hej '
    str2 = mailData.name
    str3 = str1.concat(str2)
    str4 = str3.concat('! ')
    str5 = '</p><p style=text-align: left;>Tack för att du visat intresse för Fortum Solcellspaket.</p><p style=text-align: left;>Vi återkommer till dig inom kort för att diskutera vilket solcellspaket som skulle passa dig. Inför vårt samtal vore det bra om du tog reda på följande information om ditt hus: uppskattad takyta, hustakets vinkel, antal våningar och årlig elförbrukning.</p><p style=text-align: left;>Om du har några frågor eller funderingar kan du kontakta oss på telefonnummer +46 (0)8 671 70 70 (vardagar 9-17) eller e-post till solcellspaket@fortum.com</p><p style=text-align: left;>Soliga hälsningar,</p><p style=text-align: left;>Fortum kundservice</p></td></tr></tbody></table>'
    messageContent = str4.concat(str5)
    subject = 'Fortum Solcellspaket - Intresseanmälan'
    sender = 'Fortum kundservice'
    messageTempalteId = 503
    language = 'SV'
  }

  request
    .post(azureURL)
    .send(
      {
        'Message': {
          'MessagingMessageType': messageTempalteId,
          'MessageSource': 'Forum',
          'Sender': sender,
          'DefaultLanguage': language
        },
        'AllowedChannels': [
          {
            'ChannelType': '1',
            'Priority': 1
          }
        ],
        'Recipients': [
          {
            'ContentPlaceHolderList': [
              {
                'PlaceHolderName': 'subject',
                'PlaceHolderValue': subject
              },
              {
                'PlaceHolderName': 'MessageContent',
                'PlaceHolderValue': messageContent
              }

            ],
            'Email': mailData.email
          }
        ]
      }
    )
    .set('RequestId', '1')
    .set('Ocp-Apim-Subscription-Key', ocp)
    .set('RequestingSystem', application)
    .set('TargetSystem', 'NEOLANE')
    .set('Content-Type', 'application/json')
    .set('Accept', 'application/json')
    .end(function (err, res) {
      var refId = err !== null ? err : res.text
      MailLogger(application, country, mailData.email, messageTempalteId, res.statusCode, '', 'Marketing', 'CUSTOMER', refId)
    })
}
exports.post = post
