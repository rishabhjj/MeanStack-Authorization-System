var request = require('superagent')
let MailLogger = require('./../../../../app/helpers/logger/log').mailLogger

function post (data, country, Attachments, sendMail) {
  let query = {}
  query.workorderId = data._id
  let reason = ''
  Attachments.find(query, '-__v', function (err, doc) {
    if (err || doc.length === 0) {
      sendMails(data, country, reason)
    } else {
      if (data.status === 'Cancelled') {
        reason = doc[0].vpp.reasonCancellation
      }
      sendMails(data, country, reason)
    }
  })

  //   sendMail(data, country, reason)

  function sendMails (data, country, reason) {
    let template = ''
    let customerId = data.customer.customerId !== undefined ? data.customer.customerId : ''
    let name = data.customer.name !== undefined ? data.customer.name : ''
    let firstName = data.customer.name !== undefined ? data.customer.name : ''
    let streetName = ''
    let postalCode = ''
    let postOfficeName = ''
    let deliverySiteStreetName = ''
    let deliverySitePostalCode = ''
    let deliverySitePostOfficeName = ''
    let email = ''

    if (data.customer.address !== undefined) {
      streetName = data.customer.address.street !== undefined ? data.customer.address.street : ''
      postalCode = data.customer.address.zip !== undefined ? data.customer.address.zip : ''
      postOfficeName = data.customer.address.city !== undefined ? data.customer.address.city : ''
    }

    if (data.deliverySite.address !== undefined) {
      deliverySiteStreetName = data.deliverySite.address.street !== undefined ? data.deliverySite.address.street : ''
      deliverySitePostalCode = data.deliverySite.address.zip !== undefined ? data.deliverySite.address.zip : ''
      deliverySitePostOfficeName = data.deliverySite.address.city !== undefined ? data.deliverySite.address.city : ''
    }

    if (data.customer.contactInfo !== undefined) {
      email = data.customer.contactInfo.email !== undefined ? data.customer.contactInfo.email : ''
    }

    let azureAPI = 'https://testapi.fortum.com/avaus/v1/Message'
    let azureKey = '3f7b92e86ed64d6193aec0f73704a545'
    let avausEnv = process.env.ENV || 'TEST'
    let messageSource = 'Forum'
    let messageSender = 'Fortum Asiakaspalvelu'
    let language = 'FI'

    let id = Math.floor((Math.random() * 1222222222200) + 1)

    if (avausEnv === 'PROD') {
      azureAPI = 'https://api.fortum.com/avaus/v1/Message'
      azureKey = '3693a9c99fd64dbcb65203dfa447d08d'
    }

    //    Template id: 215, name: Order created email
    //    Template id: 216, name: Order sent to installation email
    //    Template id: 217, name: Order cancelled email
    //    Template id: 218, name: Order done email
    //    Template id: 219: name: Order installation failed email

    if (data.status === 'OrderReceived' || data.status === undefined || data.status === null || data.status === '') { template = 215 }
    if (data.status === 'WaitingForInstallation') { template = 216 }
    if (data.status === 'Cancelled') { template = 217 }
    if (data.status === 'Completed') { template = 218 }

    if (template === 215 || template === 216 || template === 217 || template === 218) {
      request
        .post(azureAPI)
        .send(
          {
            'Message': {
              'MessagingMessageType': template,
              'MessageSource': messageSource,
              'Sender': messageSender,
              'DefaultLanguage': language
            },
            'AllowedChannels': [
              {
                'ChannelType': '1',
                'Priority': 1
              }
            ],
            'Recipients': [
              {
                'ContentPlaceHolderList': [
                  {
                    'PlaceHolderName': 'customerId',
                    'PlaceHolderValue': customerId
                  },
                  {
                    'PlaceHolderName': 'firstName',
                    'PlaceHolderValue': firstName
                  },
                  {
                    'PlaceHolderName': 'name',
                    'PlaceHolderValue': name
                  },

                  {
                    'PlaceHolderName': 'customerName',
                    'PlaceHolderValue': name
                  },
                  {
                    'PlaceHolderName': 'streetName',
                    'PlaceHolderValue': streetName
                  },
                  {
                    'PlaceHolderName': 'postalCode',
                    'PlaceHolderValue': postalCode
                  },
                  {
                    'PlaceHolderName': 'postOfficeName',
                    'PlaceHolderValue': postOfficeName
                  },
                  {
                    'PlaceHolderName': 'deliverySiteStreetName',
                    'PlaceHolderValue': deliverySiteStreetName
                  },
                  {
                    'PlaceHolderName': 'deliverySitepostalCode',
                    'PlaceHolderValue': deliverySitePostalCode
                  },
                  {
                    'PlaceHolderName': 'deliverySitePostOfficeName',
                    'PlaceHolderValue': deliverySitePostOfficeName
                  },
                  {
                    'PlaceHolderName': 'cancelationReason',
                    'PlaceHolderValue': reason
                  }
                ],
                'Email': email
              }
            ]
          }
        )
        .set('RequestId', id)
        .set('Ocp-Apim-Subscription-Key', azureKey)
        .set('RequestingSystem', 'VODA')
        .set('TargetSystem', 'NEOLANE')
        .set('Content-Type', 'application/json')
        .set('Accept', 'application/json')
        .end(function (err, res) {
          var refId = err !== null ? err : res.text
          MailLogger('VODA', country, email, template, res.statusCode, data._id, data.status, 'CUSTOMER', refId)
        })
    }
  }
}
exports.post = post
