var sendgridKey = process.env.SENDGRID_API_KEY || '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'
let MailLogger = require('./../../../../app/helpers/logger/log').mailLogger

function post (data, country, reason) {
  let btnText = ''
  let sub = ''
  let template = ''
  let fromEmail = 'Noreply.markets@fortum.com'

  if (data.status === 'WaitingForInstallation') {
    btnText = 'Avaa tiedot'
    sub = 'VODA: WOE-' + data.vodaOrderNumber + ' :Ready for Installation'
    template = '583e73ce-551d-4dd0-ac3f-63a3deb556a7'
  }

  if (data.status === 'Cancelled') {
    btnText = 'Avaa tiedot'
    sub = 'VODA: Tilaus WOE-' + data.vodaOrderNumber + ' peruttu'
    template = '3f706056-64a8-4c9d-893b-a03852492735'
  }

  var environment = process.env.ENV_ADMIN_URL || 'http://localhost:9000'
  var installerEmail = process.env.VODA_INSTALLER_FI_EMAIL || 'Suresh.SapaniDevarajan@partners.fortum.com'

  var sg = require('sendgrid')(sendgridKey)

  // https://retail-joda-dev-fi.herokuapp.com/voda/workorder/598464ebb09be7001111fc01

  var btn = "<a href='" + environment + '/voda/workorder/' + data._id + "' style='text-decoration:none; color: #ffffff;'>" + btnText + '</a>'
  let logText = 'VODA:Installer: WOE-' + data.vodaOrderNumber + ' WO Status: ' + data.status
  let woe = data.vodaOrderNumber !== undefined ? (data.vodaOrderNumber).toString() : '-'
  let name = ''
  let address = ''
  if (reason === undefined) {
    reason = ''
  }
  if (data.customer !== undefined && data.customer.name !== undefined) {
    name = data.customer.name
  }

  if (data.deliverySite !== undefined && data.deliverySite.address !== undefined && data.deliverySite.address.street !== undefined) {
    address = data.deliverySite.address.street
  }

  if (data.deliverySite !== undefined && data.deliverySite.address !== undefined && data.deliverySite.address.zip !== undefined) {
    address = address + ' ' + data.deliverySite.address.zip
  }

  if (data.deliverySite !== undefined && data.deliverySite.address !== undefined && data.deliverySite.address.city !== undefined) {
    address = address + ' ' + data.deliverySite.address.city
  }

  var request = sg.emptyRequest({
    method: 'POST',
    path: '/v3/mail/send',
    body: {
      personalizations: [
        {
          to: [
            {
              email: installerEmail
            }
          ],
          'substitutions': {
            '-btn-': btn,
            '-woe-': woe,
            '-name-': name,
            '-reason-': reason,
            '-address-': address
          },
          subject: sub
        }
      ],
      from: {
        email: fromEmail
      },
      template_id: template
    }
  })

  // With callback
  sg.API(request, function (error, response) {
    if (error) {
      MailLogger('VODA', country, installerEmail, template, error.response.statusCode, data.vodaOrderNumber, data.status, 'CS', error.headers)
      console.log(logText + ' HTTP Status Code: ' + error.response.statusCode)
    } else {
      MailLogger('VODA', country, installerEmail, template, response.statusCode, data.vodaOrderNumber, data.status, 'CS', response.headers)
      console.log(logText + ' HTTP Status Code: ' + response.statusCode)
    }
  })
}

exports.post = post
