var sendgridKey = process.env.SENDGRID_API_KEY || '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'
let MailLogger = require('./../../../../app/helpers/logger/log').mailLogger

function post (data, country, Attachments, sendMail) {
  let query = {}
  query.workorderId = data._id
  let reason = 'Refer the WO for further details'
  Attachments.find(query, '-__v', function (err, doc) {
    if (err || doc.length === 0) {
      if ((data.status !== 'OrderReceived') || (data.status === 'OrderReceived' && data.selfService !== undefined)) {
        sendMailcs(data, country, reason)
      }
    } else {
      if (data.status === 'Returned') {
        let returnReason = doc[doc.length - 1].vpp.returnReason
        let returnNote = doc[doc.length - 1].vpp.returnNote !== undefined ? doc[doc.length - 1].vpp.returnNote : ''
        reason = 'Return Reason: ' + returnReason + ' & additional Note: ' + returnNote
      } else if (data.status === 'Cancelled') {
        let reasonCancellation = doc[doc.length - 1].vpp.reasonCancellation
        let cancellationNote = doc[doc.length - 1].vpp.cancellationNote !== undefined ? doc[doc.length - 1].vpp.cancellationNote : ''
        reason = 'Cancelled Reason: ' + reasonCancellation + ' & additional Note: ' + cancellationNote
      }
      if ((data.status !== 'OrderReceived') || (data.status === 'OrderReceived' && data.selfService !== undefined)) {
        sendMailcs(data, country, reason)
      }
    }
  })

  function sendMailcs (data, country, reason) {
    let btnText = ''
    let sub = ''
    let template = ''
    let fromEmail = 'Noreply.markets@fortum.com'
    let environment = process.env.ENV_ADMIN_URL || 'http://localhost:9000'
    let csEmail = process.env.VODA_ESDCIS_FI_EMAIL || 'Suresh.SapaniDevarajan@partners.fortum.com'
    let customerName = data.customer.name
    let billingAddressStreet = data.customer.address.street !== undefined ? data.customer.address.street : ''
    let billingAddressPostalPlace = data.customer.address.postalPlace !== undefined ? data.customer.address.postalPlace : ''
    let billingAddressCity = data.customer.address.city !== undefined ? data.customer.address.city : ''
    let billingAddressZip = data.customer.address.zip !== undefined ? data.customer.address.zip : ''
    let deliverysiteAddressStreet = data.deliverySite.address.street !== undefined ? data.deliverySite.address.street : ''
    let deliverysiteAddressPostalPlace = data.deliverySite.address.postalPlace !== undefined ? data.deliverySite.address.postalPlace : ''
    let deliverysiteAddressCity = data.deliverySite.address.city !== undefined ? data.deliverySite.address.city : ''
    let deliverysiteAddressZip = data.deliverySite.address.zip !== undefined ? data.deliverySite.address.zip : ''

    let packageName = ''
    let measurementMethod = ''
    let contractStartDate = ''

    if (data.selfService !== undefined) {
      csEmail = process.env.VODA_DM_FI_EMAIL || 'Suresh.SapaniDevarajan@partners.fortum.com'
      packageName = data.selfService.package !== undefined ? data.selfService.package : ''
      measurementMethod = data.selfService.measurementMethod !== undefined ? data.selfService.measurementMethod : ''
      contractStartDate = data.selfService.newContractStartDate !== undefined ? data.selfService.newContractStartDate : ''
    }

    // 'OrderReceived', 'WaitingForInstallation', 'Completed', 'TimeScheduled', '', 'Cancelled'
    if (data.status === 'OrderReceived' && data.selfService !== undefined) {
      btnText = 'Avaa tiedot'
      sub = 'VODA: New Order Received'
      template = '2b8ae90f-5e9e-47b9-b508-0ed5599e51d1'
    } else if (data.status === 'Returned') {
      btnText = 'Avaa tiedot'
      sub = 'VODA: : WOE-' + data.vodaOrderNumber + ' : Returned by Installer'
      template = 'b3199307-e558-41a7-8664-18d7caf24f13'
    } else if (data.status === 'Cancelled') {
      btnText = 'Avaa tiedot'
      sub = 'VODA: WOE-' + data.vodaOrderNumber + ' : Cancelled'
      template = 'b3199307-e558-41a7-8664-18d7caf24f13'
    }

    var sg = require('sendgrid')(sendgridKey)

    // https://retail-joda-dev-fi.herokuapp.com/voda/workorder/598464ebb09be7001111fc01

    var btn = "<a href='" + environment + '/voda/workorder/' + data._id + "' style='text-decoration:none; color: #ffffff;'>" + btnText + '</a>'
    let logText = 'VODA:Customer Service: WOE-' + data.vodaOrderNumber + ' WO Status: ' + data.status

    var request = sg.emptyRequest({
      method: 'POST',
      path: '/v3/mail/send',
      body: {
        personalizations: [
          {
            to: [
              {
                email: csEmail
              }
            ],
            'substitutions': {
              '-btn-': btn,
              '-reason-': reason,
              '-customerName-': customerName,
              '-billingAddressStreet-': billingAddressStreet,
              '-billingAddressPostalPlace-': billingAddressPostalPlace,
              '-billingAddressCity-': billingAddressCity,
              '-billingAddressZip-': billingAddressZip,
              '-deliverysiteAddressStreet-': deliverysiteAddressStreet,
              '-deliverysiteAddressPostalPlace-': deliverysiteAddressPostalPlace,
              '-deliverysiteAddressCity-': deliverysiteAddressCity,
              '-deliverysiteAddressZip-': deliverysiteAddressZip,
              '-packageName-': packageName,
              '-measurementMethod-': measurementMethod,
              '-contractStartDate-': contractStartDate
            },
            subject: sub
          }
        ],
        from: {
          email: fromEmail
        },
        template_id: template
      }
    })

    // With callback
    sg.API(request, function (error, response) {
      if (error) {
        MailLogger('VODA', country, csEmail, template, error.response.statusCode, data.vodaOrderNumber, data.status, 'CS', error.headers)
        console.log(logText + 'HTTP Status Code: ' + error.response.statusCode)
      } else {
        MailLogger('VODA', country, csEmail, template, response.statusCode, data.vodaOrderNumber, data.status, 'CS', response.headers)
        console.log(logText + ' HTTP Status Code: ' + response.statusCode)
      }
    })
  }
}

exports.post = post
