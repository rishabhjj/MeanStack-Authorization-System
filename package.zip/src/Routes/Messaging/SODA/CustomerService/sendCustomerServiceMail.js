var sendgridkey = process.env.SENDGRID_API_KEY || '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'
let Moment = require('moment')
let MomentRange = require('moment-range')
let moment = MomentRange.extendMoment(Moment)
let MailLogger = require('./../../../../app/helpers/logger/log').mailLogger

function post (data, country) {
  let btnText = ''
  let sub = ''
  let template = ''
  let fromEmail = 'Noreply.markets@fortum.com'

  let visitTime = data.datetime
  let visitDate = data.datetime
  let visitDateTime = ''
  let timeToOffset = 3
  if (country === 'SE') {
    timeToOffset = 2
  }

  // TODO: Daylight saving needs to be checked 
  if (data.datetime !== '' && data.datetime !== undefined) {
    let hour = data.datetime.getHours() + timeToOffset
    let minutes = (data.datetime.getMinutes() < 10 ? '0' : '') + data.datetime.getMinutes()

    // Daylight saving - 2017-18  
    let start = new Date(2017, 9, 29)
    let end = new Date(2018, 2, 24)
    let when = moment(data.datetime)
    let range = moment.range(start, end)
    if (when.within(range)) {
      hour = hour - 1
    } // true

    // Daylight saving - 2018-19  
    start = new Date(2018, 9, 28)
    end = new Date(2019, 2, 31)
    range = moment.range(start, end)
    if (when.within(range)) {
      hour = hour - 1
    } // true

    // Daylight saving - 2019-20  
    start = new Date(2019, 9, 27)
    end = new Date(2020, 2, 29)
    range = moment.range(start, end)
    if (when.within(range)) {
      hour = hour - 1
    } // true

    visitTime = hour + ':' + minutes

    if (visitTime >= 12) {
      visitTime = visitTime - 12
      visitDate = (data.datetime.getDate() + 1) + '.' + (data.datetime.getMonth() + 1) + '.' + data.datetime.getFullYear()
    } else {
      visitDate = data.datetime.getDate() + '.' + (data.datetime.getMonth() + 1) + '.' + data.datetime.getFullYear()
    }
    visitDateTime = visitDate + '  ' + visitTime
  }

  if (data.status === 'OfferRequestReceived') { btnText = 'Avaa tiedot'; sub = 'Yhteydenottopyyntö vastaanotettu'; template = 'fdcf524b-8244-40f9-8840-a391cc9fc696' }
  if (data.status === 'PreliminaryOfferSent') { btnText = 'Avaa tiedot'; sub = data.woe + ': Alustava tarjous lähetetty'; template = '8cc23af1-703d-4462-b4f7-9c167499611b' }
  if (data.status === 'PreliminaryOfferApproved') { btnText = 'Avaa tiedot'; sub = data.woe + ': Alustava tarjous hyväksytty'; template = 'fcf2bd85-2d8d-4e52-81c5-effa8886488f' }
  if (data.status === 'AssessmentSiteVisitScheduled') { btnText = 'Avaa tiedot'; sub = data.woe + ': Asennuksen suunnittelun aika sovittu'; template = '6c64ffdd-a096-451b-aa7b-caf31765c461' }
  if (data.status === 'PreliminaryOfferApproved' && data.isScheduleCancellation === true) { btnText = 'Avaa tiedot'; sub = data.woe + ': Asennuksen suunnittelun aika peruttu'; template = '7079a706-13a3-4096-b356-caa8faa2b2df' }
  if (data.status === 'InstallationPlanCreated') { btnText = 'Avaa tiedot'; sub = data.woe + ': Asennussuunnitelma luotu'; template = '03d3ee31-fb5a-470d-9e52-9675936984dd' }
  if (data.status === 'InstallationPlanVerified') { btnText = 'Avaa tiedot'; sub = data.woe + ': Asennussuunnitelma vahvistettu'; template = 'd368654e-876a-4452-a0a7-b3342ca5accf' }
  if (data.status === 'FinalOfferSent') { btnText = 'Avaa tiedot'; sub = data.woe + ':  Päivitetty tarjous lähetetty'; template = '74c185a3-a7a4-4654-9e4e-94f16a53dfa3' }
  if (data.status === 'FinalOfferApproved') { btnText = 'Avaa tiedot'; sub = data.woe + ': Tarjous hyväksytty'; template = 'c858214c-0e91-4048-8cb8-baad8daf660b' }
  if (data.status === 'InstallationTimeScheduled') { btnText = 'Avaa tiedot'; sub = data.woe + ': Asennuksen ajankohta sovittu'; template = '37a00a7f-3ac9-41d8-84eb-d5c04a59cc91' }
  if (data.status === 'FinalOfferApproved' && data.isScheduleCancellation === true) { btnText = 'Avaa tiedot'; sub = data.woe + ': Asennuksen ajakohta peruttu'; template = '8aa4a49b-7e3b-423b-b183-106c6b4d75a3' }
  if (data.status === 'InstallationReportVerified') { btnText = 'Avaa tiedot'; sub = data.woe + ': Asennusraportti saatavilla'; template = '37e3be15-a9fc-4296-add7-cb13313df7b1' }
  if (data.status === 'InstallationApproved') { btnText = 'Avaa tiedot'; sub = data.woe + ': Asennus valmis'; template = 'f719081d-cb28-4323-977c-623397b97b97' }

  if (data.status === undefined || data.status === null || data.status === '') { btnText = 'Avaa tiedot'; sub = 'Yhteydenottopyyntö vastaanotettu'; template = 'fdcf524b-8244-40f9-8840-a391cc9fc696' }

  var environment = process.env.ENV_ADMIN_URL || 'http://localhost:9000'
  var csEmail = process.env.CS_EMAIL || 'Suresh.SapaniDevarajan@partners.fortum.com'

  if (country === 'SE') {
    if (data.status === 'OfferRequestReceived') { btnText = 'Se detaljer'; sub = sub = data.woe + ':  Intresseanmälan mottagen'; template = 'c1a38b0a-cbf5-45a2-ab35-1128bb4ec9df' }
    if (data.status === 'PreliminaryOfferSent') { btnText = 'Se detaljer'; sub = data.woe + ': Preliminärt erbjudande skickat'; template = '99c5812a-3429-48d3-8c82-17c4e2ed572a' }
    if (data.status === 'PreliminaryOfferApproved') { btnText = 'Se detaljer'; sub = data.woe + ': Preliminärt erbjudande godkänt'; template = '7d5e12b1-620e-41fa-9d70-c1d4a82770ac' }
    if (data.status === 'AssessmentSiteVisitScheduled') { btnText = 'Se detaljer'; sub = data.woe + ': Installationstid bokad'; template = 'ab5f2c42-a656-4066-8c27-df1f8ce3dcec' }
    if (data.status === 'PreliminaryOfferApproved' && data.isScheduleCancellation === true) { btnText = 'Se detaljer'; sub = data.woe + ': Hembesök avbokat'; template = '19865beb-007c-4054-a840-c6127e18379d' }
    if (data.status === 'InstallationPlanCreated') { btnText = 'Se detaljer'; sub = data.woe + ': Installationsplan klar'; template = '8e89c65a-a827-4fb6-81a7-72066aefb69e' }
    if (data.status === 'InstallationPlanVerified') { btnText = 'Se detaljer'; sub = data.woe + ': Installationsplan godkänd'; template = '37398de5-117d-4643-a495-dd5241d3eb83' }
    if (data.status === 'FinalOfferSent') { btnText = 'Se detaljer'; sub = data.woe + ': Uppdaterat erbjudande skickat'; template = 'e6260607-c59d-4ade-964c-dbdaa686cc7f' }
    if (data.status === 'FinalOfferApproved') { btnText = 'Se detaljer'; sub = data.woe + ': Beställning godkänd'; template = '05a20914-629e-4da2-9124-ad4e4235ad1f' }
    if (data.status === 'InstallationTimeScheduled') { btnText = 'Se detaljer'; sub = data.woe + ': Installationstid bekräftad'; template = 'c996249f-4cef-4e79-a095-8882dcab8121' }
    if (data.status === 'FinalOfferApproved' && data.isScheduleCancellation === true) { btnText = 'Se detaljer'; sub = data.woe + ': Installation avbokad'; template = '41bad6e8-cba8-4aaa-8c43-93a9b0ae0ded' }
    if (data.status === 'InstallationReportVerified') { btnText = 'Se detaljer'; sub = data.woe + ': Sammanställning av installation'; template = '757985d7-9812-4edc-8b90-a0bb7bcb2d14' }
    if (data.status === 'InstallationApproved') { btnText = 'Se detaljer'; sub = data.woe + ': Installation godkänd'; template = '6a5786d9-9892-44e5-b80f-5487e88bfea8' }

    if (data.status === undefined || data.status === null || data.status === '') { btnText = 'Se detaljer'; sub = 'Intresseanmälan mottagen'; template = 'c1a38b0a-cbf5-45a2-ab35-1128bb4ec9df' }

    environment = process.env.ENV_ADMIN_SE_URL || 'http://localhost:9000'
    csEmail = process.env.CS_SE_EMAIL || 'Suresh.SapaniDevarajan@partners.fortum.com'
    fromEmail = 'Noreply.markets@fortum.com'
    sendgridkey = process.env.SENDGRID_API_SE_KEY || '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'
  }

  var sg = require('sendgrid')(sendgridkey)

  var btn = "<a href='" + environment + '/soda/workorder/' + data.serviceKey + "' style='text-decoration:none; color: #ffffff;'>" + btnText + '</a>'

  let logText = 'SODA:Customer Service: WOE-' + data.woe + ' WO Status: ' + data.status

  var request = sg.emptyRequest({
    method: 'POST',
    path: '/v3/mail/send',
    body: {
      personalizations: [
        {
          to: [
            {
              email: csEmail
            }
          ],
          'substitutions': {
            '-woe-': data.woe,
            '-name-': data.name,
            '-datetime-': visitDateTime,
            '-btn-': btn,
            'logText': logText
          },
          subject: sub
        }
      ],
      from: {
        email: fromEmail
      },
      template_id: template
    }
  })

  // With callback
  sg.API(request, function (error, response) {
    if (error) {
      MailLogger('SODA', country, csEmail, template, error.response.statusCode, data.woe, data.status, 'CS', error.headers)
      console.log(logText + 'HTTP Status Code: ' + error.response.statusCode)
    } else {
      MailLogger('SODA', country, csEmail, template, response.statusCode, data.woe, data.status, 'CS', response.headers)
      console.log(logText + ' HTTP Status Code: ' + response.statusCode)
    }
  })
}

exports.post = post
