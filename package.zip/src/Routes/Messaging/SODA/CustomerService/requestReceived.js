var sendgridKey = process.env.SENDGRID_API_KEY || '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'

let MailLogger = require('./../../../../app/helpers/logger/log').mailLogger

function post (data, woe, country = 'FI') {
  let csEmail = process.env.CS_EMAIL || 'Suresh.SapaniDevarajan@partners.fortum.com'
  let environment = process.env.ENV_URL || 'http://localhost:9000'

  let templateId = '79d9ae66-edb7-4e54-874f-e7c3e091a95f'
  let sub = 'Yhteydenottopyyntö Fortum Aurinkopaketista: ' + data._id

  if (country === 'SE') {
    environment = process.env.ENV_ADMIN_SE_URL || 'http://localhost:9000'
    csEmail = process.env.CS_SE_EMAIL || 'Suresh.SapaniDevarajan@partners.fortum.com'
    sendgridKey = process.env.SENDGRID_API_SE_KEY || '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'
    templateId = 'adb7d3df-0c02-4b75-8156-550d4d3367af'
    sub = 'Intresseanmälan BC'
  }

  var sg = require('sendgrid')(sendgridKey)

  var ssnOrBusinessId = (data.ssnOrBusinessId === undefined) ? '-' : data.ssnOrBusinessId
  var roofArea = (data.benefitCalculations.roofArea === undefined) ? '' : data.benefitCalculations.roofArea.toString()
  var roofAreaSuitableForPanels = (data.benefitCalculations.roofAreaSuitableForPanels === undefined) ? '' : data.benefitCalculations.roofAreaSuitableForPanels.toString()
  var roofType = (data.benefitCalculations.roofType === undefined) ? '' : data.benefitCalculations.roofType
  var roofPitchAngle = (data.benefitCalculations.roofPitchAngle === undefined) ? '' : data.benefitCalculations.roofPitchAngle.toString()
  var roofRidgeAngleFromNorth = (data.benefitCalculations.roofRidgeAngleFromNorth === undefined) ? '' : data.benefitCalculations.roofRidgeAngleFromNorth.toString()
  var buildingType = (data.benefitCalculations.buildingType === undefined) ? '' : data.benefitCalculations.buildingType
  var recommendedProductPackageId = (data.benefitCalculations.recommendedProductPackageId === undefined) ? '' : data.benefitCalculations.recommendedProductPackageId
  var customerSelectedProductPackageId = (data.benefitCalculations.customerSelectedProductPackageId === undefined) ? '' : data.benefitCalculations.customerSelectedProductPackageId
  var heatingType = (data.benefitCalculations.heatingType === undefined) ? '' : data.benefitCalculations.heatingType
  var buildYear = (data.benefitCalculations.buildYear === undefined) ? '' : data.benefitCalculations.buildYear.toString()
  var floors = (data.benefitCalculations.floors === undefined) ? '' : data.benefitCalculations.floors.toString()
  var estimatedMonthlyConsumption = (data.benefitCalculations.estimatedMonthlyElectricityConsumption === undefined) ? '' : data.benefitCalculations.estimatedMonthlyElectricityConsumption.toString()
  var monthlySolarElectricityPotential = (data.benefitCalculations.monthlySolarElectricityPotential === undefined) ? '' : data.benefitCalculations.monthlySolarElectricityPotential.toString()
  var customerNote = (data.customerNote === undefined) ? '' : data.customerNote
  var url = "<a href='" + environment + '?key=' + data._id + "'>" + data._id + '</a>'

  if (country === 'SE') {
    url = data._id
  }

  var woeNumber = (woe === undefined) ? '' : woe.toString()

  var request = sg.emptyRequest({
    method: 'POST',
    path: '/v3/mail/send',
    body: {
      personalizations: [
        {
          to: [
            {
              email: csEmail
            }
          ],
          'substitutions': {
            '-id-': data._id,
            '-woe-': woeNumber,
            '-name-': data.contactInformation.name,
            '-ssnOrBusinessId-': ssnOrBusinessId,
            '-customerType-': data.contactInformation.customerType,
            '-phone-': data.contactInformation.phone,
            '-email-': data.contactInformation.email,
            '-deliverySiteStreet-': data.deliverySite.street,
            '-deliverySiteCity-': data.deliverySite.city,
            '-deliverySiteZip-': data.deliverySite.zip,
            '-roofArea-': roofArea,
            '-roofAreaSuitableForPanels-': roofAreaSuitableForPanels,
            '-roofType-': roofType,
            '-roofPitchAngle-': roofPitchAngle,
            '-roofRidgeAngleFromNorth-': roofRidgeAngleFromNorth,
            '-buildingType-': buildingType,
            '-recommendedProductPackageId-': recommendedProductPackageId,
            '-customerSelectedProductPackageId-': customerSelectedProductPackageId,
            '-heatingType-': heatingType,
            '-buildYear-': buildYear,
            '-floors-': floors,
            '-estimatedMonthlyConsumption-': estimatedMonthlyConsumption,
            '-monthlySolarElectricityPotential-': monthlySolarElectricityPotential,
            '-customerNote-': customerNote,
            '-url-': url
          },
          subject: sub
        }
      ],
      from: {
        email: 'Noreply.markets@fortum.com'
      },
      template_id: templateId
    }
  })

  // With promise
  sg.API(request)
    .then(response => {
      MailLogger('SODA', data.country, csEmail, '79d9ae66-edb7-4e54-874f-e7c3e091a95f', response.statusCode, woeNumber, data.status, 'CS', response.headers)
      console.log(response.statusCode)
    })
    .catch(error => {
      MailLogger('SODA', data.country, csEmail, '79d9ae66-edb7-4e54-874f-e7c3e091a95f', error.response.statusCode, woeNumber, data.status, 'CS', error.headers)
      console.log(error.response.statusCode)
    })
}

exports.post = post
