var sendgridKey = process.env.SENDGRID_API_KEY || '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'
let Moment = require('moment')
let MomentRange = require('moment-range')
let moment = MomentRange.extendMoment(Moment)
let MailLogger = require('./../../../../app/helpers/logger/log').mailLogger

function post (data, country) {
  let visitTime = data.datetime
  let visitDate = data.datetime
  let visitDateTime = ''
  let timeToOffset = 3
  if (country === 'SE') {
    timeToOffset = 2
  }

  // TODO: Daylight saving needs to be checked 
  if (data.datetime !== '' && data.datetime !== undefined) {
    let hour = data.datetime.getHours() + timeToOffset
    let minutes = (data.datetime.getMinutes() < 10 ? '0' : '') + data.datetime.getMinutes()

    // Daylight saving - 2017-18  
    let start = new Date(2017, 9, 29)
    let end = new Date(2018, 2, 24)
    let when = moment(data.datetime)
    let range = moment.range(start, end)
    if (when.within(range)) {
      hour = hour - 1
    } // true

    // Daylight saving - 2018-19  
    start = new Date(2018, 9, 28)
    end = new Date(2019, 2, 31)
    range = moment.range(start, end)
    if (when.within(range)) {
      hour = hour - 1
    } // true

    // Daylight saving - 2019-20  
    start = new Date(2019, 9, 27)
    end = new Date(2020, 2, 29)
    range = moment.range(start, end)
    if (when.within(range)) {
      hour = hour - 1
    } // true

    visitTime = hour + ':' + minutes

    if (visitTime >= 12) {
      visitTime = visitTime - 12
      visitDate = (data.datetime.getDate() + 1) + '.' + (data.datetime.getMonth() + 1) + '.' + data.datetime.getFullYear()
    } else {
      visitDate = data.datetime.getDate() + '.' + (data.datetime.getMonth() + 1) + '.' + data.datetime.getFullYear()
    }
    visitDateTime = visitDate + ' ' + visitTime
  }

  if (data.status !== 'OfferRequestReceived' && data.status !== 'PreliminaryOfferSent' && data.status !== 'FinalOfferSent' && data.status !== 'InstallationReportVerified' && data.status !== 'Cancelled') {
    let btnText = ''
    let sub = ''
    let template = ''
    let fromEmail = 'Noreply.markets@fortum.com'

    if (data.status === 'PreliminaryOfferApproved') { btnText = 'Avaa tiedot'; sub = data.woe + ': Uusi asennuksen suunnitelutilaus'; template = 'be95a64b-3b67-4edf-904b-3835a7aa42d8' }
    if (data.status === 'AssessmentSiteVisitScheduled') { btnText = 'Avaa tiedot'; sub = data.woe + ': Asennuksen suunnittelun aika sovittu'; template = '5a525e56-293d-49c5-ad36-841973a8b2a1' }
    if (data.status === 'PreliminaryOfferApproved' && data.isScheduleCancellation === true) { btnText = 'Avaa tiedot'; sub = data.woe + ': Asennuksen suunnittelun aika peruttu'; template = '9b33788c-ac93-438f-8154-e299053f9463' }
    if (data.status === 'InstallationPlanCreated') { btnText = 'Avaa tiedot'; sub = data.woe + ': Asennussuunnitelma luotu'; template = '1d2b20e6-2399-425b-b7a9-6b2c7dea449b' }
    if (data.status === 'InstallationPlanVerified') { btnText = 'Avaa tiedot'; sub = data.woe + ': Asennussuunnitelma vahvistettu'; template = '7ad4f45e-d0c1-4c82-910a-8dcab99201c7' }
    if (data.status === 'FinalOfferApproved') { btnText = 'Avaa tiedot'; sub = data.woe + ': Uusi Asennustilaus'; template = '4c4e97b1-0ff6-4139-88ba-7d6ff18a4a6f' }
    if (data.status === 'InstallationTimeScheduled') { btnText = 'Avaa tiedot'; sub = data.woe + ': Asennuksen ajankohta sovittu'; template = '4db1669a-7d17-4ee4-b436-ec62cdb798bc' }
    if (data.status === 'FinalOfferApproved' && data.isScheduleCancellation === true) { btnText = 'Avaa tiedot'; sub = data.woe + ': Asennuksen ajakohta peruttu'; template = '5fa81764-7746-416b-9adf-fd044edc246a' }
    if (data.status === 'InstallationReportVerified') { btnText = 'Avaa tiedot'; sub = data.woe + ': Asennusraportti saatavilla'; template = '29c47cfc-b56d-4187-b83c-9e4c1c723714' }
    if (data.status === 'InstallationApproved') { btnText = 'Avaa tiedot'; sub = data.woe + ': Asennus valmis'; template = '78836263-0a18-46b9-8b85-a93fe8769570' }

    var environment = process.env.ENV_ADMIN_URL || 'http://localhost:9000'
    var installerEmail = process.env.INSTALLER_EMAIL || 'Suresh.SapaniDevarajan@partners.fortum.com'

    if (country === 'SE') {
      if (data.status === 'PreliminaryOfferApproved') { btnText = 'Se detaljer'; sub = data.woe + ': Preliminärt erbjudande godkänt'; template = '2a4927f1-aa57-44e9-9bc7-01f34f757e70' }
      if (data.status === 'AssessmentSiteVisitScheduled') { btnText = 'Se detaljer'; sub = data.woe + ': Installationstid bokad'; template = '51270030-2ecf-43cb-b9f0-e9f31233269e' }
      if (data.status === 'PreliminaryOfferApproved' && data.isScheduleCancellation === true) { btnText = 'Se detaljer'; sub = data.woe + ': Hembesök avbokat'; template = 'e2b7d5ca-3aa0-4527-9780-d324296c9356' }
      if (data.status === 'InstallationPlanCreated') { btnText = 'Se detaljer'; sub = data.woe + ': Installationspaln klar'; template = '845f52f3-0a3a-4daf-a6f2-47983f1b0c46' }
      if (data.status === 'InstallationPlanVerified') { btnText = 'Se detaljer'; sub = data.woe + ':  Installationsplan godkänd'; template = '5fedf75d-2e3f-4a6a-b359-07f18853ef1c' }
      if (data.status === 'FinalOfferApproved') { btnText = 'Se detaljer'; sub = data.woe + ': Beställning godkänd'; template = 'a57dfa62-0bec-44f9-aab8-270febff78a9' }
      if (data.status === 'InstallationTimeScheduled') { btnText = 'Se detaljer'; sub = data.woe + ': Installationstid bekräftad'; template = 'ec70f679-630a-41d4-a81a-a55271204169' }
      if (data.status === 'FinalOfferApproved' && data.isScheduleCancellation === true) { btnText = 'Se detaljer'; sub = data.woe + ': Installation avbokad'; template = 'f07c52d6-f7de-433d-b8ac-099671c36ddc' }
      if (data.status === 'InstallationReportVerified') { btnText = 'Se detaljer'; sub = data.woe + ': Sammanställning av installation'; template = 'e830e3ce-7744-4f53-8fce-a8d1b58acde4' }
      if (data.status === 'InstallationApproved') { btnText = 'Se detaljer'; sub = data.woe + ': Installation godkänd'; template = '25414cf0-5aeb-4be9-9d66-28df3adf22c1' }

      environment = process.env.ENV_ADMIN_SE_URL || 'http://localhost:9000'
      installerEmail = process.env.INSTALLER_SE_EMAIL || 'Suresh.SapaniDevarajan@partners.fortum.com'
      fromEmail = 'Noreply.markets@fortum.com'
      sendgridKey = process.env.SENDGRID_API_SE_KEY || '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'
    }

    var sg = require('sendgrid')(sendgridKey)

    let logText = 'SODA:Installer: WOE-' + data.woe + ' WO Status: ' + data.status

    var btn = "<a href='" + environment + '/soda/workorder/' + data.serviceKey + "' style='text-decoration:none; color: #ffffff;'>" + btnText + '</a>'

    var request = sg.emptyRequest({
      method: 'POST',
      path: '/v3/mail/send',
      body: {
        personalizations: [
          {
            to: [
              {
                email: installerEmail
              }
            ],
            'substitutions': {
              '-woe-': data.woe,
              '-datetime-': visitDateTime,
              '-name-': data.name,
              '-btn-': btn,
              'logText': logText
            },
            subject: sub
          }
        ],
        from: {
          email: fromEmail
        },
        template_id: template
      }
    })

    // With callback
    sg.API(request, function (error, response) {
      if (error) {
        MailLogger('SODA', country, installerEmail, template, error.response.statusCode, data.woe, data.status, 'INSTALLER', error.headers)
        console.log(logText + 'HTTP Status Code: ' + error.response.statusCode)
      } else {
        MailLogger('SODA', country, installerEmail, template, response.statusCode, data.woe, data.status, 'INSTALLER', response.headers)
        console.log(logText + ' HTTP Status Code: ' + response.statusCode)
      }
    })
  }
}

exports.post = post
