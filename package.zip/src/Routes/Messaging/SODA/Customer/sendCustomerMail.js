var request = require('superagent')
let Moment = require('moment')
let MomentRange = require('moment-range')
let moment = MomentRange.extendMoment(Moment)
let MailLogger = require('./../../../../app/helpers/logger/log').mailLogger

function post (mailData, country) {
  let visitTime = mailData.datetime
  let visitDate = mailData.datetime
  let visitDateTime = ''
  let timeToOffset = 3
  if (country === 'SE') {
    timeToOffset = 2
  }

  if (mailData.datetime !== '' && mailData.datetime !== undefined) {
    let hour = mailData.datetime.getHours() + timeToOffset
    let minutes = (mailData.datetime.getMinutes() < 10 ? '0' : '') + mailData.datetime.getMinutes()

    // Daylight saving - 2017-18  
    let start = new Date(2017, 9, 29)
    let end = new Date(2018, 2, 24)
    let when = moment(mailData.datetime)
    let range = moment.range(start, end)
    if (when.within(range)) {
      hour = hour - 1
    } // true

    // Daylight saving - 2018-19  
    start = new Date(2018, 9, 28)
    end = new Date(2019, 2, 31)
    range = moment.range(start, end)
    if (when.within(range)) {
      hour = hour - 1
    } // true

    // Daylight saving - 2019-20  
    start = new Date(2019, 9, 27)
    end = new Date(2020, 2, 29)
    range = moment.range(start, end)
    if (when.within(range)) {
      hour = hour - 1
    } // true

    visitTime = hour + ':' + minutes

    if (visitTime >= 12) {
      visitTime = visitTime - 12
      visitDate = (mailData.datetime.getDate() + 1) + '.' + (mailData.datetime.getMonth() + 1) + '.' + mailData.datetime.getFullYear()
    } else {
      visitDate = mailData.datetime.getDate() + '.' + (mailData.datetime.getMonth() + 1) + '.' + mailData.datetime.getFullYear()
    }
    visitDateTime = visitDate + ' ' + visitTime
  }

  let sub = ''
  let template = ''
  let name = mailData.name
  let pi = mailData.pi
  let ew = mailData.ew
  let em = mailData.em
  let rot = mailData.rot
  let total = mailData.total

  let environment = process.env.ENV_URL || 'http://localhost:9000'
  let url = environment + '?key=' + mailData.serviceKey
  let azureAPI = 'https://testapi.fortum.com/avaus/v1/Message'
  let azureKey = '3f7b92e86ed64d6193aec0f73704a545'
  let avausEnv = process.env.ENV || 'TEST'
  let messageSource = 'Forum'
  let messageSender = 'Fortum Asiakaspalvelu'
  let language = 'FI'

  let id = Math.floor((Math.random() * 1222222222200) + 1)

  if (avausEnv === 'PROD') {
    azureAPI = 'https://api.fortum.com/avaus/v1/Message'
    azureKey = '3693a9c99fd64dbcb65203dfa447d08d'
  }

  if (mailData.status === 'OfferRequestReceived') { sub = 'Fortum Aurinkopaketti: Yhteydenottopyyntö lähetetty'; template = 200 }
  if (mailData.status === 'PreliminaryOfferSent') { sub = 'Fortum Aurinkopaketti: Tarjous vastaanotettu'; template = 201 }
  if (mailData.status === 'PreliminaryOfferApproved') { sub = 'Fortum Aurinkopaketti: Tilausvahvistus'; template = 202 }
  if (mailData.status === 'AssessmentSiteVisitScheduled') { sub = 'Fortum Aurinkopaketti: Asennuksen suunnittelukäynnin aika sovittu'; template = 203 }
  if (mailData.status === 'PreliminaryOfferApproved' && mailData.isScheduleCancellation === true) { sub = 'Fortum Aurinkopaketti: Asennuksen suunnittelukäynnin aika peruttu'; template = 214 }
  if (mailData.status === 'InstallationPlanVerified') { sub = 'Fortum Aurinkopaketti: Asennuksen suunnittelukäynti suoritettu'; template = 205 }
  if (mailData.status === 'FinalOfferSent') { sub = 'Fortum Aurinkopaketti: Tarjous vastaanotettu'; template = 206 }
  if (mailData.status === 'FinalOfferApproved') { sub = 'Fortum Aurinkopaketti: Tilausvahvistus'; template = 207 }
  if (mailData.status === 'InstallationTimeScheduled') { sub = 'Fortum Aurinkopaketti: Asennusaika sovittu'; template = 208 }
  if (mailData.status === 'FinalOfferApproved' && mailData.isScheduleCancellation === true) { sub = 'Fortum Aurinkopaketti: Asennusaika peruttu'; template = 212 }
  if (mailData.status === 'InstallationReportVerified') { sub = 'Fortum Aurinkopaketti: Asennusraportti valmis'; template = 210 }
  if (mailData.status === 'InstallationApproved') { sub = 'Fortum Aurinkopaketti: Asennus valmis'; template = 211 }

  if (mailData.status === undefined || mailData.status === null || mailData.status === '') { sub = 'Fortum Aurinkopaketti: Yhteydenottopyyntö lähetetty'; template = 200 }

  if (country === 'SE') {
    if (mailData.status === 'OfferRequestReceived') { sub = 'Fortum Solcellspaket: Intresseanmälan mottagen'; template = 200 }
    if (mailData.status === 'PreliminaryOfferSent') { sub = 'Fortum Solcellspaket: Preliminärt erbjudande skickat'; template = 201 }
    if (mailData.status === 'PreliminaryOfferApproved') { sub = 'Fortum Solcellspaket: Preliminärt erbjudande godkänt'; template = 202 }
    if (mailData.status === 'AssessmentSiteVisitScheduled') { sub = 'Fortum Solcellspaket: Installationbekräftelse'; template = 203 }
    if (mailData.status === 'PreliminaryOfferApproved' && mailData.isScheduleCancellation === true) { sub = 'Fortum Solcellspaket: hembesök avbokat'; template = 214 }
    if (mailData.status === 'InstallationPlanVerified') { sub = 'Fortum Solcellspaket: Installationsplan klar'; template = 205 }
    if (mailData.status === 'FinalOfferSent') { sub = 'Fortum Solcellspaket: Uppdaterat erbjudande skickat'; template = 206 }
    if (mailData.status === 'FinalOfferApproved') { sub = 'Fortum Solcellspaket: Beställning godkänd'; template = 207 }
    if (mailData.status === 'InstallationTimeScheduled') { sub = 'Fortum Solcellspaket: Installationstid bekräftad'; template = 208 }
    if (mailData.status === 'FinalOfferApproved' && mailData.isScheduleCancellation === true) { sub = 'Fortum Solcellspaket: Installation avbokat'; template = 212 }
    if (mailData.status === 'InstallationReportVerified') { sub = 'Fortum Solcellspaket: Sammanställning av installation'; template = 210 }
    if (mailData.status === 'InstallationApproved') { sub = 'Fortum Solcellspaket: Installation godkänd'; template = 211 }

    if (mailData.status === undefined || mailData.status === null || mailData.status === '') { sub = 'Fortum Solcellspaket: Intresseanmälan mottagen'; template = 200 }

    environment = process.env.ENV_SE_URL || 'http://localhost:9000'
    url = environment + '?key=' + mailData.serviceKey
    messageSender = 'Fortum Kundtjänst'
    language = 'SV_SE'
  }

  request
    .post(azureAPI)
    .send(
      {
        'Message': {
          'MessagingMessageType': template,
          'MessageSource': messageSource,
          'Sender': messageSender,
          'DefaultLanguage': language
        },
        'AllowedChannels': [
          {
            'ChannelType': '1',
            'Priority': 1
          }
        ],
        'Recipients': [
          {
            'ContentPlaceHolderList': [
              {
                'PlaceHolderName': 'subject',
                'PlaceHolderValue': sub
              },
              {
                'PlaceHolderName': 'name',
                'PlaceHolderValue': name
              },
              {
                'PlaceHolderName': 'url',
                'PlaceHolderValue': url
              },
              {
                'PlaceHolderName': 'visitDateTime',
                'PlaceHolderValue': visitDateTime
              },
              {
                'PlaceHolderName': 'visitTime',
                'PlaceHolderValue': visitTime
              },
              {
                'PlaceHolderName': 'visitDate',
                'PlaceHolderValue': visitDate
              },
              {
                'PlaceHolderName': 'pi',
                'PlaceHolderValue': pi
              },
              {
                'PlaceHolderName': 'ew',
                'PlaceHolderValue': ew
              },
              {
                'PlaceHolderName': 'em',
                'PlaceHolderValue': em
              },
              {
                'PlaceHolderName': 'rot',
                'PlaceHolderValue': rot
              },
              {
                'PlaceHolderName': 'total',
                'PlaceHolderValue': total
              },
              {
                'PlaceHolderName': 'piTitle',
                'PlaceHolderValue': 'Solcellspaket & Installation'
              },
              {
                'PlaceHolderName': 'ewTitle',
                'PlaceHolderValue': 'Extra arbete'
              },
              {
                'PlaceHolderName': 'emTitle',
                'PlaceHolderValue': 'Extra Material'
              },
              {
                'PlaceHolderName': 'rotTitle',
                'PlaceHolderValue': 'ROT'
              },
              {
                'PlaceHolderName': 'totalTitle',
                'PlaceHolderValue': 'Total'
              }
            ],
            'Email': mailData.email
          }
        ]
      }
    )
    .set('RequestId', id)
    .set('Ocp-Apim-Subscription-Key', azureKey)
    .set('RequestingSystem', 'SODA')
    .set('TargetSystem', 'NEOLANE')
    .set('Content-Type', 'application/json')
    .set('Accept', 'application/json')
    .end(function (err, res) {
      var refId = err !== null ? err : res.text
      MailLogger('SODA', country, mailData.email, template, res.statusCode, url, mailData.status, 'CUSTOMER', refId)
    })
}
exports.post = post
