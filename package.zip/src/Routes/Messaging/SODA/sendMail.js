// let requestReceived = require('./CustomerService/requestReceived')
let installerMailer = require('./Installer/sendInstallerMail')
let customerMailer = require('./Customer/sendCustomerMail')
let customerServiceMailer = require('./CustomerService/sendCustomerServiceMail')

function send (doc, country, targetStatus, existingStatus, isScheduleCancellation, ROT) {
  let customer = process.env.SODA_SEND_MAIL_TO_CUSTOMER || 'TRUE'
  let installer = process.env.SODA_SEND_MAIL_TO_INSTALLER_COMPANY || 'TRUE'
  let cs = process.env.SODA_SEND_MAIL_TO_CUSTOMER_SERVICE_TEAM || 'TRUE'

  if (targetStatus !== 'NONE' && (targetStatus !== existingStatus)) {
    // Send mail if the PATCH changes the WO Status & (Don't send mail if the existing and target status is same)
    let datetime = ''
    if (doc.assessmentHomeVisit !== undefined && targetStatus === 'AssessmentSiteVisitScheduled') { datetime = doc.assessmentHomeVisit }
    if (doc.installationHomeVisit !== undefined && targetStatus === 'InstallationTimeScheduled') { datetime = doc.installationHomeVisit }

    let pi = 0
    let ew = 0
    let em = 0
    let rot = 0
    if (doc.basePrice !== undefined) { pi = doc.basePrice.package };
    let total = pi + ew + em - rot

    let passDateTime = datetime

    let data = {
      'name': doc.contactInformation.name,
      'woe': 'WOE' + doc.workOrderNumber,
      'status': targetStatus,
      'serviceKey': doc._id,
      'datetime': passDateTime,
      'isScheduleCancellation': isScheduleCancellation
    }

    if (customer.toUpperCase() === 'TRUE') {
      if (country === 'SE' && (targetStatus === 'PreliminaryOfferSent' || targetStatus === 'PreliminaryOfferApproved' ||
                targetStatus === 'FinalOfferSent' || targetStatus === 'FinalOfferApproved')) {
        // extraDesignatedWorkAndMaterial
        if (doc.extraDesignatedWorkAndMaterial.length > 0) {
          for (let i = 0; i < doc.extraDesignatedWorkAndMaterial.length; i++) {
            if (doc.extraDesignatedWorkAndMaterial[i].type !== undefined && doc.extraDesignatedWorkAndMaterial[i].type === 'Work') {
              ew = ew + doc.extraDesignatedWorkAndMaterial[i].amount
            } else {
              em = em + doc.extraDesignatedWorkAndMaterial[i].amount
            }
          }
        }

        // extraDesignatedWorkAndMaterial
        if (doc.extraNonDesignatedWorkAndMaterial.length > 0) {
          for (let i = 0; i < doc.extraNonDesignatedWorkAndMaterial.length; i++) {
            if (doc.extraNonDesignatedWorkAndMaterial[i].type !== undefined && doc.extraNonDesignatedWorkAndMaterial[i].type === 'Work') {
              ew = ew + doc.extraNonDesignatedWorkAndMaterial[i].amount
            } else {
              em = em + doc.extraNonDesignatedWorkAndMaterial[i].amount
            }
          }
        }

        total = pi + ew + em - rot
        let mailData = {
          'name': doc.contactInformation.name,
          'email': doc.contactInformation.email,
          'serviceKey': doc._id,
          'status': doc.status,
          'datetime': passDateTime,
          'isScheduleCancellation': isScheduleCancellation,
          'pi': pi,
          'ew': ew,
          'em': em,
          'rot': rot,
          'total': total
        }

        withROT(mailData, country, doc._id, customerMailer, ROT)
      } else {
        let mailData = {
          'name': doc.contactInformation.name,
          'email': doc.contactInformation.email,
          'serviceKey': doc._id,
          'status': doc.status,
          'datetime': passDateTime,
          'isScheduleCancellation': isScheduleCancellation,
          'pi': pi,
          'ew': ew,
          'em': em,
          'rot': rot,
          'total': total
        }
        customerMailer.post(mailData, country)
      }
    }
    if (installer.toUpperCase() === 'TRUE') {
      installerMailer.post(data, country)
    }

    if (cs.toUpperCase() === 'TRUE') {
      customerServiceMailer.post(data, country)
    }
  }
}

function withROT (mailData, country, workOrderServiceKey, customerMailer, ROT) {
  let query = {}
  query.workOrderServiceKey = workOrderServiceKey

  ROT.find(query, '-__v', function (err, data) {
    let rot = 0
    if (err) {
      console.log('Error occured... while trying to retrive ROT before sending mail - workOrderServiceKey: ' + workOrderServiceKey)
    } else {
      if (data != null && data.length > 0) {
        if ((data[0].allocation !== undefined) && (data[0].allocation.length > 0)) {
          for (let i = 0; i < data[0].allocation.length; i++) {
            rot = rot + data[0].allocation[i].amount
          }
        }
      }
    }
    mailData.rot = rot
    customerMailer.post(mailData, country)
  })
}

module.exports = {
  send: send
}
