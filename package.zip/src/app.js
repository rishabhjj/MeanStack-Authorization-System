import express from 'express'
import mongoose from 'mongoose'
import bodyParser from 'body-parser'
import helmet from 'helmet'

// Shared or Common
import audit from './app/models//shared/auditModel'
import attachments from './app/models//shared/attachmentsModel'
import contact from './app/models//shared/contactModel'
import deliverySite from './app/models//external/deliverySiteModel'
import paymentType from './app/models//shared/paymentTypesModel'
import item from './app/models//shared/itemServiceMasterModel'

// Home Charging
import hodaContact from './app/models//hoda/hodaContactModel'
import hodaEVType from './app/models//hoda/hodaEVTypeModel'
import hodaCampaign from './app/models//hoda/hodaCampaignModel'
import hodaWorkorder from './app/models//hoda/hodaWorkOrderModel'
// Solar
import sodaWorkorder from './app/models//soda/workOrderModel'
import sodaProduct from './app/models//soda/productModel'
import sodaProductFeature from './app/models//soda/productFeatureModel'
import sodaWorkMaterial from './app/models//soda/workMaterialModel'
import sodaAgeing from './app/models//soda/sodaAgeingModel'
import sodaAddressLead from './app/models//soda/sodaAddressLeadModel'
import sodaROT from './app/models//soda/sodaROTModel'

// Virtual Power Plant (VPP)
import vodaWorkOrder from './app/models//voda/vodaWorkOrderModel'
import vodaMaterial from './app/models//voda/vodaMaterialModel'
import vodaAgeing from './app/models//voda/vodaAgeingModel'
import vodaPostalCode from './app/models//voda/vodaPostalCodeModel'
import vodaCampaignPrice from './app/models//voda/vodaCampaignPriceModel'

let app = express()
app.use(helmet())
let port = process.env.PORT || 3000
let dbURL = process.env.MONGODB_URI || 'mongodb://heroku_7bg5gkf0:tetu942nofsj6bq4q54rl6g185@ds161518.mlab.com:61518/heroku_7bg5gkf0'
// let dbURL = process.env.MONGODB_URI || "mongodb://heroku_1f8qrqxn:4g182uckjp70g8f6kvo0h9rcu@ds145779-a0.mlab.com:45779,ds145779-a1.mlab.com:45779/heroku_1f8qrqxn?replicaSet=rs-ds145779";

mongoose.Promise = global.Promise
mongoose.connect(dbURL, { useMongoClient: true })

app.use(function (req, res, next) {
  req.env = process.env.ENV || 'TEST'
  req.header('Content-Type', 'application/json')
  req.header('Accept', 'application/json')
  res.header('Access-Control-Allow-Origin', '*')
  res.header('Access-Control-Allow-Methods', 'PATCH,GET,PUT,DELETE,OPTIONS,POST')
  res.header('Access-Control-Allow-Headers', 'App, Country, Token, Authorization, Origin,X-Application, X-Country, X-Request-Id, X-Requested-With, Content-Type, Accept, Ocp-Apim-Subscription-Key,Content-Disposition')
  next()
})

app.use('/api/docs', express.static('build/app/docs'))

app.use(bodyParser.urlencoded({ extended: true, limit: '16mb' }))
app.use(bodyParser.json({ limit: '16mb' }))

// SODA
let sodaworkOrderRouter = require('./app/controllers/soda/sodaWorkOrder')(sodaWorkorder, audit, sodaAgeing, sodaROT, sodaAddressLead)
app.use('/api/WorkOrder', sodaworkOrderRouter)
app.use('/api/SODA/WorkOrder', sodaworkOrderRouter)

let sodaProductRouter = require('./app/controllers/soda/sodaProduct')(sodaProduct, audit)
app.use('/api/Product', sodaProductRouter)

let sodaProductFeatureRouter = require('./app/controllers/soda/sodaProductFeature')(sodaProductFeature, audit)
app.use('/api/Feature', sodaProductFeatureRouter)

let sodaWorkMaterialRouter = require('./app/controllers/soda/sodaWorkMaterial')(sodaWorkMaterial, audit)
app.use('/api/WorkMaterial', sodaWorkMaterialRouter)

let sodaAddressLeadRouter = require('./app/controllers/soda/sodaAddressLead')(sodaAddressLead)
app.use('/api/SODA/AddressLead', sodaAddressLeadRouter)

// VODA
let vodaCampaignPriceRouter = require('./app/controllers/voda/vodaCampaignPrice')(vodaCampaignPrice, audit)
app.use('/api/VODA/CampaignPrice', vodaCampaignPriceRouter)

let vodaPostalCodeRouter = require('./app/controllers/voda/vodaPostalCode')(vodaPostalCode)
app.use('/api/VODA/PostalCode', vodaPostalCodeRouter)

let vodaMaterialRouter = require('./app/controllers/voda/vodaMaterial')(vodaMaterial, audit)
app.use('/api/VODA/Material', vodaMaterialRouter)

let vodaWorkOrderRouter = require('./route/voda/workorder/voda-workorder')(vodaWorkOrder, vodaAgeing, attachments, audit)
app.use('/api/VODA/WorkOrder', vodaWorkOrderRouter)

let vodaDeviceRouter = require('./Routes/VODA/Device/Tingcore/vDevice')(audit)
app.use('/api/VODA/Device', vodaDeviceRouter)

let vodaSettingsTypeRouter = require('./Routes/VODA/Device/Tingcore/vSettingsType')(audit)
app.use('/api/VODA/Device/SettingsType', vodaSettingsTypeRouter)

let vodaDeviceSettingsRouter = require('./Routes/VODA/Device/Tingcore/vDeviceSettings')(audit)
app.use('/api/VODA/Device/Settings', vodaDeviceSettingsRouter)

let vodaDeviceConnectionRouter = require('./Routes/VODA/Device/Tingcore/vDeviceConnection')()
app.use('/api/VODA/Device/Connect', vodaDeviceConnectionRouter)

let vodaDeviceSignalStrengthRouter = require('./Routes/VODA/Device/Tingcore/vDeviceSignalStrength')()
app.use('/api/VODA/Device/Signal', vodaDeviceSignalStrengthRouter)

let vodaDeviceFailSafeRouter = require('./Routes/VODA/Device/Tingcore/vDeviceFailSafe')()
app.use('/api/VODA/Device/FailSafe', vodaDeviceFailSafeRouter)

let vodaDeviceRelayRouter = require('./Routes/VODA/Device/Tingcore/vDeviceRelay')()
app.use('/api/VODA/Device/Relay', vodaDeviceRelayRouter)

let jobsVodaWORouter = require('./route/voda/jobs/voda-jobs-workorder')(vodaWorkOrder, vodaAgeing, attachments)
app.use('/api/voda/jobs/workorders', jobsVodaWORouter)

// COMMON
let customerRouter = require('./app/controllers/shared/customer')(vodaWorkOrder, hodaWorkorder, audit)
app.use('/api/Customers', customerRouter)

let itemsRouter = require('./app/controllers/shared/itemServiceMaster')(item)
app.use('/api/Items', itemsRouter)

let campaignItemsRouter = require('./app/controllers/shared/campaignItems')(item, hodaCampaign)
app.use('/api/CampaignItems', campaignItemsRouter)

let paymentTypeRouter = require('./app/controllers/shared/paymentType')(paymentType)
app.use('/api/PaymentTypes', paymentTypeRouter)

let logsRouter = require('./Routes/Shared/Audit/audit')(audit)
app.use('/api/Logs', logsRouter)

let contactRouter = require('./Routes/Shared/Contact/contact')(contact)
app.use('/api/Contact', contactRouter)

let attachmentsRouter = require('./Routes/Shared/Attachment/attachments')(attachments, audit)
app.use('/api/Attachments', attachmentsRouter)

let deliverySiteRouter = require('./app/controllers/shared/deliverysite')(sodaWorkorder, sodaProduct, deliverySite)
app.use('/api/external/deliverySites', deliverySiteRouter)

// HODA
let hodaEVTypeRouter = require('./app/controllers/hoda/hodaEVType')(hodaEVType, audit)
app.use('/api/HODA/EVTypes', hodaEVTypeRouter)

let hodaContactRouter = require('./app/controllers/hoda/hodaContact')(hodaContact)
app.use('/api/HODA/Contacts', hodaContactRouter)

let hodaCampaignRouter = require('./app/controllers/hoda/hodaCampaign')(hodaCampaign, audit)
app.use('/api/HODA/Campaigns', hodaCampaignRouter)

let hodaWorkorderRouter = require('./app/controllers/hoda/hodaWorkorder')(hodaWorkorder, audit)
app.use('/api/HODA/Workorders', hodaWorkorderRouter)

let hodaWorkorderJobRouter = require('./app/controllers/hoda/hodaWorkorderJob')(hodaWorkorder, audit)
app.use('/api/HODA/Jobs/Workorders', hodaWorkorderJobRouter)

let hodaDeviceRouter = require('./app/controllers/hoda/hodaDevice')(hodaWorkorder, audit)
app.use('/api/HODA/Chargers', hodaDeviceRouter)

app.get('/', (req, res) => {
  res.send('Welcome to Work Order Management (WOM) API!!!')
})

app.listen(port, () => {
  console.log('Running on port:' + port)
})
