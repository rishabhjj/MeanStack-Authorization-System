package com.cts.coloplast.dao;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.model.AmazonDynamoDBException;

public class DBConnector {
	
	
	public AmazonDynamoDB createDBClient() {
		
		AmazonDynamoDB client = null;
		try {
			 client = AmazonDynamoDBClientBuilder.standard()
		            .withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("http://localhost:8001", "local"))
		            .build();
			

		} catch (AmazonDynamoDBException ade) {
			System.out.println("Failed to create DynamoDB client: " + ade.getErrorMessage());
			System.err.println("Failed to create DynamoDB client: " + ade.getErrorMessage());
		}
		catch (AmazonServiceException ase) {
			System.out.println("Failed to create DynamoDB client: " + ase.getErrorMessage());
			System.err.println("Failed to create DynamoDB client: " + ase.getErrorMessage());
		}
		
		return client;

	}

}
