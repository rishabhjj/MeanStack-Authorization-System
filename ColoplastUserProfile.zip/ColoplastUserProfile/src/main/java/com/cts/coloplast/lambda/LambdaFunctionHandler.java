package com.cts.coloplast.lambda;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestStreamHandler;
import com.cts.coloplast.apigateway.RequestParser;
import com.cts.coloplast.apigateway.ResponseBuilder;
import com.cts.coloplast.model.User;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class LambdaFunctionHandler implements RequestStreamHandler {

    @Override
    public void handleRequest(InputStream input, OutputStream output, Context context) throws IOException {

        // TODO: Implement your stream handler. See https://docs.aws.amazon.com/lambda/latest/dg/java-handler-io-type-stream.html for more information.
        // This demo implementation capitalizes the characters from the input stream.
        
    	RequestParser request = new RequestParser();
    	UserProfileFunctions usf = new UserProfileFunctions();
    	ResponseBuilder response = new ResponseBuilder();
    	User user = request.parseJson(input);

    	// Add orchestration logic based on request json call a method - create or update user.
    	if (user != null)     usf.createUser(user);
    	
    	ObjectNode responseJson = response.buildResponse("User " + user.getEmailId() + " has been created succesfully");
    	
    	OutputStreamWriter writer = new OutputStreamWriter(output, "UTF-8");
        writer.write(responseJson.asText());  
        writer.close();
//        System.out.println(responseJson);
        
    }

}
