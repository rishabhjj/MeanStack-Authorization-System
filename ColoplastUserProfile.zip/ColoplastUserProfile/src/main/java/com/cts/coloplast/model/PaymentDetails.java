package com.cts.coloplast.model;

import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;

@DynamoDBDocument
public class PaymentDetails {

	private List<CreditCard> creditCard;
	private List<BankAccount> bankAccount;
	
	public List<CreditCard> getCreditCard() {
		return creditCard;
	}
	public void setCreditCard(List<CreditCard> creditCard) {
		this.creditCard = creditCard;
	}
	public List<BankAccount> getBankAccount() {
		return bankAccount;
	}
	public void setBankAccount(List<BankAccount> bankAccount) {
		this.bankAccount = bankAccount;
	}
	
}
