package com.cts.coloplast.apigateway;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cts.coloplast.model.Address;
import com.cts.coloplast.model.BankAccount;
import com.cts.coloplast.model.CreditCard;
import com.cts.coloplast.model.PaymentDetails;
import com.cts.coloplast.model.PaymentInfo;
import com.cts.coloplast.model.User;
import com.cts.coloplast.model.UserDetails;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class RequestParser {

	public User parseJson(InputStream input) throws JsonProcessingException, IOException {

		// instantiate the user class and its properties

		User user = null;
		ObjectMapper mapper = new ObjectMapper();
		//File file = new File(input);
		user = mapper.readValue(input, User.class);
	

		return user;
	}
}
