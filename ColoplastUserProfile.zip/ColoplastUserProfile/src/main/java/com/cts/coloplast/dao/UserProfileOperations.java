package com.cts.coloplast.dao;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.model.AmazonDynamoDBException;
import com.cts.coloplast.model.User;

public class UserProfileOperations implements UserProfileDao {

	@Override
	public String updateUserDao(User user, AmazonDynamoDB client) {
		// TODO Auto-generated method stub
		return "User update feature is yet to be developed";
	}

	@Override
	public String createUserDao(User user, AmazonDynamoDB client) {
		// TODO Auto-generated method stub

		try {
			DynamoDBMapper mapper = new DynamoDBMapper(client);

			String email = user.getEmailId();

			User user1 = mapper.load(User.class, email); //LOAD should be replaced with searchExpression by email for faster response

			if (user1 != null)
				return "User: " + user.getEmailId() + "already exists";
			else
				mapper.save(user);
		} catch (AmazonDynamoDBException dde) {
			System.out.println("DynamoDb User Insert failed");
			System.err.println("DynamoDb User Insert failed" + dde.getErrorMessage());
		} catch (AmazonServiceException ase) {
			System.out.println("DynamoDb User Insert failed");
			System.err.println("DynamoDb User Insert failed" + ase.getErrorMessage());
		} catch (NullPointerException npe) {
			System.out.println("Null Pointer Exception");
			System.err.println(npe.getMessage());
		}

		return "User " + user.getEmailId() + " has been created succesfully";

	}
}
