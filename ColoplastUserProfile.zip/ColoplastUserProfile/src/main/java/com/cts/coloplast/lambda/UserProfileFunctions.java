package com.cts.coloplast.lambda;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.cts.coloplast.dao.DBConnector;
import com.cts.coloplast.dao.UserProfileOperations;
import com.cts.coloplast.model.User;

public class UserProfileFunctions {

	public String createUser(User user) {
		
		DBConnector dbc = new DBConnector();
		
		AmazonDynamoDB client = dbc.createDBClient();
		
		UserProfileOperations upo = new UserProfileOperations();
		
		String output = upo.createUserDao(user, client);
		
		return output;
	}
}
