package com.cts.coloplast.dao;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.cts.coloplast.model.User;

public interface UserProfileDao {

	public String createUserDao(User user, AmazonDynamoDB client);
	public String updateUserDao(User user, AmazonDynamoDB client);
	
}
