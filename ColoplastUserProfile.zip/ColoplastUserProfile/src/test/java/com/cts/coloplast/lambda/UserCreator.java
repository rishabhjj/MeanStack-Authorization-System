package com.cts.coloplast.lambda;

import java.io.File;
import java.io.IOException;
import java.util.List;

import com.cts.coloplast.model.*;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UserCreator {

	public User createUserObject(File file) throws IOException {
		// TODO Auto-generated method stub
		
		User user = null;
		ObjectMapper mapper = new ObjectMapper();
		//File file = new File("D:\\eclipse\\workspace\\testCreateUserDaoNewUser.json");
		user = mapper.readValue(file, User.class);

//		System.out.println("Email : " + user.getEmailId());
//		System.out.println("City : " + user.getUserDetails().getAddress().get(0).getCity());
//		System.out.println("Credit Card Number: " + user.getUserDetails().getPaymentInfo().get(1).getCardNumber());
//		
		return user;
	}

}
