package com.cts.coloplast.lambda;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.cts.coloplast.model.*;
import com.fasterxml.jackson.databind.JsonNode;

public class UserObjectCreator {

	public User createUserObject(File file) throws JsonProcessingException, IOException {

		// instantiate the user class and its properties

		List<Address> addressList = new ArrayList<>();
		List<PaymentInfo> paymentInfoList = new ArrayList<>();
		UserDetails userDetails = new UserDetails();
		User user = new User();

		// InputStream input = new FileInputStream(file);
		// ObjectMapper mapper = new ObjectMapper();

		JsonParser parser = new JsonFactory().createParser(file);

		JsonNode rootNode = new ObjectMapper().readTree(parser);
		Iterator<JsonNode> iter = rootNode.iterator();
		Iterator<JsonNode> addressIter, paymentInfoIter, paymentDetailsIter;
		JsonNode currentNode, addressNode, userDetailsNode, paymentInfoNode;
		while (iter.hasNext()) {
			currentNode = (JsonNode) iter.next();

			// set the "non-nested" json properties
			userDetails.setFirstName((currentNode.path("userDetails")).path("firstName").asText());
			userDetails.setLastName((currentNode.path("userDetails")).path("lastName").asText());
			userDetails.setUserType((currentNode.path("userDetails")).path("userType").asText());

			// instantiate the address node and address-iterator
			addressNode = currentNode.path("userDetails").path("address");
			addressIter = addressNode.iterator();

			// iterate though all addresses, set properties, add to list of addresses
			while (addressIter.hasNext()) {
				Address address = new Address();

				addressNode = (JsonNode) addressIter.next();
				address.setStreet(addressNode.path("street").asText());
				address.setCity(((addressNode.path("city")).asText()));
				address.setState(((addressNode.path("state")).asText()));
				address.setZip(((addressNode.path("zip")).asText()));
				addressList.add(address);

//				System.out.println(addressList.toString());
			}

			// instantiate the paymentInfo node and paymentInfo-iterator
			paymentInfoNode = currentNode.path("userDetails").path("paymentInfo");
			paymentInfoIter = paymentInfoNode.iterator();
			while (paymentInfoIter.hasNext()) {

				paymentInfoNode = (JsonNode) paymentInfoIter.next();
				PaymentInfo paymentInfo = new PaymentInfo();
				// PaymentDetails paymentDetails = new PaymentDetails();
				// CreditCard creditCard = new CreditCard();
				// BankAccount bankAccount = new BankAccount();
				// // set "non-nested" values - paymenttype
				paymentInfo.setPaymentType(paymentInfoNode.path("paymentType").asText());

				if (paymentInfoNode.path("paymentType").asText().equals("CreditCard")) {
					paymentInfo.setCardNumber(paymentInfoNode.path("cardNumber").asLong());
					paymentInfo.setNameOnCard(paymentInfoNode.path("nameOnCard").asText());
					paymentInfo.setExpiry(paymentInfoNode.path("expiry").asText());
//					System.out.println("Credit Card: " + paymentInfo.getCardNumber());
					paymentInfoList.add(paymentInfo);
				}

				else if (paymentInfoNode.path("paymentType").asText().equals("BankAccount")) {
					paymentInfo.setAccountNumber(paymentInfoNode.path("accountNumber").asText());
					paymentInfo.setAccountCode(paymentInfoNode.path("accountCode").asText());
//					System.out.println("Bank Account:" + paymentInfo.getAccountNumber());
					paymentInfoList.add(paymentInfo);
				} else
					System.out.println("Payment Type unrecognized: " + paymentInfoNode.path("paymentType").asText());

			}

			userDetails.setAddress(addressList);
			userDetails.setPaymentInfo(paymentInfoList);
			user.setEmailId(currentNode.path("emailId").asText());
			user.setUserDetails(userDetails);
		}
//		System.out.println(user.getEmailId() + user.getUserDetails().getAddress());

		return user;
	}
}
