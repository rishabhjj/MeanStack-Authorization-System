package com.cts.coloplast.lambda;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.s3.model.transform.Unmarshallers.AccessControlListUnmarshaller;
import com.cts.coloplast.apigateway.RequestParser;
import com.cts.coloplast.apigateway.ResponseBuilder;
import com.cts.coloplast.dao.UserProfileDao;
import com.cts.coloplast.dao.UserProfileOperations;
import com.cts.coloplast.model.Address;
import com.cts.coloplast.model.User;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * A simple test harness for locally invoking your Lambda function handler.
 */
public class LambdaFunctionHandlerTest {

	private static final String SAMPLE_INPUT_STRING = "{\"foo\": \"bar\"}";
	private static final String EXPECTED_OUTPUT_STRING = "{\"User john1@email.com has been created Sucessfully\"}";

	//

	/**
	 * @throws IOException
	 */
	

	
	
	
	@Test
	public void testCreateUserDaoNewUser() throws IOException {
		// CLEANUP REQUIRED : remove all Sysouts added for debugging
		// logic to be added to check if the user already exists before - delete user
		// before calling the FUT.
		// seperate input files and include in resources package
		UserProfileOperations daotest = new UserProfileOperations();
		User user = new User();
		File file = new File("D:\\eclipse\\workspace\\testCreateUserDaoNewUser.json");

		InputStream input = new FileInputStream(file);

		AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
				.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("http://localhost:8001", "local"))
				.build();

		UserObjectCreator userCreator = new UserObjectCreator();

		user = userCreator.createUserObject(file);
		DynamoDBMapper mapper = new DynamoDBMapper(client);
		User user1 = mapper.load(User.class, user.getEmailId());

		if (user1 != null)
			mapper.delete(user1);
		String actualOutput = daotest.createUserDao(user, client);

		user1 = mapper.load(User.class, user.getEmailId());

		// need to modify assert logic to compare the user vs user1.

		boolean sizeAddress = user.getUserDetails().getAddress().size() == user1.getUserDetails().getAddress().size();
		boolean sizePaymentInfo = user.getUserDetails().getPaymentInfo().size() == user1.getUserDetails()
				.getPaymentInfo().size();
		boolean compareEmail = user.getEmailId().equals(user1.getEmailId());
		boolean result = sizeAddress && sizePaymentInfo && compareEmail;

		Assert.assertEquals(true, result);
	}

	@Test
	public void testCreateUserDaoExistingUser() throws IOException {

		UserProfileOperations daotest = new UserProfileOperations();
		User user = new User();
		File file = new File("D:\\eclipse\\workspace\\testCreateUserDaoExistingUser.json");

		AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
				.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("http://localhost:8001", "local"))
				.build();

		UserObjectCreator userCreator = new UserObjectCreator();

		user = userCreator.createUserObject(file);
		// User Object creator method
		String actualOutput = daotest.createUserDao(user, client);

		DynamoDBMapper mapper = new DynamoDBMapper(client);
		User user1 = mapper.load(User.class, user.getEmailId());
		Assert.assertEquals("User: " + user1.getEmailId() + "already exists", actualOutput);

	}

	@Test
	public void testRequestParser() throws IOException {

		RequestParser parser = new RequestParser();
		User expectedUser = new User();

		// setup prequisites - create the input stream object and output User Object
		File file = new File("D:\\eclipse\\workspace\\testCreateUserDaoNewUser.json");
		InputStream input = new FileInputStream(file);
		UserObjectCreator userCreator = new UserObjectCreator();
		expectedUser = userCreator.createUserObject(file);

		User outputUser = parser.parseJson(input);

		boolean sizeAddress = expectedUser.getUserDetails().getAddress().size() == outputUser.getUserDetails()
				.getAddress().size();
		boolean sizePaymentInfo = expectedUser.getUserDetails().getPaymentInfo().size() == outputUser.getUserDetails()
				.getPaymentInfo().size();
		boolean compareEmail = expectedUser.getEmailId().equals(outputUser.getEmailId());
		boolean result = sizeAddress && sizePaymentInfo && compareEmail;
		Assert.assertEquals(true, result);

	}

	@Test
	public void testLambdaFunctionHandlerNewUser() throws IOException {

		LambdaFunctionHandler handler = new LambdaFunctionHandler();

		File file = new File("D:\\eclipse\\workspace\\testLambdaFunctionHandler.json");

		InputStream input = new FileInputStream(file);
		OutputStream output = new ByteArrayOutputStream();

		UserObjectCreator userCreator = new UserObjectCreator();

		User inputUser = userCreator.createUserObject(file);

		AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
				.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("http://localhost:8001", "local"))
				.build();

		DynamoDBMapper mapper = new DynamoDBMapper(client);
		User tempUser = mapper.load(User.class, inputUser.getEmailId());

		if (tempUser != null)
			mapper.delete(tempUser);

		handler.handleRequest(input, output, null);
		User outputUser = mapper.load(User.class, inputUser.getEmailId());

		boolean sizeAddress = inputUser.getUserDetails().getAddress().size() == outputUser.getUserDetails()
				.getAddress().size();
		boolean sizePaymentInfo = inputUser.getUserDetails().getPaymentInfo().size() == outputUser.getUserDetails()
				.getPaymentInfo().size();
		boolean compareEmail = inputUser.getEmailId().equals(outputUser.getEmailId());
		boolean result = sizeAddress && sizePaymentInfo && compareEmail;
		//Assert.assertEquals(true, result);
		Assert.assertTrue(sizeAddress && sizePaymentInfo && compareEmail);
	}

	@Test
	public void testUserProfileFunctionCreateUser() throws IOException {
		File file = new File("D:\\eclipse\\workspace\\testCreateUserDaoExistingUser.json");

		UserObjectCreator userCreator = new UserObjectCreator();
		User user = userCreator.createUserObject(file);

		AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
				.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("http://localhost:8001", "local"))
				.build();

		DynamoDBMapper mapper = new DynamoDBMapper(client);
		User user1 = mapper.load(User.class, user.getEmailId());

		if (user1 != null)
			mapper.delete(user1);

		UserProfileFunctions usf = new UserProfileFunctions();
		String actualOutput = usf.createUser(user);
		String expectedOutput = String.format("User %s has been created succesfully", user.getEmailId());
		Assert.assertEquals(expectedOutput, actualOutput);
	

	}

}
