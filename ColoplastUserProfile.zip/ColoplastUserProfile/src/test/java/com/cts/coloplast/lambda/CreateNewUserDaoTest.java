package com.cts.coloplast.lambda;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Collection;

import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.omg.Messaging.SyncScopeHelper;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.cts.coloplast.dao.UserProfileOperations;
import com.cts.coloplast.model.User;
import com.fasterxml.jackson.core.JsonProcessingException;

@RunWith(Parameterized.class)
public class CreateNewUserDaoTest {

	
	private File file = null; 
//			new File("D:\\eclipse\\workspace\\testCreateUserDaoNewUser.json");
	private String expectedResult;



	public CreateNewUserDaoTest(File file, String expectedResult) {
		this.file = file;
		this.expectedResult = expectedResult;
	}
	
	@Parameterized.Parameters
	public static Collection users() {
		return Arrays.asList(new Object[][] {
			{new File("D:\\eclipse\\workspace\\testCreateUserDaoNewUser.json"), "User Created Sucessfully"},
			{new File("D:\\eclipse\\workspace\\testCreateUserDaoNewUser1.json"), "User1 Created Sucessfully"}
//			{new File("./testCreateUserDaoNewUser.json"), "User Created Sucessfully"},
//			{new File("./testCreateUserDaoNewUser1.json"), "User1 Created Sucessfully"}
		});
	}
	
	@Test
	public void testCreateNewUserDao() throws JsonProcessingException, IOException {
		
		UserProfileOperations daotest = new UserProfileOperations();
		User user = new User();
		//InputStream input = new FileInputStream(file);

		AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
				.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("http://localhost:8001", "local"))
				.build();

		UserCreator userCreator = new UserCreator();

		user = userCreator.createUserObject(file);
		DynamoDBMapper mapper = new DynamoDBMapper(client);
		

		User user1 = mapper.load(User.class, user.getEmailId());
		if (user1 != null)
			mapper.delete(user1);

		String actualOutput = daotest.createUserDao(user, client);

		

		
		// need to modify assert logic to compare the user vs user1.

		boolean sizeAddress = user.getUserDetails().getAddress().size() == user1.getUserDetails().getAddress().size();
		boolean sizePaymentInfo = user.getUserDetails().getPaymentInfo().size() == user1.getUserDetails()
				.getPaymentInfo().size();
		boolean compareEmail = user.getEmailId().equals(user1.getEmailId());
		boolean result = sizeAddress && sizePaymentInfo && compareEmail;

		Assert.assertEquals(true, result);
		System.out.println("testCreateNewUserDao	Passed	" +  file);
	}
	
	
	@Test
	public void testLambdaFunctionHandlerNewUser() throws IOException {

		LambdaFunctionHandler handler = new LambdaFunctionHandler();

		//File file = new File("D:\\eclipse\\workspace\\testLambdaFunctionHandler.json");

		InputStream input = new FileInputStream(file);
		OutputStream output = new ByteArrayOutputStream();

		UserCreator userCreator = new UserCreator();

		User inputUser = userCreator.createUserObject(file);

		AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
				.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("http://localhost:8001", "local"))
				.build();

		DynamoDBMapper mapper = new DynamoDBMapper(client);
		User tempUser = mapper.load(User.class, inputUser.getEmailId());

		if (tempUser != null)
			mapper.delete(tempUser);

		
		handler.handleRequest(input, output, null);
		User outputUser = mapper.load(User.class, inputUser.getEmailId());

		boolean sizeAddress = inputUser.getUserDetails().getAddress().size() == outputUser.getUserDetails()
				.getAddress().size();
		boolean sizePaymentInfo = inputUser.getUserDetails().getPaymentInfo().size() == outputUser.getUserDetails()
				.getPaymentInfo().size();
		boolean compareEmail = inputUser.getEmailId().equals(outputUser.getEmailId());
		boolean result = sizeAddress && sizePaymentInfo && compareEmail;
		//Assert.assertEquals(true, result);
		Assert.assertTrue(sizeAddress && sizePaymentInfo && compareEmail);
		
		System.out.println("testLambdaFunctionHandlerNewUser	Passed	" +  file);

	}
	
}
