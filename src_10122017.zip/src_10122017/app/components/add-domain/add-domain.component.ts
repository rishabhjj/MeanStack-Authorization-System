import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {Router} from '@angular/router';
import {GetPostService} from '../../services/get-post.service';


@Component({
  selector: 'app-add-domain',
  templateUrl: './add-domain.component.html',
  styleUrls: ['./add-domain.component.css']
})
export class AddDomainComponent implements OnInit {
  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
name : any;
state:boolean=false;
constructor(private _getpost: GetPostService, private router:Router) { 
  _getpost.showMenuEvent.subscribe(
    (showMenu) => {
      this.state = !this.state;
    }
 );

}

  ngOnInit() {
    this.state = false;
  }
  
  onRegisterSubmit1(){
    console.log("Form Submitted");
    const type="domain";
    
    const  name= this.name
    
      console.log(name);
    
    this._getpost.addDomain("domain",name).subscribe(
      
      );
      setTimeout(() => 
      {
          this.router.navigate(['/']);
      },
      2000);
      //this.flashMessage.show('You are now registerd and can login now', {cssClass: 'alert-success', timeout:3000});
   //this.router.navigate(['/']);
  }
}
