import { Component, OnInit,Input } from '@angular/core';
import * as _ from "lodash";
import {Router} from '@angular/router';
import {GetPostService} from '../../services/get-post.service';
import { ActivatedRoute } from '@angular/router';
import { BreadcrumbComponent } from '../breadcrumb/breadcrumb.component';
import { Subscription } from 'rxjs/Subscription';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {
   myArray = ['#209e91', '#2dacd1', '#90b900','#dfb81c','#e85656'];
  data =[];
  dd =[];
  raj:any;
test :any ="rishabh";
  address = [];
  //toggle1:boolean=false;
  subscription: Subscription;
   color =[];
   state:boolean=false;
  constructor(private _getpost: GetPostService) { 
    _getpost.showMenuEvent.subscribe(
      (showMenu) => {
        this.state;
        console.log(showMenu + "123" + this.state);
      }
      
   );
 
  }
  
    ngOnInit() {
      this.state=false;
      localStorage.clear();
      console.log(window.location.href);
      localStorage.setItem("url",window.location.href);
  console.log("test");
 this._getpost.getDomain("domain").subscribe(data => {
  console.log(data);
  this.dd = data;
  this.address = _.chunk(this.dd,3);
  console.log(this.address);
  console.log(data);
  for(var i = 0;i<this.dd.length;i++)
    { 
      if(i<=4)
    this.color.push(this.myArray[i]);
      else{
        i=0;
        this.dd.length = this.dd.length - 5;
        this.color.push(this.myArray[i]);
      }

  
    }
    console.log(this.color);
 },
  error => {
    console.log(error);
  })

 console.log(this.color);
}    

 getRandomColor() {
  var letters = '0123456789ABCDEF';

  var myArray = ['#209e91', '#2dacd1', '#90b900','#dfb81c','#e85656'];

  var color = '#';
    color += myArray[Math.floor(Math.random() * myArray.length)];
  
  return color;
}

}

