import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddBtComponent } from './add-bt.component';

describe('AddBtComponent', () => {
  let component: AddBtComponent;
  let fixture: ComponentFixture<AddBtComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddBtComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddBtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
