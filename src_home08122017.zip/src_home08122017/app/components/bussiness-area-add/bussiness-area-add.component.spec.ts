import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BussinessAreaAddComponent } from './bussiness-area-add.component';

describe('BussinessAreaAddComponent', () => {
  let component: BussinessAreaAddComponent;
  let fixture: ComponentFixture<BussinessAreaAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BussinessAreaAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BussinessAreaAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
