import { Component } from '@angular/core';
import {trigger, state,style,transition,animate,keyframes} from '@angular/animations';
import {AfterViewInit, OnInit} from "@angular/core";
import {ViewChild} from "@angular/core";

import * as _ from "lodash";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit, OnInit {
  rectW:number = 100;
  rectH:number = 100;
  rectColor:string = "pink";
  context:CanvasRenderingContext2D;
  test :any;
  state :boolean;

  ngAfterViewInit() {

   
  }
  toggle(){
    this.state = !this.state;
    
    }
  
  ngOnInit(){
    this.state=false;
  }

}
