import { Component } from '@angular/core';
import {trigger, state,style,transition,animate,keyframes} from '@angular/animations';
import {AfterViewInit, OnInit} from "@angular/core";
import {ViewChild} from "@angular/core";
import {GetPostService} from './services/get-post.service';
import { ModalComponent } from './components/modal/modal.component';
import * as _ from "lodash";
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {
  rectW:number = 100;
  rectH:number = 100;
  rectColor:string = "pink";
  context:CanvasRenderingContext2D;
  test :any;
  state :any = true;
  constructor(private _getpost: GetPostService) {}
  ngAfterViewInit() {

   
  }
  toggle():void {
    this.state = !this.state;
    this. _getpost.showMenuEvent.emit(this.state);
   // this.state = !this.state;
  }
  currentCompany:any = 'Define';
  
    high( item: any) {
  
      this.currentCompany = item;
      console.log(this.currentCompany );
    console.log(item);
    }
  

}
