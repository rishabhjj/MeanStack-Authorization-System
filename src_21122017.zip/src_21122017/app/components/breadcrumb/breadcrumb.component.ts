import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.css'],
  inputs: ['parentValue']
})
export class BreadcrumbComponent implements OnInit {
  @Input() public name: String;
  @Input() public baName: String;
  @Input() public bsname: String;
value :any;
bread: any;
values = [];
name1:any;
names = [];
type = [];
len:any;
comp= [];
id = [];
quer=[];
len2:any;
nfrname= [];


  constructor() { }

  ngOnInit() {  
      console.log(this.name + "Business Domain");
      console.log(this.baName + "Business area nmae");
      console.log(this.bsname  + "Business area nmae")
      // this.names.push(this.name);
      // this.names.push(this.baName);
      // this.names.push(this.bsname);
      // console.log(this.names);
      //this.names.push("");
         this.type = ['Domain' , 'Business Area ' , 'Business Scenario', 'Business Transaction'];
         var     keys = Object.keys(localStorage),
              j = keys.length;
              this.bread = "";
              // this.bread = "One Pace";
              // this.bread = " NFR Blue Print " + ">>" + localStorage.getItem('url');;
            //  this.values.push("NFR Define");
              this.values.push(localStorage.getItem('url'));
              this.comp.push(localStorage.getItem('url'));
          for(var i = 0;i<j;i++) {
            if(keys[i]=='ba-home'){
              this.value = localStorage.getItem(keys[i]);
             // this.bread = this.bread  + this.value;
              // this.bread = this.bread + " >>" + this.value  ;
              // console.log(keys[i] + ":  " + this.value);
              // console.log(this.bread);
              var a2 = this.value.split('/');
              console.log(a2);
              var a3 = a2[5].split('?');
              var a4 = a3[1].split('=');
              console.log(a3);
              this.comp.push(a2[3]);
              this.id.push(a3[0]);
             // var res = str.replace("Microsoft", "W3Schools");
              var an = a4[1].replace("%20", " ");
              this.nfrname.push(an);
              this.quer.push(a4[1]);

              this.values.push(this.value);
            }
            if(keys[i]=='bs-home'){
              this.value = localStorage.getItem(keys[i]);
              //this.bread = this.bread  + this.value;
              //this.bread = this.bread + " >>" + this.value;
              // console.log(keys[i] + ":  " + this.value);
              // console.log(this.bread);
              var a2 = this.value.split('/');
              var a3 = a2[5].split('?');
              var a4 = a3[1].split('=');
              console.log(a3);
              this.comp.push(a2[3]);
              this.id.push(a3[0]);
              var an = a4[1].replace("%20", " ");
              this.nfrname.push(an);
              this.quer.push(a4[1]);
              this.values.push(this.value);
            }
              //values.push( localStorage.getItem(keys[i]) );
              if(keys[i]=='bt-home'){
                this.value = localStorage.getItem(keys[i]);
               // this.bread = this.bread  + this.value;
                //this.bread = this.bread + " >>" + this.value;
                // console.log(keys[i] + ":  " + this.value);
                // console.log(this.bread);
                var a2 = this.value.split('=');
                console.log(a2);
                this.comp.push("bt-oi");
                var an = a2[1].replace("%20", " ");
                this.nfrname.push(an);
                this.quer.push(a2[1]);
                this.values.push(this.value);
              }

              
              if(keys[i]=='1'){
                this.name1 = localStorage.getItem(keys[i]);
                this.names.push(this.name1);
              }
              if(keys[i]=='2'){
                this.name1 = localStorage.getItem(keys[i]);
                this.names.push(this.name1);
              }
              if(keys[i]=='3'){
                this.name1 = localStorage.getItem(keys[i]);
                this.names.push(this.name1);
              }
              
             
              // if(keys[i]=='url'){
              // this.value = localStorage.getItem(keys[i]);
              // this.bread = this.bread + " >>" + this.value;
              // console.log(keys[i] + ":  " + this.value);
              // console.log(this.bread);
              // }
              //console.log(this.values + "testings");
              

          }
      // console.log(this.values + "testings");
          // this.bread = "One Pace";
          // this.bread = this.bread  + " >> domain";
          // console.log(i);
          this.len = this.values.length;
          console.log(this.len);
          console.log(this.names);
          console.log(this.values);
          this.len2 =  this.comp.length;
          console.log(this.comp);
          console.log("upper");
        }
          



}
